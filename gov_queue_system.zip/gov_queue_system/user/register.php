<?php
session_name('user_session');
session_start();
include("../config/db.php");

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: ../admin/dashboard.php");
    } else {
        header("Location: dashboard.php");
    }
    exit();
}

$error = "";
$success = "";

if (isset($_POST['register'])) {
    $full_name = trim($_POST['full_name']);
    $email     = trim($_POST['email']);
    $password  = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($full_name) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        $check_stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows > 0) {
            $error = "This email is already registered. Please login instead.";
        } else {
            $role = str_ends_with($email, "@gov.com") ? "admin" : "user";
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert_stmt = $conn->prepare("INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, ?)");
            $insert_stmt->bind_param("ssss", $full_name, $email, $hashed_password, $role);

            if ($insert_stmt->execute()) {
                $success = "Account registered successfully! You can now login.";
                $full_name = "";
                $email = "";
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Queue Management System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .strength-weak { width: 33%; background-color: #ef4444; }
        .strength-medium { width: 66%; background-color: #f59e0b; }
        .strength-strong { width: 100%; background-color: #10b981; }
    </style>
</head>
<body class="bg-gradient-to-br from-indigo-600 to-purple-700 min-h-screen flex items-center justify-center p-4">

    <div class="fixed top-5 right-5 z-50 flex flex-col gap-3">
        <?php if(!empty($error)): ?>
            <div id="error-toast" class="bg-white border-l-4 border-red-500 shadow-2xl rounded-lg p-4 flex items-center justify-between min-w-[300px] animate-bounce">
                <div class="flex items-center">
                    <span class="text-red-500 mr-3 text-xl font-bold">✕</span>
                    <p class="text-gray-800 text-sm font-medium"><?php echo htmlspecialchars($error); ?></p>
                </div>
                <button onclick="this.parentElement.remove()" class="text-gray-400 hover:text-gray-600 ml-4">✕</button>
            </div>
        <?php endif; ?>

        <?php if(!empty($success)): ?>
            <div id="success-toast" class="bg-white border-l-4 border-green-500 shadow-2xl rounded-lg p-4 flex flex-col min-w-[300px]">
                <div class="flex items-center mb-2">
                    <span class="text-green-500 mr-3 text-xl font-bold">✓</span>
                    <p class="text-gray-800 text-sm font-semibold"><?php echo htmlspecialchars($success); ?></p>
                </div>
                <a href="login.php" class="text-indigo-600 text-xs font-bold hover:underline ml-8">CLICK HERE TO LOGIN</a>
            </div>
        <?php endif; ?>
    </div>

    <div class="bg-white rounded-3xl shadow-2xl overflow-hidden max-w-5xl w-full flex flex-col md:flex-row">
        
        <div class="md:w-5/12 bg-gradient-to-br from-indigo-500 to-purple-600 p-10 md:p-16 text-white flex flex-col justify-center">
            <h1 class="text-3xl md:text-4xl font-bold mb-6">Join Our Queue System</h1>
            <p class="text-indigo-100 mb-8 leading-relaxed">Create an account to access our streamlined appointment booking and queue management services.</p>
            
            <ul class="space-y-4">
                <li class="flex items-center"><span class="bg-white/20 rounded-full p-1 mr-3 text-xs">✓</span> Quick registration</li>
                <li class="flex items-center"><span class="bg-white/20 rounded-full p-1 mr-3 text-xs">✓</span> Book appointments online</li>
                <li class="flex items-center"><span class="bg-white/20 rounded-full p-1 mr-3 text-xs">✓</span> Track queue position</li>
                <li class="flex items-center"><span class="bg-white/20 rounded-full p-1 mr-3 text-xs">✓</span> Real-time updates</li>
            </ul>
        </div>

        <div class="md:w-7/12 p-8 md:p-12 lg:p-16 max-h-[90vh] overflow-y-auto">
            <div class="text-center mb-10">
                <h2 class="text-3xl font-bold text-gray-800 mb-2">Create Account</h2>
                <p class="text-gray-500">Fill in your details to get started</p>
            </div>

            <form method="POST" autocomplete="on" id="registerForm" class="space-y-6">
                <div>
                    <label for="full_name" class="block text-sm font-semibold text-gray-700 mb-2">Full Name <span class="text-red-500">*</span></label>
                    <input type="text" id="full_name" name="full_name" required autocomplete="name"
                           class="w-full px-4 py-3 border-2 border-gray-100 rounded-xl focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all outline-none"
                           placeholder="Enter your full name" 
                           value="<?php echo isset($full_name) ? htmlspecialchars($full_name) : ''; ?>">
                </div>

                <div>
                    <label for="email" class="block text-sm font-semibold text-gray-700 mb-2">Email Address <span class="text-red-500">*</span></label>
                    <input type="email" id="email" name="email" required autocomplete="email"
                           class="w-full px-4 py-3 border-2 border-gray-100 rounded-xl focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all outline-none"
                           placeholder="Enter your email" 
                           value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>">
                </div>

                <div>
                    <label for="password" class="block text-sm font-semibold text-gray-700 mb-2">Password <span class="text-red-500">*</span></label>
                    <div class="relative">
                        <input type="password" id="password" name="password" required autocomplete="new-password" oninput="checkPasswordStrength()"
                               class="w-full px-4 py-3 border-2 border-gray-100 rounded-xl focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all outline-none"
                               placeholder="Create a password">
                        <span class="absolute right-4 top-1/2 -translate-y-1/2 cursor-pointer text-gray-400 select-none text-xl" onclick="togglePassword('password')">👁️</span>
                    </div>
                    <div class="mt-3 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                        <div id="strength-bar" class="h-full w-0 transition-all duration-300"></div>
                    </div>
                    <p class="text-xs text-gray-400 mt-2 italic text-right">Min. 6 characters</p>
                </div>

                <div>
                    <label for="confirm_password" class="block text-sm font-semibold text-gray-700 mb-2">Confirm Password <span class="text-red-500">*</span></label>
                    <div class="relative">
                        <input type="password" id="confirm_password" name="confirm_password" required autocomplete="new-password"
                               class="w-full px-4 py-3 border-2 border-gray-100 rounded-xl focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all outline-none"
                               placeholder="Re-enter your password">
                        <span class="absolute right-4 top-1/2 -translate-y-1/2 cursor-pointer text-gray-400 select-none text-xl" onclick="togglePassword('confirm_password')">👁️</span>
                    </div>
                </div>

                <button type="submit" name="register" 
                        class="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold py-4 rounded-xl shadow-lg hover:shadow-indigo-500/40 transform hover:-translate-y-0.5 active:translate-y-0 transition-all">
                    Create Account
                </button>
            </form>

            <div class="mt-8 text-center text-sm text-gray-500">
                Already have an account? <a href="login.php" class="text-indigo-600 font-bold hover:underline">Login here</a>
            </div>
        </div>
    </div>

    <script>
        function togglePassword(fieldId) {
            const passwordInput = document.getElementById(fieldId);
            const toggleIcon = passwordInput.nextElementSibling;
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.textContent = '🙈';
            } else {
                passwordInput.type = 'password';
                toggleIcon.textContent = '👁️';
            }
        }

        function checkPasswordStrength() {
            const password = document.getElementById('password').value;
            const strengthBar = document.getElementById('strength-bar');
            
            strengthBar.className = 'h-full transition-all duration-300';
            
            if (password.length === 0) {
                strengthBar.style.width = '0%';
                return;
            }
            
            let strength = 0;
            if (password.length >= 6) strength++;
            if (password.length >= 10) strength++;
            if (/\d/.test(password)) strength++;
            if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
            if (/[^A-Za-z0-9]/.test(password)) strength++;
            
            if (strength <= 2) {
                strengthBar.classList.add('strength-weak');
            } else if (strength <= 3) {
                strengthBar.classList.add('strength-medium');
            } else {
                strengthBar.classList.add('strength-strong');
            }
        }

        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Passwords do not match!');
                document.getElementById('confirm_password').focus();
            } else if (password.length < 6) {
                e.preventDefault();
                alert('Password must be at least 6 characters long!');
                document.getElementById('password').focus();
            }
        });

        window.onload = function() {
            const successMsg = document.getElementById('success-toast');
            if (!successMsg) {
                document.getElementById('full_name').focus();
            }
        };
    </script>
</body>
</html>