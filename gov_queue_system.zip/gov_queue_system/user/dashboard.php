<?php
session_name('user_session');
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include("../config/db.php");

// Only allow logged-in users
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Get upcoming appointments count
$today = date('Y-m-d');
$upcoming_query = "SELECT COUNT(*) as count FROM appointments WHERE user_id = ? AND appointment_date >= ? AND status != 'completed'";
$upcoming_stmt = $conn->prepare($upcoming_query);
$upcoming_stmt->bind_param("is", $user_id, $today);
$upcoming_stmt->execute();
$upcoming_count = $upcoming_stmt->get_result()->fetch_assoc()['count'];

// Get today's appointments with queue info
$today_query = "
    SELECT a.appointment_id, a.appointment_time, s.service_name, 
           q.queue_number, q.status, sc.counter_name
    FROM appointments a
    JOIN services s ON a.service_id = s.service_id
    JOIN queue q ON a.appointment_id = q.appointment_id
    JOIN service_counters sc ON q.counter_id = sc.counter_id
    WHERE a.user_id = ? AND a.appointment_date = ?
    ORDER BY q.queue_number ASC
";
$today_stmt = $conn->prepare($today_query);
$today_stmt->bind_param("is", $user_id, $today);
$today_stmt->execute();
$today_appointments = $today_stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gradient-to-br from-indigo-600 to-purple-700 min-h-screen font-sans antialiased p-4 md:p-8">

    <div class="max-w-6xl mx-auto space-y-6">
        
        <header class="bg-white rounded-2xl shadow-xl p-6 flex flex-col md:flex-row justify-between items-center gap-4">
            <div class="text-center md:text-left">
                <h2 class="text-3xl font-extrabold text-gray-800">User Dashboard</h2>
                <p class="text-gray-500 mt-1">Welcome back, <span class="text-indigo-600 font-semibold"><?php echo htmlspecialchars($_SESSION['name']); ?></span></p>
            </div>
            <a href="logout.php" class="bg-red-500 hover:bg-red-600 text-white px-6 py-2.5 rounded-xl font-bold transition-all transform active:scale-95 shadow-lg shadow-red-200">
                Logout
            </a>
        </header>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            <div class="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 text-white flex flex-col justify-center items-center shadow-2xl">
                <h3 class="text-lg font-medium opacity-80 uppercase tracking-wider">Upcoming</h3>
                <div class="text-7xl font-black my-4"><?php echo $upcoming_count; ?></div>
                <div class="bg-white/20 px-4 py-1 rounded-full text-sm">Active Appointments</div>
            </div>

            <div class="bg-white rounded-2xl shadow-xl p-6 border border-gray-100">
                <h3 class="text-xl font-bold text-gray-800 mb-4 border-b pb-2 flex items-center">
                    <i data-lucide="zap" class="w-5 h-5 mr-2 text-yellow-500"></i> Quick Actions
                </h3>
                <div class="space-y-3">
                    <a href="book_appointment.php" class="flex items-center p-4 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl transition-all group border border-indigo-100">
                        <span class="w-10 h-10 bg-indigo-600 text-white rounded-full flex items-center justify-center font-bold mr-4 group-hover:scale-110 transition-transform">+</span>
                        <span class="font-semibold">Book an Appointment</span>
                    </a>
                    <a href="my_appointments.php" class="flex items-center p-4 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-xl transition-all group border border-purple-100">
                        <span class="w-10 h-10 bg-purple-600 text-white rounded-full flex items-center justify-center mr-4 group-hover:scale-110 transition-transform text-lg">📋</span>
                        <span class="font-semibold">My Queue Status</span>
                    </a>
                </div>
            </div>

            <div class="bg-white rounded-2xl shadow-xl p-6 border border-gray-100 overflow-hidden">
                <h3 class="text-xl font-bold text-gray-800 mb-4 border-b pb-2">Today's Schedule</h3>
                <div class="overflow-y-auto max-h-[300px] pr-2 custom-scrollbar">
                    <?php if ($today_appointments->num_rows > 0): ?>
                        <?php while ($appt = $today_appointments->fetch_assoc()): ?>
                            <div class="mb-4 p-4 bg-slate-50 border-l-4 border-indigo-500 rounded-r-xl shadow-sm hover:shadow-md transition-shadow">
                                <h4 class="font-bold text-gray-800"><?php echo htmlspecialchars($appt['service_name']); ?></h4>
                                <div class="flex justify-between text-xs text-gray-500 mt-2 font-medium">
                                    <span>🕒 <?php echo date('h:i A', strtotime($appt['appointment_time'])); ?></span>
                                    <span>📍 <?php echo htmlspecialchars($appt['counter_name']); ?></span>
                                </div>
                                <div class="mt-3 flex gap-2">
                                    <span class="bg-indigo-600 text-white text-[10px] uppercase px-2 py-1 rounded font-bold">Queue #<?php echo $appt['queue_number']; ?></span>
                                    <?php 
                                        $statusClass = [
                                            'waiting' => 'bg-yellow-100 text-yellow-700',
                                            'serving' => 'bg-blue-100 text-blue-700',
                                            'done' => 'bg-green-100 text-green-700'
                                        ];
                                        $cls = $statusClass[strtolower($appt['status'])] ?? 'bg-gray-100';
                                    ?>
                                    <span class="<?php echo $cls; ?> text-[10px] uppercase px-2 py-1 rounded font-bold">
                                        <?php echo ucfirst($appt['status']); ?>
                                    </span>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="text-center py-12 opacity-40">
                            <p class="text-sm italic">No appointments for today.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-2xl shadow-2xl p-6 border border-gray-100">
            <div class="flex items-center justify-between mb-4 border-b pb-4">
                <h3 class="text-xl font-bold text-gray-800 flex items-center">
                    <span class="relative flex h-3 w-3 mr-3">
                        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                        <span class="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                    </span>
                    AI Assistant
                </h3>
            </div>
            
            <div id="chat-box" class="h-80 overflow-y-auto mb-4 p-4 bg-slate-50 rounded-xl space-y-4 border border-slate-100">
                <div class="text-center">
                    <p class="text-xs text-slate-400 bg-white px-4 py-2 rounded-full inline-block shadow-sm italic">
                        Ask about services, appointments, or queue status.
                    </p>
                </div>
            </div>

            <div class="flex gap-2">
                <input type="text" id="user-msg" 
                       class="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-5 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all text-sm" 
                       placeholder="Type your question..." />
                <button onclick="sendMessage()" 
                        class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-xl font-bold transition-all shadow-lg active:scale-95">
                    Send
                </button>
            </div>
        </div>
    </div>

    <script>
        // Initializing Lucide Icons
        lucide.createIcons();

        // Toast Helper
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true
        });

        async function sendMessage() {
            const msgInput = document.getElementById("user-msg");
            const msg = msgInput.value.trim();
            if(!msg) return;

            const chatBox = document.getElementById("chat-box");
            
            // Append User Message
            const userDiv = document.createElement('div');
            userDiv.className = 'flex justify-end';
            userDiv.innerHTML = `<div class="bg-indigo-600 text-white px-4 py-2 rounded-2xl rounded-tr-none text-sm max-w-[80%] shadow-md shadow-indigo-100">
                                    ${escapeHtml(msg)}
                                 </div>`;
            chatBox.appendChild(userDiv);

            msgInput.value = "";
            chatBox.scrollTop = chatBox.scrollHeight;

            try {
                const res = await fetch("http://127.0.0.1:5000/chat", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ message: msg }),
                });

                const data = await res.json();
                
                // Append Bot Message
                const botDiv = document.createElement('div');
                botDiv.className = 'flex justify-start';
                botDiv.innerHTML = `<div class="bg-white border border-slate-200 text-gray-800 px-4 py-2 rounded-2xl rounded-tl-none text-sm max-w-[80%] shadow-sm">
                                        ${escapeHtml(data.reply).replace(/\n/g, '<br>')}
                                    </div>`;
                chatBox.appendChild(botDiv);
                
                chatBox.scrollTop = chatBox.scrollHeight;
            } catch(e) {
                Toast.fire({ icon: 'error', title: 'Assistant Offline' });
                const errorDiv = document.createElement('div');
                errorDiv.className = 'flex justify-start';
                errorDiv.innerHTML = `<div class="bg-red-50 text-red-600 px-4 py-2 rounded-xl text-xs">
                                        Sorry, I'm currently offline.
                                      </div>`;
                chatBox.appendChild(errorDiv);
                chatBox.scrollTop = chatBox.scrollHeight;
            }
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        document.getElementById("user-msg").addEventListener("keypress", (e) => {
            if (e.key === "Enter") sendMessage();
        });

        // Show welcome toast on load
        window.onload = () => {
            Toast.fire({ icon: 'info', title: 'Live updates enabled' });
        };

        // Refresh Logic (30s)
        setInterval(() => location.reload(), 30000);
    </script>

    <style>
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
    </style>
</body>
</html>