<?php
session_name('user_session');
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include("../config/db.php");

// Only logged-in users
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

// Fetch services
$services = mysqli_query($conn, "
    SELECT s.service_id, s.service_name, s.category, s.counter_id
    FROM services s
    INNER JOIN service_counters c ON s.counter_id = c.counter_id
    ORDER BY s.category, s.service_name
");

// Prevent double booking on refresh using POST-Redirect-GET
if (isset($_POST['book'])) {
    $user_id = $_SESSION['user_id'];
    $service_id = intval($_POST['service_id']);
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];

    if (strtotime($appointment_date) < strtotime(date('Y-m-d'))) {
        $_SESSION['error'] = "Cannot book appointments in the past!";
        header("Location: book_appointment.php");
        exit();
    }

    $check = $conn->prepare("
        SELECT * FROM appointments 
        WHERE user_id=? AND service_id=? AND appointment_date=?
    ");
    $check->bind_param("iis", $user_id, $service_id, $appointment_date);
    $check->execute();
    $res_check = $check->get_result();

    if ($res_check->num_rows > 0) {
        $_SESSION['error'] = "You already booked this service on this date.";
        header("Location: book_appointment.php");
        exit();
    } else {
        $stmt = $conn->prepare("SELECT counter_id FROM services WHERE service_id=?");
        $stmt->bind_param("i", $service_id);
        $stmt->execute();
        $service_res = $stmt->get_result()->fetch_assoc();
        
        if (!$service_res) {
            $_SESSION['error'] = "Service not found!";
            header("Location: book_appointment.php");
            exit();
        }
        
        $counter_id = $service_res['counter_id'];

        $stmt = $conn->prepare("
            INSERT INTO appointments (user_id, service_id, appointment_date, appointment_time, status)
            VALUES (?, ?, ?, ?, 'pending')
        ");
        $stmt->bind_param("iiss", $user_id, $service_id, $appointment_date, $appointment_time);
        $stmt->execute();
        $appointment_id = $stmt->insert_id;

        $stmt = $conn->prepare("
            SELECT COUNT(*) AS total
            FROM queue q
            JOIN appointments a ON q.appointment_id = a.appointment_id
            WHERE q.counter_id=? AND a.appointment_date=?
        ");
        $stmt->bind_param("is", $counter_id, $appointment_date);
        $stmt->execute();
        $queue_count = $stmt->get_result()->fetch_assoc();
        $queue_number = $queue_count['total'] + 1;

        $stmt = $conn->prepare("
            INSERT INTO queue (appointment_id, queue_number, counter_id, status)
            VALUES (?, ?, ?, 'waiting')
        ");
        $stmt->bind_param("iii", $appointment_id, $queue_number, $counter_id);
        $stmt->execute();

        $_SESSION['success'] = "Appointment booked! Your queue number is #$queue_number";
        header("Location: book_appointment.php");
        exit();
    }
}

$success = $_SESSION['success'] ?? "";
$error = $_SESSION['error'] ?? "";
unset($_SESSION['success'], $_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Appointment</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-gradient-to-br from-indigo-600 to-purple-700 min-h-screen flex items-center justify-center p-4">

    <div class="w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden">
        <div class="bg-gradient-to-r from-indigo-500 to-purple-600 p-8 text-center text-white">
            <h2 class="text-3xl font-bold tracking-tight">Book an Appointment</h2>
            <p class="mt-2 text-indigo-100 opacity-90">Schedule your service appointment efficiently</p>
        </div>

        <div class="p-6 md:p-10">
            <div class="bg-indigo-5 border-l-4 border-indigo-500 p-5 mb-8 rounded-r-lg">
                <h4 class="text-indigo-900 font-bold mb-2 flex items-center">
                    <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"></path></svg>
                    Important Information:
                </h4>
                <ul class="text-indigo-800 text-sm space-y-1 list-disc list-inside opacity-90">
                    <li>Arrive 10 minutes before your appointment</li>
                    <li>Watch the screen for your queue number</li>
                    <li>Manage your bookings in "My Appointments"</li>
                </ul>
            </div>

            <form method="POST" id="bookingForm" class="space-y-6">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Select Service *</label>
                    <select name="service_id" id="service_id" required class="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all bg-gray-50">
                        <option value="">-- Choose a Service --</option>
                        <?php 
                        $current_category = "";
                        mysqli_data_seek($services, 0);
                        while ($row = mysqli_fetch_assoc($services)) { 
                            if ($current_category != $row['category']) {
                                if ($current_category != "") echo '</optgroup>';
                                echo '<optgroup label="' . htmlspecialchars($row['category']) . '" class="font-bold text-gray-900">';
                                $current_category = $row['category'];
                            }
                        ?>
                            <option value="<?= $row['service_id'] ?>"><?= htmlspecialchars($row['service_name']) ?></option>
                        <?php } 
                        if ($current_category != "") echo '</optgroup>';
                        ?>
                    </select>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Appointment Date *</label>
                        <input type="date" name="appointment_date" id="appointment_date" required min="<?php echo date('Y-m-d'); ?>" class="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-indigo-500 bg-gray-50 transition-all">
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">Preferred Time *</label>
                        <input type="time" name="appointment_time" id="appointment_time" required min="08:00" max="17:00" class="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-indigo-500 bg-gray-50 transition-all">
                        <p class="mt-1.5 text-xs text-gray-500">Office hours: 8:00 AM - 5:00 PM</p>
                    </div>
                </div>

                <button type="submit" name="book" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg transform transition active:scale-95">
                    Book Appointment Now
                </button>
            </form>

            <div class="mt-8 pt-6 border-t border-gray-100 flex justify-center">
                <a href="dashboard.php" class="text-indigo-600 hover:text-purple-700 font-semibold flex items-center transition-colors">
                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
                    Back to Dashboard
                </a>
            </div>
        </div>
    </div>

    <script>
        // SweetAlert Toast Configuration
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
            timerProgressBar: true
        });

        // Trigger Success/Error Toasts from PHP
        <?php if($success): ?>
            Toast.fire({ icon: 'success', title: '<?php echo $success; ?>' });
        <?php endif; ?>

        <?php if($error): ?>
            Toast.fire({ icon: 'error', title: '<?php echo addslashes($error); ?>' });
        <?php endif; ?>

        // Confirm booking with SweetAlert Modal
        document.getElementById('bookingForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const service = document.getElementById('service_id').selectedOptions[0].text;
            const date = document.getElementById('appointment_date').value;
            const time = document.getElementById('appointment_time').value;

            if(!service || service.includes('--')) {
                Toast.fire({ icon: 'warning', title: 'Please select a service' });
                return;
            }

            Swal.fire({
                title: 'Confirm Booking?',
                html: `<div class="text-left bg-gray-50 p-4 rounded-lg">
                        <p><b>Service:</b> ${service}</p>
                        <p><b>Date:</b> ${date}</p>
                        <p><b>Time:</b> ${time}</p>
                       </div>`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#4f46e5',
                cancelButtonColor: '#94a3b8',
                confirmButtonText: 'Yes, Confirm it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    this.submit();
                }
            });
        });

        // Clear history to prevent duplicate alerts on refresh
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
</body>
</html>