<?php
session_name('user_session');
session_start();

// If already logged in as user, redirect to user dashboard
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    if ($_SESSION['role'] === 'user') {
        header("Location: dashboard.php");
        exit();
    }
}

// Clear any existing session data to start fresh
session_unset();

include("../config/db.php");

$error_message = ""; // Variable to hold error for the Toast

if (isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $role = trim($user['role']);
            
            if ($role === 'admin') {
                session_destroy();
                session_name('admin_session');
                session_start();
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['name']    = $user['full_name'];
                $_SESSION['role']    = 'admin';
                header("Location: ../admin/dashboard.php");
            } else {
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['name']    = $user['full_name'];
                $_SESSION['role']    = 'user';
                header("Location: dashboard.php");
            }
            exit();
        } else {
            $error_message = "Incorrect password. Please try again.";
        }
    } else {
        $error_message = "No account found with that email address.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Queue Management System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gradient-to-br from-indigo-600 via-purple-700 to-pink-500 min-h-screen flex items-center justify-center p-4 md:p-6">

    <div class="max-w-4xl w-full bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row min-h-[600px]">
        
        <div class="md:w-1/2 bg-gradient-to-br from-indigo-600 to-purple-800 p-10 md:p-14 text-white flex flex-col justify-center">
            <div class="space-y-6">
                <div class="bg-white/20 w-16 h-16 rounded-2xl flex items-center justify-center backdrop-blur-sm shadow-xl mb-4">
                    <svg class="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
                <h1 class="text-3xl md:text-4xl font-extrabold tracking-tight">Queue Management <br><span class="text-indigo-200">System</span></h1>
                <p class="text-indigo-100/80 leading-relaxed">Streamline your service appointments and manage queues efficiently with our smart tracking system.</p>
                
                <ul class="space-y-4 pt-4">
                    <li class="flex items-center space-x-3">
                        <span class="bg-indigo-500/30 p-1 rounded-full text-indigo-200 text-xs font-bold">✓</span>
                        <span class="text-sm font-medium">Book appointments online</span>
                    </li>
                    <li class="flex items-center space-x-3">
                        <span class="bg-indigo-500/30 p-1 rounded-full text-indigo-200 text-xs font-bold">✓</span>
                        <span class="text-sm font-medium">Real-time queue tracking</span>
                    </li>
                    <li class="flex items-center space-x-3">
                        <span class="bg-indigo-500/30 p-1 rounded-full text-indigo-200 text-xs font-bold">✓</span>
                        <span class="text-sm font-medium">Smart counter management</span>
                    </li>
                </ul>
            </div>
        </div>

        <div class="md:w-1/2 p-10 md:p-14 bg-white">
            <div class="mb-10 text-center md:text-left">
                <h2 class="text-3xl font-bold text-gray-800">Welcome Back</h2>
                <p class="text-gray-500 mt-2">Login to manage your schedule</p>
            </div>

            <form method="POST" autocomplete="on" class="space-y-6">
                <div class="space-y-1">
                    <label for="email" class="text-sm font-semibold text-gray-700 ml-1">Email Address</label>
                    <input type="email" 
                           id="email" 
                           name="email" 
                           placeholder="name@company.com" 
                           required 
                           autocomplete="email"
                           class="w-full px-4 py-3.5 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all outline-none bg-gray-50/50"
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                </div>

                <div class="space-y-1">
                    <label for="password" class="text-sm font-semibold text-gray-700 ml-1">Password</label>
                    <div class="relative group">
                        <input type="password" 
                               id="password" 
                               name="password" 
                               placeholder="••••••••" 
                               required 
                               autocomplete="current-password"
                               class="w-full px-4 py-3.5 rounded-xl border border-gray-200 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all outline-none bg-gray-50/50">
                        <span class="absolute right-4 top-1/2 -translate-y-1/2 cursor-pointer text-gray-400 hover:text-indigo-600 transition-colors select-none text-xl" 
                              id="toggle-btn"
                              onclick="togglePassword()">
                            👁️
                        </span>
                    </div>
                </div>

                <button type="submit" name="login" 
                        class="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-xl font-bold text-lg shadow-lg shadow-indigo-200 transform transition-all active:scale-[0.98] focus:ring-4 focus:ring-purple-500/30">
                    Sign In
                </button>
            </form>

            <div class="mt-8 text-center">
                <p class="text-gray-500 text-sm">
                    Don't have an account? 
                    <a href="register.php" class="text-indigo-600 font-bold hover:text-indigo-800 transition-colors">Register here</a>
                </p>
            </div>
        </div>
    </div>

    <script>
        // Toast Configuration
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 4000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });

        // Trigger Toast if PHP error exists
        <?php if($error_message != ""): ?>
            Toast.fire({
                icon: 'error',
                title: '<?php echo $error_message; ?>'
            });
        <?php endif; ?>

        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.getElementById('toggle-btn');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.textContent = '🙈';
            } else {
                passwordInput.type = 'password';
                toggleIcon.textContent = '👁️';
            }
        }

        // Auto-focus email
        window.addEventListener('DOMContentLoaded', () => {
            document.getElementById('email').focus();
        });
    </script>
</body>
</html>