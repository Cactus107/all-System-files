<?php
session_name('user_session');
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include("../config/db.php");

// Only logged-in users
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$query = "
    SELECT a.appointment_id, a.appointment_date, a.appointment_time, 
           s.service_name, s.category,
           q.queue_number, q.status, sc.counter_name
    FROM appointments a
    JOIN services s ON a.service_id = s.service_id
    JOIN queue q ON a.appointment_id = q.appointment_id
    JOIN service_counters sc ON q.counter_id = sc.counter_id
    WHERE a.user_id = ?
    ORDER BY a.appointment_date DESC, q.queue_number ASC
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$today = date('Y-m-d');
$upcoming = [];
$past = [];

while ($row = $result->fetch_assoc()) {
    if ($row['appointment_date'] >= $today) {
        $upcoming[] = $row;
    } else {
        $past[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Appointments</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen pb-12">

    <nav class="bg-white border-b border-gray-200 mb-8 shadow-sm">
        <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
            <div class="flex items-center space-x-2">
                <div class="bg-green-600 p-2 rounded-lg">
                    <i data-lucide="calendar-check" class="text-white w-6 h-6"></i>
                </div>
                <h1 class="text-xl font-bold text-gray-800">My Appointments</h1>
            </div>
            <div class="text-right">
                <p class="text-sm text-gray-500">Logged in as</p>
                <p class="text-sm font-semibold text-gray-800"><?php echo htmlspecialchars($_SESSION['name']); ?></p>
            </div>
        </div>
    </nav>

    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="flex border-b border-gray-200 bg-gray-50/50">
                <button class="tab-btn active px-6 py-4 text-sm font-medium border-b-2 border-green-600 text-green-700 bg-white" 
                        onclick="openTab(event, 'upcoming')">
                    Upcoming (<?php echo count($upcoming); ?>)
                </button>
                <button class="tab-btn px-6 py-4 text-sm font-medium border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-100 transition-all" 
                        onclick="openTab(event, 'past')">
                    History (<?php echo count($past); ?>)
                </button>
            </div>

            <div id="upcoming" class="tab-content active p-6">
                <?php if (count($upcoming) > 0): ?>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="border-b border-gray-100">
                                    <th class="py-4 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Appointment Info</th>
                                    <th class="py-4 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider text-center">Queue #</th>
                                    <th class="py-4 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Service Detail</th>
                                    <th class="py-4 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Counter</th>
                                    <th class="py-4 px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-50">
                                <?php foreach ($upcoming as $row): 
                                    $statusClass = [
                                        'waiting' => 'bg-yellow-100 text-yellow-700',
                                        'serving' => 'bg-blue-100 text-blue-700 animate-pulse',
                                        'done' => 'bg-green-100 text-green-700',
                                        'cancelled' => 'bg-red-100 text-red-700'
                                    ][strtolower($row['status'])] ?? 'bg-gray-100';
                                ?>
                                    <tr class="hover:bg-gray-50/80 transition-colors">
                                        <td class="py-4 px-4">
                                            <div class="font-semibold text-gray-900"><?php echo date('M d, Y', strtotime($row['appointment_date'])); ?></div>
                                            <div class="text-xs text-gray-500"><?php echo date('h:i A', strtotime($row['appointment_time'])); ?></div>
                                        </td>
                                        <td class="py-4 px-4 text-center">
                                            <span class="text-2xl font-black text-green-600">#<?php echo $row['queue_number']; ?></span>
                                        </td>
                                        <td class="py-4 px-4">
                                            <div class="text-sm font-medium text-gray-800"><?php echo htmlspecialchars($row['service_name']); ?></div>
                                            <span class="inline-block mt-1 px-2 py-0.5 text-[10px] bg-gray-100 text-gray-600 rounded uppercase font-bold tracking-tight"><?php echo htmlspecialchars($row['category']); ?></span>
                                        </td>
                                        <td class="py-4 px-4">
                                            <span class="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold border border-indigo-100">
                                                <?php echo htmlspecialchars($row['counter_name']); ?>
                                            </span>
                                        </td>
                                        <td class="py-4 px-4">
                                            <span class="px-3 py-1 rounded-full text-[11px] font-bold uppercase <?php echo $statusClass; ?>">
                                                <?php echo ucfirst($row['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-16">
                        <div class="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
                            <i data-lucide="clock" class="text-gray-400 w-8 h-8"></i>
                        </div>
                        <p class="text-gray-500 font-medium mb-6">No upcoming appointments found.</p>
                        <a href="book_appointment.php" class="inline-flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white font-bold rounded-lg transition-all shadow-md">
                            <i data-lucide="plus" class="w-4 h-4 mr-2"></i> Book Now
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <div id="past" class="tab-content p-6">
                <?php if (count($past) > 0): ?>
                    <div class="overflow-x-auto opacity-75 grayscale-[0.5]">
                        <table class="w-full text-left border-collapse">
                            <thead>
                                <tr class="border-b border-gray-100 text-gray-400">
                                    <th class="py-4 px-4 text-xs font-semibold uppercase">Date/Time</th>
                                    <th class="py-4 px-4 text-xs font-semibold uppercase">Service</th>
                                    <th class="py-4 px-4 text-xs font-semibold uppercase">Queue</th>
                                    <th class="py-4 px-4 text-xs font-semibold uppercase">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-50">
                                <?php foreach ($past as $row): ?>
                                    <tr>
                                        <td class="py-4 px-4 text-sm font-medium"><?php echo date('M d, Y', strtotime($row['appointment_date'])); ?></td>
                                        <td class="py-4 px-4 text-sm"><?php echo htmlspecialchars($row['service_name']); ?></td>
                                        <td class="py-4 px-4 text-sm font-bold">#<?php echo $row['queue_number']; ?></td>
                                        <td class="py-4 px-4 text-sm italic text-gray-500"><?php echo ucfirst($row['status']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-12 text-gray-400">
                        <p>Your appointment history is empty.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="mt-8 flex justify-between items-center">
            <a href="dashboard.php" class="flex items-center text-sm font-bold text-green-600 hover:text-green-800 transition-colors">
                <i data-lucide="arrow-left" class="w-4 h-4 mr-2"></i> Back to Dashboard
            </a>
            <p class="text-xs text-gray-400 italic">Page auto-refreshes every 30 seconds</p>
        </div>
    </div>

    <div id="refresh-toast" class="fixed bottom-5 right-5 bg-gray-900 text-white px-4 py-2 rounded-lg shadow-xl text-xs flex items-center space-x-2 transform translate-y-20 transition-transform duration-500">
        <div class="w-2 h-2 bg-green-500 rounded-full animate-ping"></div>
        <span>Updating queue status...</span>
    </div>

    <script>
        // Initialize Lucide Icons
        lucide.createIcons();

        function openTab(evt, tabName) {
            var tabContents = document.getElementsByClassName("tab-content");
            for (var i = 0; i < tabContents.length; i++) {
                tabContents[i].classList.remove("active");
            }

            var tabs = document.getElementsByClassName("tab-btn");
            for (var i = 0; i < tabs.length; i++) {
                tabs[i].classList.remove("active", "border-green-600", "text-green-700", "bg-white");
                tabs[i].classList.add("border-transparent", "text-gray-500");
            }

            document.getElementById(tabName).classList.add("active");
            evt.currentTarget.classList.add("active", "border-green-600", "text-green-700", "bg-white");
            evt.currentTarget.classList.remove("border-transparent", "text-gray-500");
        }

        // Show "Updating" toast before refresh
        setTimeout(function() {
            document.getElementById('refresh-toast').classList.remove('translate-y-20');
            setTimeout(function() {
                location.reload();
            }, 2000);
        }, 28000);
    </script>
</body>
</html>