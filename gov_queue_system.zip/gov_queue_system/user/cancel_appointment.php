<?php
session_name('user_session');
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include("../config/db.php");

// Only allow logged-in users
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit();
}

// Check if appointment_id is provided
if (!isset($_GET['id'])) {
    $_SESSION['error'] = "Invalid request - no appointment specified.";
    header("Location: my_appointments.php");
    exit();
}

$appointment_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

// Verify the appointment belongs to this user and get details
$check_query = "
    SELECT a.appointment_id, a.appointment_date, a.status, s.service_name, q.queue_id, q.status as queue_status
    FROM appointments a
    JOIN services s ON a.service_id = s.service_id
    LEFT JOIN queue q ON a.appointment_id = q.appointment_id
    WHERE a.appointment_id = ? AND a.user_id = ?
";
$check_stmt = $conn->prepare($check_query);
$check_stmt->bind_param("ii", $appointment_id, $user_id);
$check_stmt->execute();
$result = $check_stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Appointment not found or you don't have permission to cancel it.";
    header("Location: my_appointments.php");
    exit();
}

$appointment = $result->fetch_assoc();

// Business Logic Checks (No changes to functionality)
if ($appointment['status'] === 'completed' || $appointment['status'] === 'cancelled') {
    $_SESSION['error'] = "This appointment has already been " . $appointment['status'] . " and cannot be canceled.";
    header("Location: my_appointments.php");
    exit();
}

if ($appointment['queue_status'] === 'serving' || $appointment['queue_status'] === 'done') {
    $_SESSION['error'] = "Cannot cancel - this appointment is already being processed.";
    header("Location: my_appointments.php");
    exit();
}

if (strtotime($appointment['appointment_date']) < strtotime(date('Y-m-d'))) {
    $_SESSION['error'] = "Cannot cancel past appointments.";
    header("Location: my_appointments.php");
    exit();
}

// Execution
$success_flag = false;
$cancel_appointment = "UPDATE appointments SET status = 'cancelled' WHERE appointment_id = ?";
$cancel_stmt = $conn->prepare($cancel_appointment);
$cancel_stmt->bind_param("i", $appointment_id);

if ($cancel_stmt->execute()) {
    if ($appointment['queue_id']) {
        $cancel_queue = "UPDATE queue SET status = 'cancelled' WHERE queue_id = ?";
        $queue_stmt = $conn->prepare($cancel_queue);
        $queue_stmt->bind_param("i", $appointment['queue_id']);
        $queue_stmt->execute();
    }
    $_SESSION['success'] = "Appointment for " . htmlspecialchars($appointment['service_name']) . " has been canceled.";
    $success_flag = true;
} else {
    $_SESSION['error'] = "Failed to cancel appointment. Please try again.";
    $success_flag = false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Processing Cancellation...</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-slate-50 min-h-screen flex items-center justify-center p-6">

    <div class="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center border border-slate-100">
        <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-indigo-50 text-indigo-600 mb-6 animate-pulse">
            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
            </svg>
        </div>
        
        <h2 class="text-2xl font-bold text-slate-800 mb-2">Processing Request</h2>
        <p class="text-slate-500">Please wait while we update your appointment status...</p>
        
        <div class="mt-8">
            <div class="w-full bg-slate-100 rounded-full h-1.5 mb-4">
                <div class="bg-indigo-600 h-1.5 rounded-full animate-[progress_1.5s_ease-in-out_infinite]" style="width: 45%"></div>
            </div>
        </div>
    </div>

    <style>
        @keyframes progress {
            0% { width: 0%; margin-left: 0%; }
            50% { width: 50%; margin-left: 25%; }
            100% { width: 0%; margin-left: 100%; }
        }
    </style>

    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 2000,
            timerProgressBar: true
        });

        // Use the flags from PHP to trigger the Toast before redirecting
        <?php if($success_flag): ?>
            Toast.fire({
                icon: 'success',
                title: 'Cancelled Successfully'
            }).then(() => {
                window.location.href = 'my_appointments.php';
            });
        <?php else: ?>
            Toast.fire({
                icon: 'error',
                title: 'Error updating status'
            }).then(() => {
                window.location.href = 'my_appointments.php';
            });
        <?php endif; ?>
    </script>
</body>
</html>