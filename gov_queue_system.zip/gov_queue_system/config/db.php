<?php
$conn = mysqli_connect("localhost", "root", "", "gov_queue_system");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
