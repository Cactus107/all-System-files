from flask import Flask, request, jsonify
from flask_cors import CORS
import re

app = Flask(__name__)
CORS(app)

# Simple knowledge base
knowledge_base = {
    "services": {
        "keywords": ["service", "services", "what do you offer", "what can i do"],
        "response": """We offer the following services:

MEMBERSHIP SERVICES:
- New Member Registration
- Membership Renewal
- Update Member Information
- Membership Card Replacement

HOSPITALIZATION SERVICES:
- Admission Verification
- Benefit Coverage Inquiry
- Billing and Claims Processing
- Pre-authorization Requests"""
    },
    "appointment": {
        "keywords": ["book", "appointment", "schedule", "reserve"],
        "response": "To book an appointment:\n1. Go to 'Book an Appointment' from your dashboard\n2. Select the service you need\n3. Choose your preferred date and time\n4. Submit your booking\n\nYou will receive a queue number after booking."
    },
    "queue": {
        "keywords": ["queue", "number", "waiting", "status", "position"],
        "response": "To check your queue status:\n1. Go to 'View My Appointments & Queue' from your dashboard\n2. You can see all your appointments with queue numbers\n3. The status will show: Waiting, Serving, or Done\n\nYour queue number will be called when it's your turn."
    },
    "membership": {
        "keywords": ["member", "membership", "register", "join"],
        "response": "Membership Services Include:\n- New member registration\n- Renewal of existing membership\n- Update personal information\n- Request membership card replacement\n\nPlease book an appointment for membership services."
    },
    "hospitalization": {
        "keywords": ["hospital", "admission", "benefits", "coverage", "claims"],
        "response": "Hospitalization Services Include:\n- Admission verification\n- Check benefit coverage\n- Process billing and claims\n- Pre-authorization for procedures\n\nFor hospitalization services, please book an appointment or contact us directly."
    },
    "hours": {
        "keywords": ["hours", "time", "open", "close", "schedule"],
        "response": "Office Hours:\nMonday - Friday: 8:00 AM - 5:00 PM\nSaturday - Sunday: Closed\n\nAppointments can be booked for any weekday during office hours."
    },
    "help": {
        "keywords": ["help", "assistance", "support", "how"],
        "response": "I can help you with:\n- Information about our services\n- Booking appointments\n- Checking queue status\n- Membership inquiries\n- Hospitalization services\n- Office hours\n\nJust ask me anything!"
    }
}

def find_response(message):
    """Find the best matching response based on keywords"""
    message_lower = message.lower()
    
    # Check each category for keyword matches
    for category, data in knowledge_base.items():
        for keyword in data["keywords"]:
            if keyword in message_lower:
                return data["response"]
    
    # Default response if no match found
    return """Hello! I'm here to help you with:
- Government services information
- Booking appointments
- Queue status
- Membership services
- Hospitalization services

What would you like to know?"""

@app.route("/chat", methods=["POST"])
def chat():
    try:
        data = request.json
        msg = data.get("message", "")
        
        if not msg:
            return jsonify({"reply": "Please type a message."}), 400
        
        # Get response based on message
        reply = find_response(msg)
        
        return jsonify({"reply": reply})
    
    except Exception as e:
        return jsonify({"reply": "Sorry, I encountered an error. Please try again."}), 500

@app.route("/health", methods=["GET"])
def health():
    """Health check endpoint"""
    return jsonify({"status": "online", "message": "Chatbot is running"}), 200

if __name__ == "__main__":
    print("Chatbot server starting on http://127.0.0.1:5000")
    app.run(host='127.0.0.1', port=5000, debug=True)