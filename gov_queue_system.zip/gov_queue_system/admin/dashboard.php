<?php
session_name('admin_session');
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include("../config/db.php");

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || trim($_SESSION['role']) !== 'admin') {
    header("Location: ../user/login.php");
    exit();
}

$success = $_SESSION['success'] ?? "";
$error = $_SESSION['error'] ?? "";
unset($_SESSION['success'], $_SESSION['error']);

$today = date('Y-m-d');

// Helper function for counts to keep code clean
function getCount($conn, $query, $date) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $date);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

$total_count = getCount($conn, "SELECT COUNT(*) as total FROM queue q JOIN appointments a ON q.appointment_id = a.appointment_id WHERE a.appointment_date = ?", $today)['total'];
$waiting_count = getCount($conn, "SELECT COUNT(*) as waiting FROM queue q JOIN appointments a ON q.appointment_id = a.appointment_id WHERE a.appointment_date = ? AND q.status = 'waiting'", $today)['waiting'];
$serving_count = getCount($conn, "SELECT COUNT(*) as serving FROM queue q JOIN appointments a ON q.appointment_id = a.appointment_id WHERE a.appointment_date = ? AND q.status = 'serving'", $today)['serving'];
$done_count = getCount($conn, "SELECT COUNT(*) as done FROM queue q JOIN appointments a ON q.appointment_id = a.appointment_id WHERE a.appointment_date = ? AND q.status = 'done'", $today)['done'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-slate-50 min-h-screen p-4 md:p-8 font-sans text-slate-900">

    <div class="max-w-7xl mx-auto">
        <header class="bg-white p-6 rounded-xl shadow-sm flex flex-col md:flex-row justify-between items-center mb-8 gap-4 border border-slate-200">
            <div>
                <h2 class="text-2xl font-bold text-slate-800">Admin Dashboard</h2>
                <p class="text-slate-500 text-sm">Welcome back, <span class="font-semibold text-indigo-600"><?php echo htmlspecialchars($_SESSION['name']); ?></span></p>
            </div>
            <a href="logout.php" class="bg-red-500 hover:bg-red-600 text-white px-6 py-2.5 rounded-lg font-semibold transition-all transform hover:-translate-y-0.5 shadow-md shadow-red-100">Logout</a>
        </header>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-white p-6 rounded-xl shadow-sm border-t-4 border-blue-500 hover:shadow-md transition-shadow">
                <p class="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Queue</p>
                <p class="text-4xl font-bold text-blue-600 mt-2"><?php echo $total_count; ?></p>
            </div>
            <div class="bg-white p-6 rounded-xl shadow-sm border-t-4 border-amber-500 hover:shadow-md transition-shadow">
                <p class="text-xs font-bold text-slate-400 uppercase tracking-wider">Waiting</p>
                <p class="text-4xl font-bold text-amber-500 mt-2"><?php echo $waiting_count; ?></p>
            </div>
            <div class="bg-white p-6 rounded-xl shadow-sm border-t-4 border-purple-500 hover:shadow-md transition-shadow">
                <p class="text-xs font-bold text-slate-400 uppercase tracking-wider">Serving</p>
                <p class="text-4xl font-bold text-purple-600 mt-2"><?php echo $serving_count; ?></p>
            </div>
            <div class="bg-white p-6 rounded-xl shadow-sm border-t-4 border-emerald-500 hover:shadow-md transition-shadow">
                <p class="text-xs font-bold text-slate-400 uppercase tracking-wider">Completed</p>
                <p class="text-4xl font-bold text-emerald-600 mt-2"><?php echo $done_count; ?></p>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                <h3 class="text-lg font-bold text-slate-700">Today's Queue <span class="text-slate-400 font-normal ml-2">— <?php echo date('F d, Y'); ?></span></h3>
            </div>
            
            <div class="overflow-x-auto">
                <?php
                $query = "SELECT q.queue_id, q.queue_number, q.status, s.service_name, sc.counter_name, u.full_name
                          FROM queue q
                          JOIN appointments a ON q.appointment_id = a.appointment_id
                          JOIN services s ON a.service_id = s.service_id
                          JOIN service_counters sc ON q.counter_id = sc.counter_id
                          JOIN users u ON a.user_id = u.user_id
                          WHERE a.appointment_date = ?
                          ORDER BY q.counter_id ASC, q.queue_number ASC";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("s", $today);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0): ?>
                    <table class="w-full text-left">
                        <thead class="bg-slate-800 text-white text-xs uppercase tracking-wider">
                            <tr>
                                <th class="px-6 py-4 font-semibold">Queue #</th>
                                <th class="px-6 py-4 font-semibold">Service</th>
                                <th class="px-6 py-4 font-semibold">Customer</th>
                                <th class="px-6 py-4 font-semibold">Counter</th>
                                <th class="px-6 py-4 font-semibold">Status</th>
                                <th class="px-6 py-4 font-semibold">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            <?php while ($row = $result->fetch_assoc()): ?>
                                <tr class="hover:bg-slate-50 transition-colors">
                                    <td class="px-6 py-4 font-bold text-slate-900 text-lg">#<?php echo $row['queue_number']; ?></td>
                                    <td class="px-6 py-4 text-slate-600"><?php echo htmlspecialchars($row['service_name']); ?></td>
                                    <td class="px-6 py-4 font-medium text-slate-700"><?php echo htmlspecialchars($row['full_name']); ?></td>
                                    <td class="px-6 py-4 text-slate-600"><?php echo htmlspecialchars($row['counter_name']); ?></td>
                                    <td class="px-6 py-4">
                                        <?php 
                                            $statusClass = [
                                                'waiting' => 'bg-amber-100 text-amber-700 border-amber-200',
                                                'serving' => 'bg-purple-100 text-purple-700 border-purple-200',
                                                'done'    => 'bg-emerald-100 text-emerald-700 border-emerald-200'
                                            ][strtolower($row['status'])] ?? 'bg-slate-100 text-slate-700';
                                        ?>
                                        <span class="px-3 py-1 rounded-full text-[10px] font-bold uppercase border <?php echo $statusClass; ?>">
                                            <?php echo $row['status']; ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if ($row['status'] === 'done'): ?>
                                            <span class="text-emerald-500 font-bold text-sm flex items-center gap-1">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" /></svg>
                                                Completed
                                            </span>
                                        <?php else: ?>
                                            <div class="flex gap-2">
                                                <?php if ($row['status'] === 'waiting'): ?>
                                                    <a href="process_queue.php?id=<?php echo $row['queue_id']; ?>&action=serve" 
                                                       class="serve-btn bg-blue-600 hover:bg-blue-700 text-white px-4 py-1.5 rounded-md text-xs font-bold transition-all shadow-sm">Serve</a>
                                                <?php else: ?>
                                                    <span class="bg-slate-200 text-slate-400 px-4 py-1.5 rounded-md text-xs font-bold cursor-not-allowed">Serve</span>
                                                <?php endif; ?>
                                                <a href="process_queue.php?id=<?php echo $row['queue_id']; ?>&action=done" 
                                                   class="done-btn bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-1.5 rounded-md text-xs font-bold transition-all shadow-sm">Done</a>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="text-center py-20">
                        <div class="text-6xl mb-4 opacity-20">📋</div>
                        <h4 class="text-xl font-bold text-slate-400">No appointments scheduled for today</h4>
                        <p class="text-slate-400">New bookings will appear here automatically.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // SweetAlert Toast Configuration
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });

        // Trigger Toasts from PHP
        <?php if($success): ?>
            Toast.fire({ icon: 'success', title: '<?php echo $success; ?>' });
        <?php endif; ?>

        <?php if($error): ?>
            Toast.fire({ icon: 'error', title: '<?php echo $error; ?>' });
        <?php endif; ?>

        // Confirm Actions with SweetAlert
        document.querySelectorAll('.done-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const url = this.href;
                Swal.fire({
                    title: 'Complete Transaction?',
                    text: "You are marking this queue as finished.",
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#10b981',
                    cancelButtonColor: '#64748b',
                    confirmButtonText: 'Yes, mark as done'
                }).then((result) => {
                    if (result.isConfirmed) window.location.href = url;
                });
            });
        });

        document.querySelectorAll('.serve-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const url = this.href;
                Swal.fire({
                    title: 'Start Serving?',
                    icon: 'info',
                    showCancelButton: true,
                    confirmButtonColor: '#2563eb',
                    cancelButtonColor: '#64748b',
                    confirmButtonText: 'Yes, serve now'
                }).then((result) => {
                    if (result.isConfirmed) window.location.href = url;
                });
            });
        });

        // Auto-refresh every 10 seconds
        setTimeout(() => { location.reload(); }, 10000);
    </script>
</body>
</html>