<?php
session_name('admin_session');
session_start();

// Store admin info before destroying session
$was_logged_in = isset($_SESSION['user_id']);

// Destroy admin session
session_unset();
session_destroy();

// Clear session cookie
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time()-3600, '/');
}

// Redirect to login
header("Location: ../user/login.php");
exit();
?>