<?php
session_name('admin_session');
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

include("../config/db.php");

// Only admin can access
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || trim($_SESSION['role']) !== 'admin') {
    header("Location: ../user/login.php");
    exit();
}

// Check if queue_id and action are provided
if (!isset($_GET['id']) || !isset($_GET['action'])) {
    $_SESSION['error'] = "Invalid request - missing parameters.";
    header("Location: dashboard.php");
    exit();
}

$queue_id = intval($_GET['id']);
$action = $_GET['action'];

// Validate action
if (!in_array($action, ['serve', 'done'])) {
    $_SESSION['error'] = "Invalid action specified.";
    header("Location: dashboard.php");
    exit();
}

// Get current queue status and customer info
$check_query = "
    SELECT q.status, q.queue_number, u.full_name, s.service_name 
    FROM queue q
    JOIN appointments a ON q.appointment_id = a.appointment_id
    JOIN users u ON a.user_id = u.user_id
    JOIN services s ON a.service_id = s.service_id
    WHERE q.queue_id = ?
";
$check_stmt = $conn->prepare($check_query);
$check_stmt->bind_param("i", $queue_id);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows === 0) {
    $_SESSION['error'] = "Queue entry not found.";
    header("Location: dashboard.php");
    exit();
}

$current_queue = $check_result->fetch_assoc();
$current_status = $current_queue['status'];
$queue_number = $current_queue['queue_number'];
$customer_name = $current_queue['full_name'];
$service_name = $current_queue['service_name'];

// Prevent changing status if already done
if ($current_status === 'done') {
    $_SESSION['error'] = "Cannot modify - this transaction has already been completed.";
    header("Location: dashboard.php");
    exit();
}

// Update status based on action
if ($action === 'serve') {
    // Check if trying to serve when already serving
    if ($current_status === 'serving') {
        $_SESSION['error'] = "This customer is already being served.";
        header("Location: dashboard.php");
        exit();
    }
    
    $new_status = 'serving';
    $success_message = "Queue #{$queue_number} ({$customer_name}) is now being served for {$service_name}.";
    
} elseif ($action === 'done') {
    $new_status = 'done';
    $success_message = "Transaction completed for Queue #{$queue_number} ({$customer_name} - {$service_name}).";
    
    // Also update the appointment status to 'completed'
    $update_appointment = "
        UPDATE appointments a 
        INNER JOIN queue q ON a.appointment_id = q.appointment_id 
        SET a.status = 'completed' 
        WHERE q.queue_id = ?
    ";
    $appt_stmt = $conn->prepare($update_appointment);
    $appt_stmt->bind_param("i", $queue_id);
    
    if (!$appt_stmt->execute()) {
        $_SESSION['error'] = "Failed to update appointment status.";
        header("Location: dashboard.php");
        exit();
    }
}

// Update queue status
$update_query = "UPDATE queue SET status = ? WHERE queue_id = ?";
$stmt = $conn->prepare($update_query);
$stmt->bind_param("si", $new_status, $queue_id);

if ($stmt->execute()) {
    $_SESSION['success'] = $success_message;
} else {
    $_SESSION['error'] = "Failed to update queue status. Please try again.";
}

// Redirect back to dashboard
header("Location: dashboard.php");
exit();
?>