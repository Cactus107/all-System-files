<?php
session_name('user_session');
session_start();
include("../config/db.php");

// Admin Access Control
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../user/login.php");
    exit();
}

$message = "";
$messageType = "";

// Handle Verification Action
if (isset($_POST['action']) && isset($_POST['appointment_id'])) {
    $appointment_id = $_POST['appointment_id'];
    $action = $_POST['action']; // 'approve' or 'reject'
    
    if ($action === 'approve') {
        // Update appointment status and set queue status to 'waiting'
        $update_query = "UPDATE queue SET status = 'waiting' WHERE appointment_id = ?";
        $msg_text = "Appointment verified and added to queue.";
    } else {
        $update_query = "UPDATE queue SET status = 'cancelled' WHERE appointment_id = ?";
        $msg_text = "Appointment has been rejected.";
    }

    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("i", $appointment_id);
    
    if ($stmt->execute()) {
        $message = $msg_text;
        $messageType = "success";
    } else {
        $message = "Error updating appointment.";
        $messageType = "error";
    }
}

// Fetch Unverified Appointments (Status: 'pending')
$query = "
    SELECT a.appointment_id, a.appointment_date, a.appointment_time, 
           u.full_name, u.email, s.service_name, q.status
    FROM appointments a
    JOIN users u ON a.user_id = u.user_id
    JOIN services s ON a.service_id = s.service_id
    JOIN queue q ON a.appointment_id = q.appointment_id
    WHERE q.status = 'pending'
    ORDER BY a.appointment_date ASC, a.appointment_time ASC
";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Appointments - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-50 min-h-screen">

    <nav class="bg-white border-b border-gray-200 shadow-sm px-6 py-4">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <div class="flex items-center gap-2">
                <a href="dashboard.php" class="p-2 hover:bg-gray-100 rounded-full transition-colors">
                    <i data-lucide="arrow-left" class="w-5 h-5 text-gray-600"></i>
                </a>
                <h1 class="text-xl font-bold text-gray-800">Verify Appointments</h1>
            </div>
            <span class="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">Admin Portal</span>
        </div>
    </nav>

    <main class="max-w-7xl mx-auto px-6 py-10">
        
        <?php if($message): ?>
            <div class="mb-6 p-4 rounded-xl flex items-center gap-3 <?php echo $messageType === 'success' ? 'bg-green-100 text-green-800 border-l-4 border-green-500' : 'bg-red-100 text-red-800 border-l-4 border-red-500'; ?>">
                <i data-lucide="<?php echo $messageType === 'success' ? 'check-circle' : 'alert-circle'; ?>" class="w-5 h-5"></i>
                <p class="font-medium"><?php echo $message; ?></p>
            </div>
        <?php endif; ?>

        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                <h2 class="font-bold text-gray-700">Pending Verification (<?php echo $result->num_rows; ?>)</h2>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="text-xs font-bold text-gray-400 uppercase tracking-widest border-b border-gray-100">
                            <th class="px-6 py-4 text-center">Date & Time</th>
                            <th class="px-6 py-4">Customer Details</th>
                            <th class="px-6 py-4">Requested Service</th>
                            <th class="px-6 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-50">
                        <?php if($result->num_rows > 0): ?>
                            <?php while($row = $result->fetch_assoc()): ?>
                                <tr class="hover:bg-gray-50/50 transition-colors">
                                    <td class="px-6 py-4 text-center">
                                        <div class="text-sm font-bold text-gray-900"><?php echo date('M d, Y', strtotime($row['appointment_date'])); ?></div>
                                        <div class="text-xs text-gray-500"><?php echo date('h:i A', strtotime($row['appointment_time'])); ?></div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm font-semibold text-gray-800"><?php echo htmlspecialchars($row['full_name']); ?></div>
                                        <div class="text-xs text-gray-500"><?php echo htmlspecialchars($row['email']); ?></div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-100">
                                            <?php echo htmlspecialchars($row['service_name']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-right">
                                        <form method="POST" class="flex justify-end gap-2">
                                            <input type="hidden" name="appointment_id" value="<?php echo $row['appointment_id']; ?>">
                                            
                                            <button type="submit" name="action" value="approve" 
                                                    class="p-2 bg-green-50 text-green-600 hover:bg-green-600 hover:text-white rounded-lg transition-all" title="Approve">
                                                <i data-lucide="check-check" class="w-5 h-5"></i>
                                            </button>
                                            
                                            <button type="submit" name="action" value="reject" 
                                                    class="p-2 bg-red-50 text-red-600 hover:bg-red-600 hover:text-white rounded-lg transition-all" title="Reject">
                                                <i data-lucide="x" class="w-5 h-5"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="px-6 py-16 text-center">
                                    <div class="flex flex-col items-center opacity-40">
                                        <i data-lucide="shield-check" class="w-12 h-12 mb-3"></i>
                                        <p class="text-lg font-medium">All caught up! No pending verifications.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>