-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2026 at 04:25 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `philhealth_queue`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL,
  `reference_code` varchar(24) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `walkin_name` varchar(150) DEFAULT NULL,
  `walkin_mobile` varchar(30) DEFAULT NULL,
  `service_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `counter_id` int(11) DEFAULT NULL,
  `client_status` varchar(30) NOT NULL DEFAULT 'Regular',
  `appointment_date` date NOT NULL,
  `appointment_time` time DEFAULT NULL,
  `arrival_time` datetime DEFAULT NULL,
  `source` enum('online','walkin') NOT NULL DEFAULT 'online',
  `status` enum('booked','checked_in','completed','cancelled','no_show') NOT NULL DEFAULT 'booked',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appointment_id`, `reference_code`, `user_id`, `walkin_name`, `walkin_mobile`, `service_id`, `category_id`, `counter_id`, `client_status`, `appointment_date`, `appointment_time`, `arrival_time`, `source`, `status`, `created_at`) VALUES
(1, 'REF-20260203-6493', 1, NULL, NULL, 13, 2, 3, 'Regular', '2026-02-03', '13:30:00', '2026-02-03 14:06:38', 'online', 'completed', '2026-02-03 12:30:35'),
(2, 'REF-20260203-98D1', 1, NULL, NULL, 10, 1, 1, 'Regular', '2026-02-04', '09:30:00', '2026-02-04 08:29:34', 'online', 'completed', '2026-02-03 12:36:37'),
(3, 'REF-20260203-ABB8', 1, NULL, NULL, 11, 1, 1, 'Regular', '2026-02-05', '13:00:00', NULL, 'online', 'no_show', '2026-02-03 13:06:40'),
(4, 'REF-20260203-3E6F', 1, NULL, NULL, 14, 2, 3, 'Regular', '2026-02-03', '13:45:00', '2026-02-03 14:15:14', 'online', 'completed', '2026-02-03 13:44:55'),
(7, 'REF-20260203-F0DD', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-03', NULL, '2026-02-03 14:17:59', 'walkin', 'completed', '2026-02-03 14:17:59'),
(8, 'REF-20260203-7C84', 4, NULL, NULL, 14, 2, 3, 'Regular', '2026-02-03', '15:10:00', '2026-02-03 15:04:20', 'online', 'completed', '2026-02-03 15:04:03'),
(9, 'REF-20260203-E41D', 1, NULL, NULL, 11, 1, 1, 'Regular', '2026-02-03', '16:35:00', '2026-02-03 16:34:41', 'online', 'completed', '2026-02-03 16:34:14'),
(10, 'REF-20260203-FD44', 4, NULL, NULL, 12, 1, 2, 'Regular', '2026-02-03', '16:35:00', '2026-02-03 16:35:42', 'online', 'completed', '2026-02-03 16:35:31'),
(11, 'REF-20260203-9E5C', 4, NULL, NULL, 15, 2, 4, 'Regular', '2026-02-03', '10:00:00', '2026-02-03 17:08:27', 'online', 'completed', '2026-02-03 16:36:11'),
(12, 'REF-20260203-7F91', 1, NULL, NULL, 13, 2, 3, 'Regular', '2026-02-03', '16:36:00', '2026-02-03 16:37:18', 'online', 'completed', '2026-02-03 16:36:56'),
(13, 'REF-20260203-1760', 4, NULL, NULL, 13, 2, 3, 'Regular', '2026-02-03', '16:37:00', '2026-02-03 16:38:04', 'online', 'completed', '2026-02-03 16:37:51'),
(14, 'REF-20260203-5DAB', NULL, '', '', 14, 2, 3, 'Regular', '2026-02-03', NULL, '2026-02-03 16:41:55', 'walkin', 'completed', '2026-02-03 16:41:55'),
(15, 'REF-20260203-C6B3', 4, NULL, NULL, 14, 2, 3, 'Regular', '2026-02-03', '17:00:00', '2026-02-03 17:08:41', 'online', 'completed', '2026-02-03 17:08:03'),
(16, 'REF-20260203-BD33', 1, NULL, NULL, 14, 2, 3, 'Regular', '2026-02-04', '10:00:00', '2026-02-04 08:29:41', 'online', 'completed', '2026-02-03 18:37:51'),
(17, 'REF-20260203-BD3F', NULL, '', '', 13, 2, 3, 'Regular', '2026-02-03', NULL, '2026-02-03 18:41:58', 'walkin', 'completed', '2026-02-03 18:41:58'),
(18, 'REF-20260204-309F', 6, NULL, NULL, 11, 1, 2, 'Regular', '2026-02-04', '10:00:00', '2026-02-04 09:01:06', 'online', 'completed', '2026-02-04 09:00:40'),
(20, 'REF-20260204-57A6', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 09:18:37', 'walkin', 'completed', '2026-02-04 09:18:37'),
(21, 'REF-20260204-8B9F', 6, NULL, NULL, 12, 1, 3, 'Regular', '2026-02-04', '10:20:00', '2026-02-04 09:20:04', 'online', 'completed', '2026-02-04 09:19:45'),
(22, 'REF-20260204-C9CD', 6, NULL, NULL, 15, 2, 4, 'Regular', '2026-02-04', '10:30:00', '2026-02-04 09:33:13', 'online', 'completed', '2026-02-04 09:33:06'),
(23, 'REF-20260204-ED3E', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 09:42:29', 'walkin', 'completed', '2026-02-04 09:42:29'),
(24, 'REF-20260204-9271', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 09:46:17', 'walkin', 'completed', '2026-02-04 09:46:17'),
(25, 'REF-20260204-16B8', NULL, '', '', 11, 1, 2, 'Regular', '2026-02-04', NULL, '2026-02-04 09:46:57', 'walkin', 'completed', '2026-02-04 09:46:57'),
(26, 'REF-20260204-2267', 6, NULL, NULL, 13, 2, 4, 'Regular', '2026-02-04', '10:00:00', '2026-02-04 09:51:00', 'online', 'completed', '2026-02-04 09:49:49'),
(27, 'REF-20260204-4CE5', 6, NULL, NULL, 14, 2, 4, 'Regular', '2026-02-04', '11:00:00', '2026-02-04 09:50:17', 'online', 'completed', '2026-02-04 09:50:04'),
(28, 'REF-20260204-53AA', 6, NULL, NULL, 15, 2, 5, 'Regular', '2026-02-04', '13:00:00', NULL, 'online', 'no_show', '2026-02-04 09:51:41'),
(29, 'REF-20260204-C3AE', 1, NULL, NULL, 15, 2, 5, 'Regular', '2026-02-04', '11:00:00', '2026-02-04 09:52:29', 'online', 'completed', '2026-02-04 09:52:18'),
(30, 'REF-20260204-D0F1', 1, NULL, NULL, 10, 1, 1, 'Regular', '2026-02-04', '11:30:00', '2026-02-04 09:53:01', 'online', 'completed', '2026-02-04 09:52:54'),
(31, 'REF-20260204-5C2F', 1, NULL, NULL, 11, 1, 2, 'Regular', '2026-02-04', '13:30:00', '2026-02-04 09:54:07', 'online', 'completed', '2026-02-04 09:54:01'),
(32, 'REF-20260204-1211', 4, NULL, NULL, 15, 2, 5, 'Regular', '2026-02-04', '09:58:00', '2026-02-04 09:58:40', 'online', 'completed', '2026-02-04 09:58:28'),
(33, 'REF-20260204-4381', 4, NULL, NULL, 11, 1, 2, 'Regular', '2026-02-04', '10:01:00', '2026-02-04 10:01:15', 'online', 'completed', '2026-02-04 10:01:08'),
(34, 'REF-20260204-4F08', 4, NULL, NULL, 12, 1, 3, 'Regular', '2026-02-04', '10:01:00', '2026-02-04 10:02:05', 'online', 'completed', '2026-02-04 10:01:57'),
(35, 'REF-20260204-DD25', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 10:02:09', 'walkin', 'completed', '2026-02-04 10:02:09'),
(36, 'REF-20260204-13DB', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-04', NULL, '2026-02-04 10:02:13', 'walkin', 'completed', '2026-02-04 10:02:13'),
(37, 'REF-20260204-381F', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-04', NULL, '2026-02-04 10:02:17', 'walkin', 'completed', '2026-02-04 10:02:17'),
(38, 'REF-20260204-8F74', NULL, '', '', 11, 1, 2, 'Regular', '2026-02-04', NULL, '2026-02-04 10:02:26', 'walkin', 'completed', '2026-02-04 10:02:26'),
(39, 'REF-20260204-2A23', 7, NULL, NULL, 10, 1, 1, 'Regular', '2026-02-04', '11:30:00', '2026-02-04 11:12:40', 'online', 'completed', '2026-02-04 11:11:36'),
(40, 'REF-20260204-55D2', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-04', NULL, '2026-02-04 11:14:35', 'walkin', 'completed', '2026-02-04 11:14:35'),
(41, 'REF-20260204-7287', 1, NULL, NULL, 14, 2, 4, 'Regular', '2026-02-04', '13:30:00', '2026-02-04 12:50:07', 'online', 'completed', '2026-02-04 12:49:58'),
(42, 'REF-20260204-B368', 1, NULL, NULL, 13, 2, 4, 'Regular', '2026-02-04', '13:00:00', '2026-02-04 12:58:42', 'online', 'completed', '2026-02-04 12:58:32'),
(43, 'REF-20260204-CE86', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 13:02:34', 'walkin', 'completed', '2026-02-04 13:02:34'),
(44, 'REF-20260204-DC7E', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 13:02:38', 'walkin', 'completed', '2026-02-04 13:02:38'),
(45, 'REF-20260204-ADD1', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-04', NULL, '2026-02-04 13:02:41', 'walkin', 'completed', '2026-02-04 13:02:41'),
(46, 'REF-20260204-83D4', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-04', NULL, '2026-02-04 13:02:45', 'walkin', 'completed', '2026-02-04 13:02:45'),
(47, 'REF-20260204-A9F6', NULL, '', '', 11, 1, 2, 'Regular', '2026-02-04', NULL, '2026-02-04 13:02:49', 'walkin', 'completed', '2026-02-04 13:02:49'),
(48, 'REF-20260204-5693', NULL, '', '', 12, 1, 3, 'Regular', '2026-02-04', NULL, '2026-02-04 13:02:54', 'walkin', 'completed', '2026-02-04 13:02:54'),
(49, 'REF-20260204-1E80', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 13:02:59', 'walkin', 'completed', '2026-02-04 13:02:59'),
(50, 'REF-20260204-ACD7', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-04', NULL, '2026-02-04 13:03:02', 'walkin', 'completed', '2026-02-04 13:03:02'),
(51, 'REF-20260204-925B', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-04', NULL, '2026-02-04 13:03:02', 'walkin', 'completed', '2026-02-04 13:03:02'),
(52, 'REF-20260204-8949', NULL, '', '', 12, 1, 3, 'Regular', '2026-02-04', NULL, '2026-02-04 13:05:32', 'walkin', 'completed', '2026-02-04 13:05:32'),
(53, 'REF-20260204-B536', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 13:09:35', 'walkin', 'completed', '2026-02-04 13:09:35'),
(54, 'REF-20260204-7CEA', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 13:09:39', 'walkin', 'completed', '2026-02-04 13:09:39'),
(55, 'REF-20260204-90C0', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-04', NULL, '2026-02-04 13:09:44', 'walkin', 'completed', '2026-02-04 13:09:44'),
(56, 'REF-20260204-B84C', NULL, '', '', 11, 1, 2, 'Regular', '2026-02-04', NULL, '2026-02-04 13:09:48', 'walkin', 'completed', '2026-02-04 13:09:48'),
(57, 'REF-20260204-EA83', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-04', NULL, '2026-02-04 13:10:24', 'walkin', 'completed', '2026-02-04 13:10:24'),
(58, 'REF-20260204-9868', NULL, '', '', 12, 1, 3, 'Regular', '2026-02-04', NULL, '2026-02-04 13:10:54', 'walkin', 'completed', '2026-02-04 13:10:54'),
(59, 'REF-20260204-29E9', NULL, '', '', 11, 1, 2, 'Regular', '2026-02-04', NULL, '2026-02-04 13:25:27', 'walkin', 'completed', '2026-02-04 13:25:27'),
(60, 'REF-20260204-9ACE', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-04', NULL, '2026-02-04 13:25:30', 'walkin', 'completed', '2026-02-04 13:25:30'),
(61, 'REF-20260204-3B0A', NULL, '', '', 12, 1, 3, 'Regular', '2026-02-04', NULL, '2026-02-04 13:25:33', 'walkin', 'completed', '2026-02-04 13:25:33'),
(62, 'REF-20260204-CC33', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 13:25:37', 'walkin', 'completed', '2026-02-04 13:25:37'),
(63, 'REF-20260204-DDBC', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-04', NULL, '2026-02-04 13:25:40', 'walkin', 'completed', '2026-02-04 13:25:40'),
(64, 'REF-20260210-42B8', 1, NULL, NULL, 14, 2, 4, 'Regular', '2026-02-10', '12:30:00', '2026-02-10 12:08:38', 'online', 'completed', '2026-02-10 12:07:39'),
(65, 'REF-20260210-C6F8', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-10', NULL, '2026-02-10 12:08:50', 'walkin', 'completed', '2026-02-10 12:08:50'),
(66, 'REF-20260210-72D7', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-10', NULL, '2026-02-10 12:08:56', 'walkin', 'completed', '2026-02-10 12:08:56'),
(67, 'REF-20260210-0243', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-10', NULL, '2026-02-10 12:10:33', 'walkin', 'completed', '2026-02-10 12:10:33'),
(68, 'REF-20260210-916D', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-10', NULL, '2026-02-10 12:10:36', 'walkin', 'completed', '2026-02-10 12:10:36'),
(69, 'REF-20260210-9C6C', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-10', NULL, '2026-02-10 12:10:40', 'walkin', 'completed', '2026-02-10 12:10:40'),
(70, 'REF-20260210-EAFB', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-10', NULL, '2026-02-10 12:10:44', 'walkin', 'completed', '2026-02-10 12:10:44'),
(71, 'REF-20260210-7789', NULL, '', '', 11, 1, 2, 'Regular', '2026-02-10', NULL, '2026-02-10 12:10:48', 'walkin', 'completed', '2026-02-10 12:10:48'),
(72, 'REF-20260210-964C', NULL, '', '', 12, 1, 3, 'Regular', '2026-02-10', NULL, '2026-02-10 12:10:52', 'walkin', 'completed', '2026-02-10 12:10:52'),
(73, 'REF-20260213-9A73', 6, NULL, NULL, 14, 2, 4, 'Regular', '2026-02-13', '14:35:00', '2026-02-13 14:31:27', 'online', 'completed', '2026-02-13 14:31:14'),
(74, 'REF-20260213-4704', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-13', NULL, '2026-02-13 14:42:12', 'walkin', 'completed', '2026-02-13 14:42:12'),
(75, 'REF-20260213-8F55', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-13', NULL, '2026-02-13 14:42:15', 'walkin', 'completed', '2026-02-13 14:42:15'),
(76, 'REF-20260213-311B', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-13', NULL, '2026-02-13 14:42:17', 'walkin', 'completed', '2026-02-13 14:42:17'),
(77, 'REF-20260213-4ED5', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-13', NULL, '2026-02-13 14:42:20', 'walkin', 'completed', '2026-02-13 14:42:20'),
(78, 'REF-20260213-D06D', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-13', NULL, '2026-02-13 14:42:24', 'walkin', 'completed', '2026-02-13 14:42:24'),
(79, 'REF-20260213-82BE', NULL, '', '', 12, 1, 3, 'Regular', '2026-02-13', NULL, '2026-02-13 14:42:28', 'walkin', 'completed', '2026-02-13 14:42:28'),
(80, 'REF-20260213-7D5E', 6, NULL, NULL, 12, 1, 3, 'Regular', '2026-02-13', '15:55:00', '2026-02-13 15:54:34', 'online', 'completed', '2026-02-13 15:54:20'),
(81, 'REF-20260213-5CC3', NULL, '', '', 11, 1, 2, 'Regular', '2026-02-13', NULL, '2026-02-13 16:29:01', 'walkin', 'completed', '2026-02-13 16:29:01'),
(82, 'REF-20260213-ECB6', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-13', NULL, '2026-02-13 16:29:07', 'walkin', 'completed', '2026-02-13 16:29:07'),
(83, 'REF-20260213-7852', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-13', NULL, '2026-02-13 16:29:17', 'walkin', 'completed', '2026-02-13 16:29:17'),
(84, 'REF-20260213-7429', NULL, '', '', 12, 1, 3, 'Regular', '2026-02-13', NULL, '2026-02-13 16:29:25', 'walkin', 'completed', '2026-02-13 16:29:25'),
(85, 'REF-20260213-AC09', 1, NULL, NULL, 12, 1, 3, 'Regular', '2026-02-14', '08:30:00', NULL, 'online', 'no_show', '2026-02-13 16:44:22'),
(86, 'REF-20260213-103B', 4, NULL, NULL, 15, 2, 5, 'Regular', '2026-02-14', '08:30:00', NULL, 'online', 'no_show', '2026-02-13 17:26:21'),
(87, 'REF-20260218-E82E', 18, NULL, NULL, 11, 1, 2, 'Regular', '2026-03-03', '08:00:00', NULL, 'online', 'booked', '2026-02-18 20:47:11'),
(88, 'REF-20260226-3A43', 4, NULL, NULL, 14, 2, 4, 'Regular', '2026-02-26', '12:24:00', NULL, 'online', 'no_show', '2026-02-26 12:24:28'),
(89, 'REF-20260226-EA62', 4, NULL, NULL, 13, 2, 4, 'Regular', '2026-02-26', '12:25:00', NULL, 'online', 'no_show', '2026-02-26 12:25:30'),
(90, 'REF-20260226-0F17', 4, NULL, NULL, 14, 2, 4, 'Regular', '2026-02-26', '12:26:00', NULL, 'online', 'no_show', '2026-02-26 12:26:17'),
(91, 'REF-20260226-905A', 4, NULL, NULL, 13, 2, 4, 'Regular', '2026-02-26', '14:30:00', '2026-02-26 12:27:52', 'online', 'completed', '2026-02-26 12:26:50'),
(92, 'REF-20260226-7516', 4, NULL, NULL, 15, 2, 5, 'Regular', '2026-02-26', '14:30:00', '2026-02-26 12:28:03', 'online', 'completed', '2026-02-26 12:27:19'),
(94, 'REF-20260226-5D87', 4, NULL, NULL, 12, 1, 2, 'Senior Citizen', '2026-02-26', '13:40:00', '2026-02-26 13:20:38', 'online', 'completed', '2026-02-26 13:20:24'),
(97, 'REF-20260226-FA45', 1, NULL, NULL, 12, 1, 4, 'Pregnant', '2026-02-26', '14:00:00', '2026-02-26 13:22:35', 'online', 'completed', '2026-02-26 13:22:28'),
(98, 'REF-20260226-91A9', NULL, '', '', 15, 2, 8, 'PWD', '2026-02-26', NULL, '2026-02-26 20:05:38', 'walkin', 'completed', '2026-02-26 20:05:38'),
(99, 'REF-20260226-22C6', NULL, '', '', 14, 2, 8, 'PWD', '2026-02-26', NULL, '2026-02-26 20:13:34', 'walkin', 'completed', '2026-02-26 20:13:34'),
(100, 'REF-20260226-A0DA', NULL, '', '', 14, 2, 2, 'PWD', '2026-02-26', NULL, '2026-02-26 21:36:10', 'walkin', 'completed', '2026-02-26 21:36:10'),
(101, 'REF-20260226-DA79', NULL, '', '', 15, 2, 2, 'Senior Citizen', '2026-02-26', NULL, '2026-02-26 21:36:24', 'walkin', 'completed', '2026-02-26 21:36:24'),
(102, 'REF-20260226-5A61', NULL, '', '', 13, 2, 2, 'Pregnant', '2026-02-26', NULL, '2026-02-26 21:36:37', 'walkin', 'completed', '2026-02-26 21:36:37'),
(103, 'REF-20260226-6D85', NULL, '', '', 12, 1, 2, 'PWD', '2026-02-26', NULL, '2026-02-26 21:36:49', 'walkin', 'completed', '2026-02-26 21:36:49'),
(104, 'REF-20260226-EA52', NULL, '', '', 14, 2, 8, 'Regular', '2026-02-26', NULL, '2026-02-26 21:36:59', 'walkin', 'completed', '2026-02-26 21:36:59'),
(105, 'REF-20260226-99EF', NULL, '', '', 13, 2, 8, 'Regular', '2026-02-26', NULL, '2026-02-26 21:57:17', 'walkin', 'completed', '2026-02-26 21:57:17'),
(106, 'REF-20260226-A1D8', NULL, '', '', 14, 2, 2, 'PWD', '2026-02-26', NULL, '2026-02-26 21:57:23', 'walkin', 'completed', '2026-02-26 21:57:23'),
(107, 'REF-20260226-334F', 4, NULL, NULL, 14, 2, 2, 'PWD', '2026-02-27', '09:00:00', '2026-02-27 08:39:55', 'online', 'completed', '2026-02-26 23:19:02'),
(108, 'REF-20260226-9699', 1, NULL, NULL, 15, 2, 2, 'PWD', '2026-02-27', '09:30:00', '2026-02-27 08:40:23', 'online', 'completed', '2026-02-26 23:36:46'),
(109, 'REF-20260226-0913', 18, NULL, NULL, 12, 1, 2, 'Pregnant', '2026-02-27', '10:37:00', '2026-02-27 08:40:53', 'online', 'completed', '2026-02-26 23:37:42'),
(110, 'REF-20260227-8338', NULL, '', '', 10, 1, 7, 'Regular', '2026-02-27', NULL, '2026-02-27 08:47:27', 'walkin', 'checked_in', '2026-02-27 08:47:27'),
(111, 'REF-20260301-E7BD', 4, NULL, NULL, 13, 2, 9, 'Regular', '2026-03-01', '16:25:00', '2026-03-01 15:27:10', 'online', 'completed', '2026-03-01 15:25:40'),
(112, 'REF-20260301-875A', 4, NULL, NULL, 14, 2, 2, 'PWD', '2026-03-01', '16:45:00', '2026-03-01 15:42:29', 'online', 'completed', '2026-03-01 15:31:33'),
(113, 'REF-20260301-4778', 1, NULL, NULL, 15, 2, 2, 'Pregnant', '2026-03-01', '16:21:00', '2026-03-01 16:03:56', 'online', 'completed', '2026-03-01 16:03:13'),
(114, 'REF-20260301-5E88', NULL, 'John Die', '', 13, 2, 8, 'Regular', '2026-03-01', NULL, '2026-03-01 23:16:09', 'walkin', 'completed', '2026-03-01 23:16:09'),
(115, 'REF-20260301-4AB1', NULL, 'Doe Die', '', 15, 2, 8, 'Regular', '2026-03-01', NULL, '2026-03-01 23:16:25', 'walkin', 'completed', '2026-03-01 23:16:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`),
  ADD UNIQUE KEY `uq_appointments_reference` (`reference_code`),
  ADD KEY `idx_appt_user_date` (`user_id`,`appointment_date`),
  ADD KEY `idx_appt_status_date` (`status`,`appointment_date`),
  ADD KEY `idx_appt_category_date` (`category_id`,`appointment_date`),
  ADD KEY `fk_appt_service` (`service_id`),
  ADD KEY `fk_appt_counter` (`counter_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `fk_appt_category` FOREIGN KEY (`category_id`) REFERENCES `queue_categories` (`category_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_appt_counter` FOREIGN KEY (`counter_id`) REFERENCES `service_counters` (`counter_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_appt_service` FOREIGN KEY (`service_id`) REFERENCES `services` (`service_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_appt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
