-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2026 at 04:38 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `item_inventory_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `table_name` varchar(80) NOT NULL,
  `record_id` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`log_id`, `user_id`, `action`, `table_name`, `record_id`, `details`, `created_at`) VALUES
(2, 2, 'Create staff account', 'users', 2, 'Staff registered: Edgen07', '2026-03-06 06:30:38'),
(3, 2, 'Update category', 'categories', 1, 'Changed is_active to 1', '2026-03-06 06:31:14'),
(4, 3, 'Create staff account', 'users', 3, 'Staff registered: admin', '2026-03-06 06:32:19'),
(5, 2, 'Create client', 'clients', 1, 'Created client: dela cuz', '2026-03-06 06:34:38'),
(6, 2, 'Create client', 'clients', 2, 'Created client: Dela Fernan', '2026-03-06 06:35:00'),
(7, 2, 'Create item', 'items', 1, 'Created item Stall Chair [ITM-2026-001]', '2026-03-06 06:36:39'),
(8, 2, 'Create item', 'items', 2, 'Created item Printer [ITM-2026-002]', '2026-03-06 06:37:30'),
(9, 2, 'Borrow item', 'transactions', 1, 'Borrowed quantity 10 for item ID 1', '2026-03-06 06:38:01'),
(10, 2, 'Return item', 'transactions', 2, 'Returned quantity 9 for item ID 1', '2026-03-06 06:38:46'),
(11, 2, 'Return item', 'transactions', 3, 'Returned quantity 1 for item ID 1', '2026-03-06 06:39:22'),
(12, 2, 'Delete item', 'items', 2, 'Deleted item id: 2', '2026-03-06 06:57:24'),
(13, 2, 'Create item', 'items', 4, 'Created item: Printer [ITM-2026-002]', '2026-03-06 06:57:49'),
(14, 2, 'Borrow item', 'transactions', 4, 'Borrowed quantity 2 for item ID 4', '2026-03-06 07:07:25'),
(15, 2, 'Return item', 'transactions', 5, 'Returned quantity 2 for item_id 4', '2026-03-06 07:26:40'),
(16, 2, 'Update category', 'categories', 4, 'Changed is_active to 0', '2026-03-06 07:27:27'),
(17, 2, 'Create item', 'items', 5, 'Created item: Personal Computer [ITM-2026-003]', '2026-03-06 07:46:18'),
(18, 2, 'Update category', 'categories', 4, 'Changed is_active to 1', '2026-03-06 07:46:45'),
(19, 2, 'Borrow item', 'transactions', 6, 'Borrowed quantity 25 for item_id 4', '2026-03-06 07:58:40'),
(20, 2, 'Return item', 'transactions', 7, 'Returned quantity 25 for item_id 4 by client_id 1', '2026-03-06 08:01:43'),
(21, 2, 'Borrow item', 'transactions', 8, 'Borrowed quantity 20 for item_id 1', '2026-03-06 08:06:22'),
(22, 2, 'Return item', 'transactions', 9, 'Returned quantity 20 for item_id 1 by client_id 1', '2026-03-06 08:06:59'),
(23, 2, 'Create item', 'items', 6, 'Created item: Bluetooth Speaker [ITM-2026-004]', '2026-03-06 08:19:11'),
(24, 3, 'Update staff status', 'users', 2, 'Changed active status to 0', '2026-03-06 08:19:51'),
(25, 3, 'Update staff status', 'users', 2, 'Changed active status to 1', '2026-03-06 08:19:58'),
(26, 3, 'Update staff status', 'users', 2, 'Changed active status to 0', '2026-03-06 08:19:59'),
(27, 3, 'Update staff status', 'users', 2, 'Changed active status to 1', '2026-03-06 08:20:41'),
(28, 2, 'Create item', 'items', 7, 'Created item: ballpen [ITM-2026-005]', '2026-03-06 08:31:55'),
(29, 2, 'Delete item', 'items', 7, 'Deleted item id: 7', '2026-03-06 09:28:37'),
(30, 2, 'Delete item', 'items', 6, 'Deleted item id: 6', '2026-03-06 09:28:42'),
(31, 2, 'Create client', 'clients', 3, 'Created client: Joshua Galorport', '2026-03-06 12:39:19'),
(32, 2, 'Borrow item', 'transactions', 10, 'Borrowed quantity 20 for item_id 1', '2026-03-06 12:40:00'),
(33, 2, 'Return item', 'transactions', 11, 'Returned quantity 20 for item_id 1 by client_id 3', '2026-03-06 12:41:16'),
(34, 2, 'Borrow item', 'transactions', 12, 'Borrowed quantity 35 for item_id 4', '2026-03-06 12:41:56'),
(35, 2, 'Return item', 'transactions', 13, 'Returned quantity 35 for item_id 4 by client_id 3', '2026-03-06 12:42:35'),
(36, 3, 'Update staff status', 'users', 2, 'Changed active status to 0', '2026-03-06 12:43:17'),
(37, 3, 'Update staff status', 'users', 2, 'Changed active status to 1', '2026-03-06 12:44:08'),
(38, 2, 'Update item', 'items', 5, 'Updated item: Personal Computer', '2026-03-07 01:57:37'),
(39, 2, 'Update item', 'items', 4, 'Updated item: Printer', '2026-03-07 01:57:46'),
(40, 2, 'Update item', 'items', 1, 'Updated item: Stall Chair', '2026-03-07 01:57:54'),
(41, 2, 'Create item', 'items', 8, 'Created: Bluetooth Speaker [ITM-2026-004]', '2026-03-07 02:36:22'),
(42, 2, 'Borrow item', 'transactions', 14, 'Borrowed qty 9 for item_id 8', '2026-03-07 02:37:09'),
(43, 2, 'Return item', 'transactions', 15, 'Returned quantity 9 for item_id 8 by client_id 3', '2026-03-07 02:38:25'),
(44, 2, 'Update item', 'items', 4, 'Updated: Printer', '2026-03-07 02:39:44'),
(45, 2, 'Update item', 'items', 5, 'Updated: Laptop', '2026-03-07 02:41:27'),
(46, 2, 'Update item', 'items', 1, 'Updated: Stall Chair', '2026-03-07 02:41:39'),
(47, 2, 'Archive item', 'items', 1, 'Archived: Stall Chair', '2026-03-07 02:42:57'),
(48, 2, 'Create item', 'items', 9, 'Created: Stall Chair [ITM-2026-005]', '2026-03-07 02:43:24'),
(49, 2, 'Archive item', 'items', 8, 'Archived: Bluetooth Speaker', '2026-03-07 02:43:52'),
(50, 2, 'Restore item', 'items', 8, 'Restored: Bluetooth Speaker', '2026-03-07 02:43:57'),
(51, 2, 'Borrow item', 'transactions', 16, 'Borrowed qty 100 for item_id 9', '2026-03-07 02:44:41'),
(52, 2, 'Return item', 'transactions', 17, 'Returned quantity 100 for item_id 9 by client_id 1', '2026-03-07 02:45:30'),
(53, 2, 'Restore item', 'items', 1, 'Restored: Stall Chair', '2026-03-07 02:46:08'),
(54, 2, 'Archive item', 'items', 1, 'Archived: Stall Chair', '2026-03-07 02:46:14'),
(55, 2, 'Force delete item', 'items', 1, 'Permanently deleted archived item: Stall Chair including all transaction records.', '2026-03-07 02:51:29'),
(56, 2, 'Create item', 'items', 10, 'Created: Grass Cutter [ITM-2026-006]', '2026-03-07 03:24:53'),
(57, 2, 'Update item', 'items', 10, 'Updated: Grass Cutter', '2026-03-07 03:37:45'),
(58, 2, 'Update item', 'items', 10, 'Updated: Grass Cutter', '2026-03-07 03:37:55'),
(59, 2, 'Archive client', 'clients', 1, 'Archived client: dela cuz', '2026-03-07 03:49:20'),
(60, 2, 'Restore client', 'clients', 1, 'Restored client: dela cuz', '2026-03-07 03:52:09'),
(61, 2, 'Create client', 'clients', 4, 'Created client: John doe', '2026-03-07 03:55:52'),
(62, 2, 'Archive client', 'clients', 2, 'Archived client: Dela Fernan', '2026-03-07 03:59:24'),
(63, 2, 'Archive client', 'clients', 1, 'Archived client: dela cuz', '2026-03-07 03:59:32'),
(64, 2, 'Archive client', 'clients', 3, 'Archived client: Joshua Galorport', '2026-03-07 03:59:35'),
(65, 2, 'Restore client', 'clients', 3, 'Restored client: Joshua Galorport', '2026-03-07 04:05:34'),
(66, 2, 'Restore client', 'clients', 1, 'Restored client: dela cuz', '2026-03-07 04:05:36'),
(67, 2, 'Restore client', 'clients', 2, 'Restored client: Dela Fernan', '2026-03-07 04:05:39'),
(68, 2, 'Delete client', 'clients', 4, 'Deleted client: John doe', '2026-03-07 04:09:26'),
(69, 2, 'Create client', 'clients', 5, 'Created client: John doe', '2026-03-07 04:10:14'),
(70, 2, 'Update client', 'clients', 3, 'Updated client: Joshua Galorport', '2026-03-07 04:10:31'),
(71, 2, 'Archive client', 'clients', 1, 'Archived client: dela cuz', '2026-03-07 04:10:42'),
(72, 2, 'Restore client', 'clients', 1, 'Restored client: dela cuz', '2026-03-07 04:10:46'),
(73, 4, 'Create staff account', 'users', 4, 'Staff registered: John', '2026-03-07 04:36:15'),
(74, 4, 'Borrow item', 'transactions', 18, 'Borrowed qty 2 for item_id 10', '2026-03-07 04:36:57'),
(75, 4, 'Borrow item', 'transactions', 19, 'Borrowed qty 1 for item_id 8', '2026-03-07 04:37:15'),
(76, 4, 'Borrow item', 'transactions', 20, 'Borrowed qty 2 for item_id 5', '2026-03-07 04:37:34'),
(77, 4, 'Return item', 'transactions', 21, 'Returned quantity 2 for item_id 5 by client_id 5', '2026-03-07 04:37:49'),
(78, 4, 'Return item', 'transactions', 22, 'Returned quantity 1 for item_id 8 by client_id 2', '2026-03-07 04:38:08'),
(79, 4, 'Return item', 'transactions', 23, 'Returned quantity 2 for item_id 10 by client_id 5', '2026-03-07 04:38:23'),
(80, 2, 'Archive client', 'clients', 3, 'Archived client: Joshua Galorport', '2026-03-07 05:14:26'),
(81, 2, 'Restore client', 'clients', 3, 'Restored client: Joshua Galorport', '2026-03-07 05:14:33'),
(82, 2, 'Archive item', 'items', 4, 'Archived: Printer', '2026-03-07 06:08:37'),
(83, 2, 'Restore item', 'items', 4, 'Restored: Printer', '2026-03-07 06:08:46'),
(84, 2, 'Toggle category status', 'categories', 1, 'Changed status to deactivated', '2026-03-07 08:27:58'),
(85, 2, 'Toggle category status', 'categories', 1, 'Changed status to activated', '2026-03-07 08:28:02'),
(86, 2, 'Create item', 'items', 11, 'Created: dasdsad [ITM-2026-0007]', '2026-03-07 08:36:53'),
(87, 2, 'Delete item', 'items', 11, 'Deleted: dasdsad', '2026-03-07 08:36:59'),
(88, 2, 'Create client', 'clients', 6, 'Created client: Kent Beron', '2026-03-07 08:37:34'),
(89, 2, 'Update client', 'clients', 6, 'Updated client: Kent Beron', '2026-03-07 08:37:49'),
(90, 2, 'Borrow item', 'transactions', 24, 'Borrowed qty 1 for item_id 5', '2026-03-07 08:38:42'),
(91, 2, 'Return item', 'transactions', 25, 'Returned quantity 1 for item_id 5 by client_id 6', '2026-03-07 08:39:01'),
(92, 2, 'Borrow item', 'transactions', 26, 'Borrowed qty 1 for item_id 5', '2026-03-07 08:40:31'),
(93, 2, 'Return item', 'transactions', 27, 'Returned quantity 1 for item_id 5 by client_id 3', '2026-03-07 08:41:20');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `description`, `is_active`, `created_at`) VALUES
(1, 'Electronics', 'Electronic devices and accessories', 1, '2026-03-06 06:29:13'),
(2, 'Furniture', 'Office and room furniture', 1, '2026-03-06 06:29:13'),
(3, 'Office Supplies', 'Daily office supplies', 1, '2026-03-06 06:29:13'),
(4, 'Tools', 'Maintenance and utility tools', 1, '2026-03-06 06:29:13');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `address` text DEFAULT NULL,
  `contact_no` varchar(50) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`client_id`, `full_name`, `address`, `contact_no`, `email`, `is_active`, `created_at`) VALUES
(1, 'dela cuz', 'Magcagong', '09778832381', 'del@gmail.com', 1, '2026-03-06 06:34:38'),
(2, 'Dela Fernan', 'Magcagong', '09752611718', 'fer@gmail.com', 1, '2026-03-06 06:35:00'),
(3, 'Joshua Galorport', 'tagbina', '069495945433', 'josh@gmail.com', 1, '2026-03-06 12:39:19'),
(5, 'John doe', 'Magcagong', '+639778832381', 'doe@gmail.com', 1, '2026-03-07 04:10:14'),
(6, 'Kent Beron', 'Magcagong, Maragusan', '07521311233', 'kent@gmail.com', 1, '2026-03-07 08:37:34');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `item_code` varchar(60) NOT NULL,
  `serial_barcode` varchar(120) DEFAULT NULL,
  `item_name` varchar(150) NOT NULL,
  `category_id` int(11) NOT NULL,
  `quantity_stock` int(11) NOT NULL DEFAULT 0,
  `quantity_borrowed` int(11) NOT NULL DEFAULT 0,
  `reorder_level` int(11) NOT NULL DEFAULT 5,
  `item_status` enum('available','low_stock','out_of_stock','inactive') NOT NULL DEFAULT 'available',
  `location` varchar(120) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `image_path` varchar(255) DEFAULT NULL,
  `is_archived` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_code`, `serial_barcode`, `item_name`, `category_id`, `quantity_stock`, `quantity_borrowed`, `reorder_level`, `item_status`, `location`, `notes`, `created_by`, `created_at`, `updated_at`, `image_path`, `is_archived`) VALUES
(4, 'ITM-2026-002', '42223323232', 'Printer', 3, 35, 0, 5, 'available', NULL, NULL, 2, '2026-03-06 06:57:49', '2026-03-07 06:08:46', 'uploads/items/item_20260307_103944_4f8078502722.webp', 0),
(5, 'ITM-2026-003', '932742884727', 'Laptop', 3, 40, 0, 5, 'available', NULL, NULL, 2, '2026-03-06 07:46:18', '2026-03-07 08:41:20', 'uploads/items/item_20260307_104127_808792cf9230.webp', 0),
(8, 'ITM-2026-004', '92973727322', 'Bluetooth Speaker', 1, 10, 0, 5, 'available', NULL, NULL, 2, '2026-03-07 02:36:22', '2026-03-07 04:38:08', 'uploads/items/item_20260307_103622_e9e2b94654fc.webp', 0),
(9, 'ITM-2026-005', '929183131', 'Stall Chair', 2, 100, 0, 5, 'available', NULL, NULL, 2, '2026-03-07 02:43:24', '2026-03-07 02:45:30', 'uploads/items/item_20260307_104324_27b009cf835e.webp', 0),
(10, 'ITM-2026-006', '623342342343', 'Grass Cutter', 4, 25, 0, 5, 'available', NULL, NULL, 2, '2026-03-07 03:24:53', '2026-03-07 04:38:23', 'uploads/items/item_20260307_113755_7f0135733208.webp', 0);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL,
  `transaction_type` enum('borrow','return') NOT NULL,
  `item_id` int(11) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `item_status_details` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `transacted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`transaction_id`, `transaction_type`, `item_id`, `client_id`, `staff_id`, `quantity`, `item_status_details`, `remarks`, `transacted_at`) VALUES
(4, 'borrow', 4, 2, 2, 2, NULL, '', '2026-03-06 07:07:25'),
(5, 'return', 4, 2, 2, 2, 'Goods', '', '2026-03-06 07:26:40'),
(6, 'borrow', 4, 1, 2, 25, NULL, '', '2026-03-06 07:58:40'),
(7, 'return', 4, 1, 2, 25, 'Goods', '', '2026-03-06 08:01:43'),
(12, 'borrow', 4, 3, 2, 35, NULL, '', '2026-03-06 12:41:56'),
(13, 'return', 4, 3, 2, 35, 'Damage', '', '2026-03-06 12:42:35'),
(14, 'borrow', 8, 3, 2, 9, NULL, '', '2026-03-07 02:37:09'),
(15, 'return', 8, 3, 2, 9, 'Goods', '', '2026-03-07 02:38:25'),
(16, 'borrow', 9, 1, 2, 100, NULL, '', '2026-03-07 02:44:41'),
(17, 'return', 9, 1, 2, 100, 'Goods', '', '2026-03-07 02:45:30'),
(18, 'borrow', 10, 5, 4, 2, NULL, '', '2026-03-07 04:36:57'),
(19, 'borrow', 8, 2, 4, 1, NULL, '', '2026-03-07 04:37:15'),
(20, 'borrow', 5, 5, 4, 2, NULL, '', '2026-03-07 04:37:34'),
(21, 'return', 5, 5, 4, 2, 'Goods', '', '2026-03-07 04:37:49'),
(22, 'return', 8, 2, 4, 1, '', '', '2026-03-07 04:38:08'),
(23, 'return', 10, 5, 4, 2, 'Goods', '', '2026-03-07 04:38:23'),
(24, 'borrow', 5, 6, 2, 1, NULL, '', '2026-03-07 08:38:42'),
(25, 'return', 5, 6, 2, 1, 'Goods', '', '2026-03-07 08:39:01'),
(26, 'borrow', 5, 3, 2, 1, NULL, '', '2026-03-07 08:40:31'),
(27, 'return', 5, 3, 2, 1, 'Goods', '', '2026-03-07 08:41:20');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(120) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','staff') NOT NULL DEFAULT 'staff',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `username`, `password_hash`, `role`, `is_active`, `created_at`) VALUES
(2, 'Edgen Bill Bangit', 'Edgen07', '$2y$10$OEkqCPzr2iwvxUGIshR8IOYrLoBKQ4hSMc0KZizpSkAJysC2h7I0G', 'staff', 1, '2026-03-06 06:30:38'),
(3, 'cactus', 'admin', '$2y$10$2onl0mPc7KlFd3i2KWddN.UIYglpo3xyXOUKwGIBB6lwuNAKrwXrK', 'admin', 1, '2026-03-06 06:32:19'),
(4, 'John Doe', 'John', '$2y$10$6KsLIeYbqytNTSf0DmryJeh.DtkkKS7DnynH.V4vTgydpNv2SBWc2', 'staff', 1, '2026-03-07 04:36:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `fk_audit_user` (`user_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_name` (`category_name`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`),
  ADD UNIQUE KEY `item_code` (`item_code`),
  ADD UNIQUE KEY `serial_barcode` (`serial_barcode`),
  ADD KEY `fk_items_category` (`category_id`),
  ADD KEY `fk_items_user` (`created_by`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `fk_tx_item` (`item_id`),
  ADD KEY `fk_tx_client` (`client_id`),
  ADD KEY `fk_tx_staff` (`staff_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `fk_items_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_items_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `fk_tx_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tx_item` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tx_staff` FOREIGN KEY (`staff_id`) REFERENCES `users` (`user_id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
