-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2026 at 04:39 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `philhealth_queue_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `appointment_type_id` int(11) NOT NULL,
  `appointment_date` date NOT NULL,
  `time_slot` time NOT NULL,
  `status` enum('Booked','Cancelled','CheckedIn','Queued','Serving','Done','NoShow') DEFAULT 'Booked',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reference_code` varchar(32) DEFAULT NULL,
  `source` enum('Online','WalkIn') NOT NULL DEFAULT 'Online',
  `walkin_name` varchar(120) DEFAULT NULL,
  `walkin_phone` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `user_id`, `appointment_type_id`, `appointment_date`, `time_slot`, `status`, `notes`, `created_at`, `reference_code`, `source`, `walkin_name`, `walkin_phone`) VALUES
(1, 2, 1, '2026-02-06', '00:54:00', 'Done', NULL, '2026-02-06 03:54:30', NULL, 'Online', NULL, NULL),
(2, 2, 2, '2026-02-06', '12:00:00', 'Done', NULL, '2026-02-06 03:58:20', NULL, 'Online', NULL, NULL),
(3, 2, 2, '2026-02-07', '13:00:00', 'Done', NULL, '2026-02-06 05:02:32', NULL, 'Online', NULL, NULL),
(4, 4, 1, '2026-02-06', '14:00:00', 'Done', NULL, '2026-02-06 05:04:13', NULL, 'Online', NULL, NULL),
(5, 5, 2, '2026-02-06', '14:30:00', 'NoShow', NULL, '2026-02-06 06:28:16', NULL, 'Online', NULL, NULL),
(6, 2, 3, '2026-02-06', '15:00:00', 'Done', NULL, '2026-02-06 06:50:21', 'PH-20260206-HAU4', 'Online', NULL, NULL),
(7, 2, 5, '2026-02-07', '10:30:00', 'NoShow', NULL, '2026-02-06 06:51:43', 'PH-20260206-GGM7', 'Online', NULL, NULL),
(8, 2, 6, '2026-02-06', '14:55:00', 'Done', NULL, '2026-02-06 06:56:00', 'PH-20260206-D8XZ', 'Online', NULL, NULL),
(9, 2, 5, '2026-02-06', '15:38:00', 'Done', NULL, '2026-02-06 07:38:27', 'PH-20260206-Z446', 'Online', NULL, NULL),
(10, 5, 3, '2026-02-06', '15:51:00', 'Done', NULL, '2026-02-06 07:51:53', 'PH-20260206-XYZN', 'Online', NULL, NULL),
(11, 5, 2, '2026-02-06', '16:30:00', 'Done', NULL, '2026-02-06 08:30:20', 'PH-20260206-6V3U', 'Online', NULL, NULL),
(12, 5, 5, '2026-02-06', '16:32:00', 'Done', NULL, '2026-02-06 08:32:35', 'PH-20260206-FWWR', 'Online', NULL, NULL),
(13, 2, 3, '2026-02-06', '16:59:00', 'Done', NULL, '2026-02-06 08:59:29', 'PH-20260206-W99C', 'Online', NULL, NULL),
(14, 2, 2, '2026-02-08', '09:30:00', 'Booked', NULL, '2026-02-07 13:42:42', 'PH-20260207-ZQHQ', 'Online', NULL, NULL),
(15, 2, 2, '2026-02-10', '13:00:00', 'Done', NULL, '2026-02-10 03:57:43', 'PH-20260210-HMK4', 'Online', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `appointment_types`
--

CREATE TABLE `appointment_types` (
  `id` int(11) NOT NULL,
  `service_category` enum('Membership','Hospitalization') NOT NULL,
  `name` varchar(120) NOT NULL,
  `purpose` text NOT NULL,
  `required_documents` text NOT NULL,
  `assigned_counter_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment_types`
--

INSERT INTO `appointment_types` (`id`, `service_category`, `name`, `purpose`, `required_documents`, `assigned_counter_id`) VALUES
(1, 'Membership', 'Membership Registration', 'Register new PhilHealth member', 'Duly accomplished PMRF, Valid ID, Birth Certificate', 1),
(2, 'Membership', 'Membership Renewal', 'Renew membership status', 'Valid ID, Proof of Contribution', 2),
(3, 'Membership', 'Update of Member Information', 'Update personal/member details', 'Valid ID, Supporting documents (e.g., marriage certificate, affidavit)', 3),
(4, 'Hospitalization', 'Admission Verification', 'Verify member admission eligibility', 'PhilHealth ID / PIN, Hospital Admission Form', 4),
(5, 'Hospitalization', 'Benefit Coverage Assessment', 'Assess benefit coverage', 'PhilHealth ID / PIN, Medical Abstract / Doctor’s Order', 4),
(6, 'Hospitalization', 'Hospital Billing & Claims Processing', 'Process hospital billing and claims', 'Claim Form, Official Receipts, Medical Records', 5);

-- --------------------------------------------------------

--
-- Table structure for table `counters`
--

CREATE TABLE `counters` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` enum('Membership','Hospitalization') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `counters`
--

INSERT INTO `counters` (`id`, `name`, `category`) VALUES
(1, 'Membership Registration Counter 1', 'Membership'),
(2, 'Membership Renewal Counter 2', 'Membership'),
(3, 'Update of Member Information Counter 3', 'Membership'),
(4, 'Admission Verification & Benefits Coverage Assessment Counter 1', 'Hospitalization'),
(5, 'Hospital Billing & Claims Processing Counter 2', 'Hospitalization');

-- --------------------------------------------------------

--
-- Table structure for table `queue_tickets`
--

CREATE TABLE `queue_tickets` (
  `id` int(11) NOT NULL,
  `appointment_id` int(11) DEFAULT NULL,
  `counter_id` int(11) NOT NULL,
  `queue_date` date NOT NULL,
  `queue_number` int(11) NOT NULL,
  `checked_in_at` datetime DEFAULT NULL,
  `called_at` datetime DEFAULT NULL,
  `served_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  `status` enum('Waiting','Calling','Serving','Done','Skipped') DEFAULT 'Waiting',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `served_by` int(11) DEFAULT NULL,
  `walkin_name` varchar(120) DEFAULT NULL,
  `walkin_phone` varchar(40) DEFAULT NULL,
  `appointment_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `queue_tickets`
--

INSERT INTO `queue_tickets` (`id`, `appointment_id`, `counter_id`, `queue_date`, `queue_number`, `checked_in_at`, `called_at`, `served_at`, `finished_at`, `status`, `created_at`, `served_by`, `walkin_name`, `walkin_phone`, `appointment_type_id`) VALUES
(1, 1, 1, '2026-02-06', 1, '2026-02-06 11:54:47', NULL, '2026-02-06 11:57:30', '2026-02-06 11:57:41', 'Done', '2026-02-06 03:54:47', NULL, NULL, NULL, NULL),
(2, 2, 2, '2026-02-06', 1, '2026-02-06 12:02:38', NULL, '2026-02-06 12:03:33', '2026-02-06 12:03:58', 'Done', '2026-02-06 04:02:38', 1, NULL, NULL, NULL),
(3, 3, 2, '2026-02-07', 1, '2026-02-06 13:02:46', '2026-02-06 13:04:51', '2026-02-06 13:04:51', '2026-02-07 21:06:44', 'Done', '2026-02-06 05:02:46', 3, NULL, NULL, NULL),
(4, 4, 1, '2026-02-06', 2, '2026-02-06 13:04:18', '2026-02-06 13:04:31', '2026-02-06 13:04:31', '2026-02-06 13:05:17', 'Done', '2026-02-06 05:04:18', NULL, NULL, NULL, NULL),
(5, 6, 3, '2026-02-06', 1, '2026-02-06 15:20:45', '2026-02-06 15:21:43', '2026-02-06 15:21:43', '2026-02-06 15:21:47', 'Done', '2026-02-06 07:20:45', NULL, NULL, NULL, NULL),
(6, 8, 5, '2026-02-06', 1, '2026-02-06 15:21:05', '2026-02-06 15:21:53', '2026-02-06 15:21:53', '2026-02-06 15:21:54', 'Done', '2026-02-06 07:21:05', 3, NULL, NULL, NULL),
(7, 9, 4, '2026-02-06', 1, '2026-02-06 15:38:36', '2026-02-06 15:40:48', '2026-02-06 15:40:48', '2026-02-06 15:44:56', 'Done', '2026-02-06 07:38:36', NULL, NULL, NULL, NULL),
(8, 10, 3, '2026-02-06', 2, '2026-02-06 15:52:01', '2026-02-06 15:52:42', '2026-02-06 15:52:43', '2026-02-06 15:52:47', 'Done', '2026-02-06 07:52:01', NULL, NULL, NULL, NULL),
(9, 11, 2, '2026-02-06', 2, '2026-02-06 16:30:27', '2026-02-06 16:33:14', '2026-02-06 16:33:14', '2026-02-06 16:33:16', 'Done', '2026-02-06 08:30:27', 1, NULL, NULL, NULL),
(10, 12, 4, '2026-02-06', 2, '2026-02-06 16:32:42', '2026-02-06 16:33:28', '2026-02-06 16:33:28', '2026-02-06 16:33:30', 'Done', '2026-02-06 08:32:42', NULL, NULL, NULL, NULL),
(11, 13, 3, '2026-02-06', 3, '2026-02-06 16:59:44', '2026-02-06 17:00:34', '2026-02-06 17:00:34', '2026-02-06 17:01:55', 'Done', '2026-02-06 08:59:44', NULL, NULL, NULL, NULL),
(12, NULL, 5, '2026-02-07', 1, '2026-02-07 21:29:05', NULL, '2026-02-07 21:40:17', '2026-02-07 21:40:20', 'Done', '2026-02-07 13:29:05', 3, 'Roy Doe', NULL, 3),
(13, 15, 2, '2026-02-10', 1, '2026-02-10 11:57:54', '2026-02-10 11:58:45', '2026-02-10 11:58:48', '2026-02-10 11:58:57', 'Done', '2026-02-10 03:57:54', 3, NULL, NULL, NULL),
(14, NULL, 2, '2026-02-10', 2, '2026-02-10 11:59:30', '2026-02-10 11:59:41', '2026-02-10 11:59:45', '2026-02-10 11:59:52', 'Done', '2026-02-10 03:59:30', 3, 'Joshua Galorport', NULL, 6);

-- --------------------------------------------------------

--
-- Table structure for table `slot_capacity`
--

CREATE TABLE `slot_capacity` (
  `id` int(11) NOT NULL,
  `counter_id` int(11) NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT 10
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `slot_capacity`
--

INSERT INTO `slot_capacity` (`id`, `counter_id`, `capacity`) VALUES
(1, 1, 10),
(2, 2, 10),
(3, 3, 10),
(4, 4, 10),
(5, 5, 10);

-- --------------------------------------------------------

--
-- Table structure for table `staff_counter_history`
--

CREATE TABLE `staff_counter_history` (
  `id` int(11) NOT NULL,
  `staff_user_id` int(11) NOT NULL,
  `counter_id` int(11) NOT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff_counter_history`
--

INSERT INTO `staff_counter_history` (`id`, `staff_user_id`, `counter_id`, `assigned_at`) VALUES
(1, 1, 1, '2026-02-06 03:55:46'),
(2, 3, 2, '2026-02-06 04:01:50'),
(3, 3, 2, '2026-02-06 05:05:10'),
(4, 1, 2, '2026-02-06 06:57:21'),
(5, 1, 1, '2026-02-06 07:21:29'),
(6, 1, 4, '2026-02-06 07:21:36'),
(7, 1, 3, '2026-02-06 07:21:42'),
(8, 1, 5, '2026-02-06 07:21:52'),
(9, 1, 2, '2026-02-06 07:22:21'),
(10, 1, 5, '2026-02-06 07:22:29'),
(11, 1, 5, '2026-02-06 07:22:36'),
(12, 1, 2, '2026-02-06 07:22:40'),
(13, 1, 3, '2026-02-06 07:22:45'),
(14, 1, 4, '2026-02-06 07:22:52'),
(15, 1, 4, '2026-02-06 07:40:46'),
(16, 1, 3, '2026-02-06 07:52:41'),
(17, 1, 3, '2026-02-06 07:54:10'),
(18, 1, 2, '2026-02-06 08:28:55'),
(19, 1, 5, '2026-02-06 08:29:01'),
(20, 1, 1, '2026-02-06 08:29:22'),
(21, 1, 1, '2026-02-06 08:33:08'),
(22, 1, 2, '2026-02-06 08:33:13'),
(23, 1, 3, '2026-02-06 08:33:20'),
(24, 1, 4, '2026-02-06 08:33:25'),
(25, 1, 5, '2026-02-06 08:33:33'),
(26, 1, 4, '2026-02-06 08:42:40'),
(27, 1, 2, '2026-02-06 08:43:00'),
(28, 3, 3, '2026-02-06 08:47:04'),
(29, 3, 2, '2026-02-06 08:59:59'),
(30, 3, 1, '2026-02-06 09:00:04'),
(31, 3, 4, '2026-02-06 09:00:18'),
(32, 3, 3, '2026-02-06 09:00:33'),
(33, 3, 2, '2026-02-06 09:20:37'),
(34, 3, 2, '2026-02-06 09:27:50'),
(35, 3, 3, '2026-02-06 09:28:05'),
(36, 3, 3, '2026-02-06 09:30:36'),
(37, 3, 3, '2026-02-06 09:30:48'),
(38, 3, 3, '2026-02-06 09:30:49'),
(39, 3, 3, '2026-02-06 09:32:20'),
(40, 3, 3, '2026-02-06 09:35:58'),
(41, 3, 3, '2026-02-06 09:37:34'),
(42, 3, 4, '2026-02-06 09:37:41'),
(43, 3, 3, '2026-02-06 09:39:22'),
(44, 3, 4, '2026-02-06 09:39:50'),
(45, 3, 2, '2026-02-06 09:42:16'),
(46, 3, 4, '2026-02-06 09:42:20'),
(47, 3, 4, '2026-02-06 09:42:36'),
(48, 3, 1, '2026-02-06 09:42:50'),
(49, 3, 2, '2026-02-06 09:42:58'),
(50, 3, 3, '2026-02-06 09:43:05'),
(51, 3, 4, '2026-02-06 09:43:12'),
(52, 3, 5, '2026-02-06 09:43:17'),
(53, 3, 5, '2026-02-06 09:43:27'),
(54, 3, 2, '2026-02-06 16:05:38'),
(55, 3, 3, '2026-02-06 16:05:56'),
(56, 3, 5, '2026-02-06 16:06:13'),
(57, 3, 4, '2026-02-06 16:06:18'),
(58, 3, 1, '2026-02-07 13:06:33'),
(59, 3, 2, '2026-02-07 13:06:40'),
(60, 3, 3, '2026-02-07 13:07:05'),
(61, 3, 4, '2026-02-07 13:07:10'),
(62, 3, 5, '2026-02-07 13:07:16'),
(63, 3, 2, '2026-02-10 03:58:38'),
(64, 3, 4, '2026-02-10 04:00:30');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('Citizen','Staff','Admin') NOT NULL DEFAULT 'Citizen',
  `assigned_counter_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `phone`, `password_hash`, `role`, `assigned_counter_id`, `is_active`, `created_at`) VALUES
(1, 'Bill Doe', 'bill@gmail.com', NULL, '$2y$10$Oqi2npFBTVmPhSlhgeDl3.161tm8gQheWJ6udnPL8vscCZ9vX1Fdq', 'Staff', 2, 1, '2026-02-06 03:53:34'),
(2, 'John Doe', 'john@gmail.com', NULL, '$2y$10$jrFizOvHS5NwEAtU6E3lY.Vt9NfwiBlT/XvMdvLMC19/EGL46Fm7S', 'Citizen', NULL, 1, '2026-02-06 03:54:04'),
(3, 'Jay Doe', 'jay@gmail.com', NULL, '$2y$10$.Jc/1d0z7.XRUAnE4Ee4Y.IzQocX.DfksCrbqj46Dol.Qw3dzLfOS', 'Staff', 4, 1, '2026-02-06 04:01:39'),
(4, 'Darel Doe', 'darel@gmail.com', NULL, '$2y$10$eI/f1COgI59a44cabF534.3.HRVBtRUXijYVxIej76jlrCOVwvc3y', 'Citizen', NULL, 1, '2026-02-06 05:03:33'),
(5, 'Juan Dela', 'juan@gmail.com', NULL, '$2y$10$Ve3UvPE82q15UuS3yubnP.mf1uKJPyC4ItPuh0zDVkQPEff4NCCYW', 'Citizen', NULL, 1, '2026-02-06 06:27:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ux_appointments_reference_code` (`reference_code`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `appointment_type_id` (`appointment_type_id`);

--
-- Indexes for table `appointment_types`
--
ALTER TABLE `appointment_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `assigned_counter_id` (`assigned_counter_id`);

--
-- Indexes for table `counters`
--
ALTER TABLE `counters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `queue_tickets`
--
ALTER TABLE `queue_tickets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_counter_day_number` (`counter_id`,`queue_date`,`queue_number`),
  ADD KEY `appointment_id` (`appointment_id`);

--
-- Indexes for table `slot_capacity`
--
ALTER TABLE `slot_capacity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `counter_id` (`counter_id`);

--
-- Indexes for table `staff_counter_history`
--
ALTER TABLE `staff_counter_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_user_id` (`staff_user_id`),
  ADD KEY `counter_id` (`counter_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `assigned_counter_id` (`assigned_counter_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `appointment_types`
--
ALTER TABLE `appointment_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `counters`
--
ALTER TABLE `counters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `queue_tickets`
--
ALTER TABLE `queue_tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `slot_capacity`
--
ALTER TABLE `slot_capacity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `staff_counter_history`
--
ALTER TABLE `staff_counter_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`appointment_type_id`) REFERENCES `appointment_types` (`id`);

--
-- Constraints for table `appointment_types`
--
ALTER TABLE `appointment_types`
  ADD CONSTRAINT `appointment_types_ibfk_1` FOREIGN KEY (`assigned_counter_id`) REFERENCES `counters` (`id`);

--
-- Constraints for table `queue_tickets`
--
ALTER TABLE `queue_tickets`
  ADD CONSTRAINT `queue_tickets_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`),
  ADD CONSTRAINT `queue_tickets_ibfk_2` FOREIGN KEY (`counter_id`) REFERENCES `counters` (`id`);

--
-- Constraints for table `slot_capacity`
--
ALTER TABLE `slot_capacity`
  ADD CONSTRAINT `slot_capacity_ibfk_1` FOREIGN KEY (`counter_id`) REFERENCES `counters` (`id`);

--
-- Constraints for table `staff_counter_history`
--
ALTER TABLE `staff_counter_history`
  ADD CONSTRAINT `staff_counter_history_ibfk_1` FOREIGN KEY (`staff_user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `staff_counter_history_ibfk_2` FOREIGN KEY (`counter_id`) REFERENCES `counters` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`assigned_counter_id`) REFERENCES `counters` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
