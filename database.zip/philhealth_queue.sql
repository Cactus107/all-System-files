-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2026 at 04:21 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `philhealth_queue`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL,
  `reference_code` varchar(24) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `walkin_name` varchar(150) DEFAULT NULL,
  `walkin_mobile` varchar(30) DEFAULT NULL,
  `service_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `counter_id` int(11) DEFAULT NULL,
  `client_status` varchar(30) NOT NULL DEFAULT 'Regular',
  `appointment_date` date NOT NULL,
  `appointment_time` time DEFAULT NULL,
  `arrival_time` datetime DEFAULT NULL,
  `source` enum('online','walkin') NOT NULL DEFAULT 'online',
  `status` enum('booked','checked_in','completed','cancelled','no_show') NOT NULL DEFAULT 'booked',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appointment_id`, `reference_code`, `user_id`, `walkin_name`, `walkin_mobile`, `service_id`, `category_id`, `counter_id`, `client_status`, `appointment_date`, `appointment_time`, `arrival_time`, `source`, `status`, `created_at`) VALUES
(1, 'REF-20260203-6493', 1, NULL, NULL, 13, 2, 3, 'Regular', '2026-02-03', '13:30:00', '2026-02-03 14:06:38', 'online', 'completed', '2026-02-03 12:30:35'),
(2, 'REF-20260203-98D1', 1, NULL, NULL, 10, 1, 1, 'Regular', '2026-02-04', '09:30:00', '2026-02-04 08:29:34', 'online', 'completed', '2026-02-03 12:36:37'),
(3, 'REF-20260203-ABB8', 1, NULL, NULL, 11, 1, 1, 'Regular', '2026-02-05', '13:00:00', NULL, 'online', 'no_show', '2026-02-03 13:06:40'),
(4, 'REF-20260203-3E6F', 1, NULL, NULL, 14, 2, 3, 'Regular', '2026-02-03', '13:45:00', '2026-02-03 14:15:14', 'online', 'completed', '2026-02-03 13:44:55'),
(7, 'REF-20260203-F0DD', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-03', NULL, '2026-02-03 14:17:59', 'walkin', 'completed', '2026-02-03 14:17:59'),
(8, 'REF-20260203-7C84', 4, NULL, NULL, 14, 2, 3, 'Regular', '2026-02-03', '15:10:00', '2026-02-03 15:04:20', 'online', 'completed', '2026-02-03 15:04:03'),
(9, 'REF-20260203-E41D', 1, NULL, NULL, 11, 1, 1, 'Regular', '2026-02-03', '16:35:00', '2026-02-03 16:34:41', 'online', 'completed', '2026-02-03 16:34:14'),
(10, 'REF-20260203-FD44', 4, NULL, NULL, 12, 1, 2, 'Regular', '2026-02-03', '16:35:00', '2026-02-03 16:35:42', 'online', 'completed', '2026-02-03 16:35:31'),
(11, 'REF-20260203-9E5C', 4, NULL, NULL, 15, 2, 4, 'Regular', '2026-02-03', '10:00:00', '2026-02-03 17:08:27', 'online', 'completed', '2026-02-03 16:36:11'),
(12, 'REF-20260203-7F91', 1, NULL, NULL, 13, 2, 3, 'Regular', '2026-02-03', '16:36:00', '2026-02-03 16:37:18', 'online', 'completed', '2026-02-03 16:36:56'),
(13, 'REF-20260203-1760', 4, NULL, NULL, 13, 2, 3, 'Regular', '2026-02-03', '16:37:00', '2026-02-03 16:38:04', 'online', 'completed', '2026-02-03 16:37:51'),
(14, 'REF-20260203-5DAB', NULL, '', '', 14, 2, 3, 'Regular', '2026-02-03', NULL, '2026-02-03 16:41:55', 'walkin', 'completed', '2026-02-03 16:41:55'),
(15, 'REF-20260203-C6B3', 4, NULL, NULL, 14, 2, 3, 'Regular', '2026-02-03', '17:00:00', '2026-02-03 17:08:41', 'online', 'completed', '2026-02-03 17:08:03'),
(16, 'REF-20260203-BD33', 1, NULL, NULL, 14, 2, 3, 'Regular', '2026-02-04', '10:00:00', '2026-02-04 08:29:41', 'online', 'completed', '2026-02-03 18:37:51'),
(17, 'REF-20260203-BD3F', NULL, '', '', 13, 2, 3, 'Regular', '2026-02-03', NULL, '2026-02-03 18:41:58', 'walkin', 'completed', '2026-02-03 18:41:58'),
(18, 'REF-20260204-309F', 6, NULL, NULL, 11, 1, 2, 'Regular', '2026-02-04', '10:00:00', '2026-02-04 09:01:06', 'online', 'completed', '2026-02-04 09:00:40'),
(20, 'REF-20260204-57A6', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 09:18:37', 'walkin', 'completed', '2026-02-04 09:18:37'),
(21, 'REF-20260204-8B9F', 6, NULL, NULL, 12, 1, 3, 'Regular', '2026-02-04', '10:20:00', '2026-02-04 09:20:04', 'online', 'completed', '2026-02-04 09:19:45'),
(22, 'REF-20260204-C9CD', 6, NULL, NULL, 15, 2, 4, 'Regular', '2026-02-04', '10:30:00', '2026-02-04 09:33:13', 'online', 'completed', '2026-02-04 09:33:06'),
(23, 'REF-20260204-ED3E', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 09:42:29', 'walkin', 'completed', '2026-02-04 09:42:29'),
(24, 'REF-20260204-9271', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 09:46:17', 'walkin', 'completed', '2026-02-04 09:46:17'),
(25, 'REF-20260204-16B8', NULL, '', '', 11, 1, 2, 'Regular', '2026-02-04', NULL, '2026-02-04 09:46:57', 'walkin', 'completed', '2026-02-04 09:46:57'),
(26, 'REF-20260204-2267', 6, NULL, NULL, 13, 2, 4, 'Regular', '2026-02-04', '10:00:00', '2026-02-04 09:51:00', 'online', 'completed', '2026-02-04 09:49:49'),
(27, 'REF-20260204-4CE5', 6, NULL, NULL, 14, 2, 4, 'Regular', '2026-02-04', '11:00:00', '2026-02-04 09:50:17', 'online', 'completed', '2026-02-04 09:50:04'),
(28, 'REF-20260204-53AA', 6, NULL, NULL, 15, 2, 5, 'Regular', '2026-02-04', '13:00:00', NULL, 'online', 'no_show', '2026-02-04 09:51:41'),
(29, 'REF-20260204-C3AE', 1, NULL, NULL, 15, 2, 5, 'Regular', '2026-02-04', '11:00:00', '2026-02-04 09:52:29', 'online', 'completed', '2026-02-04 09:52:18'),
(30, 'REF-20260204-D0F1', 1, NULL, NULL, 10, 1, 1, 'Regular', '2026-02-04', '11:30:00', '2026-02-04 09:53:01', 'online', 'completed', '2026-02-04 09:52:54'),
(31, 'REF-20260204-5C2F', 1, NULL, NULL, 11, 1, 2, 'Regular', '2026-02-04', '13:30:00', '2026-02-04 09:54:07', 'online', 'completed', '2026-02-04 09:54:01'),
(32, 'REF-20260204-1211', 4, NULL, NULL, 15, 2, 5, 'Regular', '2026-02-04', '09:58:00', '2026-02-04 09:58:40', 'online', 'completed', '2026-02-04 09:58:28'),
(33, 'REF-20260204-4381', 4, NULL, NULL, 11, 1, 2, 'Regular', '2026-02-04', '10:01:00', '2026-02-04 10:01:15', 'online', 'completed', '2026-02-04 10:01:08'),
(34, 'REF-20260204-4F08', 4, NULL, NULL, 12, 1, 3, 'Regular', '2026-02-04', '10:01:00', '2026-02-04 10:02:05', 'online', 'completed', '2026-02-04 10:01:57'),
(35, 'REF-20260204-DD25', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 10:02:09', 'walkin', 'completed', '2026-02-04 10:02:09'),
(36, 'REF-20260204-13DB', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-04', NULL, '2026-02-04 10:02:13', 'walkin', 'completed', '2026-02-04 10:02:13'),
(37, 'REF-20260204-381F', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-04', NULL, '2026-02-04 10:02:17', 'walkin', 'completed', '2026-02-04 10:02:17'),
(38, 'REF-20260204-8F74', NULL, '', '', 11, 1, 2, 'Regular', '2026-02-04', NULL, '2026-02-04 10:02:26', 'walkin', 'completed', '2026-02-04 10:02:26'),
(39, 'REF-20260204-2A23', 7, NULL, NULL, 10, 1, 1, 'Regular', '2026-02-04', '11:30:00', '2026-02-04 11:12:40', 'online', 'completed', '2026-02-04 11:11:36'),
(40, 'REF-20260204-55D2', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-04', NULL, '2026-02-04 11:14:35', 'walkin', 'completed', '2026-02-04 11:14:35'),
(41, 'REF-20260204-7287', 1, NULL, NULL, 14, 2, 4, 'Regular', '2026-02-04', '13:30:00', '2026-02-04 12:50:07', 'online', 'completed', '2026-02-04 12:49:58'),
(42, 'REF-20260204-B368', 1, NULL, NULL, 13, 2, 4, 'Regular', '2026-02-04', '13:00:00', '2026-02-04 12:58:42', 'online', 'completed', '2026-02-04 12:58:32'),
(43, 'REF-20260204-CE86', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 13:02:34', 'walkin', 'completed', '2026-02-04 13:02:34'),
(44, 'REF-20260204-DC7E', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 13:02:38', 'walkin', 'completed', '2026-02-04 13:02:38'),
(45, 'REF-20260204-ADD1', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-04', NULL, '2026-02-04 13:02:41', 'walkin', 'completed', '2026-02-04 13:02:41'),
(46, 'REF-20260204-83D4', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-04', NULL, '2026-02-04 13:02:45', 'walkin', 'completed', '2026-02-04 13:02:45'),
(47, 'REF-20260204-A9F6', NULL, '', '', 11, 1, 2, 'Regular', '2026-02-04', NULL, '2026-02-04 13:02:49', 'walkin', 'completed', '2026-02-04 13:02:49'),
(48, 'REF-20260204-5693', NULL, '', '', 12, 1, 3, 'Regular', '2026-02-04', NULL, '2026-02-04 13:02:54', 'walkin', 'completed', '2026-02-04 13:02:54'),
(49, 'REF-20260204-1E80', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 13:02:59', 'walkin', 'completed', '2026-02-04 13:02:59'),
(50, 'REF-20260204-ACD7', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-04', NULL, '2026-02-04 13:03:02', 'walkin', 'completed', '2026-02-04 13:03:02'),
(51, 'REF-20260204-925B', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-04', NULL, '2026-02-04 13:03:02', 'walkin', 'completed', '2026-02-04 13:03:02'),
(52, 'REF-20260204-8949', NULL, '', '', 12, 1, 3, 'Regular', '2026-02-04', NULL, '2026-02-04 13:05:32', 'walkin', 'completed', '2026-02-04 13:05:32'),
(53, 'REF-20260204-B536', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 13:09:35', 'walkin', 'completed', '2026-02-04 13:09:35'),
(54, 'REF-20260204-7CEA', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 13:09:39', 'walkin', 'completed', '2026-02-04 13:09:39'),
(55, 'REF-20260204-90C0', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-04', NULL, '2026-02-04 13:09:44', 'walkin', 'completed', '2026-02-04 13:09:44'),
(56, 'REF-20260204-B84C', NULL, '', '', 11, 1, 2, 'Regular', '2026-02-04', NULL, '2026-02-04 13:09:48', 'walkin', 'completed', '2026-02-04 13:09:48'),
(57, 'REF-20260204-EA83', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-04', NULL, '2026-02-04 13:10:24', 'walkin', 'completed', '2026-02-04 13:10:24'),
(58, 'REF-20260204-9868', NULL, '', '', 12, 1, 3, 'Regular', '2026-02-04', NULL, '2026-02-04 13:10:54', 'walkin', 'completed', '2026-02-04 13:10:54'),
(59, 'REF-20260204-29E9', NULL, '', '', 11, 1, 2, 'Regular', '2026-02-04', NULL, '2026-02-04 13:25:27', 'walkin', 'completed', '2026-02-04 13:25:27'),
(60, 'REF-20260204-9ACE', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-04', NULL, '2026-02-04 13:25:30', 'walkin', 'completed', '2026-02-04 13:25:30'),
(61, 'REF-20260204-3B0A', NULL, '', '', 12, 1, 3, 'Regular', '2026-02-04', NULL, '2026-02-04 13:25:33', 'walkin', 'completed', '2026-02-04 13:25:33'),
(62, 'REF-20260204-CC33', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-04', NULL, '2026-02-04 13:25:37', 'walkin', 'completed', '2026-02-04 13:25:37'),
(63, 'REF-20260204-DDBC', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-04', NULL, '2026-02-04 13:25:40', 'walkin', 'completed', '2026-02-04 13:25:40'),
(64, 'REF-20260210-42B8', 1, NULL, NULL, 14, 2, 4, 'Regular', '2026-02-10', '12:30:00', '2026-02-10 12:08:38', 'online', 'completed', '2026-02-10 12:07:39'),
(65, 'REF-20260210-C6F8', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-10', NULL, '2026-02-10 12:08:50', 'walkin', 'completed', '2026-02-10 12:08:50'),
(66, 'REF-20260210-72D7', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-10', NULL, '2026-02-10 12:08:56', 'walkin', 'completed', '2026-02-10 12:08:56'),
(67, 'REF-20260210-0243', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-10', NULL, '2026-02-10 12:10:33', 'walkin', 'completed', '2026-02-10 12:10:33'),
(68, 'REF-20260210-916D', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-10', NULL, '2026-02-10 12:10:36', 'walkin', 'completed', '2026-02-10 12:10:36'),
(69, 'REF-20260210-9C6C', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-10', NULL, '2026-02-10 12:10:40', 'walkin', 'completed', '2026-02-10 12:10:40'),
(70, 'REF-20260210-EAFB', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-10', NULL, '2026-02-10 12:10:44', 'walkin', 'completed', '2026-02-10 12:10:44'),
(71, 'REF-20260210-7789', NULL, '', '', 11, 1, 2, 'Regular', '2026-02-10', NULL, '2026-02-10 12:10:48', 'walkin', 'completed', '2026-02-10 12:10:48'),
(72, 'REF-20260210-964C', NULL, '', '', 12, 1, 3, 'Regular', '2026-02-10', NULL, '2026-02-10 12:10:52', 'walkin', 'completed', '2026-02-10 12:10:52'),
(73, 'REF-20260213-9A73', 6, NULL, NULL, 14, 2, 4, 'Regular', '2026-02-13', '14:35:00', '2026-02-13 14:31:27', 'online', 'completed', '2026-02-13 14:31:14'),
(74, 'REF-20260213-4704', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-13', NULL, '2026-02-13 14:42:12', 'walkin', 'completed', '2026-02-13 14:42:12'),
(75, 'REF-20260213-8F55', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-13', NULL, '2026-02-13 14:42:15', 'walkin', 'completed', '2026-02-13 14:42:15'),
(76, 'REF-20260213-311B', NULL, '', '', 13, 2, 4, 'Regular', '2026-02-13', NULL, '2026-02-13 14:42:17', 'walkin', 'completed', '2026-02-13 14:42:17'),
(77, 'REF-20260213-4ED5', NULL, '', '', 15, 2, 5, 'Regular', '2026-02-13', NULL, '2026-02-13 14:42:20', 'walkin', 'completed', '2026-02-13 14:42:20'),
(78, 'REF-20260213-D06D', NULL, '', '', 10, 1, 1, 'Regular', '2026-02-13', NULL, '2026-02-13 14:42:24', 'walkin', 'completed', '2026-02-13 14:42:24'),
(79, 'REF-20260213-82BE', NULL, '', '', 12, 1, 3, 'Regular', '2026-02-13', NULL, '2026-02-13 14:42:28', 'walkin', 'completed', '2026-02-13 14:42:28'),
(80, 'REF-20260213-7D5E', 6, NULL, NULL, 12, 1, 3, 'Regular', '2026-02-13', '15:55:00', '2026-02-13 15:54:34', 'online', 'completed', '2026-02-13 15:54:20'),
(81, 'REF-20260213-5CC3', NULL, '', '', 11, 1, 2, 'Regular', '2026-02-13', NULL, '2026-02-13 16:29:01', 'walkin', 'completed', '2026-02-13 16:29:01'),
(82, 'REF-20260213-ECB6', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-13', NULL, '2026-02-13 16:29:07', 'walkin', 'completed', '2026-02-13 16:29:07'),
(83, 'REF-20260213-7852', NULL, '', '', 14, 2, 4, 'Regular', '2026-02-13', NULL, '2026-02-13 16:29:17', 'walkin', 'completed', '2026-02-13 16:29:17'),
(84, 'REF-20260213-7429', NULL, '', '', 12, 1, 3, 'Regular', '2026-02-13', NULL, '2026-02-13 16:29:25', 'walkin', 'completed', '2026-02-13 16:29:25'),
(85, 'REF-20260213-AC09', 1, NULL, NULL, 12, 1, 3, 'Regular', '2026-02-14', '08:30:00', NULL, 'online', 'no_show', '2026-02-13 16:44:22'),
(86, 'REF-20260213-103B', 4, NULL, NULL, 15, 2, 5, 'Regular', '2026-02-14', '08:30:00', NULL, 'online', 'no_show', '2026-02-13 17:26:21'),
(87, 'REF-20260218-E82E', 18, NULL, NULL, 11, 1, 2, 'Regular', '2026-03-03', '08:00:00', NULL, 'online', 'booked', '2026-02-18 20:47:11'),
(88, 'REF-20260226-3A43', 4, NULL, NULL, 14, 2, 4, 'Regular', '2026-02-26', '12:24:00', NULL, 'online', 'no_show', '2026-02-26 12:24:28'),
(89, 'REF-20260226-EA62', 4, NULL, NULL, 13, 2, 4, 'Regular', '2026-02-26', '12:25:00', NULL, 'online', 'no_show', '2026-02-26 12:25:30'),
(90, 'REF-20260226-0F17', 4, NULL, NULL, 14, 2, 4, 'Regular', '2026-02-26', '12:26:00', NULL, 'online', 'no_show', '2026-02-26 12:26:17'),
(91, 'REF-20260226-905A', 4, NULL, NULL, 13, 2, 4, 'Regular', '2026-02-26', '14:30:00', '2026-02-26 12:27:52', 'online', 'completed', '2026-02-26 12:26:50'),
(92, 'REF-20260226-7516', 4, NULL, NULL, 15, 2, 5, 'Regular', '2026-02-26', '14:30:00', '2026-02-26 12:28:03', 'online', 'completed', '2026-02-26 12:27:19'),
(94, 'REF-20260226-5D87', 4, NULL, NULL, 12, 1, 2, 'Senior Citizen', '2026-02-26', '13:40:00', '2026-02-26 13:20:38', 'online', 'completed', '2026-02-26 13:20:24'),
(97, 'REF-20260226-FA45', 1, NULL, NULL, 12, 1, 4, 'Pregnant', '2026-02-26', '14:00:00', '2026-02-26 13:22:35', 'online', 'completed', '2026-02-26 13:22:28'),
(98, 'REF-20260226-91A9', NULL, '', '', 15, 2, 8, 'PWD', '2026-02-26', NULL, '2026-02-26 20:05:38', 'walkin', 'completed', '2026-02-26 20:05:38'),
(99, 'REF-20260226-22C6', NULL, '', '', 14, 2, 8, 'PWD', '2026-02-26', NULL, '2026-02-26 20:13:34', 'walkin', 'completed', '2026-02-26 20:13:34'),
(100, 'REF-20260226-A0DA', NULL, '', '', 14, 2, 2, 'PWD', '2026-02-26', NULL, '2026-02-26 21:36:10', 'walkin', 'completed', '2026-02-26 21:36:10'),
(101, 'REF-20260226-DA79', NULL, '', '', 15, 2, 2, 'Senior Citizen', '2026-02-26', NULL, '2026-02-26 21:36:24', 'walkin', 'completed', '2026-02-26 21:36:24'),
(102, 'REF-20260226-5A61', NULL, '', '', 13, 2, 2, 'Pregnant', '2026-02-26', NULL, '2026-02-26 21:36:37', 'walkin', 'completed', '2026-02-26 21:36:37'),
(103, 'REF-20260226-6D85', NULL, '', '', 12, 1, 2, 'PWD', '2026-02-26', NULL, '2026-02-26 21:36:49', 'walkin', 'completed', '2026-02-26 21:36:49'),
(104, 'REF-20260226-EA52', NULL, '', '', 14, 2, 8, 'Regular', '2026-02-26', NULL, '2026-02-26 21:36:59', 'walkin', 'completed', '2026-02-26 21:36:59'),
(105, 'REF-20260226-99EF', NULL, '', '', 13, 2, 8, 'Regular', '2026-02-26', NULL, '2026-02-26 21:57:17', 'walkin', 'completed', '2026-02-26 21:57:17'),
(106, 'REF-20260226-A1D8', NULL, '', '', 14, 2, 2, 'PWD', '2026-02-26', NULL, '2026-02-26 21:57:23', 'walkin', 'completed', '2026-02-26 21:57:23'),
(107, 'REF-20260226-334F', 4, NULL, NULL, 14, 2, 2, 'PWD', '2026-02-27', '09:00:00', '2026-02-27 08:39:55', 'online', 'completed', '2026-02-26 23:19:02'),
(108, 'REF-20260226-9699', 1, NULL, NULL, 15, 2, 2, 'PWD', '2026-02-27', '09:30:00', '2026-02-27 08:40:23', 'online', 'completed', '2026-02-26 23:36:46'),
(109, 'REF-20260226-0913', 18, NULL, NULL, 12, 1, 2, 'Pregnant', '2026-02-27', '10:37:00', '2026-02-27 08:40:53', 'online', 'completed', '2026-02-26 23:37:42'),
(110, 'REF-20260227-8338', NULL, '', '', 10, 1, 7, 'Regular', '2026-02-27', NULL, '2026-02-27 08:47:27', 'walkin', 'checked_in', '2026-02-27 08:47:27'),
(111, 'REF-20260301-E7BD', 4, NULL, NULL, 13, 2, 9, 'Regular', '2026-03-01', '16:25:00', '2026-03-01 15:27:10', 'online', 'completed', '2026-03-01 15:25:40'),
(112, 'REF-20260301-875A', 4, NULL, NULL, 14, 2, 2, 'PWD', '2026-03-01', '16:45:00', '2026-03-01 15:42:29', 'online', 'completed', '2026-03-01 15:31:33'),
(113, 'REF-20260301-4778', 1, NULL, NULL, 15, 2, 2, 'Pregnant', '2026-03-01', '16:21:00', '2026-03-01 16:03:56', 'online', 'completed', '2026-03-01 16:03:13'),
(114, 'REF-20260301-5E88', NULL, 'John Die', '', 13, 2, 8, 'Regular', '2026-03-01', NULL, '2026-03-01 23:16:09', 'walkin', 'completed', '2026-03-01 23:16:09'),
(115, 'REF-20260301-4AB1', NULL, 'Doe Die', '', 15, 2, 8, 'Regular', '2026-03-01', NULL, '2026-03-01 23:16:25', 'walkin', 'completed', '2026-03-01 23:16:25');

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `log_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `actor_user_id` int(11) DEFAULT NULL,
  `actor_name` varchar(100) DEFAULT NULL,
  `actor_role` varchar(20) DEFAULT NULL,
  `action` varchar(30) NOT NULL,
  `queue_id` int(11) DEFAULT NULL,
  `appointment_id` int(11) DEFAULT NULL,
  `queue_code` varchar(10) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `counter_id` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`log_id`, `created_at`, `actor_user_id`, `actor_name`, `actor_role`, `action`, `queue_id`, `appointment_id`, `queue_code`, `category_id`, `counter_id`, `details`) VALUES
(1, '2026-02-03 17:02:36', 2, 'Staff User', 'staff', 'mark_done', 8, NULL, 'H005', 2, NULL, 'Service completed'),
(2, '2026-02-03 17:02:40', 2, 'Staff User', 'staff', 'mark_done', 6, NULL, 'M003', 1, NULL, 'Service completed'),
(3, '2026-02-03 17:02:57', 2, 'Staff User', 'staff', 'call_next', 9, NULL, 'H006', 2, 1, 'Called to Counter #1'),
(4, '2026-02-03 17:03:06', 2, 'Staff User', 'staff', 'mark_done', 9, NULL, 'H006', 2, NULL, 'Service completed'),
(5, '2026-02-03 17:08:56', 3, 'John Doe', 'staff', 'call_next', 10, NULL, 'H007', 2, 1, 'Called to Counter #1'),
(6, '2026-02-03 17:09:01', 3, 'John Doe', 'staff', 'mark_done', 10, NULL, 'H007', 2, NULL, 'Service completed'),
(7, '2026-02-03 17:09:19', 3, 'John Doe', 'staff', 'call_next', 11, NULL, 'H008', 2, 1, 'Called to Counter #1'),
(8, '2026-02-03 17:09:26', 3, 'John Doe', 'staff', 'mark_done', 11, NULL, 'H008', 2, NULL, 'Service completed'),
(9, '2026-02-03 18:42:10', 3, 'John Doe', 'staff', 'call_next', 12, NULL, 'H009', 2, 1, 'Called to Counter #1'),
(10, '2026-02-03 18:42:39', 3, 'John Doe', 'staff', 'mark_done', 12, NULL, 'H009', 2, NULL, 'Service completed'),
(11, '2026-02-04 08:30:03', 2, 'Staff User', 'staff', 'call_next', 14, NULL, 'H001', 2, 2, 'Called to Counter #2'),
(12, '2026-02-04 08:30:15', 2, 'Staff User', 'staff', 'call_next', 13, NULL, 'M001', 1, 2, 'Called to Counter #2'),
(13, '2026-02-04 08:30:53', 2, 'Staff User', 'staff', 'mark_done', 14, NULL, 'H001', 2, NULL, 'Service completed'),
(14, '2026-02-04 08:30:59', 2, 'Staff User', 'staff', 'mark_done', 13, NULL, 'M001', 1, NULL, 'Service completed'),
(15, '2026-02-04 09:01:42', 2, 'Staff User', 'staff', 'call_next', 15, NULL, 'M002', 1, 1, 'Called to Counter #1'),
(16, '2026-02-04 09:02:04', 2, 'Staff User', 'staff', 'mark_done', 15, NULL, 'M002', 1, NULL, 'Service completed'),
(17, '2026-02-04 09:20:50', 2, 'Staff User', 'staff', 'call_next', 17, NULL, 'M003', 1, 1, 'Called to Counter #1'),
(18, '2026-02-04 09:20:57', 2, 'Staff User', 'staff', 'call_next', 16, NULL, 'H002', 2, 1, 'Called to Counter #1'),
(19, '2026-02-04 09:21:02', 2, 'Staff User', 'staff', 'mark_done', 17, NULL, 'M003', 1, NULL, 'Service completed'),
(20, '2026-02-04 09:21:36', 2, 'Staff User', 'staff', 'mark_done', 16, NULL, 'H002', 2, NULL, 'Service completed'),
(21, '2026-02-04 09:35:17', 2, 'Staff User', 'staff', 'call_next', 18, NULL, 'H003', 2, 4, 'Called to Counter #4'),
(22, '2026-02-04 09:43:37', 2, 'Staff User', 'staff', 'mark_done', 18, NULL, 'H003', 2, 4, 'Service completed'),
(23, '2026-02-04 09:45:55', 2, 'Staff User', 'staff', 'call_next', 19, NULL, 'H004', 2, 4, 'Called to Counter #4'),
(24, '2026-02-04 09:47:34', 2, 'Staff User', 'staff', 'call_next', 21, NULL, 'M004', 1, 2, 'Called to Counter #2'),
(25, '2026-02-04 09:48:05', 2, 'Staff User', 'staff', 'mark_done', 19, NULL, 'H004', 2, 4, 'Service completed'),
(26, '2026-02-04 09:48:10', 2, 'Staff User', 'staff', 'call_next', 20, NULL, 'H005', 2, 4, 'Called to Counter #4'),
(27, '2026-02-04 09:48:31', 2, 'Staff User', 'staff', 'mark_done', 20, NULL, 'H005', 2, 4, 'Service completed'),
(28, '2026-02-04 09:48:54', 2, 'Staff User', 'staff', 'mark_done', 21, NULL, 'M004', 1, 2, 'Service completed'),
(29, '2026-02-04 09:54:25', 2, 'Staff User', 'staff', 'call_next', 22, NULL, 'H006', 2, 4, 'Called to Counter #4'),
(30, '2026-02-04 09:54:30', 2, 'Staff User', 'staff', 'call_next', 25, NULL, 'M005', 1, 1, 'Called to Counter #1'),
(31, '2026-02-04 09:54:48', 2, 'Staff User', 'staff', 'mark_done', 22, NULL, 'H006', 2, 4, 'Service completed'),
(32, '2026-02-04 09:54:54', 2, 'Staff User', 'staff', 'call_next', 23, NULL, 'H007', 2, 4, 'Called to Counter #4'),
(33, '2026-02-04 09:55:00', 2, 'Staff User', 'staff', 'mark_done', 23, NULL, 'H007', 2, 4, 'Service completed'),
(34, '2026-02-04 09:55:06', 2, 'Staff User', 'staff', 'call_next', 24, NULL, 'H008', 2, 5, 'Called to Counter #5'),
(35, '2026-02-04 09:55:37', 2, 'Staff User', 'staff', 'mark_done', 25, NULL, 'M005', 1, 1, 'Service completed'),
(36, '2026-02-04 09:55:48', 2, 'Staff User', 'staff', 'call_next', 26, NULL, 'M006', 1, 2, 'Called to Counter #2'),
(37, '2026-02-04 09:55:57', 2, 'Staff User', 'staff', 'mark_done', 26, NULL, 'M006', 1, 2, 'Service completed'),
(38, '2026-02-04 09:56:30', 2, 'Staff User', 'staff', 'mark_done', 24, NULL, 'H008', 2, 5, 'Service completed'),
(39, '2026-02-04 09:59:36', 2, 'Staff User', 'staff', 'call_next', 27, NULL, 'H009', 2, 5, 'Called to Counter #5'),
(40, '2026-02-04 10:03:27', 2, 'Staff User', 'staff', 'call_next', 32, NULL, 'M009', 1, 1, 'Called to Counter #1'),
(41, '2026-02-04 10:03:35', 2, 'Staff User', 'staff', 'call_next', 28, NULL, 'M007', 1, 2, 'Called to Counter #2'),
(42, '2026-02-04 10:04:04', 2, 'Staff User', 'staff', 'call_next', 30, NULL, 'H010', 2, 4, 'Called to Counter #4'),
(43, '2026-02-04 10:38:22', 2, 'Staff User', 'staff', 'mark_done', 30, NULL, 'H010', 2, 4, 'Service completed'),
(44, '2026-02-04 10:45:07', 2, 'Staff User', 'staff', 'mark_done', 27, NULL, 'H009', 2, 5, 'Service completed'),
(45, '2026-02-04 10:45:11', 2, 'Staff User', 'staff', 'mark_done', 28, NULL, 'M007', 1, 2, 'Service completed'),
(46, '2026-02-04 10:45:21', 2, 'Staff User', 'staff', 'mark_done', 32, NULL, 'M009', 1, 1, 'Service completed'),
(47, '2026-02-04 10:45:30', 2, 'Staff User', 'staff', 'call_next', 31, NULL, 'H011', 2, 5, 'Called to Counter #5'),
(48, '2026-02-04 10:46:24', 2, 'Staff User', 'staff', 'call_next', 33, NULL, 'M010', 1, 2, 'Called to Counter #2'),
(49, '2026-02-04 10:46:28', 2, 'Staff User', 'staff', 'call_next', 29, NULL, 'M008', 1, 3, 'Called to Counter #3'),
(50, '2026-02-04 10:58:44', 2, 'Staff User', 'staff', 'mark_done', 31, NULL, 'H011', 2, 5, 'Service completed'),
(51, '2026-02-04 10:59:52', 2, 'Staff User', 'staff', 'mark_done', 29, NULL, 'M008', 1, 3, 'Service completed'),
(52, '2026-02-04 11:04:10', 2, 'Staff User', 'staff', 'mark_done', 33, NULL, 'M010', 1, 2, 'Service completed'),
(53, '2026-02-04 11:13:35', 3, 'John Doe', 'staff', 'call_next', 34, NULL, 'M011', 1, 1, 'Called to Counter #1'),
(54, '2026-02-04 11:15:29', 3, 'John Doe', 'staff', 'mark_done', 34, NULL, 'M011', 1, 1, 'Service completed'),
(55, '2026-02-04 11:15:46', 3, 'John Doe', 'staff', 'call_next', 35, NULL, 'M012', 1, 1, 'Called to Counter #1'),
(56, '2026-02-04 11:15:58', 3, 'John Doe', 'staff', 'mark_done', 35, NULL, 'M012', 1, 1, 'Service completed'),
(57, '2026-02-04 12:50:57', 3, 'John Doe', 'staff', 'call_next', 36, NULL, 'H012', 2, 4, 'Called to Counter #4'),
(58, '2026-02-04 12:51:14', 3, 'John Doe', 'staff', 'mark_done', 36, NULL, 'H012', 2, 4, 'Service completed'),
(59, '2026-02-04 12:58:49', 3, 'John Doe', 'staff', 'call_next', 37, NULL, 'H013', 2, 4, 'Called to Counter #4'),
(60, '2026-02-04 12:58:55', 3, 'John Doe', 'staff', 'mark_done', 37, NULL, 'H013', 2, 4, 'Service completed'),
(61, '2026-02-04 13:03:33', 3, 'John Doe', 'staff', 'call_next', 38, NULL, 'H014', 2, 4, 'Called to Counter #4'),
(62, '2026-02-04 13:03:46', 3, 'John Doe', 'staff', 'call_next', 42, NULL, 'M014', 1, 2, 'Called to Counter #2'),
(63, '2026-02-04 13:03:56', 3, 'John Doe', 'staff', 'call_next', 40, NULL, 'H016', 2, 5, 'Called to Counter #5'),
(64, '2026-02-04 13:04:02', 3, 'John Doe', 'staff', 'call_next', 41, NULL, 'M013', 1, 1, 'Called to Counter #1'),
(65, '2026-02-04 13:04:07', 3, 'John Doe', 'staff', 'call_next', 43, NULL, 'M015', 1, 3, 'Called to Counter #3'),
(66, '2026-02-04 13:06:13', 3, 'John Doe', 'staff', 'mark_done', 38, NULL, 'H014', 2, 4, 'Service completed'),
(67, '2026-02-04 13:06:29', 3, 'John Doe', 'staff', 'mark_done', 41, NULL, 'M013', 1, 1, 'Service completed'),
(68, '2026-02-04 13:06:35', 3, 'John Doe', 'staff', 'call_next', 39, NULL, 'H015', 2, 4, 'Called to Counter #4'),
(69, '2026-02-04 13:06:51', 3, 'John Doe', 'staff', 'mark_done', 42, NULL, 'M014', 1, 2, 'Service completed'),
(70, '2026-02-04 13:06:59', 3, 'John Doe', 'staff', 'mark_done', 39, NULL, 'H015', 2, 4, 'Service completed'),
(71, '2026-02-04 13:07:06', 3, 'John Doe', 'staff', 'call_next', 44, NULL, 'H017', 2, 4, 'Called to Counter #4'),
(72, '2026-02-04 13:07:18', 3, 'John Doe', 'staff', 'mark_done', 40, NULL, 'H016', 2, 5, 'Service completed'),
(73, '2026-02-04 13:07:22', 3, 'John Doe', 'staff', 'mark_done', 43, NULL, 'M015', 1, 3, 'Service completed'),
(74, '2026-02-04 13:07:29', 3, 'John Doe', 'staff', 'call_next', 47, NULL, 'M016', 1, 3, 'Called to Counter #3'),
(75, '2026-02-04 13:07:37', 3, 'John Doe', 'staff', 'call_next', 45, NULL, 'H018', 2, 5, 'Called to Counter #5'),
(76, '2026-02-04 13:07:46', 3, 'John Doe', 'staff', 'mark_done', 44, NULL, 'H017', 2, 4, 'Service completed'),
(77, '2026-02-04 13:07:55', 3, 'John Doe', 'staff', 'mark_done', 45, NULL, 'H018', 2, 5, 'Service completed'),
(78, '2026-02-04 13:08:00', 3, 'John Doe', 'staff', 'mark_done', 47, NULL, 'M016', 1, 3, 'Service completed'),
(79, '2026-02-04 13:08:06', 3, 'John Doe', 'staff', 'call_next', 46, NULL, 'H019', 2, 5, 'Called to Counter #5'),
(80, '2026-02-04 13:08:09', 3, 'John Doe', 'staff', 'mark_done', 46, NULL, 'H019', 2, 5, 'Service completed'),
(81, '2026-02-04 13:09:59', 3, 'John Doe', 'staff', 'call_next', 48, NULL, 'H020', 2, 4, 'Called to Counter #4'),
(82, '2026-02-04 13:10:12', 3, 'John Doe', 'staff', 'mark_done', 48, NULL, 'H020', 2, 4, 'Service completed'),
(83, '2026-02-04 13:10:18', 3, 'John Doe', 'staff', 'call_next', 49, NULL, 'H021', 2, 4, 'Called to Counter #4'),
(84, '2026-02-04 13:10:33', 3, 'John Doe', 'staff', 'call_next', 52, NULL, 'H022', 2, 5, 'Called to Counter #5'),
(85, '2026-02-04 13:10:37', 3, 'John Doe', 'staff', 'call_next', 50, NULL, 'M017', 1, 1, 'Called to Counter #1'),
(86, '2026-02-04 13:10:43', 3, 'John Doe', 'staff', 'call_next', 51, NULL, 'M018', 1, 2, 'Called to Counter #2'),
(87, '2026-02-04 13:11:00', 3, 'John Doe', 'staff', 'call_next', 53, NULL, 'M019', 1, 3, 'Called to Counter #3'),
(88, '2026-02-04 13:22:26', 3, 'John Doe', 'staff', 'mark_done', 49, NULL, 'H021', 2, 4, 'Service completed'),
(89, '2026-02-04 13:22:29', 3, 'John Doe', 'staff', 'mark_done', 52, NULL, 'H022', 2, 5, 'Service completed'),
(90, '2026-02-04 13:22:31', 3, 'John Doe', 'staff', 'mark_done', 50, NULL, 'M017', 1, 1, 'Service completed'),
(91, '2026-02-04 13:22:43', 3, 'John Doe', 'staff', 'mark_done', 51, NULL, 'M018', 1, 2, 'Service completed'),
(92, '2026-02-04 13:22:46', 3, 'John Doe', 'staff', 'mark_done', 53, NULL, 'M019', 1, 3, 'Service completed'),
(93, '2026-02-04 13:25:51', 3, 'John Doe', 'staff', 'call_next', 57, NULL, 'H023', 2, 4, 'Called to Counter #4'),
(94, '2026-02-04 13:25:56', 3, 'John Doe', 'staff', 'call_next', 58, NULL, 'H024', 2, 5, 'Called to Counter #5'),
(95, '2026-02-04 13:26:00', 3, 'John Doe', 'staff', 'call_next', 55, NULL, 'M021', 1, 1, 'Called to Counter #1'),
(96, '2026-02-04 13:26:04', 3, 'John Doe', 'staff', 'call_next', 54, NULL, 'M020', 1, 2, 'Called to Counter #2'),
(97, '2026-02-04 13:26:08', 3, 'John Doe', 'staff', 'call_next', 56, NULL, 'M022', 1, 3, 'Called to Counter #3'),
(98, '2026-02-04 13:26:37', 3, 'John Doe', 'staff', 'mark_done', 57, NULL, 'H023', 2, 4, 'Service completed'),
(99, '2026-02-04 13:26:40', 3, 'John Doe', 'staff', 'mark_done', 58, NULL, 'H024', 2, 5, 'Service completed'),
(100, '2026-02-04 13:26:43', 3, 'John Doe', 'staff', 'mark_done', 54, NULL, 'M020', 1, 2, 'Service completed'),
(101, '2026-02-04 13:26:45', 3, 'John Doe', 'staff', 'mark_done', 55, NULL, 'M021', 1, 1, 'Service completed'),
(102, '2026-02-04 13:26:48', 3, 'John Doe', 'staff', 'mark_done', 56, NULL, 'M022', 1, 3, 'Service completed'),
(103, '2026-02-10 12:09:26', 2, 'Staff User', 'staff', 'call_next', 59, NULL, 'H001', 2, 4, 'Called to Counter #4'),
(104, '2026-02-10 12:09:38', 2, 'Staff User', 'staff', 'mark_done', 59, NULL, 'H001', 2, 4, 'Service completed'),
(105, '2026-02-10 12:09:54', 2, 'Staff User', 'staff', 'call_next', 60, NULL, 'H002', 2, 4, 'Called to Counter #4'),
(106, '2026-02-10 12:10:14', 2, 'Staff User', 'staff', 'mark_done', 60, NULL, 'H002', 2, 4, 'Service completed'),
(107, '2026-02-10 12:10:25', 2, 'Staff User', 'staff', 'call_next', 61, NULL, 'H003', 2, 4, 'Called to Counter #4'),
(108, '2026-02-10 12:11:35', 2, 'Staff User', 'staff', 'call_next', 64, NULL, 'H006', 2, 5, 'Called to Counter #5'),
(109, '2026-02-10 12:11:41', 2, 'Staff User', 'staff', 'call_next', 66, NULL, 'M002', 1, 2, 'Called to Counter #2'),
(110, '2026-02-10 12:11:46', 2, 'Staff User', 'staff', 'call_next', 65, NULL, 'M001', 1, 1, 'Called to Counter #1'),
(111, '2026-02-10 12:11:51', 2, 'Staff User', 'staff', 'call_next', 67, NULL, 'M003', 1, 3, 'Called to Counter #3'),
(112, '2026-02-10 12:12:23', 2, 'Staff User', 'staff', 'mark_done', 61, NULL, 'H003', 2, 4, 'Service completed'),
(113, '2026-02-10 12:12:26', 2, 'Staff User', 'staff', 'mark_done', 65, NULL, 'M001', 1, 1, 'Service completed'),
(114, '2026-02-10 12:12:31', 2, 'Staff User', 'staff', 'mark_done', 64, NULL, 'H006', 2, 5, 'Service completed'),
(115, '2026-02-10 12:12:34', 2, 'Staff User', 'staff', 'mark_done', 66, NULL, 'M002', 1, 2, 'Service completed'),
(116, '2026-02-10 12:12:43', 2, 'Staff User', 'staff', 'call_next', 62, NULL, 'H004', 2, 4, 'Called to Counter #4'),
(117, '2026-02-10 12:12:49', 2, 'Staff User', 'staff', 'mark_done', 62, NULL, 'H004', 2, 4, 'Service completed'),
(118, '2026-02-10 12:12:56', 2, 'Staff User', 'staff', 'call_next', 63, NULL, 'H005', 2, 4, 'Called to Counter #4'),
(119, '2026-02-10 12:13:00', 2, 'Staff User', 'staff', 'mark_done', 63, NULL, 'H005', 2, 4, 'Service completed'),
(120, '2026-02-10 12:13:04', 2, 'Staff User', 'staff', 'mark_done', 67, NULL, 'M003', 1, 3, 'Service completed'),
(121, '2026-02-13 14:31:53', 2, 'Staff User', 'staff', 'call_next', 68, NULL, 'H001', 2, 4, 'Called to Counter #4'),
(122, '2026-02-13 14:31:58', 2, 'Staff User', 'staff', 'mark_done', 68, NULL, 'H001', 2, 4, 'Service completed'),
(123, '2026-02-13 14:44:33', 2, 'Staff User', 'staff', 'call_next', 69, NULL, 'M001', 1, 1, 'Called to Counter #1'),
(124, '2026-02-13 14:47:58', 2, 'Staff User', 'staff', 'mark_done', 69, NULL, 'M001', 1, 1, 'Service completed'),
(125, '2026-02-13 14:48:49', 2, 'Staff User', 'staff', 'call_next', 73, NULL, 'M002', 1, 1, 'Called to Counter #1'),
(126, '2026-02-13 14:48:55', 2, 'Staff User', 'staff', 'call_next', 74, NULL, 'M003', 1, 3, 'Called to Counter #3'),
(127, '2026-02-13 14:49:00', 2, 'Staff User', 'staff', 'call_next', 70, NULL, 'H002', 2, 4, 'Called to Counter #4'),
(128, '2026-02-13 14:49:07', 2, 'Staff User', 'staff', 'call_next', 72, NULL, 'H004', 2, 5, 'Called to Counter #5'),
(129, '2026-02-13 14:51:28', 2, 'Staff User', 'staff', 'mark_done', 72, NULL, 'H004', 2, 5, 'Service completed'),
(130, '2026-02-13 14:51:41', 2, 'Staff User', 'staff', 'mark_done', 70, NULL, 'H002', 2, 4, 'Service completed'),
(131, '2026-02-13 14:51:47', 2, 'Staff User', 'staff', 'call_next', 71, NULL, 'H003', 2, 4, 'Called to Counter #4'),
(132, '2026-02-13 14:51:50', 2, 'Staff User', 'staff', 'mark_done', 71, NULL, 'H003', 2, 4, 'Service completed'),
(133, '2026-02-13 15:12:40', 2, 'Staff User', 'staff', 'mark_done', 73, NULL, 'M002', 1, 1, 'Service completed'),
(134, '2026-02-13 15:12:53', 2, 'Staff User', 'staff', 'mark_done', 74, NULL, 'M003', 1, 3, 'Service completed'),
(135, '2026-02-13 15:54:49', 2, 'Staff User', 'staff', 'call_next', 75, NULL, 'M004', 1, 3, 'Called to Counter #3'),
(136, '2026-02-13 15:54:57', 2, 'Staff User', 'staff', 'mark_done', 75, NULL, 'M004', 1, 3, 'Service completed'),
(137, '2026-02-13 16:29:48', 3, 'John Doe', 'staff', 'call_next', 76, NULL, 'M005', 1, 2, 'Called to Counter #2'),
(138, '2026-02-13 16:29:55', 3, 'John Doe', 'staff', 'mark_done', 76, NULL, 'M005', 1, 2, 'Service completed'),
(139, '2026-02-13 16:30:02', 3, 'John Doe', 'staff', 'call_next', 79, NULL, 'M006', 1, 3, 'Called to Counter #3'),
(140, '2026-02-13 16:30:04', 3, 'John Doe', 'staff', 'mark_done', 79, NULL, 'M006', 1, 3, 'Service completed'),
(141, '2026-02-13 16:30:12', 3, 'John Doe', 'staff', 'call_next', 77, NULL, 'H005', 2, 4, 'Called to Counter #4'),
(142, '2026-02-13 16:30:16', 3, 'John Doe', 'staff', 'mark_done', 77, NULL, 'H005', 2, 4, 'Service completed'),
(143, '2026-02-13 16:30:18', 3, 'John Doe', 'staff', 'call_next', 78, NULL, 'H006', 2, 4, 'Called to Counter #4'),
(144, '2026-02-13 16:30:23', 3, 'John Doe', 'staff', 'mark_done', 78, NULL, 'H006', 2, 4, 'Service completed'),
(145, '2026-02-26 12:28:11', 2, 'Staff User', 'staff', 'call_next', 80, NULL, 'H001', 2, 4, 'Called to Counter #4'),
(146, '2026-02-26 12:28:15', 2, 'Staff User', 'staff', 'call_next', 81, NULL, 'H002', 2, 5, 'Called to Counter #5'),
(147, '2026-02-26 12:28:20', 2, 'Staff User', 'staff', 'mark_done', 81, NULL, 'H002', 2, 5, 'Service completed'),
(148, '2026-02-26 12:28:30', 2, 'Staff User', 'staff', 'mark_done', 80, NULL, 'H001', 2, 4, 'Service completed'),
(149, '2026-02-26 13:30:28', 2, 'Staff User', 'staff', 'call_next', 82, NULL, 'M001', 1, 2, 'Called to Counter #2'),
(150, '2026-02-26 13:30:36', 2, 'Staff User', 'staff', 'mark_done', 82, NULL, 'M001', 1, 2, 'Service completed'),
(151, '2026-02-26 13:35:37', 2, 'Staff User', 'staff', 'call_next', 83, NULL, 'M002', 1, 4, 'Called to Counter #4'),
(152, '2026-02-26 13:35:40', 2, 'Staff User', 'staff', 'mark_done', 83, NULL, 'M002', 1, 4, 'Service completed'),
(153, '2026-02-26 20:05:52', 2, 'Staff User', 'staff', 'call_next', 84, NULL, 'H2003', 2, 8, 'Called to Counter #8'),
(154, '2026-02-26 20:05:56', 2, 'Staff User', 'staff', 'mark_done', 84, NULL, 'H2003', 2, 8, 'Service completed'),
(155, '2026-02-26 21:35:42', 2, 'Staff User', 'staff', 'call_next', 85, NULL, 'H2004', 2, 8, 'Called to Counter #8'),
(156, '2026-02-26 21:35:46', 2, 'Staff User', 'staff', 'mark_done', 85, NULL, 'H2004', 2, 8, 'Service completed'),
(157, '2026-02-26 21:39:45', 2, 'Staff User', 'staff', 'call_next', 86, NULL, 'H2005', 2, 2, 'Called to Counter #2'),
(158, '2026-02-26 21:39:48', 2, 'Staff User', 'staff', 'mark_done', 86, NULL, 'H2005', 2, 2, 'Service completed'),
(159, '2026-02-26 21:39:49', 2, 'Staff User', 'staff', 'call_next', 87, NULL, 'H2006', 2, 2, 'Called to Counter #2'),
(160, '2026-02-26 21:39:51', 2, 'Staff User', 'staff', 'mark_done', 87, NULL, 'H2006', 2, 2, 'Service completed'),
(161, '2026-02-26 21:39:52', 2, 'Staff User', 'staff', 'call_next', 88, NULL, 'H2007', 2, 2, 'Called to Counter #2'),
(162, '2026-02-26 21:41:59', 2, 'Staff User', 'staff', 'mark_done', 88, NULL, 'H2007', 2, 2, 'Service completed'),
(163, '2026-02-26 21:42:02', 2, 'Staff User', 'staff', 'call_next', 89, NULL, 'M2003', 1, 2, 'Called to Counter #2'),
(164, '2026-02-26 21:42:08', 2, 'Staff User', 'staff', 'mark_done', 89, NULL, 'M2003', 1, 2, 'Service completed'),
(165, '2026-02-26 21:57:35', 2, 'Staff User', 'staff', 'call_next', 92, NULL, 'H2010', 2, 2, 'Called to Counter #2'),
(166, '2026-02-26 21:57:37', 2, 'Staff User', 'staff', 'mark_done', 92, NULL, 'H2010', 2, 2, 'Service completed'),
(167, '2026-02-26 21:57:43', 2, 'Staff User', 'staff', 'call_next', 90, NULL, 'H2008', 2, 8, 'Called to Counter #8'),
(168, '2026-02-26 21:57:46', 2, 'Staff User', 'staff', 'mark_done', 90, NULL, 'H2008', 2, 8, 'Service completed'),
(169, '2026-02-26 21:57:47', 2, 'Staff User', 'staff', 'call_next', 91, NULL, 'H2009', 2, 8, 'Called to Counter #8'),
(170, '2026-02-26 21:57:49', 2, 'Staff User', 'staff', 'mark_done', 91, NULL, 'H2009', 2, 8, 'Service completed'),
(171, '2026-02-27 08:41:08', 2, 'Staff User', 'staff', 'call_next', 93, NULL, 'H2001', 2, 2, 'Called to Counter #2'),
(172, '2026-02-27 08:41:12', 2, 'Staff User', 'staff', 'mark_done', 93, NULL, 'H2001', 2, 2, 'Service completed'),
(173, '2026-02-27 08:41:16', 2, 'Staff User', 'staff', 'call_next', 94, NULL, 'H2002', 2, 2, 'Called to Counter #2'),
(174, '2026-02-27 08:41:18', 2, 'Staff User', 'staff', 'mark_done', 94, NULL, 'H2002', 2, 2, 'Service completed'),
(175, '2026-02-27 08:41:21', 2, 'Staff User', 'staff', 'call_next', 95, NULL, 'M2001', 1, 2, 'Called to Counter #2'),
(176, '2026-02-27 08:41:25', 2, 'Staff User', 'staff', 'mark_done', 95, NULL, 'M2001', 1, 2, 'Service completed'),
(177, '2026-03-01 15:42:33', 2, 'Staff User', 'staff', 'call_next', 98, NULL, 'H2002', 2, 2, 'Called to Counter #2'),
(178, '2026-03-01 15:42:36', 2, 'Staff User', 'staff', 'mark_done', 98, NULL, 'H2002', 2, 2, 'Service completed'),
(179, '2026-03-01 15:42:41', 2, 'Staff User', 'staff', 'call_next', 97, NULL, 'H2001', 2, 9, 'Called to Counter #9'),
(180, '2026-03-01 15:48:10', 2, 'Staff User', 'staff', 'mark_done', 97, NULL, 'H2001', 2, 9, 'Service completed'),
(181, '2026-03-01 16:04:16', 3, 'John Doe', 'staff', 'call_next', 99, 113, 'H2003', 2, 2, 'Called to Counter #2 | Client: Jay Batiola | Status: Checked in'),
(182, '2026-03-01 16:04:34', 3, 'John Doe', 'staff', 'mark_done', 99, 113, 'H2003', 2, 2, 'Service completed | Client: Jay Batiola | Status: Completed'),
(183, '2026-03-01 23:16:36', 3, 'John Doe', 'staff', 'call_next', 100, 114, 'H2004', 2, 8, 'Called to Counter #8 | Client: John Die | Status: Checked in'),
(184, '2026-03-01 23:16:38', 3, 'John Doe', 'staff', 'mark_done', 100, 114, 'H2004', 2, 8, 'Service completed | Client: John Die | Status: Completed'),
(185, '2026-03-01 23:16:40', 3, 'John Doe', 'staff', 'call_next', 101, 115, 'H2005', 2, 8, 'Called to Counter #8 | Client: Doe Die | Status: Checked in'),
(186, '2026-03-01 23:16:43', 3, 'John Doe', 'staff', 'mark_done', 101, 115, 'H2005', 2, 8, 'Service completed | Client: Doe Die | Status: Completed');

-- --------------------------------------------------------

--
-- Table structure for table `chatbot_events`
--

CREATE TABLE `chatbot_events` (
  `event_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_type` varchar(64) NOT NULL,
  `payload_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload_json`)),
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chatbot_events`
--

INSERT INTO `chatbot_events` (`event_id`, `user_id`, `event_type`, `payload_json`, `created_at`) VALUES
(1, 4, 'user_message', '{\"text\":\"asd\",\"source\":\"typed\",\"node_id\":null}', '2026-02-21 08:51:40'),
(2, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-21 08:51:40'),
(3, 4, 'quick_reply_click', '{\"label\":\"Book appointment\",\"value\":\"Book appointment\",\"node_id\":\"book\"}', '2026-02-21 08:51:52'),
(4, 4, 'user_message', '{\"text\":\"Book appointment\",\"source\":\"button\",\"node_id\":\"book\"}', '2026-02-21 08:51:52'),
(5, 4, 'bot_response', '{\"node_id\":\"book\",\"has_quick_replies\":true}', '2026-02-21 08:51:52'),
(6, 4, 'quick_reply_click', '{\"label\":\"Back to menu\",\"value\":\"Menu\",\"node_id\":\"root\"}', '2026-02-21 08:51:56'),
(7, 4, 'user_message', '{\"text\":\"Menu\",\"source\":\"button\",\"node_id\":\"root\"}', '2026-02-21 08:51:56'),
(8, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-21 08:51:56'),
(9, 4, 'user_message', '{\"text\":\"hi\",\"source\":\"typed\",\"node_id\":null}', '2026-02-21 08:56:55'),
(10, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-21 08:56:56'),
(11, 4, 'quick_reply_click', '{\"label\":\"Service requirements\",\"value\":\"Service requirements\",\"node_id\":\"req\"}', '2026-02-21 08:57:00'),
(12, 4, 'user_message', '{\"text\":\"Service requirements\",\"source\":\"button\",\"node_id\":\"req\"}', '2026-02-21 08:57:00'),
(13, 4, 'bot_response', '{\"node_id\":\"req\",\"has_quick_replies\":true}', '2026-02-21 08:57:00'),
(14, 4, 'user_message', '{\"text\":\"hi\",\"source\":\"typed\",\"node_id\":null}', '2026-02-21 09:03:57'),
(15, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-21 09:03:57'),
(16, 4, 'user_message', '{\"text\":\"fdfd\",\"source\":\"typed\",\"node_id\":null}', '2026-02-21 09:04:26'),
(17, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-21 09:04:26'),
(18, 4, 'quick_reply_click', '{\"label\":\"Book appointment\",\"value\":\"Book appointment\",\"node_id\":\"book\"}', '2026-02-21 09:04:43'),
(19, 4, 'user_message', '{\"text\":\"Book appointment\",\"source\":\"button\",\"node_id\":\"book\"}', '2026-02-21 09:04:44'),
(20, 4, 'bot_response', '{\"node_id\":\"book\",\"has_quick_replies\":true}', '2026-02-21 09:04:44'),
(21, 4, 'user_message', '{\"text\":\"what service are you booking?\",\"source\":\"typed\",\"node_id\":null}', '2026-02-21 09:05:19'),
(22, 4, 'bot_response', '{\"node_id\":\"book\",\"has_quick_replies\":true}', '2026-02-21 09:05:19'),
(23, 4, 'user_message', '{\"text\":\"hi\",\"source\":\"typed\",\"node_id\":null}', '2026-02-21 09:06:10'),
(24, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-21 09:06:10'),
(25, 4, 'quick_reply_click', '{\"label\":\"Book appointment\",\"value\":\"Book appointment\",\"node_id\":\"book\"}', '2026-02-21 10:11:03'),
(26, 4, 'user_message', '{\"text\":\"Book appointment\",\"source\":\"button\",\"node_id\":\"book\"}', '2026-02-21 10:11:03'),
(27, 4, 'bot_response', '{\"node_id\":\"book\",\"has_quick_replies\":true}', '2026-02-21 10:11:03'),
(28, 4, 'quick_reply_click', '{\"label\":\"What can I book?\",\"value\":\"What services can I book?\",\"node_id\":\"book_services\"}', '2026-02-21 10:11:29'),
(29, 4, 'user_message', '{\"text\":\"What services can I book?\",\"source\":\"button\",\"node_id\":\"book_services\"}', '2026-02-21 10:11:29'),
(30, 4, 'bot_response', '{\"node_id\":\"book\",\"has_quick_replies\":true}', '2026-02-21 10:11:29'),
(31, 4, 'quick_reply_click', '{\"label\":\"What can I book?\",\"value\":\"What services can I book?\",\"node_id\":\"book_services\"}', '2026-02-21 10:11:32'),
(32, 4, 'user_message', '{\"text\":\"What services can I book?\",\"source\":\"button\",\"node_id\":\"book_services\"}', '2026-02-21 10:11:32'),
(33, 4, 'bot_response', '{\"node_id\":\"book\",\"has_quick_replies\":true}', '2026-02-21 10:11:32'),
(34, 4, 'quick_reply_click', '{\"label\":\"Book appointment\",\"value\":\"Book appointment\",\"node_id\":\"book\"}', '2026-02-21 10:14:16'),
(35, 4, 'user_message', '{\"text\":\"Book appointment\",\"source\":\"button\",\"node_id\":\"book\"}', '2026-02-21 10:14:16'),
(36, 4, 'bot_response', '{\"node_id\":\"book\",\"has_quick_replies\":true}', '2026-02-21 10:14:16'),
(37, 4, 'user_message', '{\"text\":\"fsd\",\"source\":\"typed\",\"node_id\":null}', '2026-02-21 10:18:17'),
(38, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-21 10:18:17'),
(39, 4, 'user_message', '{\"text\":\"what are the services you provide?\",\"source\":\"typed\",\"node_id\":null}', '2026-02-21 10:18:48'),
(40, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-21 10:18:48'),
(41, 4, 'quick_reply_click', '{\"label\":\"Book appointment\",\"value\":\"Book appointment\",\"node_id\":\"book\"}', '2026-02-21 10:20:03'),
(42, 4, 'user_message', '{\"text\":\"Book appointment\",\"source\":\"button\",\"node_id\":\"book\"}', '2026-02-21 10:20:03'),
(43, 4, 'bot_response', '{\"node_id\":\"book\",\"has_quick_replies\":true}', '2026-02-21 10:20:03'),
(44, 4, 'quick_reply_click', '{\"label\":\"What can I book?\",\"value\":\"What services can I book?\",\"node_id\":\"book_services\"}', '2026-02-21 10:20:10'),
(45, 4, 'user_message', '{\"text\":\"What services can I book?\",\"source\":\"button\",\"node_id\":\"book_services\"}', '2026-02-21 10:20:10'),
(46, 4, 'bot_response', '{\"node_id\":\"book\",\"has_quick_replies\":true}', '2026-02-21 10:20:10'),
(47, 4, 'quick_reply_click', '{\"label\":\"Back to menu\",\"value\":\"Menu\",\"node_id\":\"root\"}', '2026-02-21 10:20:16'),
(48, 4, 'user_message', '{\"text\":\"Menu\",\"source\":\"button\",\"node_id\":\"root\"}', '2026-02-21 10:20:16'),
(49, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-21 10:20:16'),
(50, 4, 'quick_reply_click', '{\"label\":\"Service requirements\",\"value\":\"Service requirements\",\"node_id\":\"req\"}', '2026-02-21 10:20:18'),
(51, 4, 'user_message', '{\"text\":\"Service requirements\",\"source\":\"button\",\"node_id\":\"req\"}', '2026-02-21 10:20:18'),
(52, 4, 'bot_response', '{\"node_id\":\"req\",\"has_quick_replies\":true}', '2026-02-21 10:20:18'),
(53, 4, 'quick_reply_click', '{\"label\":\"My queue status\",\"value\":\"Queue status\",\"node_id\":\"queue\"}', '2026-02-21 10:23:15'),
(54, 4, 'user_message', '{\"text\":\"Queue status\",\"source\":\"button\",\"node_id\":\"queue\"}', '2026-02-21 10:23:15'),
(55, 4, 'bot_response', '{\"node_id\":\"queue\",\"has_quick_replies\":true}', '2026-02-21 10:23:15'),
(56, 4, 'quick_reply_click', '{\"label\":\"Meaning of Serving\\/Done\",\"value\":\"What does Serving mean?\",\"node_id\":\"queue_meaning\"}', '2026-02-21 10:23:22'),
(57, 4, 'user_message', '{\"text\":\"What does Serving mean?\",\"source\":\"button\",\"node_id\":\"queue_meaning\"}', '2026-02-21 10:23:23'),
(58, 4, 'bot_response', '{\"node_id\":\"queue\",\"has_quick_replies\":true}', '2026-02-21 10:23:23'),
(59, 4, 'quick_reply_click', '{\"label\":\"Meaning of Serving\\/Done\",\"value\":\"What does Serving mean?\",\"node_id\":\"queue_meaning\"}', '2026-02-21 10:23:32'),
(60, 4, 'user_message', '{\"text\":\"What does Serving mean?\",\"source\":\"button\",\"node_id\":\"queue_meaning\"}', '2026-02-21 10:23:32'),
(61, 4, 'bot_response', '{\"node_id\":\"queue\",\"has_quick_replies\":true}', '2026-02-21 10:23:32'),
(62, 4, 'quick_reply_click', '{\"label\":\"My queue number today\",\"value\":\"What is my queue number today?\",\"node_id\":\"queue_num\"}', '2026-02-21 10:23:35'),
(63, 4, 'user_message', '{\"text\":\"What is my queue number today?\",\"source\":\"button\",\"node_id\":\"queue_num\"}', '2026-02-21 10:23:35'),
(64, 4, 'bot_response', '{\"node_id\":\"queue\",\"has_quick_replies\":true}', '2026-02-21 10:23:35'),
(65, 4, 'quick_reply_click', '{\"label\":\"Back to menu\",\"value\":\"Menu\",\"node_id\":\"root\"}', '2026-02-21 10:23:37'),
(66, 4, 'user_message', '{\"text\":\"Menu\",\"source\":\"button\",\"node_id\":\"root\"}', '2026-02-21 10:23:37'),
(67, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-21 10:23:37'),
(68, 4, 'quick_reply_click', '{\"label\":\"Talk to agent\",\"value\":\"Talk to agent\",\"node_id\":\"agent\"}', '2026-02-21 10:23:39'),
(69, 4, 'user_message', '{\"text\":\"Talk to agent\",\"source\":\"button\",\"node_id\":\"agent\"}', '2026-02-21 10:23:39'),
(70, 4, 'bot_response', '{\"node_id\":\"agent\",\"has_quick_replies\":true}', '2026-02-21 10:23:40'),
(71, 4, 'quick_reply_click', '{\"label\":\"Back to menu\",\"value\":\"Menu\",\"node_id\":\"root\"}', '2026-02-21 10:23:51'),
(72, 4, 'user_message', '{\"text\":\"Menu\",\"source\":\"button\",\"node_id\":\"root\"}', '2026-02-21 10:23:51'),
(73, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-21 10:23:51'),
(74, 4, 'quick_reply_click', '{\"label\":\"Service requirements\",\"value\":\"Service requirements\",\"node_id\":\"req\"}', '2026-02-21 10:23:54'),
(75, 4, 'user_message', '{\"text\":\"Service requirements\",\"source\":\"button\",\"node_id\":\"req\"}', '2026-02-21 10:23:54'),
(76, 4, 'bot_response', '{\"node_id\":\"req\",\"has_quick_replies\":true}', '2026-02-21 10:23:54'),
(77, 4, 'quick_reply_click', '{\"label\":\"Service requirements\",\"value\":\"Service requirements\",\"node_id\":\"req\"}', '2026-02-21 10:26:10'),
(78, 4, 'user_message', '{\"text\":\"Service requirements\",\"source\":\"button\",\"node_id\":\"req\"}', '2026-02-21 10:26:10'),
(79, 4, 'bot_response', '{\"node_id\":\"req\",\"has_quick_replies\":true}', '2026-02-21 10:26:11'),
(80, 4, 'quick_reply_click', '{\"label\":\"What documents do I need?\",\"value\":\"What documents are required?\",\"node_id\":\"req_docs\"}', '2026-02-21 10:26:20'),
(81, 4, 'user_message', '{\"text\":\"What documents are required?\",\"source\":\"button\",\"node_id\":\"req_docs\"}', '2026-02-21 10:26:20'),
(82, 4, 'bot_response', '{\"node_id\":\"req\",\"has_quick_replies\":true}', '2026-02-21 10:26:20'),
(83, 4, 'quick_reply_click', '{\"label\":\"Requirements per service\",\"value\":\"Show requirements per service\",\"node_id\":\"req_per_service\"}', '2026-02-21 10:26:24'),
(84, 4, 'user_message', '{\"text\":\"Show requirements per service\",\"source\":\"button\",\"node_id\":\"req_per_service\"}', '2026-02-21 10:26:24'),
(85, 4, 'bot_response', '{\"node_id\":\"req\",\"has_quick_replies\":true}', '2026-02-21 10:26:24'),
(86, 4, 'user_message', '{\"text\":\"membership registration\",\"source\":\"typed\",\"node_id\":null}', '2026-02-21 10:26:44'),
(87, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-21 10:26:44'),
(88, 4, 'user_message', '{\"text\":\"Proseso ng Pagkuha ng Appointment\",\"source\":\"button\",\"node_id\":\"appointment_process\"}', '2026-02-21 10:54:42'),
(89, 4, 'bot_response', '{\"node_id\":\"appointment_process\",\"has_quick_replies\":true}', '2026-02-21 10:54:42'),
(90, 4, 'quick_reply_click', '{\"label\":\"Benepisyong Pangkalusugan\",\"value\":\"Benepisyong Pangkalusugan\",\"node_id\":\"benefits\"}', '2026-02-21 10:56:06'),
(91, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-02-21 10:56:06'),
(92, 4, 'bot_response', '{\"node_id\":\"benefits\",\"has_quick_replies\":true}', '2026-02-21 10:56:06'),
(93, 4, 'user_message', '{\"text\":\"Impormasyon sa Membership\",\"source\":\"button\",\"node_id\":\"membership\"}', '2026-02-21 10:56:53'),
(94, 4, 'bot_response', '{\"node_id\":\"membership\",\"has_quick_replies\":true}', '2026-02-21 10:56:53'),
(95, 4, 'user_message', '{\"text\":\"Impormasyon sa Membership\",\"source\":\"button\",\"node_id\":\"membership\"}', '2026-02-21 11:32:38'),
(96, 4, 'bot_response', '{\"node_id\":\"membership\",\"has_quick_replies\":true}', '2026-02-21 11:32:38'),
(97, 4, 'user_message', '{\"text\":\"Impormasyon sa Membership\",\"source\":\"button\",\"node_id\":\"membership\"}', '2026-02-21 11:39:33'),
(98, 4, 'bot_response', '{\"node_id\":\"membership\",\"has_quick_replies\":true}', '2026-02-21 11:39:33'),
(99, 7, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-02-21 14:36:13'),
(100, 7, 'bot_response', '{\"node_id\":\"benefits\",\"has_quick_replies\":true}', '2026-02-21 14:36:13'),
(101, 7, 'user_message', '{\"text\":\"Proseso ng Pagkuha ng Appointment\",\"source\":\"button\",\"node_id\":\"appointment_process\"}', '2026-02-21 14:51:09'),
(102, 7, 'bot_response', '{\"node_id\":\"appointment_process\",\"has_quick_replies\":true}', '2026-02-21 14:51:09'),
(103, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-02-24 12:27:24'),
(104, 4, 'bot_response', '{\"node_id\":\"benefits\",\"has_quick_replies\":true}', '2026-02-24 12:27:24'),
(105, 4, 'user_message', '{\"text\":\"Ano ang Philhealth Yakap?\",\"source\":\"typed\",\"node_id\":null}', '2026-02-24 12:27:29'),
(106, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-24 12:27:29'),
(107, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-02-24 12:28:09'),
(108, 4, 'bot_response', '{\"node_id\":\"benefits\",\"has_quick_replies\":true}', '2026-02-24 12:28:09'),
(109, 4, 'user_message', '{\"text\":\"Ano ang Philhealth Yakap?\",\"source\":\"typed\",\"node_id\":null}', '2026-02-24 12:28:34'),
(110, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-24 12:28:34'),
(111, 4, 'user_message', '{\"text\":\"Proseso ng Pagkuha ng Appointment\",\"source\":\"button\",\"node_id\":\"appointment_process\"}', '2026-02-24 20:30:02'),
(112, 4, 'bot_response', '{\"node_id\":\"appointment_process\",\"has_quick_replies\":true}', '2026-02-24 20:30:13'),
(113, 4, 'user_message', '{\"text\":\"Pano lumilipad ang mga ibon?\",\"source\":\"typed\",\"node_id\":\"appointment_process\"}', '2026-02-24 20:31:26'),
(114, 4, 'bot_response', '{\"node_id\":\"appointment_process\",\"has_quick_replies\":true}', '2026-02-24 20:31:31'),
(115, 4, 'user_message', '{\"text\":\"daswe\",\"source\":\"typed\",\"node_id\":\"appointment_process\"}', '2026-02-24 20:31:56'),
(116, 4, 'bot_response', '{\"node_id\":\"appointment_process\",\"has_quick_replies\":true}', '2026-02-24 20:32:00'),
(117, 4, 'user_message', '{\"text\":\"ghdgfhrwfsf\",\"source\":\"typed\",\"node_id\":\"appointment_process\"}', '2026-02-24 20:32:06'),
(118, 4, 'bot_response', '{\"node_id\":\"appointment_process\",\"has_quick_replies\":true}', '2026-02-24 20:32:09'),
(119, 4, 'user_message', '{\"text\":\"rfesdfqwrefg\",\"source\":\"typed\",\"node_id\":\"appointment_process\"}', '2026-02-24 20:32:14'),
(120, 4, 'bot_response', '{\"node_id\":\"appointment_process\",\"has_quick_replies\":true}', '2026-02-24 20:32:17'),
(121, 4, 'user_message', '{\"text\":\"Impormasyon sa Membership\",\"source\":\"button\",\"node_id\":\"membership\"}', '2026-02-24 20:42:22'),
(122, 4, 'bot_response', '{\"node_id\":\"membership\",\"has_quick_replies\":true}', '2026-02-24 20:42:22'),
(123, 4, 'user_message', '{\"text\":\"updating records\",\"source\":\"typed\",\"node_id\":\"membership\"}', '2026-02-24 20:42:36'),
(124, 4, 'bot_response', '{\"node_id\":\"membership\",\"has_quick_replies\":true}', '2026-02-24 20:42:37'),
(125, 4, 'user_message', '{\"text\":\"dasdsafas\",\"source\":\"typed\",\"node_id\":\"membership\"}', '2026-02-24 20:42:44'),
(126, 4, 'bot_response', '{\"node_id\":\"membership\",\"has_quick_replies\":true}', '2026-02-24 20:42:44'),
(127, 4, 'user_message', '{\"text\":\"asdas\",\"source\":\"typed\",\"node_id\":\"membership\"}', '2026-02-24 20:42:45'),
(128, 4, 'bot_response', '{\"node_id\":\"membership\",\"has_quick_replies\":true}', '2026-02-24 20:42:45'),
(129, 4, 'user_message', '{\"text\":\"f\",\"source\":\"typed\",\"node_id\":\"membership\"}', '2026-02-24 20:42:45'),
(130, 4, 'bot_response', '{\"node_id\":\"membership\",\"has_quick_replies\":true}', '2026-02-24 20:42:45'),
(131, 4, 'user_message', '{\"text\":\"f\",\"source\":\"typed\",\"node_id\":\"membership\"}', '2026-02-24 20:42:45'),
(132, 4, 'bot_response', '{\"node_id\":\"membership\",\"has_quick_replies\":true}', '2026-02-24 20:42:45'),
(133, 4, 'user_message', '{\"text\":\"f\",\"source\":\"typed\",\"node_id\":\"membership\"}', '2026-02-24 20:42:46'),
(134, 4, 'bot_response', '{\"node_id\":\"membership\",\"has_quick_replies\":true}', '2026-02-24 20:42:46'),
(135, 4, 'user_message', '{\"text\":\"as\",\"source\":\"typed\",\"node_id\":\"membership\"}', '2026-02-24 20:42:46'),
(136, 4, 'bot_response', '{\"node_id\":\"membership\",\"has_quick_replies\":true}', '2026-02-24 20:42:46'),
(137, 4, 'user_message', '{\"text\":\"sa\",\"source\":\"typed\",\"node_id\":\"membership\"}', '2026-02-24 20:42:46'),
(138, 4, 'bot_response', '{\"node_id\":\"membership\",\"has_quick_replies\":true}', '2026-02-24 20:42:46'),
(139, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-02-24 20:42:50'),
(140, 4, 'bot_response', '{\"node_id\":\"benefits\",\"has_quick_replies\":true}', '2026-02-24 20:42:50'),
(141, 4, 'user_message', '{\"text\":\"Impormasyon sa Membership\",\"source\":\"button\",\"node_id\":\"membership\"}', '2026-02-24 20:42:52'),
(142, 4, 'bot_response', '{\"node_id\":\"membership\",\"has_quick_replies\":true}', '2026-02-24 20:42:52'),
(143, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-02-24 20:42:54'),
(144, 4, 'bot_response', '{\"node_id\":\"benefits\",\"has_quick_replies\":true}', '2026-02-24 20:42:54'),
(145, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-02-24 20:42:55'),
(146, 4, 'bot_response', '{\"node_id\":\"benefits\",\"has_quick_replies\":true}', '2026-02-24 20:42:55'),
(147, 4, 'user_message', '{\"text\":\"asfsafas\",\"source\":\"typed\",\"node_id\":\"benefits\"}', '2026-02-24 20:42:57'),
(148, 4, 'bot_response', '{\"node_id\":\"benefits\",\"has_quick_replies\":true}', '2026-02-24 20:42:57'),
(149, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-02-26 23:19:57'),
(150, 4, 'bot_response', '{\"node_id\":\"benefits\",\"has_quick_replies\":true}', '2026-02-26 23:20:05'),
(151, 4, 'user_message', '{\"text\":\"how the birds fly?\",\"source\":\"typed\",\"node_id\":\"benefits\"}', '2026-02-26 23:20:21'),
(152, 4, 'bot_response', '{\"node_id\":\"benefits\",\"has_quick_replies\":true}', '2026-02-26 23:20:29'),
(153, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-02-28 12:40:01'),
(154, 4, 'bot_response', '{\"node_id\":\"benefits\",\"has_quick_replies\":true}', '2026-02-28 12:40:29'),
(155, 4, 'user_message', '{\"text\":\"Proseso ng Pagkuha ng Appointment\",\"source\":\"button\",\"node_id\":\"appointment_process\"}', '2026-02-28 12:56:46'),
(156, 4, 'bot_response', '{\"node_id\":\"appointment_process\",\"has_quick_replies\":true}', '2026-02-28 12:56:53'),
(157, 4, 'user_message', '{\"text\":\"how the birds fly?\",\"source\":\"typed\",\"node_id\":\"appointment_process\"}', '2026-02-28 12:57:32'),
(158, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-28 12:57:38'),
(159, 4, 'user_message', '{\"text\":\"3+3?\",\"source\":\"typed\",\"node_id\":\"root\"}', '2026-02-28 12:57:50'),
(160, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-28 12:57:50'),
(161, 4, 'user_message', '{\"text\":\"what are the benefits of philhealth?\",\"source\":\"typed\",\"node_id\":\"root\"}', '2026-02-28 12:59:00'),
(162, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-28 12:59:06'),
(163, 4, 'user_message', '{\"text\":\"sdasfsaf\",\"source\":\"typed\",\"node_id\":\"root\"}', '2026-02-28 12:59:15'),
(164, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-28 12:59:15'),
(165, 4, 'user_message', '{\"text\":\"Queue status\",\"source\":\"button\",\"node_id\":\"queue\"}', '2026-02-28 12:59:33'),
(166, 4, 'bot_response', '{\"node_id\":\"queue\",\"has_quick_replies\":true}', '2026-02-28 12:59:40'),
(167, 4, 'user_message', '{\"text\":\"What is my queue number today?\",\"source\":\"button\",\"node_id\":\"queue_num\"}', '2026-02-28 13:00:27'),
(168, 4, 'bot_response', '{\"node_id\":\"queue_num\",\"has_quick_replies\":false}', '2026-02-28 13:00:32'),
(169, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-02-28 13:30:24'),
(170, 4, 'bot_response', '{\"node_id\":\"benefits\",\"has_quick_replies\":true}', '2026-02-28 13:30:31'),
(171, 4, 'user_message', '{\"text\":\"Proseso ng Pagkuha ng Appointment\",\"source\":\"button\",\"node_id\":\"appointment_process\"}', '2026-02-28 13:31:07'),
(172, 4, 'bot_response', '{\"node_id\":\"appointment_process\",\"has_quick_replies\":true}', '2026-02-28 13:31:12'),
(173, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-02-28 14:17:48'),
(174, 4, 'bot_response', '{\"node_id\":\"benefits\",\"has_quick_replies\":true}', '2026-02-28 14:17:54'),
(175, 4, 'user_message', '{\"text\":\"Proseso ng Pagkuha ng Appointment\",\"source\":\"button\",\"node_id\":\"appointment_process\"}', '2026-02-28 14:18:04'),
(176, 4, 'bot_response', '{\"node_id\":\"appointment_process\",\"has_quick_replies\":true}', '2026-02-28 14:18:10'),
(177, 4, 'user_message', '{\"text\":\"Impormasyon sa Membership\",\"source\":\"button\",\"node_id\":\"membership\"}', '2026-02-28 14:19:16'),
(178, 4, 'bot_response', '{\"node_id\":\"membership\",\"has_quick_replies\":true}', '2026-02-28 14:19:19'),
(179, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-02-28 14:19:47'),
(180, 4, 'bot_response', '{\"node_id\":\"benefits\",\"has_quick_replies\":true}', '2026-02-28 14:19:52'),
(181, 4, 'user_message', '{\"text\":\"how the birds fly?\",\"source\":\"typed\",\"node_id\":\"benefits\"}', '2026-02-28 14:20:02'),
(182, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-28 14:20:07'),
(183, 4, 'user_message', '{\"text\":\"asdsadas\",\"source\":\"typed\",\"node_id\":\"root\"}', '2026-02-28 14:20:40'),
(184, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-28 14:20:40'),
(185, 4, 'user_message', '{\"text\":\"Proseso ng Pagkuha ng Appointment\",\"source\":\"button\",\"node_id\":\"appointment_process\"}', '2026-02-28 17:50:32'),
(186, 4, 'bot_response', '{\"node_id\":\"appointment_process\",\"has_quick_replies\":true}', '2026-02-28 17:50:55'),
(187, 4, 'user_message', '{\"text\":\"how the birds fly?\",\"source\":\"typed\",\"node_id\":\"appointment_process\"}', '2026-02-28 17:51:21'),
(188, 4, 'bot_response', '{\"node_id\":\"root\",\"has_quick_replies\":true}', '2026-02-28 17:51:25'),
(189, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-03-01 15:32:15'),
(190, 4, 'bot_response', '{\"node_id\":\"benefits\"}', '2026-03-01 15:32:22'),
(191, 4, 'user_message', '{\"text\":\"how the birds fly? and 1+12\",\"source\":\"typed\",\"node_id\":\"benefits\"}', '2026-03-01 15:32:54'),
(192, 4, 'bot_response', '{\"node_id\":\"root\"}', '2026-03-01 15:33:00'),
(193, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-03-01 21:33:15'),
(194, 4, 'bot_response', '{\"node_id\":\"benefits\"}', '2026-03-01 21:33:26'),
(195, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-03-01 21:42:12'),
(196, 4, 'bot_response', '{\"node_id\":\"benefits\"}', '2026-03-01 21:42:32'),
(197, 4, 'user_message', '{\"text\":\"Proseso ng Pagkuha ng Appointment\",\"source\":\"button\",\"node_id\":\"appointment_process\"}', '2026-03-01 21:42:57'),
(198, 4, 'bot_response', '{\"node_id\":\"appointment_process\"}', '2026-03-01 21:43:06'),
(199, 4, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-03-01 21:53:51'),
(200, 4, 'bot_response', '{\"node_id\":\"benefits\"}', '2026-03-01 21:53:59'),
(201, 4, 'user_message', '{\"text\":\"how the birds fly?\",\"source\":\"typed\",\"node_id\":\"benefits\"}', '2026-03-01 21:54:11'),
(202, 4, 'bot_response', '{\"node_id\":\"root\"}', '2026-03-01 21:54:18'),
(203, 4, 'user_message', '{\"text\":\"dasdsa\",\"source\":\"typed\",\"node_id\":\"root\"}', '2026-03-01 21:54:22'),
(204, 4, 'bot_response', '{\"node_id\":\"root\"}', '2026-03-01 21:54:23'),
(205, 4, 'user_message', '{\"text\":\"how how\",\"source\":\"typed\",\"node_id\":\"root\"}', '2026-03-01 21:55:12'),
(206, 4, 'bot_response', '{\"node_id\":\"root\"}', '2026-03-01 21:55:12'),
(207, 4, 'user_message', '{\"text\":\"Proseso ng Pagkuha ng Appointment\",\"source\":\"button\",\"node_id\":\"appointment_process\"}', '2026-03-01 21:55:27'),
(208, 4, 'bot_response', '{\"node_id\":\"appointment_process\"}', '2026-03-01 21:55:54'),
(209, 1, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-03-01 22:39:00'),
(210, 1, 'bot_response', '{\"node_id\":\"benefits\"}', '2026-03-01 22:39:06'),
(211, 1, 'user_message', '{\"text\":\"dasfasf\",\"source\":\"typed\",\"node_id\":\"benefits\"}', '2026-03-01 22:39:12'),
(212, 1, 'bot_response', '{\"node_id\":\"benefits\"}', '2026-03-01 22:39:19'),
(213, 1, 'user_message', '{\"text\":\"how the birds fly?\",\"source\":\"typed\",\"node_id\":\"benefits\"}', '2026-03-01 22:39:31'),
(214, 1, 'bot_response', '{\"node_id\":\"benefits\"}', '2026-03-01 22:39:39'),
(215, 1, 'user_message', '{\"text\":\"Benepisyong Pangkalusugan\",\"source\":\"button\",\"node_id\":\"benefits\"}', '2026-03-01 22:39:45'),
(216, 1, 'bot_response', '{\"node_id\":\"benefits\"}', '2026-03-01 22:39:51'),
(217, 1, 'user_message', '{\"text\":\"how the birds fly?\",\"source\":\"typed\",\"node_id\":\"benefits\"}', '2026-03-01 22:40:05'),
(218, 1, 'bot_response', '{\"node_id\":\"benefits\"}', '2026-03-01 22:40:35'),
(219, 1, 'user_message', '{\"text\":\"twgerfrrwe\",\"source\":\"typed\",\"node_id\":\"benefits\"}', '2026-03-01 22:40:56'),
(220, 1, 'bot_response', '{\"node_id\":\"benefits\"}', '2026-03-01 22:41:01'),
(221, 1, 'user_message', '{\"text\":\"Impormasyon sa Membership\",\"source\":\"button\",\"node_id\":\"membership\"}', '2026-03-01 22:41:10'),
(222, 1, 'bot_response', '{\"node_id\":\"membership\"}', '2026-03-01 22:41:16'),
(223, 1, 'user_message', '{\"text\":\"how the birds fly?\",\"source\":\"typed\",\"node_id\":\"membership\"}', '2026-03-01 22:41:26'),
(224, 1, 'bot_response', '{\"node_id\":\"root\"}', '2026-03-01 22:41:30');

-- --------------------------------------------------------

--
-- Table structure for table `counter_services`
--

CREATE TABLE `counter_services` (
  `id` int(11) NOT NULL,
  `counter_id` int(11) NOT NULL,
  `service_name` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `counter_services`
--

INSERT INTO `counter_services` (`id`, `counter_id`, `service_name`, `is_active`) VALUES
(1, 4, 'Membership Registration', 1),
(2, 4, 'Membership Renewal', 1),
(3, 4, 'Amendment of Member Data Record', 1),
(4, 6, 'Membership Registration', 1),
(5, 6, 'Membership Renewal', 1),
(6, 6, 'Amendment of Member Data Record', 1),
(7, 7, 'Membership Registration', 1),
(8, 7, 'Membership Renewal', 1),
(9, 7, 'Amendment of Member Data Record', 1),
(10, 8, 'Admission Verification', 1),
(11, 8, 'Benefit Coverage Assessment', 1),
(12, 8, 'Hospital Billing & Claims', 1),
(13, 9, 'Admission Verification', 1),
(14, 9, 'Benefit Coverage Assessment', 1),
(15, 9, 'Hospital Billing & Claims', 1),
(16, 2, 'Membership Registration', 1),
(17, 2, 'Membership Renewal', 1),
(18, 2, 'Amendment of Member Data Record', 1),
(19, 2, 'Admission Verification', 1),
(20, 2, 'Benefit Coverage Assessment', 1),
(21, 2, 'Hospital Billing & Claims', 1);

-- --------------------------------------------------------

--
-- Table structure for table `queue`
--

CREATE TABLE `queue` (
  `queue_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `queue_date` date NOT NULL,
  `category_id` int(11) NOT NULL,
  `prefix` varchar(3) NOT NULL,
  `queue_number` int(11) NOT NULL,
  `queue_code` varchar(10) NOT NULL,
  `counter_id` int(11) DEFAULT NULL,
  `status` enum('waiting','serving','done','cancelled') NOT NULL DEFAULT 'waiting',
  `queued_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `queue`
--

INSERT INTO `queue` (`queue_id`, `appointment_id`, `queue_date`, `category_id`, `prefix`, `queue_number`, `queue_code`, `counter_id`, `status`, `queued_at`) VALUES
(1, 1, '2026-02-03', 2, 'H', 1, 'H001', 1, 'done', '2026-02-03 14:06:38'),
(2, 4, '2026-02-03', 2, 'H', 2, 'H002', 1, 'done', '2026-02-03 14:15:14'),
(3, 7, '2026-02-03', 1, 'M', 1, 'M001', 1, 'done', '2026-02-03 14:17:59'),
(4, 8, '2026-02-03', 2, 'H', 3, 'H003', 1, 'done', '2026-02-03 15:04:20'),
(5, 9, '2026-02-03', 1, 'M', 2, 'M002', 1, 'done', '2026-02-03 16:34:41'),
(6, 10, '2026-02-03', 1, 'M', 3, 'M003', 1, 'done', '2026-02-03 16:35:42'),
(7, 12, '2026-02-03', 2, 'H', 4, 'H004', 1, 'done', '2026-02-03 16:37:18'),
(8, 13, '2026-02-03', 2, 'H', 5, 'H005', 1, 'done', '2026-02-03 16:38:04'),
(9, 14, '2026-02-03', 2, 'H', 6, 'H006', 1, 'done', '2026-02-03 16:41:55'),
(10, 11, '2026-02-03', 2, 'H', 7, 'H007', 1, 'done', '2026-02-03 17:08:27'),
(11, 15, '2026-02-03', 2, 'H', 8, 'H008', 1, 'done', '2026-02-03 17:08:41'),
(12, 17, '2026-02-03', 2, 'H', 9, 'H009', 1, 'done', '2026-02-03 18:41:58'),
(13, 2, '2026-02-04', 1, 'M', 1, 'M001', 2, 'done', '2026-02-04 08:29:34'),
(14, 16, '2026-02-04', 2, 'H', 1, 'H001', 2, 'done', '2026-02-04 08:29:41'),
(15, 18, '2026-02-04', 1, 'M', 2, 'M002', 1, 'done', '2026-02-04 09:01:06'),
(16, 20, '2026-02-04', 2, 'H', 2, 'H002', 1, 'done', '2026-02-04 09:18:37'),
(17, 21, '2026-02-04', 1, 'M', 3, 'M003', 1, 'done', '2026-02-04 09:20:04'),
(18, 22, '2026-02-04', 2, 'H', 3, 'H003', 4, 'done', '2026-02-04 09:33:13'),
(19, 23, '2026-02-04', 2, 'H', 4, 'H004', 4, 'done', '2026-02-04 09:42:29'),
(20, 24, '2026-02-04', 2, 'H', 5, 'H005', 4, 'done', '2026-02-04 09:46:17'),
(21, 25, '2026-02-04', 1, 'M', 4, 'M004', 2, 'done', '2026-02-04 09:46:57'),
(22, 27, '2026-02-04', 2, 'H', 6, 'H006', 4, 'done', '2026-02-04 09:50:17'),
(23, 26, '2026-02-04', 2, 'H', 7, 'H007', 4, 'done', '2026-02-04 09:51:00'),
(24, 29, '2026-02-04', 2, 'H', 8, 'H008', 5, 'done', '2026-02-04 09:52:29'),
(25, 30, '2026-02-04', 1, 'M', 5, 'M005', 1, 'done', '2026-02-04 09:53:01'),
(26, 31, '2026-02-04', 1, 'M', 6, 'M006', 2, 'done', '2026-02-04 09:54:07'),
(27, 32, '2026-02-04', 2, 'H', 9, 'H009', 5, 'done', '2026-02-04 09:58:40'),
(28, 33, '2026-02-04', 1, 'M', 7, 'M007', 2, 'done', '2026-02-04 10:01:15'),
(29, 34, '2026-02-04', 1, 'M', 8, 'M008', 3, 'done', '2026-02-04 10:02:05'),
(30, 35, '2026-02-04', 2, 'H', 10, 'H010', 4, 'done', '2026-02-04 10:02:09'),
(31, 36, '2026-02-04', 2, 'H', 11, 'H011', 5, 'done', '2026-02-04 10:02:13'),
(32, 37, '2026-02-04', 1, 'M', 9, 'M009', 1, 'done', '2026-02-04 10:02:17'),
(33, 38, '2026-02-04', 1, 'M', 10, 'M010', 2, 'done', '2026-02-04 10:02:26'),
(34, 39, '2026-02-04', 1, 'M', 11, 'M011', 1, 'done', '2026-02-04 11:12:40'),
(35, 40, '2026-02-04', 1, 'M', 12, 'M012', 1, 'done', '2026-02-04 11:14:35'),
(36, 41, '2026-02-04', 2, 'H', 12, 'H012', 4, 'done', '2026-02-04 12:50:07'),
(37, 42, '2026-02-04', 2, 'H', 13, 'H013', 4, 'done', '2026-02-04 12:58:42'),
(38, 43, '2026-02-04', 2, 'H', 14, 'H014', 4, 'done', '2026-02-04 13:02:34'),
(39, 44, '2026-02-04', 2, 'H', 15, 'H015', 4, 'done', '2026-02-04 13:02:38'),
(40, 45, '2026-02-04', 2, 'H', 16, 'H016', 5, 'done', '2026-02-04 13:02:41'),
(41, 46, '2026-02-04', 1, 'M', 13, 'M013', 1, 'done', '2026-02-04 13:02:45'),
(42, 47, '2026-02-04', 1, 'M', 14, 'M014', 2, 'done', '2026-02-04 13:02:49'),
(43, 48, '2026-02-04', 1, 'M', 15, 'M015', 3, 'done', '2026-02-04 13:02:54'),
(44, 49, '2026-02-04', 2, 'H', 17, 'H017', 4, 'done', '2026-02-04 13:02:59'),
(45, 50, '2026-02-04', 2, 'H', 18, 'H018', 5, 'done', '2026-02-04 13:03:02'),
(46, 51, '2026-02-04', 2, 'H', 19, 'H019', 5, 'done', '2026-02-04 13:03:02'),
(47, 52, '2026-02-04', 1, 'M', 16, 'M016', 3, 'done', '2026-02-04 13:05:32'),
(48, 53, '2026-02-04', 2, 'H', 20, 'H020', 4, 'done', '2026-02-04 13:09:35'),
(49, 54, '2026-02-04', 2, 'H', 21, 'H021', 4, 'done', '2026-02-04 13:09:39'),
(50, 55, '2026-02-04', 1, 'M', 17, 'M017', 1, 'done', '2026-02-04 13:09:44'),
(51, 56, '2026-02-04', 1, 'M', 18, 'M018', 2, 'done', '2026-02-04 13:09:48'),
(52, 57, '2026-02-04', 2, 'H', 22, 'H022', 5, 'done', '2026-02-04 13:10:24'),
(53, 58, '2026-02-04', 1, 'M', 19, 'M019', 3, 'done', '2026-02-04 13:10:54'),
(54, 59, '2026-02-04', 1, 'M', 20, 'M020', 2, 'done', '2026-02-04 13:25:27'),
(55, 60, '2026-02-04', 1, 'M', 21, 'M021', 1, 'done', '2026-02-04 13:25:30'),
(56, 61, '2026-02-04', 1, 'M', 22, 'M022', 3, 'done', '2026-02-04 13:25:33'),
(57, 62, '2026-02-04', 2, 'H', 23, 'H023', 4, 'done', '2026-02-04 13:25:37'),
(58, 63, '2026-02-04', 2, 'H', 24, 'H024', 5, 'done', '2026-02-04 13:25:40'),
(59, 64, '2026-02-10', 2, 'H', 1, 'H001', 4, 'done', '2026-02-10 12:08:38'),
(60, 65, '2026-02-10', 2, 'H', 2, 'H002', 4, 'done', '2026-02-10 12:08:50'),
(61, 66, '2026-02-10', 2, 'H', 3, 'H003', 4, 'done', '2026-02-10 12:08:56'),
(62, 67, '2026-02-10', 2, 'H', 4, 'H004', 4, 'done', '2026-02-10 12:10:33'),
(63, 68, '2026-02-10', 2, 'H', 5, 'H005', 4, 'done', '2026-02-10 12:10:36'),
(64, 69, '2026-02-10', 2, 'H', 6, 'H006', 5, 'done', '2026-02-10 12:10:40'),
(65, 70, '2026-02-10', 1, 'M', 1, 'M001', 1, 'done', '2026-02-10 12:10:44'),
(66, 71, '2026-02-10', 1, 'M', 2, 'M002', 2, 'done', '2026-02-10 12:10:48'),
(67, 72, '2026-02-10', 1, 'M', 3, 'M003', 3, 'done', '2026-02-10 12:10:52'),
(68, 73, '2026-02-13', 2, 'H', 1, 'H001', 4, 'done', '2026-02-13 14:31:27'),
(69, 74, '2026-02-13', 1, 'M', 1, 'M001', 1, 'done', '2026-02-13 14:42:12'),
(70, 75, '2026-02-13', 2, 'H', 2, 'H002', 4, 'done', '2026-02-13 14:42:15'),
(71, 76, '2026-02-13', 2, 'H', 3, 'H003', 4, 'done', '2026-02-13 14:42:17'),
(72, 77, '2026-02-13', 2, 'H', 4, 'H004', 5, 'done', '2026-02-13 14:42:20'),
(73, 78, '2026-02-13', 1, 'M', 2, 'M002', 1, 'done', '2026-02-13 14:42:24'),
(74, 79, '2026-02-13', 1, 'M', 3, 'M003', 3, 'done', '2026-02-13 14:42:28'),
(75, 80, '2026-02-13', 1, 'M', 4, 'M004', 3, 'done', '2026-02-13 15:54:34'),
(76, 81, '2026-02-13', 1, 'M', 5, 'M005', 2, 'done', '2026-02-13 16:29:01'),
(77, 82, '2026-02-13', 2, 'H', 5, 'H005', 4, 'done', '2026-02-13 16:29:07'),
(78, 83, '2026-02-13', 2, 'H', 6, 'H006', 4, 'done', '2026-02-13 16:29:17'),
(79, 84, '2026-02-13', 1, 'M', 6, 'M006', 3, 'done', '2026-02-13 16:29:25'),
(80, 91, '2026-02-26', 2, 'H', 1, 'H001', 4, 'done', '2026-02-26 12:27:52'),
(81, 92, '2026-02-26', 2, 'H', 2, 'H002', 5, 'done', '2026-02-26 12:28:03'),
(82, 94, '2026-02-26', 1, 'M', 1, 'M001', 2, 'done', '2026-02-26 13:20:38'),
(83, 97, '2026-02-26', 1, 'M', 2, 'M002', 4, 'done', '2026-02-26 13:22:35'),
(84, 98, '2026-02-26', 2, 'H', 3, 'H2003', 8, 'done', '2026-02-26 20:05:38'),
(85, 99, '2026-02-26', 2, 'H', 4, 'H2004', 8, 'done', '2026-02-26 20:13:34'),
(86, 100, '2026-02-26', 2, 'H', 5, 'H2005', 2, 'done', '2026-02-26 21:36:10'),
(87, 101, '2026-02-26', 2, 'H', 6, 'H2006', 2, 'done', '2026-02-26 21:36:24'),
(88, 102, '2026-02-26', 2, 'H', 7, 'H2007', 2, 'done', '2026-02-26 21:36:37'),
(89, 103, '2026-02-26', 1, 'M', 3, 'M2003', 2, 'done', '2026-02-26 21:36:49'),
(90, 104, '2026-02-26', 2, 'H', 8, 'H2008', 8, 'done', '2026-02-26 21:36:59'),
(91, 105, '2026-02-26', 2, 'H', 9, 'H2009', 8, 'done', '2026-02-26 21:57:17'),
(92, 106, '2026-02-26', 2, 'H', 10, 'H2010', 2, 'done', '2026-02-26 21:57:23'),
(93, 107, '2026-02-27', 2, 'H', 1, 'H2001', 2, 'done', '2026-02-27 08:39:55'),
(94, 108, '2026-02-27', 2, 'H', 2, 'H2002', 2, 'done', '2026-02-27 08:40:23'),
(95, 109, '2026-02-27', 1, 'M', 1, 'M2001', 2, 'done', '2026-02-27 08:40:53'),
(96, 110, '2026-02-27', 1, 'M', 2, 'M2002', 7, 'waiting', '2026-02-27 08:47:27'),
(97, 111, '2026-03-01', 2, 'H', 1, 'H2001', 9, 'done', '2026-03-01 15:27:10'),
(98, 112, '2026-03-01', 2, 'H', 2, 'H2002', 2, 'done', '2026-03-01 15:42:29'),
(99, 113, '2026-03-01', 2, 'H', 3, 'H2003', 2, 'done', '2026-03-01 16:03:56'),
(100, 114, '2026-03-01', 2, 'H', 4, 'H2004', 8, 'done', '2026-03-01 23:16:09'),
(101, 115, '2026-03-01', 2, 'H', 5, 'H2005', 8, 'done', '2026-03-01 23:16:25');

-- --------------------------------------------------------

--
-- Table structure for table `queue_categories`
--

CREATE TABLE `queue_categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(80) NOT NULL,
  `prefix` varchar(3) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `queue_categories`
--

INSERT INTO `queue_categories` (`category_id`, `category_name`, `prefix`, `is_active`) VALUES
(1, 'Membership', 'M', 1),
(2, 'Hospitalization', 'H', 1);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_id` int(11) NOT NULL,
  `service_name` varchar(150) NOT NULL,
  `category_id` int(11) NOT NULL,
  `counter_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `service_name`, `category_id`, `counter_id`, `is_active`, `created_at`) VALUES
(10, 'Membership Registration', 1, 1, 1, '2026-02-03 11:41:46'),
(11, 'Membership Renewal', 1, 2, 1, '2026-02-03 11:41:46'),
(12, 'Amendment of Member Data Record', 1, 3, 1, '2026-02-03 11:41:46'),
(13, 'Admission Verification', 2, 4, 1, '2026-02-03 11:41:46'),
(14, 'Benefit Coverage Assessment', 2, 4, 1, '2026-02-03 11:41:46'),
(15, 'Hospital Billing & Claims', 2, 5, 1, '2026-02-03 11:41:46');

-- --------------------------------------------------------

--
-- Table structure for table `service_counters`
--

CREATE TABLE `service_counters` (
  `counter_id` int(11) NOT NULL,
  `counter_name` varchar(80) NOT NULL,
  `service_type` varchar(80) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_counters`
--

INSERT INTO `service_counters` (`counter_id`, `counter_name`, `service_type`, `is_active`) VALUES
(1, 'Counter 1', 'Membership', 0),
(2, 'Counter 2', 'Membership', 1),
(3, 'Counter 3', 'Membership', 0),
(4, 'Counter 4', 'Membership', 1),
(5, 'Counter 5', 'Hospitalization', 0),
(6, 'Counter 6', 'Membership', 1),
(7, 'Counter 7', 'Membership', 1),
(8, 'Counter 8', 'Hospitalization', 1),
(9, 'Counter 9', 'Hospitalization', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(190) NOT NULL,
  `mobile_number` varchar(30) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('user','staff','admin') NOT NULL DEFAULT 'user',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `email`, `mobile_number`, `password_hash`, `role`, `created_at`) VALUES
(1, 'Jay Batiola', 'Jay@gmail.com', '', '$2y$10$n1oMe25J81850Ru/uikekum8nugPSorfbHge7eLk6j/2Eg6eWVb8q', 'user', '2026-02-03 12:05:43'),
(2, 'Staff User', 'staff@office.gov', NULL, '$2y$10$DVWB8hl6JKvlS5IoXqX9Z.y/3vAkku7ZOhLeKSNBj1hYk146/eUjO', 'staff', '2026-02-03 13:20:01'),
(3, 'John Doe', 'Doe@office.gov', NULL, '$2y$10$bO7efooqHTTxhCvqpmKtB.DhMP9mg3PqwMt3gHAx0fqSalDstOtqm', 'staff', '2026-02-03 13:38:22'),
(4, 'Darel Sevilla', 'darel@gmail.com', '', '$2y$10$hMubbRtXIsPBQOlecidyHOvxAJk8zweiTkmzIclen8176vMU0Mt6W', 'user', '2026-02-03 15:03:03'),
(6, 'bill Doe', 'bill@gmail.com', '', '$2y$10$2Gj2yozE9pZVxTKXkWGG9u7JZF.ffiEJZJ.Brthh6219kbYZJz/lm', 'user', '2026-02-04 08:44:37'),
(7, 'Mae Abadingo', 'Kathy@gmail.com', '', '$2y$10$f2pibtbTEDPGT8ZdvFgscObkMo7Vu7Mu.yIQ7sQIRc.Qg4EyPZkNm', 'user', '2026-02-04 11:09:46'),
(18, 'dela cuz', 'del@gmail.com', '09904288382', '$2y$10$WQS/mBSYZ1jfXi4aRgVdVuzpNeFyjpoTe2Z134UZ0ai0bDx8xFD0y', 'user', '2026-02-18 20:13:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`),
  ADD UNIQUE KEY `uq_appointments_reference` (`reference_code`),
  ADD KEY `idx_appt_user_date` (`user_id`,`appointment_date`),
  ADD KEY `idx_appt_status_date` (`status`,`appointment_date`),
  ADD KEY `idx_appt_category_date` (`category_id`,`appointment_date`),
  ADD KEY `fk_appt_service` (`service_id`),
  ADD KEY `fk_appt_counter` (`counter_id`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `idx_actor` (`actor_user_id`),
  ADD KEY `idx_action` (`action`),
  ADD KEY `idx_queue` (`queue_id`),
  ADD KEY `idx_appt` (`appointment_id`);

--
-- Indexes for table `chatbot_events`
--
ALTER TABLE `chatbot_events`
  ADD PRIMARY KEY (`event_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_event_type` (`event_type`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `counter_services`
--
ALTER TABLE `counter_services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_counter_service` (`counter_id`,`service_name`),
  ADD KEY `idx_counter` (`counter_id`);

--
-- Indexes for table `queue`
--
ALTER TABLE `queue`
  ADD PRIMARY KEY (`queue_id`),
  ADD UNIQUE KEY `uq_queue_appointment` (`appointment_id`),
  ADD UNIQUE KEY `uq_queue_code_day` (`queue_date`,`queue_code`),
  ADD UNIQUE KEY `uq_queue_day_category_num` (`queue_date`,`category_id`,`queue_number`),
  ADD KEY `idx_queue_status` (`queue_date`,`category_id`,`status`),
  ADD KEY `idx_queue_counter` (`counter_id`,`status`),
  ADD KEY `fk_queue_category` (`category_id`);

--
-- Indexes for table `queue_categories`
--
ALTER TABLE `queue_categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `uq_category_name` (`category_name`),
  ADD UNIQUE KEY `uq_category_prefix` (`prefix`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`),
  ADD KEY `idx_services_category` (`category_id`),
  ADD KEY `idx_services_counter` (`counter_id`);

--
-- Indexes for table `service_counters`
--
ALTER TABLE `service_counters`
  ADD PRIMARY KEY (`counter_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD KEY `idx_users_mobile` (`mobile_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;

--
-- AUTO_INCREMENT for table `chatbot_events`
--
ALTER TABLE `chatbot_events`
  MODIFY `event_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=225;

--
-- AUTO_INCREMENT for table `counter_services`
--
ALTER TABLE `counter_services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `queue`
--
ALTER TABLE `queue`
  MODIFY `queue_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `queue_categories`
--
ALTER TABLE `queue_categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `service_counters`
--
ALTER TABLE `service_counters`
  MODIFY `counter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `fk_appt_category` FOREIGN KEY (`category_id`) REFERENCES `queue_categories` (`category_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_appt_counter` FOREIGN KEY (`counter_id`) REFERENCES `service_counters` (`counter_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_appt_service` FOREIGN KEY (`service_id`) REFERENCES `services` (`service_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_appt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `counter_services`
--
ALTER TABLE `counter_services`
  ADD CONSTRAINT `fk_counter_services_counter` FOREIGN KEY (`counter_id`) REFERENCES `service_counters` (`counter_id`) ON DELETE CASCADE;

--
-- Constraints for table `queue`
--
ALTER TABLE `queue`
  ADD CONSTRAINT `fk_queue_appointment` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`appointment_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_queue_category` FOREIGN KEY (`category_id`) REFERENCES `queue_categories` (`category_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_queue_counter` FOREIGN KEY (`counter_id`) REFERENCES `service_counters` (`counter_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `fk_services_category` FOREIGN KEY (`category_id`) REFERENCES `queue_categories` (`category_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_services_counter` FOREIGN KEY (`counter_id`) REFERENCES `service_counters` (`counter_id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
