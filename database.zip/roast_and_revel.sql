-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2026 at 04:40 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `roast_and_revel`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `customer_name` varchar(200) DEFAULT NULL,
  `item_name` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `total_price` decimal(10,2) NOT NULL,
  `status` enum('pending','preparing','delivering','completed','cancelled') DEFAULT 'pending',
  `order_type` enum('dine-in','takeout','delivery') DEFAULT 'dine-in',
  `notes` text DEFAULT NULL,
  `assigned_staff_id` int(11) DEFAULT NULL,
  `assigned_delivery_id` int(11) DEFAULT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `batch_id`, `user_id`, `customer_name`, `item_name`, `quantity`, `total_price`, `status`, `order_type`, `notes`, `assigned_staff_id`, `assigned_delivery_id`, `order_date`, `updated_at`) VALUES
(1, 1, 3, 'John Doe', 'Honey Lavender Latte', 2, 6.25, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 13:02:05', '2026-02-28 13:06:40'),
(2, 1, 3, 'John Doe', 'Midnight Velvet Espresso', 2, 5.50, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 13:02:06', '2026-02-28 13:06:40'),
(3, 1, 3, 'John Doe', 'Seasonal Pour Over', 1, 7.00, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 13:02:08', '2026-02-28 13:06:40'),
(4, 1, 3, 'John Doe', 'Butter Croissant', 1, 3.75, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 13:02:29', '2026-02-28 13:06:40'),
(5, 1, 3, 'John Doe', 'Cold Brew Nitro', 2, 5.75, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 13:02:31', '2026-02-28 13:06:40'),
(6, 2, 6, 'John Cus Doe', 'Honey Lavender Latte', 1, 6.25, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 13:05:13', '2026-02-28 13:06:43'),
(7, 2, 6, 'John Cus Doe', 'Seasonal Pour Over', 1, 7.00, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 13:05:14', '2026-02-28 13:06:43'),
(8, 2, 6, 'John Cus Doe', 'Cold Brew Nitro', 2, 5.75, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 13:05:16', '2026-02-28 13:06:43'),
(13, 7, 6, 'John Cus Doe', 'Midnight Velvet Espresso', 2, 5.50, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 13:28:57', '2026-02-28 14:35:02'),
(14, 7, 6, 'John Cus Doe', 'Honey Lavender Latte', 3, 6.25, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 13:28:59', '2026-02-28 14:35:02'),
(15, 7, 6, 'John Cus Doe', 'Seasonal Pour Over', 1, 7.00, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 13:29:01', '2026-02-28 14:35:02'),
(26, 3, 3, 'John Doe', 'Midnight Velvet Espresso', 1, 5.50, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:13:13', '2026-02-28 14:23:41'),
(27, 3, 3, 'John Doe', 'Cold Brew Nitro', 1, 5.75, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:13:17', '2026-02-28 14:23:41'),
(28, 3, 3, 'John Doe', 'Butter Croissant', 3, 3.75, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:13:18', '2026-02-28 14:23:41'),
(29, 3, 3, 'John Doe', 'Matcha Ceremony', 2, 6.00, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:13:19', '2026-02-28 14:23:41'),
(30, 3, 3, 'John Doe', 'Seasonal Pour Over', 3, 7.00, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:13:21', '2026-02-28 14:23:41'),
(31, 4, 3, 'John Doe', 'Honey Lavender Latte', 1, 6.25, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:19:32', '2026-02-28 14:23:43'),
(32, 4, 3, 'John Doe', 'Seasonal Pour Over', 1, 7.00, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:19:33', '2026-02-28 14:23:43'),
(33, 4, 3, 'John Doe', 'Midnight Velvet Espresso', 1, 5.50, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:19:34', '2026-02-28 14:23:43'),
(34, 4, 3, 'John Doe', 'Matcha Ceremony', 1, 6.00, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:19:35', '2026-02-28 14:23:43'),
(39, 5, 3, 'John Doe', 'Honey Lavender Latte', 2, 6.25, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:25:06', '2026-02-28 14:26:28'),
(40, 5, 3, 'John Doe', 'Seasonal Pour Over', 2, 7.00, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:25:07', '2026-02-28 14:26:28'),
(41, 5, 3, 'John Doe', 'Midnight Velvet Espresso', 1, 5.50, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:25:09', '2026-02-28 14:26:28'),
(42, 5, 3, 'John Doe', 'Cold Brew Nitro', 3, 5.75, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:25:10', '2026-02-28 14:26:28'),
(43, 6, 3, 'John Doe', 'Midnight Velvet Espresso', 1, 5.50, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:29:19', '2026-02-28 14:30:48'),
(44, 6, 3, 'John Doe', 'Ice Coffee', 4, 10.00, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 14:29:21', '2026-02-28 14:30:48'),
(49, 8, 6, 'John Cus', 'Midnight Velvet Espresso', 1, 5.50, 'completed', 'dine-in', NULL, 4, 5, '2026-02-28 15:37:18', '2026-02-28 16:19:54'),
(50, 8, 6, 'John Cus', 'Cold Brew Nitro', 2, 5.75, 'completed', 'dine-in', NULL, 4, 5, '2026-02-28 15:37:19', '2026-02-28 16:19:54'),
(51, 8, 6, 'John Cus', 'Ice Coffee', 2, 10.00, 'completed', 'dine-in', NULL, 4, 5, '2026-02-28 15:37:21', '2026-02-28 16:19:54'),
(52, 8, 6, 'John Cus', 'Butter Croissant', 1, 3.75, 'completed', 'dine-in', NULL, 4, 5, '2026-02-28 15:37:22', '2026-02-28 16:19:54'),
(53, 8, 6, 'John Cus', 'Matcha Ceremony', 2, 6.00, 'completed', 'dine-in', NULL, 4, 5, '2026-02-28 15:37:22', '2026-02-28 16:19:54'),
(54, 9, 6, 'John Cus Doe', 'Honey Lavender Latte', 1, 6.25, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 16:01:41', '2026-02-28 16:19:55'),
(55, 9, 6, 'John Cus Doe', 'Seasonal Pour Over', 1, 7.00, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 16:01:42', '2026-02-28 16:19:55'),
(56, 9, 6, 'John Cus Doe', 'Matcha Ceremony', 1, 6.00, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 16:01:42', '2026-02-28 16:19:55'),
(57, 9, 6, 'John Cus Doe', 'Midnight Velvet Espresso', 1, 5.50, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 16:01:43', '2026-02-28 16:19:55'),
(58, 10, 6, 'John Cus Doe', 'Midnight Velvet Espresso', 1, 5.50, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 16:10:49', '2026-02-28 16:19:56'),
(59, 10, 6, 'John Cus Doe', 'Honey Lavender Latte', 2, 6.25, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 16:10:51', '2026-02-28 16:19:56'),
(60, 10, 6, 'John Cus Doe', 'Seasonal Pour Over', 1, 7.00, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 16:10:51', '2026-02-28 16:19:56'),
(61, 10, 6, 'John Cus Doe', 'Matcha Ceremony', 1, 6.00, 'completed', 'delivery', NULL, 4, 5, '2026-02-28 16:10:52', '2026-02-28 16:19:56'),
(62, 11, 3, 'John Doe', 'Midnight Velvet Espresso', 1, 5.50, 'completed', 'delivery', NULL, 4, 5, '2026-03-01 00:10:52', '2026-03-01 00:21:57'),
(63, 11, 3, 'John Doe', 'Honey Lavender Latte', 1, 6.25, 'completed', 'delivery', NULL, 4, 5, '2026-03-01 00:10:53', '2026-03-01 00:21:57'),
(64, 11, 3, 'John Doe', 'Seasonal Pour Over', 1, 7.00, 'completed', 'delivery', NULL, 4, 5, '2026-03-01 00:10:54', '2026-03-01 00:21:57'),
(81, 12, 3, 'John Doe', 'Seasonal Pour Over', 2, 7.00, 'pending', 'delivery', NULL, NULL, NULL, '2026-03-02 03:09:53', '2026-03-02 03:10:24'),
(82, 12, 3, 'John Doe', 'Butter Croissant', 3, 3.75, 'pending', 'delivery', NULL, NULL, NULL, '2026-03-02 03:09:57', '2026-03-02 03:10:24'),
(83, 12, 3, 'John Doe', 'Ice Coffee', 2, 10.00, 'pending', 'delivery', NULL, NULL, NULL, '2026-03-02 03:10:01', '2026-03-02 03:10:24'),
(84, 13, 3, 'John Doe', 'Honey Lavender Latte', 2, 6.25, 'pending', 'delivery', NULL, NULL, NULL, '2026-03-02 03:10:41', '2026-03-02 03:11:01'),
(85, 13, 3, 'John Doe', 'Seasonal Pour Over', 1, 7.00, 'pending', 'delivery', NULL, NULL, NULL, '2026-03-02 03:10:45', '2026-03-02 03:11:01'),
(86, 13, 3, 'John Doe', 'Midnight Velvet Espresso', 1, 5.50, 'pending', 'delivery', NULL, NULL, NULL, '2026-03-02 03:10:47', '2026-03-02 03:11:01'),
(87, 13, 3, 'John Doe', 'Butter Croissant', 3, 3.75, 'pending', 'delivery', NULL, NULL, NULL, '2026-03-02 03:10:51', '2026-03-02 03:11:01'),
(88, NULL, 3, 'John', 'Honey Lavender Latte', 2, 6.25, 'pending', 'dine-in', NULL, NULL, NULL, '2026-03-02 03:27:33', '2026-03-02 03:27:33'),
(89, 14, 2, 'John A Doe', 'Matcha Ceremony', 3, 6.00, 'completed', 'delivery', NULL, 4, 5, '2026-03-06 08:08:19', '2026-03-06 08:11:34');

-- --------------------------------------------------------

--
-- Table structure for table `order_batches`
--

CREATE TABLE `order_batches` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `customer_name` varchar(200) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(100) DEFAULT '',
  `notes` text DEFAULT NULL,
  `order_type` enum('dine-in','takeout','delivery') DEFAULT 'delivery',
  `batch_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','preparing','delivering','completed','cancelled') DEFAULT 'pending',
  `assigned_staff_id` int(11) DEFAULT NULL,
  `assigned_delivery_id` int(11) DEFAULT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_batches`
--

INSERT INTO `order_batches` (`id`, `user_id`, `customer_name`, `phone`, `address`, `city`, `notes`, `order_type`, `batch_total`, `status`, `assigned_staff_id`, `assigned_delivery_id`, `order_date`, `updated_at`) VALUES
(1, 3, 'John Doe', '09657392031', 'Magcagong', 'Maragusan', 'tapad sa Day care center', 'delivery', 45.75, 'completed', 4, 5, '2026-02-28 13:03:47', '2026-02-28 13:06:40'),
(2, 6, 'John Cus Doe', '09758232421', 'Magcagong', 'Maragusan', 'tapad sa Day care', 'delivery', 24.75, 'completed', 4, 5, '2026-02-28 13:05:56', '2026-02-28 13:06:43'),
(3, 3, 'John Doe', '09752611718', 'Magcagong', 'Maragusan', 'Tapad sa DayCare', 'delivery', 55.50, 'completed', 4, 5, '2026-02-28 14:19:09', '2026-02-28 14:23:41'),
(4, 3, 'John Doe', '09752611718', 'Magcagong', 'Maragusan', 'Tapad sa DayCare', 'delivery', 24.75, 'completed', 4, 5, '2026-02-28 14:19:45', '2026-02-28 14:23:43'),
(5, 3, 'John Doe', '09752611718', 'Magcagong', 'Maragusan', '', 'delivery', 49.25, 'completed', 4, 5, '2026-02-28 14:25:32', '2026-02-28 14:26:28'),
(6, 3, 'John Doe', '09752611718', 'P3 tambuang', 'Bislig City', '', 'delivery', 45.50, 'completed', 4, 5, '2026-02-28 14:29:43', '2026-02-28 14:30:48'),
(7, 6, 'John Cus Doe', '09752611718', 'Magcagong', 'Maragusan', 'Extra carefull', 'delivery', 36.75, 'completed', 4, 5, '2026-02-28 14:34:07', '2026-02-28 14:35:02'),
(8, 6, 'John Cus Doe', '09752611718', 'Magcagong', 'Maragusan', '', 'delivery', 52.75, 'completed', 4, 5, '2026-02-28 16:00:41', '2026-02-28 16:19:54'),
(9, 6, 'John Cus Doe', '09752611718', 'Magcagong', 'Maragusan', '', 'delivery', 24.75, 'completed', 4, 5, '2026-02-28 16:07:55', '2026-02-28 16:19:55'),
(10, 6, 'John Cus Doe', '09752611718', 'Magcagong', 'Maragusan', '', 'delivery', 31.00, 'completed', 4, 5, '2026-02-28 16:11:56', '2026-02-28 16:19:56'),
(11, 3, 'John Doe', '09778832381', 'Magcagong', 'Maragusan', '', 'delivery', 18.75, 'completed', 4, 5, '2026-03-01 00:21:06', '2026-03-01 00:21:57'),
(12, 3, 'John Doe', '09778832381', 'Magcagong', 'Maragusan', '', 'delivery', 45.25, 'pending', NULL, NULL, '2026-03-02 03:10:24', '2026-03-02 03:10:24'),
(13, 3, 'John Doe', '09778832381', 'Magcagong', 'Maragusan', '', 'delivery', 36.25, 'pending', NULL, NULL, '2026-03-02 03:11:01', '2026-03-02 03:11:01'),
(14, 2, 'John A Doe', '09752611718', 'Magcagong', 'Maragusan', 'tapad the day care', 'delivery', 18.00, 'completed', 4, 5, '2026-03-06 08:08:41', '2026-03-06 08:11:34');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `category` enum('Coffee','Tea','Pastry','Merchandise','Cold Drinks') NOT NULL DEFAULT 'Coffee',
  `is_available` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `category`, `is_available`, `created_at`) VALUES
(1, 'Midnight Velvet Espresso', 'Our darkest roast with notes of smoked chocolate and black cherry.', 5.50, 'Coffee', 1, '2026-02-28 12:58:17'),
(2, 'Honey Lavender Latte', 'Locally sourced wildflower honey infused with dried lavender.', 6.25, 'Coffee', 1, '2026-02-28 12:58:17'),
(3, 'Seasonal Pour Over', 'Single-origin beans brewed to order. Ask your barista for today\'s origin.', 7.00, 'Coffee', 1, '2026-02-28 12:58:17'),
(4, 'Cold Brew Nitro', 'Steeped for 18 hours and served on tap for a creamy finish.', 5.75, 'Cold Drinks', 1, '2026-02-28 12:58:17'),
(5, 'Matcha Ceremony', 'Ceremonial grade matcha with oat milk and a hint of vanilla.', 6.00, 'Tea', 1, '2026-02-28 12:58:17'),
(6, 'Butter Croissant', 'Flaky, golden, and buttery — baked fresh every morning.', 3.75, 'Pastry', 1, '2026-02-28 12:58:17'),
(7, 'Ice Coffee', 'Most iced coffee is made using hot water to extract flavor quickly (e.g., drip, French press, or pour-over), then chilled with ice. Some cafes use a \"flash-chilled\" method, where concentrated hot coffee is poured over ice to rapidly cool it.', 10.00, 'Cold Drinks', 1, '2026-02-28 14:29:03');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff','delivery','user') NOT NULL DEFAULT 'user',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `phone` varchar(30) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `role`, `is_active`, `created_at`, `phone`) VALUES
(2, 'John A', 'Doe', 'admin@roast.ph', '$2y$12$4T0W0VsAI4y9o/8U.naIkeop.itzt.CuD9E9sBr6VlVOsnAVuXvLC', 'admin', 1, '2026-02-28 12:59:18', '09752611718'),
(3, 'John', 'Doe', 'john@gmail.com', '$2y$12$lhX49MKuiPbw3DmPrU8FLeNIPVwh2FCsNh1HSfEx4hSF/kpmdv/O.', 'user', 1, '2026-02-28 12:59:44', '09778832381'),
(4, 'John S', 'Doe', 'john@coffee.ph', '$2y$12$K6Nr5enPvExc3aDf9kzUtu.wIFsLnqNKtxFMZtsGaLyXlSCaZ3uBK', 'staff', 1, '2026-02-28 13:00:00', ''),
(5, 'John D', 'Doe', 'john@delivery.ph', '$2y$12$/cxYw89Cbkt60bLZbGVGLOWC.ZRMhnwO.5e1gvUBIS.mtbr4kTk8q', 'delivery', 1, '2026-02-28 13:00:41', ''),
(6, 'John Cus', 'Doe', 'cus@gmail.com', '$2y$12$1jtrwx6Ku7I.8ETv5ta63.JE7aOAJKpQB7LUpazLZcB6BvsoAg156', 'user', 1, '2026-02-28 13:04:58', '09752611718');

-- --------------------------------------------------------

--
-- Table structure for table `user_addresses`
--

CREATE TABLE `user_addresses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `label` varchar(80) NOT NULL DEFAULT 'Home',
  `address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL DEFAULT '',
  `phone` varchar(30) NOT NULL DEFAULT '',
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_addresses`
--

INSERT INTO `user_addresses` (`id`, `user_id`, `label`, `address`, `city`, `phone`, `is_default`, `created_at`) VALUES
(1, 6, 'P-kape 2', 'Magcagong', 'Maragusan', '', 1, '2026-02-28 16:00:24'),
(2, 3, 'P-labana 1', 'Magcagong', 'Maragusan', '', 1, '2026-03-01 00:20:05'),
(3, 2, 'Home', 'Magcagong', 'Maragusan', '', 1, '2026-03-06 08:08:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `batch_id` (`batch_id`);

--
-- Indexes for table `order_batches`
--
ALTER TABLE `order_batches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_addresses`
--
ALTER TABLE `user_addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `order_batches`
--
ALTER TABLE `order_batches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_addresses`
--
ALTER TABLE `user_addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `order_batches` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `order_batches`
--
ALTER TABLE `order_batches`
  ADD CONSTRAINT `order_batches_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `user_addresses`
--
ALTER TABLE `user_addresses`
  ADD CONSTRAINT `user_addresses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
