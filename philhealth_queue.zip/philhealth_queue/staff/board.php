<?php
// staff/board.php

session_name('staff_session');
session_start();

require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../config/helpers.php";

date_default_timezone_set('Asia/Manila');
$today = date('Y-m-d');

const PRIORITY_COUNTER = 2;
const MEMBERSHIP_CAT_ID = 1;
const HOSP_CAT_ID = 2;
const MEMBERSHIP_COUNTERS = [4, 6, 7];
const HOSP_COUNTERS = [8, 9];
const PRIORITY_STATUSES_SQL = "'Senior Citizen','PWD','Pregnant'";

function fetch_one(mysqli $conn, string $sql, string $types, array $params): ?array
{
  $stmt = $conn->prepare($sql);
  if (!$stmt) return null;

  if ($types !== '') $stmt->bind_param($types, ...$params);

  $stmt->execute();
  $row = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  return $row ?: null;
}

function fetch_all(mysqli $conn, string $sql, string $types, array $params): array
{
  $stmt = $conn->prepare($sql);
  if (!$stmt) return [];

  if ($types !== '') $stmt->bind_param($types, ...$params);

  $stmt->execute();
  $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
  $stmt->close();

  return $rows ?: [];
}

function serving_list_by_counters(mysqli $conn, string $date, array $counters, ?int $category_id = null, bool $priorityOnly = false): array
{
  if (!$counters) return [];

  $placeholders = implode(',', array_fill(0, count($counters), '?'));
  $types = "s" . str_repeat("i", count($counters));
  $params = array_merge([$date], array_map('intval', $counters));

  $catSql = "";
  if ($category_id !== null) {
    $catSql = " AND q.category_id = ? ";
    $types .= "i";
    $params[] = $category_id;
  }

  $priorityWhere = "";
  if ($priorityOnly) {
    $priorityWhere = " AND a.client_status IN (" . PRIORITY_STATUSES_SQL . ") ";
  }

  $sql = "
    SELECT
      q.queue_code,
      q.counter_id,
      COALESCE(s.service_name, '—') AS service_name
    FROM queue q
    LEFT JOIN appointments a ON a.appointment_id = q.appointment_id
    LEFT JOIN services s     ON s.service_id     = a.service_id
    WHERE q.queue_date = ?
      AND q.status = 'serving'
      AND q.counter_id IN ($placeholders)
      $catSql
      $priorityWhere
    ORDER BY q.counter_id ASC, q.created_at ASC
  ";

  return fetch_all($conn, $sql, $types, $params);
}

function next_waiting_overall(mysqli $conn, string $date, ?int $category_id = null, ?array $counters = null, bool $priorityOnly = false): ?array
{
  $types = "s";
  $params = [$date];

  $where = "WHERE q.queue_date = ? AND q.status = 'waiting'";

  if ($category_id !== null) {
    $where .= " AND q.category_id = ?";
    $types .= "i";
    $params[] = $category_id;
  }

  if ($counters && count($counters) > 0) {
    $placeholders = implode(',', array_fill(0, count($counters), '?'));
    $where .= " AND q.counter_id IN ($placeholders)";
    $types .= str_repeat("i", count($counters));
    foreach ($counters as $cid) $params[] = (int)$cid;
  }

  if ($priorityOnly) {
    $where .= " AND a.client_status IN (" . PRIORITY_STATUSES_SQL . ")";
  }

  $sql = "
    SELECT
      q.queue_code,
      q.counter_id,
      COALESCE(s.service_name, '—') AS service_name
    FROM queue q
    LEFT JOIN appointments a ON a.appointment_id = q.appointment_id
    LEFT JOIN services s     ON s.service_id     = a.service_id
    $where
    ORDER BY q.created_at ASC
    LIMIT 1
  ";

  return fetch_one($conn, $sql, $types, $params);
}

function payload(mysqli $conn, string $today): array
{
  $m_serving_list = serving_list_by_counters($conn, $today, MEMBERSHIP_COUNTERS, MEMBERSHIP_CAT_ID, false);
  $m_serving_main = $m_serving_list ? $m_serving_list[0] : null;
  $m_next = next_waiting_overall($conn, $today, MEMBERSHIP_CAT_ID, MEMBERSHIP_COUNTERS, false);

  $h_serving_list = serving_list_by_counters($conn, $today, HOSP_COUNTERS, HOSP_CAT_ID, false);
  $h_serving_main = $h_serving_list ? $h_serving_list[0] : null;
  $h_next = next_waiting_overall($conn, $today, HOSP_CAT_ID, HOSP_COUNTERS, false);

  $p_serving_list = serving_list_by_counters($conn, $today, [PRIORITY_COUNTER], null, true);
  $p_serving_main = $p_serving_list ? $p_serving_list[0] : null;
  $p_next = next_waiting_overall($conn, $today, null, [PRIORITY_COUNTER], true);

  return [
    'server_time' => date('Y-m-d H:i:s'),
    'today_label' => date('l, M d, Y'),
    'clock' => date('h:i:s A'),
    'membership' => [
      'serving_main' => $m_serving_main,
      'serving_list' => $m_serving_list,
      'next' => $m_next,
    ],
    'hospitalization' => [
      'serving_main' => $h_serving_main,
      'serving_list' => $h_serving_list,
      'next' => $h_next,
    ],
    'priority' => [
      'serving_main' => $p_serving_main,
      'serving_list' => $p_serving_list,
      'next' => $p_next,
    ],
  ];
}

if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(payload($conn, $today), JSON_UNESCAPED_UNICODE);
  exit();
}

$init = payload($conn, $today);

function code_or_dash(?array $row): string { return ($row && !empty($row['queue_code'])) ? (string)$row['queue_code'] : '—'; }
function counter_or_dash(?array $row): string { return ($row && !empty($row['counter_id'])) ? "Counter " . (int)$row['counter_id'] : '—'; }
function service_or_dash(?array $row): string { return ($row && !empty($row['service_name'])) ? (string)$row['service_name'] : '—'; }

/**
 * Compact table like screenshot: Queue | Counter - X | SERVICE
 */
function render_serving_table(array $rows): string
{
  if (empty($rows)) return '<div class="text-sm text-slate-500">—</div>';

  $html = '<div class="overflow-x-auto">';
  $html .= '<table class="w-full border border-slate-300 bg-white/70 table-compact">';
  $html .= '<tbody>';

  foreach ($rows as $r) {
    $code = e($r['queue_code'] ?? '—');
    $counter = 'Counter - ' . (int)($r['counter_id'] ?? 0);
    $svc = e($r['service_name'] ?? '—');

    $html .= '<tr class="border-b border-slate-300 last:border-b-0">';
    $html .= '<td class="border-r border-slate-300 px-4 py-2 text-base font-extrabold text-slate-900">' . $code . '</td>';
    $html .= '<td class="border-r border-slate-300 px-4 py-2 text-sm font-semibold text-slate-900">' . e($counter) . '</td>';
    $html .= '<td class="px-4 py-2 text-sm font-extrabold text-slate-900 uppercase tracking-wide">' . $svc . '</td>';
    $html .= '</tr>';
  }

  $html .= '</tbody></table></div>';
  return $html;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1.0,viewport-fit=cover" />
  <title>PhilHealth Queue Board</title>
  <script src="https://cdn.tailwindcss.com"></script>

  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            brand: {
              50: "#F7F2D1",
              100: "#D9FF8C",
              200: "#B6F45A",
              300: "#97EB2F",
              400: "#79E114",
              500: "#5FD000",
              700: "#1F723B",
              gold: "#E4B519",
              gold2: "#D29910"
            }
          }
        }
      }
    }
  </script>

  <style>
    :root { --card: rgba(255,255,255,.78); --bdr: rgba(255,255,255,.55); }

    .lime-bg { background: linear-gradient(180deg,#D9FF8C 0%,#B6F45A 35%,#97EB2F 65%,#5FD000 100%); }

    .grid-overlay{
      background-image:
        linear-gradient(to right, rgba(255,255,255,0.18) 1px, transparent 1px),
        linear-gradient(to bottom, rgba(255,255,255,0.18) 1px, transparent 1px);
      background-size: 56px 56px;
      mask-image: radial-gradient(70% 60% at 50% 20%, black 40%, transparent 80%);
      opacity: 0.25;
    }

    .tile{ background: var(--card); border: 1px solid var(--bdr); backdrop-filter: blur(18px); box-shadow: 0 12px 50px rgba(10,50,10,.18); }
    .soft{ background: rgba(255,255,255,.70); border: 1px solid rgba(255,255,255,.55); }

    .ticker{ position: relative; overflow: hidden; border: 1px solid rgba(255,255,255,.55); background: rgba(255,255,255,.55); backdrop-filter: blur(14px); }
    .ticker-track{ display: inline-flex; gap: 2.5rem; white-space: nowrap; will-change: transform; animation: scroll 20s linear infinite; padding: .45rem 0; }
    @keyframes scroll { from { transform: translateX(0); } to { transform: translateX(-50%); } }

    .flash{ animation: flash 900ms ease-out 1; }
    @keyframes flash{
      0%{ transform: scale(1); box-shadow: 0 0 0 rgba(0,0,0,0); }
      20%{ transform: scale(1.02); box-shadow: 0 12px 40px rgba(20,80,20,.22); }
      100%{ transform: scale(1); box-shadow: 0 0 0 rgba(0,0,0,0); }
    }

    /* Floating controls */
    .fs{ position: fixed; right: 16px; bottom: 16px; z-index: 50; display:flex; flex-direction:column; gap:.5rem; }

    /* Smaller queue numbers for better fit */
    .qcode-serving{ font-size: clamp(1.8rem, 3.3vw, 3.2rem); line-height: 1.03; }
    .qcode-next{ font-size: clamp(1.35rem, 2.7vw, 2.55rem); line-height: 1.08; }

    /* Reduce card height so tables fit */
    .card-compact{ min-height: 140px; }
    @media (min-width: 640px){ .card-compact{ min-height: 165px; } }

    /* Compact table padding */
    .table-compact td{ padding: .55rem .85rem; }

    @media (prefers-reduced-motion: reduce){
      .ticker-track{ animation: none; }
      .flash{ animation: none; }
    }
  </style>
</head>

<body class="min-h-dvh text-slate-900 overflow-x-hidden">
  <div class="fixed inset-0 -z-10 lime-bg"></div>
  <div class="fixed inset-0 -z-10 grid-overlay pointer-events-none"></div>

  <div class="mx-auto w-full max-w-[1700px] px-3 sm:px-5 lg:px-7 py-4 sm:py-5 space-y-3 sm:space-y-4">

    <!-- Header -->
    <header class="tile rounded-3xl px-4 sm:px-5 py-3 sm:py-4 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
      <div class="flex items-center gap-3 min-w-0">
        <img src="../logo/philhealth_Logo.png" alt="PhilHealth Logo"
          class="h-10 w-10 sm:h-12 sm:w-12 object-contain rounded-2xl bg-white/70 border border-white/60 p-1" />
        <div class="min-w-0">
          <div class="text-base sm:text-lg lg:text-xl font-extrabold tracking-tight truncate">PhilHealth Queue Board</div>
          <div class="text-xs sm:text-sm text-slate-700/80">Please prepare MDR and valid ID</div>
        </div>
      </div>

      <div class="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4 lg:justify-end">
        <div class="text-left sm:text-right">
          <div id="clock" class="text-xl sm:text-2xl font-black tracking-tight"><?php echo e($init['clock']); ?></div>
          <div id="todayLbl" class="text-xs sm:text-sm text-slate-700/80"><?php echo e($init['today_label']); ?></div>
        </div>

        <a href="serve.php" class="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl
                  bg-brand-700 text-white font-extrabold shadow-lg hover:opacity-95 active:scale-[0.99] transition
                  w-full sm:w-auto text-sm">
          Go to Staff Serve Panel →
        </a>
      </div>
    </header>

    <!-- Ticker -->
    <div class="ticker rounded-2xl px-4 sm:px-5">
      <div class="ticker-track" aria-hidden="true">
        <div class="font-extrabold text-slate-800">NOTICE:</div>
        <div class="font-semibold text-slate-700">Priority clients (Senior Citizen / PWD / Pregnant) proceed to Counter 2 (Ground Floor).</div>
        <div class="font-semibold text-slate-700">Please maintain order and wait for your queue to be called.</div>

        <div class="font-extrabold text-slate-800">NOTICE:</div>
        <div class="font-semibold text-slate-700">Priority clients (Senior Citizen / PWD / Pregnant) proceed to Counter 2 (Ground Floor).</div>
        <div class="font-semibold text-slate-700">Please maintain order and wait for your queue to be called.</div>
      </div>
    </div>

    <!-- MAIN: 3 inline, PRIORITY IN CENTER (more compact) -->
    <main class="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4 lg:gap-4">

      <!-- Membership (LEFT) -->
      <section class="tile rounded-3xl p-4 sm:p-5 lg:order-1">
        <div class="flex items-center justify-between gap-3">
          <div class="text-base sm:text-lg font-extrabold">Membership <span class="text-slate-500">(M)</span></div>
          <span class="px-3 py-1 rounded-full bg-brand-700 text-white text-xs font-extrabold">LIVE</span>
        </div>

        <div class="mt-3 sm:mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <div class="soft rounded-2xl p-4 flex flex-col card-compact">
            <div class="text-[11px] font-extrabold text-slate-500 uppercase">Now Serving</div>
            <div id="M_serving" class="mt-3 text-center font-black text-brand-700 qcode-serving break-words">
              <?php echo e(code_or_dash($init['membership']['serving_main'])); ?>
            </div>
            <div id="M_serving_counter" class="mt-2 text-center text-sm font-extrabold text-slate-800">
              <?php echo e($init['membership']['serving_main'] ? counter_or_dash($init['membership']['serving_main']) : '—'); ?>
            </div>
            <div id="M_serving_service" class="mt-auto pt-2 text-center text-[11px] font-bold text-slate-600">
              <?php echo e($init['membership']['serving_main'] ? service_or_dash($init['membership']['serving_main']) : 'No serving queue'); ?>
            </div>
          </div>

          <div class="soft rounded-2xl p-4 flex flex-col card-compact">
            <div class="text-[11px] font-extrabold text-slate-500 uppercase">Next in Line</div>
            <div id="M_next" class="mt-3 text-center font-black text-slate-900 qcode-next break-words">
              <?php echo e(code_or_dash($init['membership']['next'])); ?>
            </div>
            <div id="M_next_counter" class="mt-2 text-center text-sm font-extrabold text-slate-800">
              <?php echo e($init['membership']['next'] ? counter_or_dash($init['membership']['next']) : '—'); ?>
            </div>
            <div id="M_next_service" class="mt-auto pt-2 text-center text-[11px] font-bold text-slate-600">
              <?php echo e($init['membership']['next'] ? service_or_dash($init['membership']['next']) : 'No waiting queue'); ?>
            </div>
          </div>
        </div>

        <div class="mt-3 soft rounded-2xl p-4">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Now Serving by Counter</div>
          <div id="M_table" class="mt-2 max-h-[260px] sm:max-h-[300px] overflow-auto">
            <?php echo render_serving_table($init['membership']['serving_list'] ?? []); ?>
          </div>
        </div>
      </section>

      <!-- Priority (CENTER) -->
      <section class="tile rounded-3xl p-4 sm:p-5 text-center lg:order-2">
        <div class="flex items-center justify-between gap-3">
          <div class="text-base sm:text-lg font-extrabold">
            Priority <span class="text-slate-500">(Counter 2)</span>
          </div>
          <span class="px-3 py-1 rounded-full bg-red-600 text-white text-xs font-extrabold animate-pulse">LIVE</span>
        </div>

        <div class="mt-3 flex flex-col items-center justify-center">
          <div class="soft w-full rounded-2xl py-4 sm:py-5 px-4 sm:px-5 text-center">
            <div class="text-sm sm:text-base font-black tracking-wide text-slate-800">PRIORITY CLIENTS</div>
            <div class="mt-2 font-black leading-tight text-brand-700" style="font-size: clamp(0.9rem, 2.1vw, 2.1rem);">
              PROCEED TO GROUND FLOOR
            </div>
            <div class="text-[11px] sm:text-xs mt-2 font-semibold text-slate-700/80">
              Counter 2 Assistance Area
            </div>
          </div>
        </div>

        <div class="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <div class="soft rounded-2xl p-4 flex flex-col card-compact">
            <div class="text-[11px] font-extrabold text-slate-500 uppercase">Now Serving</div>
            <div id="P_serving" class="mt-3 text-center font-black text-brand-700 qcode-serving break-words">
              <?php echo e(code_or_dash($init['priority']['serving_main'])); ?>
            </div>
            <div id="P_serving_counter" class="mt-2 text-center text-sm font-extrabold text-slate-800">
              <?php echo e($init['priority']['serving_main'] ? 'Counter 2' : '—'); ?>
            </div>
            <div id="P_serving_service" class="mt-auto pt-2 text-center text-[11px] font-bold text-slate-600">
              <?php echo e($init['priority']['serving_main'] ? service_or_dash($init['priority']['serving_main']) : 'No serving queue'); ?>
            </div>
          </div>

          <div class="soft rounded-2xl p-4 flex flex-col card-compact">
            <div class="text-[11px] font-extrabold text-slate-500 uppercase">Next in Line</div>
            <div id="P_next" class="mt-3 text-center font-black text-slate-900 qcode-next break-words">
              <?php echo e(code_or_dash($init['priority']['next'])); ?>
            </div>
            <div id="P_next_counter" class="mt-2 text-center text-sm font-extrabold text-slate-800">
              <?php echo e($init['priority']['next'] ? 'Counter 2' : '—'); ?>
            </div>
            <div id="P_next_service" class="mt-auto pt-2 text-center text-[11px] font-bold text-slate-600">
              <?php echo e($init['priority']['next'] ? service_or_dash($init['priority']['next']) : 'No waiting queue'); ?>
            </div>
          </div>
        </div>
      </section>

      <!-- Hospitalization (RIGHT) -->
      <section class="tile rounded-3xl p-4 sm:p-5 lg:order-3">
        <div class="flex items-center justify-between gap-3">
          <div class="text-base sm:text-lg font-extrabold">Hospitalization <span class="text-slate-500">(H)</span></div>
          <span class="px-3 py-1 rounded-full bg-brand-700 text-white text-xs font-extrabold">LIVE</span>
        </div>

        <div class="mt-3 sm:mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
          <div class="soft rounded-2xl p-4 flex flex-col card-compact">
            <div class="text-[11px] font-extrabold text-slate-500 uppercase">Now Serving</div>
            <div id="H_serving" class="mt-3 text-center font-black text-brand-700 qcode-serving break-words">
              <?php echo e(code_or_dash($init['hospitalization']['serving_main'])); ?>
            </div>
            <div id="H_serving_counter" class="mt-2 text-center text-sm font-extrabold text-slate-800">
              <?php echo e($init['hospitalization']['serving_main'] ? counter_or_dash($init['hospitalization']['serving_main']) : '—'); ?>
            </div>
            <div id="H_serving_service" class="mt-auto pt-2 text-center text-[11px] font-bold text-slate-600">
              <?php echo e($init['hospitalization']['serving_main'] ? service_or_dash($init['hospitalization']['serving_main']) : 'No serving queue'); ?>
            </div>
          </div>

          <div class="soft rounded-2xl p-4 flex flex-col card-compact">
            <div class="text-[11px] font-extrabold text-slate-500 uppercase">Next in Line</div>
            <div id="H_next" class="mt-3 text-center font-black text-slate-900 qcode-next break-words">
              <?php echo e(code_or_dash($init['hospitalization']['next'])); ?>
            </div>
            <div id="H_next_counter" class="mt-2 text-center text-sm font-extrabold text-slate-800">
              <?php echo e($init['hospitalization']['next'] ? counter_or_dash($init['hospitalization']['next']) : '—'); ?>
            </div>
            <div id="H_next_service" class="mt-auto pt-2 text-center text-[11px] font-bold text-slate-600">
              <?php echo e($init['hospitalization']['next'] ? service_or_dash($init['hospitalization']['next']) : 'No waiting queue'); ?>
            </div>
          </div>
        </div>

        <div class="mt-3 soft rounded-2xl p-4">
          <div class="text-[11px] font-extrabold text-slate-500 uppercase">Now Serving by Counter</div>
          <div id="H_table" class="mt-2 max-h-[260px] sm:max-h-[300px] overflow-auto">
            <?php echo render_serving_table($init['hospitalization']['serving_list'] ?? []); ?>
          </div>
        </div>
      </section>

    </main>
  </div>

  <!-- Controls -->
  <div class="fs">
    <button id="fsBtn"
      class="rounded-xl bg-white/80 border border-white/60 px-4 py-2 text-sm font-extrabold text-slate-800 hover:bg-white transition shadow-lg">
      Enter Fullscreen
    </button>
    <button id="soundBtn"
      class="rounded-xl bg-brand-700 px-4 py-2 text-sm font-extrabold text-white hover:opacity-95 transition shadow-lg">
      Enable Voice
    </button>
  </div>

  <script>
    function tickClock() {
      const now = new Date();
      const hh = String(((now.getHours() + 11) % 12) + 1).padStart(2, '0');
      const mm = String(now.getMinutes()).padStart(2, '0');
      const ss = String(now.getSeconds()).padStart(2, '0');
      const ampm = now.getHours() >= 12 ? 'PM' : 'AM';
      const el = document.getElementById('clock');
      if (el) el.textContent = `${hh}:${mm}:${ss} ${ampm}`;
    }
    setInterval(tickClock, 1000);
    tickClock();

    document.getElementById('fsBtn').addEventListener('click', async () => {
      try {
        if (!document.fullscreenElement) {
          await document.documentElement.requestFullscreen();
          document.getElementById('fsBtn').textContent = 'Exit Fullscreen';
        } else {
          await document.exitFullscreen();
          document.getElementById('fsBtn').textContent = 'Enter Fullscreen';
        }
      } catch (e) {}
    });

    let voiceEnabled = false;
    document.getElementById('soundBtn').addEventListener('click', () => {
      voiceEnabled = true;
      const btn = document.getElementById('soundBtn');
      btn.textContent = 'Voice Enabled';
      btn.disabled = true;
      try {
        const u = new SpeechSynthesisUtterance('Voice enabled.');
        u.rate = 1;
        speechSynthesis.speak(u);
      } catch (e) {}
    });

    function speak(text) {
      if (!voiceEnabled) return;
      try {
        speechSynthesis.cancel();
        const u = new SpeechSynthesisUtterance(text);
        u.rate = 1;
        speechSynthesis.speak(u);
      } catch (e) {}
    }

    function flash(elId) {
      const el = document.getElementById(elId);
      if (!el) return;
      el.classList.remove('flash');
      void el.offsetWidth;
      el.classList.add('flash');
    }

    const last = { M: null, H: null, P: null };

    function setText(id, v) {
      const el = document.getElementById(id);
      if (!el) return;
      el.textContent = v;
    }

    function esc(s) {
      return String(s ?? '').replace(/[&<>"']/g, c => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
      }[c]));
    }

    function renderServingTable(targetId, list) {
      const el = document.getElementById(targetId);
      if (!el) return;

      if (!list || !list.length) {
        el.innerHTML = '<div class="text-sm text-slate-500">—</div>';
        return;
      }

      const rowsHtml = list.map(r => {
        const code = esc(r.queue_code || '—');
        const c = Number(r.counter_id || 0);
        const svc = esc(r.service_name || '—');

        return `
          <tr class="border-b border-slate-300 last:border-b-0">
            <td class="border-r border-slate-300 px-4 py-2 text-base font-extrabold text-slate-900">${code}</td>
            <td class="border-r border-slate-300 px-4 py-2 text-sm font-semibold text-slate-900">Counter - ${c}</td>
            <td class="px-4 py-2 text-sm font-extrabold text-slate-900 uppercase tracking-wide">${svc}</td>
          </tr>
        `;
      }).join('');

      el.innerHTML = `
        <div class="overflow-x-auto">
          <table class="w-full border border-slate-300 bg-white/70 table-compact">
            <tbody>${rowsHtml}</tbody>
          </table>
        </div>
      `;
    }

    async function refresh() {
      try {
        const res = await fetch(`board.php?ajax=1`, { cache: 'no-store' });
        const data = await res.json();

        // MEMBERSHIP
        const mServing = data.membership?.serving_main?.queue_code || '—';
        const mServingCounter = data.membership?.serving_main?.counter_id ? `Counter ${data.membership.serving_main.counter_id}` : '—';
        const mServingService = data.membership?.serving_main?.service_name || (mServing === '—' ? 'No serving queue' : '—');

        const mNext = data.membership?.next?.queue_code || '—';
        const mNextCounter = data.membership?.next?.counter_id ? `Counter ${data.membership.next.counter_id}` : '—';
        const mNextService = data.membership?.next?.service_name || (mNext === '—' ? 'No waiting queue' : '—');

        setText('M_serving', mServing);
        setText('M_serving_counter', mServing !== '—' ? mServingCounter : '—');
        setText('M_serving_service', mServingService);

        setText('M_next', mNext);
        setText('M_next_counter', mNext !== '—' ? mNextCounter : '—');
        setText('M_next_service', mNextService);

        renderServingTable('M_table', data.membership?.serving_list || []);

        if (mServing !== last.M && mServing !== '—') {
          last.M = mServing;
          flash('M_serving');
          speak(`Now serving ${mServing}. Please proceed to ${mServingCounter}.`);
        } else if (mServing === '—') {
          last.M = null;
        }

        // HOSP
        const hServing = data.hospitalization?.serving_main?.queue_code || '—';
        const hServingCounter = data.hospitalization?.serving_main?.counter_id ? `Counter ${data.hospitalization.serving_main.counter_id}` : '—';
        const hServingService = data.hospitalization?.serving_main?.service_name || (hServing === '—' ? 'No serving queue' : '—');

        const hNext = data.hospitalization?.next?.queue_code || '—';
        const hNextCounter = data.hospitalization?.next?.counter_id ? `Counter ${data.hospitalization.next.counter_id}` : '—';
        const hNextService = data.hospitalization?.next?.service_name || (hNext === '—' ? 'No waiting queue' : '—');

        setText('H_serving', hServing);
        setText('H_serving_counter', hServing !== '—' ? hServingCounter : '—');
        setText('H_serving_service', hServingService);

        setText('H_next', hNext);
        setText('H_next_counter', hNext !== '—' ? hNextCounter : '—');
        setText('H_next_service', hNextService);

        renderServingTable('H_table', data.hospitalization?.serving_list || []);

        if (hServing !== last.H && hServing !== '—') {
          last.H = hServing;
          flash('H_serving');
          speak(`Now serving ${hServing}. Please proceed to ${hServingCounter}.`);
        } else if (hServing === '—') {
          last.H = null;
        }

        // PRIORITY
        const pServing = data.priority?.serving_main?.queue_code || '—';
        const pServingService = data.priority?.serving_main?.service_name || (pServing === '—' ? 'No serving queue' : '—');

        const pNext = data.priority?.next?.queue_code || '—';
        const pNextService = data.priority?.next?.service_name || (pNext === '—' ? 'No waiting queue' : '—');

        setText('P_serving', pServing);
        setText('P_serving_counter', pServing !== '—' ? 'Counter 2' : '—');
        setText('P_serving_service', pServingService);

        setText('P_next', pNext);
        setText('P_next_counter', pNext !== '—' ? 'Counter 2' : '—');
        setText('P_next_service', pNextService);

        if (pServing !== last.P && pServing !== '—') {
          last.P = pServing;
          flash('P_serving');
          speak(`Priority number ${pServing}. Proceed to ground floor. Counter 2.`);
        } else if (pServing === '—') {
          last.P = null;
        }

      } catch (e) {}
    }

    refresh();
    setInterval(refresh, 2500);
  </script>
</body>
</html>