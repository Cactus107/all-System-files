<?php
session_name('staff_session');
session_start();

// 1) Access Control
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['staff', 'admin'], true)) {
  header("Location: login.php");
  exit();
}

require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../config/csrf.php";
require_once __DIR__ . "/../config/helpers.php";

date_default_timezone_set('Asia/Manila');
$today = date('Y-m-d');

const PRIORITY_COUNTER = 2;

function in_list(int $id, array $arr): bool {
  return in_array($id, $arr, true);
}

/**
 * Adds guard rules PER COUNTER and also joins:
 * - appointments a
 * - services s
 * so we can display service_name in Waiting List / Now Serving.
 */
function build_counter_guard(int $counter_id): array {
  $join   = "
    LEFT JOIN appointments a ON a.appointment_id = q.appointment_id
    LEFT JOIN services s ON s.service_id = a.service_id
  ";
  $where  = "";
  $types  = "";
  $params = [];

  // Priority counter: ONLY Senior/PWD/Pregnant
  if ($counter_id === PRIORITY_COUNTER) {
    $where = "AND a.client_status IN ('Senior Citizen','PWD','Pregnant')";
    return [$join, $where, $types, $params];
  }

  // Membership counters: ONLY category_id=1 and Regular
  if (in_list($counter_id, [4, 6, 7])) {
    $where = "AND q.category_id = 1 AND (a.client_status IS NULL OR a.client_status = 'Regular')";
    return [$join, $where, $types, $params];
  }

  // Hospitalization counters: ONLY category_id=2 and Regular
  if (in_list($counter_id, [8, 9])) {
    $where = "AND q.category_id = 2 AND (a.client_status IS NULL OR a.client_status = 'Regular')";
    return [$join, $where, $types, $params];
  }

  // Default: ONLY Regular
  $where = "AND (a.client_status IS NULL OR a.client_status = 'Regular')";
  return [$join, $where, $types, $params];
}

/* -----------------------------
   AJAX: WAITING LIST (table = queue)
   ----------------------------- */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'queue') {
  header('Content-Type: application/json; charset=utf-8');

  $counter_id = (int)($_GET['counter_id'] ?? 0);
  if ($counter_id <= 0) {
    echo json_encode([]);
    exit();
  }

  [$guardJoin, $guardWhere, $guardTypes, $guardParams] = build_counter_guard($counter_id);

  $sql = "
    SELECT
      q.queue_id,
      q.queue_code,
      q.created_at AS queued_at,
      qc.category_name,
      COALESCE(s.service_name, '') AS service_name
    FROM queue q
    JOIN queue_categories qc ON qc.category_id = q.category_id
    $guardJoin
    WHERE q.queue_date = ? AND q.counter_id = ? AND q.status = 'waiting'
    $guardWhere
    ORDER BY q.created_at ASC
    LIMIT 30
  ";

  $stmt = $conn->prepare($sql);
  if (!$stmt) {
    echo json_encode([]);
    exit();
  }

  $types = "si" . $guardTypes;
  $params = array_merge([$today, $counter_id], $guardParams);
  $stmt->bind_param($types, ...$params);

  $stmt->execute();
  $res = $stmt->get_result();

  $data = [];
  while ($row = $res->fetch_assoc()) $data[] = $row;

  echo json_encode($data);
  exit();
}

/* -----------------------------
   AJAX: NOW SERVING (table = queue)
   ----------------------------- */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'serving') {
  header('Content-Type: application/json; charset=utf-8');

  $counter_id = (int)($_GET['counter_id'] ?? 0);
  if ($counter_id <= 0) {
    echo json_encode(null);
    exit();
  }

  // Include service_name for Now Serving
  $sql = "
    SELECT
      q.queue_id,
      q.queue_code,
      q.category_id,
      qc.category_name,
      COALESCE(s.service_name, '') AS service_name
    FROM queue q
    JOIN queue_categories qc ON qc.category_id = q.category_id
    LEFT JOIN appointments a ON a.appointment_id = q.appointment_id
    LEFT JOIN services s ON s.service_id = a.service_id
    WHERE q.queue_date = ? AND q.counter_id = ? AND q.status = 'serving'
    LIMIT 1
  ";

  $stmt = $conn->prepare($sql);
  if (!$stmt) {
    echo json_encode(null);
    exit();
  }

  $stmt->bind_param("si", $today, $counter_id);
  $stmt->execute();
  $row = $stmt->get_result()->fetch_assoc();

  echo json_encode($row ?: null);
  exit();
}

// Notifications
$success = $_SESSION['success'] ?? '';
$error   = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);

// Counter options (dropdown groups)
$groupSpec = [
  'Priority (P)' => [2],
  'Membership (M)' => [4, 6, 7],
  'Hospitalization/Benefits (H)' => [8, 9],
];

$allIds = [];
foreach ($groupSpec as $ids) $allIds = array_merge($allIds, $ids);
$allIds = array_values(array_unique(array_map('intval', $allIds)));

$placeholders = implode(',', array_fill(0, count($allIds), '?'));
$types = str_repeat('i', count($allIds));

$stmt = $conn->prepare("SELECT counter_id, counter_name, is_active FROM service_counters WHERE counter_id IN ($placeholders)");
$stmt->bind_param($types, ...$allIds);
$stmt->execute();
$counterRows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$counterMeta = [];
foreach ($counterRows as $r) {
  $counterMeta[(int)$r['counter_id']] = [
    'name'   => (string)$r['counter_name'],
    'active' => ((int)$r['is_active'] === 1),
  ];
}

$counterOptions = [];
foreach ($groupSpec as $groupLabel => $ids) {
  foreach ($ids as $cid) {
    $cid = (int)$cid;
    if (!isset($counterMeta[$cid]) || !$counterMeta[$cid]['active']) continue;

    [$guardJoin, $guardWhere, $guardTypes, $guardParams] = build_counter_guard($cid);

    // Count waiting from table `queue`
    $sql = "
      SELECT COUNT(*) AS c
      FROM queue q
      $guardJoin
      WHERE q.queue_date = ? AND q.counter_id = ? AND q.status = 'waiting'
      $guardWhere
    ";

    $stmt = $conn->prepare($sql);
    $types2 = "si" . $guardTypes;
    $params2 = array_merge([$today, $cid], $guardParams);
    $stmt->bind_param($types2, ...$params2);
    $stmt->execute();
    $waiting = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);

    $counterOptions[$groupLabel][] = [
      'counter_id'    => $cid,
      'counter_name'  => $counterMeta[$cid]['name'] ?: ("Counter " . $cid),
      'waiting_count' => $waiting,
    ];
  }
}

// Selected counter
$selectedCounterId = (int)($_SESSION['selected_counter_id'] ?? 0);
if ($selectedCounterId <= 0) {
  foreach ($counterOptions as $items) {
    if (!empty($items)) {
      $selectedCounterId = (int)$items[0]['counter_id'];
      $_SESSION['selected_counter_id'] = $selectedCounterId;
      break;
    }
  }
}

$selectedCounterName = '';
foreach ($counterOptions as $items) {
  foreach ($items as $c) {
    if ((int)$c['counter_id'] === $selectedCounterId) {
      $selectedCounterName = (string)$c['counter_name'];
      break 2;
    }
  }
}

/* -----------------------------
   POST Actions
   ----------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  csrf_validate();
  $action = $_POST['action'] ?? '';

  // set counter
  if ($action === 'set_counter') {
    $newCounterId = (int)($_POST['counter_id'] ?? 0);

    $allowedActive = [];
    foreach ($counterOptions as $items) {
      foreach ($items as $c) $allowedActive[(int)$c['counter_id']] = true;
    }

    if ($newCounterId <= 0 || !isset($allowedActive[$newCounterId])) {
      $_SESSION['error'] = "Invalid counter selected.";
    } else {
      $_SESSION['selected_counter_id'] = $newCounterId;
      $_SESSION['success'] = "Counter set successfully.";
    }

    header("Location: serve.php");
    exit();
  }

  $counter_id = (int)($_SESSION['selected_counter_id'] ?? 0);
  if ($counter_id <= 0) {
    $_SESSION['error'] = "No counter selected.";
    header("Location: serve.php");
    exit();
  }

  if (!in_array($action, ['call_next', 'mark_done'], true)) {
    $_SESSION['error'] = "Invalid action.";
    header("Location: serve.php");
    exit();
  }

  $conn->begin_transaction();
  try {
    if ($action === 'call_next') {
      // already serving?
      $stmt = $conn->prepare("
        SELECT queue_id
        FROM queue
        WHERE queue_date=? AND counter_id=? AND status='serving'
        LIMIT 1
        FOR UPDATE
      ");
      $stmt->bind_param("si", $today, $counter_id);
      $stmt->execute();
      if ($stmt->get_result()->fetch_assoc()) {
        throw new Exception("This counter is already serving someone.");
      }

      // next allowed waiting
      [$guardJoin, $guardWhere, $guardTypes, $guardParams] = build_counter_guard($counter_id);

      $sql = "
        SELECT q.queue_id, q.appointment_id, q.queue_code, q.category_id
        FROM queue q
        $guardJoin
        WHERE q.queue_date=? AND q.counter_id=? AND q.status='waiting'
        $guardWhere
        ORDER BY q.created_at ASC
        LIMIT 1
        FOR UPDATE
      ";

      $stmt = $conn->prepare($sql);
      $types2 = "si" . $guardTypes;
      $params2 = array_merge([$today, $counter_id], $guardParams);
      $stmt->bind_param($types2, ...$params2);
      $stmt->execute();

      $next = $stmt->get_result()->fetch_assoc();
      if (!$next) throw new Exception("No allowed waiting clients for this counter.");

      $qid    = (int)$next['queue_id'];
      $cat_id = (int)$next['category_id'];
      $aid    = !empty($next['appointment_id']) ? (int)$next['appointment_id'] : null;

      // set serving
      $stmt = $conn->prepare("UPDATE queue SET status='serving' WHERE queue_id=?");
      $stmt->bind_param("i", $qid);
      $stmt->execute();

      // audit (make sure log_audit exists in helpers.php)
      log_audit($conn, 'call_next', "Called to Counter #$counter_id", $qid, $next['queue_code'], $cat_id, $counter_id, $aid);

      $_SESSION['success'] = "Now serving: " . $next['queue_code'];
    }

    if ($action === 'mark_done') {
      $stmt = $conn->prepare("
        SELECT queue_id, appointment_id, queue_code, category_id
        FROM queue
        WHERE queue_date=? AND counter_id=? AND status='serving'
        LIMIT 1
        FOR UPDATE
      ");
      $stmt->bind_param("si", $today, $counter_id);
      $stmt->execute();

      $serving = $stmt->get_result()->fetch_assoc();
      if (!$serving) throw new Exception("No active service found for this counter.");

      $qid    = (int)$serving['queue_id'];
      $cat_id = (int)$serving['category_id'];
      $aid    = !empty($serving['appointment_id']) ? (int)$serving['appointment_id'] : null;

      $stmt = $conn->prepare("UPDATE queue SET status='done' WHERE queue_id=?");
      $stmt->bind_param("i", $qid);
      $stmt->execute();

      if ($aid !== null) {
        $stmt = $conn->prepare("UPDATE appointments SET status='completed' WHERE appointment_id=?");
        $stmt->bind_param("i", $aid);
        $stmt->execute();
      }

      log_audit($conn, 'mark_done', "Service completed", $qid, $serving['queue_code'], $cat_id, $counter_id, $aid);

      $_SESSION['success'] = "Completed: " . $serving['queue_code'];
    }

    $conn->commit();
  } catch (Exception $e) {
    $conn->rollback();
    $_SESSION['error'] = $e->getMessage();
  }

  header("Location: serve.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Staff Queue Control</title>
  <script src="https://cdn.tailwindcss.com"></script>

  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            brand: {
              50:  "#F7F2D1",
              100: "#D9FF8C",
              200: "#B6F45A",
              300: "#97EB2F",
              400: "#79E114",
              500: "#5FD000",
              700: "#1F723B",
              gold:  "#E4B519",
              gold2: "#D29910"
            }
          }
        }
      }
    }
  </script>

  <style>
    .lime-bg {
      background: linear-gradient(180deg, #D9FF8C 0%, #B6F45A 35%, #97EB2F 65%, #5FD000 100%);
    }
    .grid-overlay {
      background-image:
        linear-gradient(to right, rgba(255,255,255,0.18) 1px, transparent 1px),
        linear-gradient(to bottom, rgba(255,255,255,0.18) 1px, transparent 1px);
      background-size: 56px 56px;
      mask-image: radial-gradient(70% 60% at 50% 20%, black 40%, transparent 80%);
      opacity: 0.28;
    }
  </style>
</head>

<body class="min-h-screen text-slate-900">
  <div class="fixed inset-0 -z-10 lime-bg"></div>
  <div class="fixed inset-0 -z-10 grid-overlay pointer-events-none"></div>

  <div class="pointer-events-none fixed inset-0 overflow-hidden -z-10">
    <div class="absolute -top-52 -right-60 h-[34rem] w-[34rem] rounded-full bg-white blur-3xl opacity-20"></div>
    <div class="absolute -bottom-52 -left-60 h-[34rem] w-[34rem] rounded-full bg-brand-50 blur-3xl opacity-20"></div>
  </div>

  <div class="mx-auto max-w-6xl p-4 md:p-6 space-y-5">
    <header class="rounded-3xl border border-white/40 bg-white/75 backdrop-blur shadow-sm overflow-hidden">
      <div class="p-4 md:p-5 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        <div class="flex items-start gap-3">
          <div class="h-10 w-10 rounded-2xl bg-brand-50 flex items-center justify-center overflow-hidden border border-white/50">
            <img src="../logo/philhealth_Logo.png" alt="PhilHealth Logo" class="h-10 w-10 object-contain">
          </div>
          <div>
            <h1 class="text-xl md:text-2xl font-extrabold tracking-tight">Staff Queue Control</h1>
            <div class="mt-1 flex flex-wrap items-center gap-2 text-sm text-slate-600">
              <span class="inline-block h-2 w-2 rounded-full bg-brand-700"></span>
              <span><?php echo e(date('M d, Y')); ?></span>
              <span class="hidden sm:inline">•</span>
              <span class="hidden sm:inline">Auto refresh: 5s</span>
            </div>
          </div>
        </div>

        <div class="flex flex-col md:flex-row md:items-center gap-3">
          <form method="POST" action="serve.php" class="flex items-center gap-2 w-full md:w-auto">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="set_counter" />
            <select name="counter_id"
                    class="w-full md:w-[420px] rounded-xl border border-white/60 bg-white/90 px-3 py-2
                           text-sm font-semibold text-slate-900 shadow-sm
                           focus:outline-none focus:ring-2 focus:ring-brand-200"
                    onchange="this.form.submit()">
              <?php foreach ($counterOptions as $groupLabel => $items): ?>
                <optgroup label="<?php echo e($groupLabel); ?>">
                  <?php foreach ($items as $c): ?>
                    <option value="<?php echo (int)$c['counter_id']; ?>"
                      <?php echo ((int)$selectedCounterId === (int)$c['counter_id']) ? 'selected' : ''; ?>>
                      <?php echo e($c['counter_name'] . ' (' . (int)$c['waiting_count'] . ' waiting)'); ?>
                    </option>
                  <?php endforeach; ?>
                </optgroup>
              <?php endforeach; ?>
            </select>
          </form>

          <div class="flex flex-wrap items-center gap-2">
            <a href="board.php" class="px-3 py-2 rounded-xl text-sm font-bold bg-white/70 border border-white/60 hover:bg-white transition">Board</a>
            <a href="../kiosk/index.php" class="px-3 py-2 rounded-xl text-sm font-bold bg-white/70 border border-white/60 hover:bg-white transition">Kiosk</a>
            <a href="audit.php" class="px-3 py-2 rounded-xl text-sm font-bold bg-white/70 border border-white/60 hover:bg-white transition">Audit</a>
            <a href="logout.php" class="px-3 py-2 rounded-xl text-sm font-bold text-white bg-brand-700 hover:opacity-95 transition">Logout</a>
          </div>
        </div>
      </div>

      <?php if ($success): ?>
        <div class="px-4 md:px-5 pb-4">
          <div class="rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-800 px-4 py-3 text-sm font-semibold">
            <?php echo e($success); ?>
          </div>
        </div>
      <?php endif; ?>
      <?php if ($error): ?>
        <div class="px-4 md:px-5 pb-4">
          <div class="rounded-xl border border-red-200 bg-red-50 text-red-700 px-4 py-3 text-sm font-semibold">
            <?php echo e($error); ?>
          </div>
        </div>
      <?php endif; ?>
    </header>

    <main class="grid grid-cols-1 lg:grid-cols-12 gap-5">
      <section class="lg:col-span-4 space-y-5">
        <div class="rounded-3xl border border-white/40 bg-white/75 backdrop-blur shadow-sm p-5">
          <div class="flex items-start justify-between gap-3">
            <div>
              <div class="text-xs font-bold text-slate-500 uppercase tracking-wide">Selected Counter</div>
              <div class="mt-1 text-lg font-extrabold text-brand-700">
                <?php echo e($selectedCounterName ?: ("Counter #".$selectedCounterId)); ?>
              </div>
            </div>
            <div id="servingPill"
                 class="hidden shrink-0 text-xs font-extrabold px-2.5 py-1 rounded-full bg-brand-50 text-brand-700 border border-brand-100">
              Serving
            </div>
          </div>

          <div class="mt-4 rounded-2xl border border-white/60 bg-white/80 p-4">
            <div class="text-xs font-bold text-slate-500 uppercase tracking-wide">Now Serving</div>
            <div id="servingCode" class="mt-2 text-4xl font-extrabold tracking-tight text-slate-300">—</div>
            <div id="servingCat" class="mt-1 text-xs font-bold text-slate-500 uppercase"></div>
            <div id="servingSvc" class="mt-1 text-sm font-semibold text-slate-700"></div>

            <div class="mt-4 grid grid-cols-1 gap-2">
              <form method="POST">
                <?php echo csrf_field(); ?>
                <button id="callNextBtn" name="action" value="call_next"
                        class="w-full rounded-xl bg-brand-700 hover:opacity-95 text-white py-3 text-sm font-extrabold shadow-sm
                               disabled:opacity-40 disabled:cursor-not-allowed transition active:scale-[.99]">
                  Call Next
                </button>
              </form>

              <form method="POST" id="doneForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="mark_done" />
                <button type="button" id="doneBtn" onclick="openDoneModalFromServing()"
                        class="w-full rounded-xl border border-white/60 bg-white/80 hover:bg-white text-slate-800 py-3 text-sm font-extrabold
                               disabled:opacity-40 disabled:cursor-not-allowed transition active:scale-[.99]">
                  Mark Done
                </button>
              </form>
            </div>

            <p class="mt-3 text-xs text-slate-500">
              Call Next is disabled when someone is currently serving or if waiting is 0.
            </p>
          </div>
        </div>

        <div class="rounded-3xl border border-white/40 bg-white/75 backdrop-blur shadow-sm p-5">
          <div class="text-sm font-extrabold">Quick Rules</div>
          <ul class="mt-2 text-sm text-slate-600 space-y-1 list-disc pl-5">
            <li>FCFS per selected counter</li>
            <li>Mark Done completes current serving</li>
            <li>Auto refresh every 5 seconds</li>
          </ul>
        </div>
      </section>

      <section class="lg:col-span-8 rounded-3xl border border-white/40 bg-white/75 backdrop-blur shadow-sm p-5">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h2 class="text-lg md:text-xl font-extrabold">Waiting List</h2>
            <p class="text-sm text-slate-500">This counter only (up to 30)</p>
          </div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-bold text-slate-500 uppercase">Waiting</span>
            <span id="queueCounterBadge"
                  class="text-xs font-extrabold px-2.5 py-1 rounded-full bg-brand-50 text-brand-700 border border-brand-100">
              0
            </span>
          </div>
        </div>

        <div class="mt-4">
          <div id="queueList" class="space-y-2">
            <div class="text-slate-400 text-sm italic">Loading...</div>
          </div>
        </div>
      </section>
    </main>
  </div>

  <div id="confirmModal" class="fixed inset-0 z-50 hidden">
    <div class="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"></div>
    <div class="relative min-h-full flex items-center justify-center p-4">
      <div class="w-full max-w-md rounded-3xl bg-white/90 border border-white/60 shadow-2xl p-6 backdrop-blur">
        <div class="flex items-start gap-3">
          <div class="h-10 w-10 rounded-2xl bg-emerald-50 flex items-center justify-center">
            <svg class="h-5 w-5 text-emerald-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20 6L9 17l-5-5" />
            </svg>
          </div>
          <div class="flex-1">
            <div class="text-lg font-extrabold">Confirm Completion</div>
            <p class="mt-1 text-sm text-slate-600">
              Mark <span id="modalQueueCode" class="font-extrabold text-brand-700"></span> as done?
            </p>
          </div>
        </div>

        <div class="mt-5 flex gap-2">
          <button type="button" onclick="closeDoneModal()"
                  class="flex-1 rounded-xl border border-white/60 bg-white/80 hover:bg-white py-3 text-sm font-extrabold text-slate-800 transition">
            Cancel
          </button>
          <button type="button" id="confirmDoneBtn"
                  class="flex-1 rounded-xl bg-emerald-600 hover:opacity-95 py-3 text-sm font-extrabold text-white transition
                         flex items-center justify-center gap-2">
            <span id="btnText">Confirm</span>
            <span id="btnSpinner" class="hidden h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
          </button>
        </div>
      </div>
    </div>
  </div>

  <script>
    const selectedCounterId = <?php echo (int)$selectedCounterId; ?>;

    const queueList = document.getElementById('queueList');
    const badge = document.getElementById('queueCounterBadge');
    const callBtn = document.getElementById('callNextBtn');
    const servingCodeEl = document.getElementById('servingCode');
    const servingCatEl  = document.getElementById('servingCat');
    const servingSvcEl  = document.getElementById('servingSvc');
    const doneBtn = document.getElementById('doneBtn');
    const servingPill = document.getElementById('servingPill');

    let servingSnapshot = null;

    function rowHtml(q, i) {
      const code = (q.queue_code ?? '').toString();
      const cat  = (q.category_name ?? '').toString();
      const svc  = (q.service_name ?? '').toString();

      return `
        <div class="flex items-center justify-between rounded-2xl border border-white/60 bg-white/80 p-4 hover:bg-white transition">
          <div class="min-w-0">
            <div class="text-lg font-extrabold tracking-tight text-slate-900">${code}</div>
            <div class="mt-0.5 text-xs font-bold text-slate-500 uppercase">${cat}</div>
            ${svc ? `<div class="mt-1 text-sm font-semibold text-slate-700">${svc}</div>` : ``}
          </div>
          <span class="shrink-0 text-xs font-extrabold px-2.5 py-1 rounded-full bg-brand-50 text-brand-700 border border-brand-100">
            #${i + 1}
          </span>
        </div>
      `;
    }

    async function loadWaiting() {
      try {
        const res = await fetch(`serve.php?ajax=queue&counter_id=${selectedCounterId}`, { cache: "no-store" });
        if (!res.ok) throw new Error("HTTP " + res.status);
        const data = await res.json();

        badge.textContent = data.length;

        if (!data.length) {
          queueList.innerHTML = '<div class="rounded-2xl border border-dashed border-white/60 bg-white/50 p-6 text-sm text-slate-600">No clients waiting for this counter.</div>';
        } else {
          queueList.innerHTML = data.map(rowHtml).join('');
        }
      } catch (e) {
        badge.textContent = 0;
        queueList.innerHTML = '<div class="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm font-semibold text-red-700">Failed to load waiting list.</div>';
      }
    }

    async function loadServing() {
      try {
        const res = await fetch(`serve.php?ajax=serving&counter_id=${selectedCounterId}`, { cache: "no-store" });
        if (!res.ok) throw new Error("HTTP " + res.status);
        const row = await res.json();

        servingSnapshot = row;

        if (!row) {
          servingCodeEl.textContent = '—';
          servingCodeEl.className = 'mt-2 text-4xl font-extrabold tracking-tight text-slate-300';
          servingCatEl.textContent = '';
          servingSvcEl.textContent = '';
          doneBtn.disabled = true;
          servingPill.classList.add('hidden');
          return;
        }

        servingCodeEl.textContent = row.queue_code;
        servingCodeEl.className = 'mt-2 text-4xl font-extrabold tracking-tight text-brand-700';
        servingCatEl.textContent = row.category_name ? row.category_name.toUpperCase() : '';
        servingSvcEl.textContent = row.service_name ? row.service_name : '';
        doneBtn.disabled = false;
        servingPill.classList.remove('hidden');
      } catch (e) {
        servingSnapshot = null;
        doneBtn.disabled = true;
        servingPill.classList.add('hidden');
      }
    }

    async function refreshAll() {
      await loadServing();
      await loadWaiting();
      callBtn.disabled = !!servingSnapshot || Number(badge.textContent || 0) === 0;
    }

    setInterval(refreshAll, 5000);
    refreshAll();

    let activeFormId = null;

    function openDoneModalFromServing() {
      if (!servingSnapshot) return;
      openDoneModal(servingSnapshot.queue_code, 'doneForm');
    }

    function openDoneModal(queueCode, formId) {
      activeFormId = formId;
      document.getElementById('modalQueueCode').innerText = queueCode;
      document.getElementById('confirmModal').classList.remove('hidden');
      document.body.style.overflow = 'hidden';
    }

    function closeDoneModal() {
      document.getElementById('confirmModal').classList.add('hidden');
      document.body.style.overflow = '';
      activeFormId = null;
      const btn = document.getElementById('confirmDoneBtn');
      btn.disabled = false;
      document.getElementById('btnText').innerText = "Confirm";
      document.getElementById('btnSpinner').classList.add('hidden');
    }

    document.getElementById('confirmDoneBtn').addEventListener('click', function () {
      if (!activeFormId) return;
      this.disabled = true;
      document.getElementById('btnText').innerText = "Processing...";
      document.getElementById('btnSpinner').classList.remove('hidden');
      document.getElementById(activeFormId).submit();
    });

    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeDoneModal(); });
  </script>
</body>
</html>