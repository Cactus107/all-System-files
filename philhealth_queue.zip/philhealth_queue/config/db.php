<?php
// config/db.php

// XAMPP defaults
$db_host = "127.0.0.1";
$db_user = "root";
$db_pass = "";                 // default in XAMPP
$db_name = "philhealth_queue";

// Create connection
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . htmlspecialchars($conn->connect_error));
}

// Always use utf8mb4
$conn->set_charset("utf8mb4");
