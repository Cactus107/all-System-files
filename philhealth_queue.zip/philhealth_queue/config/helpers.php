<?php
// config/helpers.php
// IMPORTANT: NO spaces/blank chars before "<?php"

function e(?string $str): string {
  return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function generate_reference_code(): string {
  $datePart = date('Ymd');
  $randPart = strtoupper(substr(bin2hex(random_bytes(4)), 0, 4));
  return "REF-$datePart-$randPart";
}

function format_queue_code(string $prefix, int $number): string {
  $prefix = strtoupper(trim($prefix));
  return $prefix . (string)$number; // M2001 / H2001
}

function today_date(): string { return date('Y-m-d'); }

function normalize_client_status(string $s): string {
  $s = trim($s);
  $allowed = ['Regular', 'Senior Citizen', 'PWD', 'Pregnant'];
  return in_array($s, $allowed, true) ? $s : 'Regular';
}

/**
 * Active-counter picker using service_counters table.
 * Returns 2 if none active.
 */
function pick_random_active_counter(mysqli $conn, array $counterIds): int {
  $counterIds = array_values(array_unique(array_map('intval', $counterIds)));
  if (!$counterIds) return 2;

  $placeholders = implode(',', array_fill(0, count($counterIds), '?'));
  $types = str_repeat('i', count($counterIds));

  $stmt = $conn->prepare("
    SELECT counter_id
    FROM service_counters
    WHERE is_active = 1 AND counter_id IN ($placeholders)
  ");
  if (!$stmt) return 2;

  $stmt->bind_param($types, ...$counterIds);
  $stmt->execute();
  $res = $stmt->get_result();

  $active = [];
  while ($row = $res->fetch_assoc()) $active[] = (int)$row['counter_id'];
  $stmt->close();

  if (!$active) return 2;
  return $active[array_rand($active)];
}

function get_category_prefix(mysqli $conn, int $category_id): string {
  $stmt = $conn->prepare("SELECT prefix FROM queue_categories WHERE category_id=? AND is_active=1 LIMIT 1");
  if (!$stmt) throw new Exception("DB error (prefix): " . $conn->error);

  $stmt->bind_param("i", $category_id);
  $stmt->execute();
  $row = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  if (!$row) throw new Exception("Invalid category.");
  $prefix = strtoupper(trim((string)$row['prefix']));
  if ($prefix === '') throw new Exception("Category prefix not configured.");
  return $prefix;
}

function get_service_row(mysqli $conn, int $service_id): array {
  $stmt = $conn->prepare("
    SELECT service_id, category_id, is_active
    FROM services
    WHERE service_id = ?
    LIMIT 1
  ");
  if (!$stmt) throw new Exception("DB error (service): " . $conn->error);

  $stmt->bind_param("i", $service_id);
  $stmt->execute();
  $row = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  if (!$row) throw new Exception("Selected service not found.");
  if ((int)$row['is_active'] !== 1) throw new Exception("Selected service is not active.");

  return ['service_id' => (int)$row['service_id'], 'category_id' => (int)$row['category_id']];
}

/**
 * FINAL ROUTING POLICY (matches your table):
 * - Counter 2 is PRIORITY ONLY:
 *     Membership priority: Senior Citizen, PWD
 *     Hospitalization priority: Pregnant
 * - Regular routing:
 *     Membership -> 4,6,7
 *     Hospitalization -> 8,9
 */
function compute_counter_id(mysqli $conn, int $category_id, string $client_status): int
{
  $client_status = normalize_client_status($client_status);

  // Priority ONLY -> Counter 2 (any category)
  if (in_array($client_status, ['Senior Citizen', 'PWD', 'Pregnant'], true)) {
    return 2;
  }

  // Regular NEVER -> 2
  if ($category_id === 1) return pick_random_active_counter($conn, [4, 6, 7]);
  if ($category_id === 2) return pick_random_active_counter($conn, [8, 9]);

  return 2;
}

/**
 * If you want to keep a service-based signature in other pages.
 * It validates the service is active then routes using category rules above.
 */
function compute_counter_id_from_service(mysqli $conn, int $service_id, int $category_id, string $client_status): int
{
  $svc = get_service_row($conn, $service_id);
  $cat = $category_id > 0 ? $category_id : (int)$svc['category_id'];
  return compute_counter_id($conn, $cat, $client_status);
}

/**
 * Next queue number per (queue_date + service_id).
 * Must be called inside a transaction.
 * Starts at 2001.
 */
function allocate_next_queue_number(mysqli $conn, string $queue_date, int $service_id): int {
  $lockKey = "qnum:{$queue_date}:svc{$service_id}";

  $stmt = $conn->prepare("SELECT GET_LOCK(?, 10) AS got");
  if (!$stmt) throw new Exception("DB error (GET_LOCK): " . $conn->error);
  $stmt->bind_param("s", $lockKey);
  $stmt->execute();
  $got = (int)($stmt->get_result()->fetch_assoc()['got'] ?? 0);
  $stmt->close();

  if ($got !== 1) throw new Exception("Queue is busy. Please try again.");

  try {
    $stmt = $conn->prepare("
      SELECT COALESCE(MAX(queue_number), 2000) AS mx
      FROM queue
      WHERE queue_date = ? AND service_id = ?
      FOR UPDATE
    ");
    if (!$stmt) throw new Exception("DB error (max queue_number): " . $conn->error);

    $stmt->bind_param("si", $queue_date, $service_id);
    $stmt->execute();
    $mx = (int)($stmt->get_result()->fetch_assoc()['mx'] ?? 2000);
    $stmt->close();

    return $mx + 1; // first = 2001
  } finally {
    $rel = $conn->prepare("SELECT RELEASE_LOCK(?)");
    if ($rel) {
      $rel->bind_param("s", $lockKey);
      $rel->execute();
      $rel->close();
    }
  }
}

/**
 * Issue queue for an appointment (idempotent).
 * Must be called inside a transaction.
 *
 * IMPORTANT FIX:
 * - ALWAYS recompute counter_id here so PRIORITY can never be bypassed.
 */
function issue_queue_at_booking(mysqli $conn, int $appointment_id): array {
  if ($appointment_id <= 0) throw new Exception("Invalid appointment_id.");

  // Lock appointment
  $stmt = $conn->prepare("
    SELECT appointment_id, service_id, category_id, counter_id, client_status, appointment_date
    FROM appointments
    WHERE appointment_id = ?
    LIMIT 1
    FOR UPDATE
  ");
  if (!$stmt) throw new Exception("DB error (appointments): " . $conn->error);

  $stmt->bind_param("i", $appointment_id);
  $stmt->execute();
  $apt = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  if (!$apt) throw new Exception("Appointment not found.");

  $service_id    = (int)$apt['service_id'];
  $category_id   = (int)$apt['category_id'];
  $client_status = normalize_client_status((string)($apt['client_status'] ?? 'Regular'));
  $queue_date    = (string)$apt['appointment_date'];

  if ($service_id <= 0) throw new Exception("Service missing on appointment.");
  if ($queue_date === '') throw new Exception("Appointment date missing.");

  // Validate service active and ensure category
  $svc = get_service_row($conn, $service_id);
  if ($category_id <= 0) $category_id = (int)$svc['category_id'];

  // ✅ ALWAYS recompute counter (priority override guaranteed)
  // ✅ ALWAYS recompute counter using service + priority rules
$counter_id = compute_counter_id_from_service($conn, $service_id, $category_id, $client_status);

  $up = $conn->prepare("UPDATE appointments SET counter_id=? WHERE appointment_id=?");
  if (!$up) throw new Exception("DB error (update counter): " . $conn->error);
  $up->bind_param("ii", $counter_id, $appointment_id);
  $up->execute();
  $up->close();

  // If queue exists, return it
  $stmt = $conn->prepare("
    SELECT queue_id, queue_date, service_id, category_id, counter_id, prefix, queue_number, queue_code, status, created_at
    FROM queue
    WHERE appointment_id = ?
    LIMIT 1
    FOR UPDATE
  ");
  if (!$stmt) throw new Exception("DB error (queue existing): " . $conn->error);

  $stmt->bind_param("i", $appointment_id);
  $stmt->execute();
  $existing = $stmt->get_result()->fetch_assoc();
  $stmt->close();

  if ($existing) {
    return [
      'queue_id'        => (int)$existing['queue_id'],
      'appointment_id'  => $appointment_id,
      'service_id'      => (int)$existing['service_id'],
      'queue_date'      => (string)$existing['queue_date'],
      'category_id'     => (int)$existing['category_id'],
      'counter_id'      => (int)$existing['counter_id'],
      'prefix'          => (string)$existing['prefix'],
      'queue_number'    => (int)$existing['queue_number'],
      'queue_code'      => (string)$existing['queue_code'],
      'status'          => (string)$existing['status'],
      'created_at'      => (string)$existing['created_at'],
    ];
  }

  $prefix = get_category_prefix($conn, $category_id);

  for ($attempt = 0; $attempt < 10; $attempt++) {
    $queue_number = allocate_next_queue_number($conn, $queue_date, $service_id);
    $queue_code   = format_queue_code($prefix, $queue_number);

    $ins = $conn->prepare("
      INSERT INTO queue
        (appointment_id, service_id, queue_date, category_id, counter_id, prefix, queue_number, queue_code, status, created_at)
      VALUES
        (?, ?, ?, ?, ?, ?, ?, ?, 'waiting', NOW())
    ");
    if (!$ins) throw new Exception("DB error (insert queue): " . $conn->error);

    $ins->bind_param(
      "iisiisis",
      $appointment_id,
      $service_id,
      $queue_date,
      $category_id,
      $counter_id,
      $prefix,
      $queue_number,
      $queue_code
    );

    if ($ins->execute()) {
      $queue_id = (int)$conn->insert_id;
      $ins->close();

      return [
        'queue_id'        => $queue_id,
        'appointment_id'  => $appointment_id,
        'service_id'      => $service_id,
        'queue_date'      => $queue_date,
        'category_id'     => $category_id,
        'counter_id'      => $counter_id,
        'prefix'          => $prefix,
        'queue_number'    => $queue_number,
        'queue_code'      => $queue_code,
        'status'          => 'waiting',
        'created_at'      => date('Y-m-d H:i:s'),
      ];
    }

    $errno = (int)$ins->errno;
    $err   = (string)$ins->error;
    $ins->close();

    if ($errno === 1062) continue;
    throw new Exception("Queue insert failed: " . $err);
  }

  throw new Exception("Failed to issue queue after multiple retries.");
}
/**
 * Records an action into the audit_logs table.
 * Used by staff/serve.php
 *
 * Expected table columns (recommended):
 * audit_id (AI PK), actor_user_id, actor_name, actor_role,
 * action, queue_id, queue_code, category_id, counter_id,
 * details, appointment_id, created_at
 */
function log_audit(
  mysqli $conn,
  string $action,
  string $details = "",
  ?int $queue_id = null,
  ?string $queue_code = null,
  ?int $category_id = null,
  ?int $counter_id = null,
  ?int $appointment_id = null
): void {

  // Optional enrichment: attach client name/status if appointment_id given
  if ($appointment_id !== null && $appointment_id > 0) {
    $stmt_apt = $conn->prepare("
      SELECT ap.user_id, ap.walkin_name, ap.client_status, u.full_name
      FROM appointments ap
      LEFT JOIN users u ON u.user_id = ap.user_id
      WHERE ap.appointment_id = ?
      LIMIT 1
    ");
    if ($stmt_apt) {
      $stmt_apt->bind_param("i", $appointment_id);
      $stmt_apt->execute();
      $apt_result = $stmt_apt->get_result();

      if ($apt_result && ($apt_row = $apt_result->fetch_assoc())) {
        $client_name = (!empty($apt_row['user_id']) && !empty($apt_row['full_name']))
          ? (string)$apt_row['full_name']
          : (!empty($apt_row['walkin_name']) ? (string)$apt_row['walkin_name'] : 'Unknown');

        $client_status = !empty($apt_row['client_status']) ? (string)$apt_row['client_status'] : '';

        $details = ($details !== '')
          ? ($details . " | Client: " . $client_name)
          : ("Client: " . $client_name);

        if ($client_status !== '') $details .= " | ClientStatus: " . $client_status;
      }
      $stmt_apt->close();
    }
  }

  // Insert audit row
  $stmt = $conn->prepare("
    INSERT INTO audit_logs
      (actor_user_id, actor_name, actor_role, action,
       queue_id, queue_code, category_id, counter_id,
       details, appointment_id, created_at)
    VALUES
      (?, ?, ?, ?,
       ?, ?, ?, ?,
       ?, ?, NOW())
  ");
  if (!$stmt) {
    // Do not fatal the whole system if audit table is missing/mismatched
    // but still expose an actionable error in dev.
    throw new Exception("Audit Log Prepare Error: " . $conn->error);
  }

  $actor_user_id = (int)($_SESSION['user_id'] ?? 0);
  $actor_name    = (string)($_SESSION['name'] ?? 'System');
  $actor_role    = (string)($_SESSION['role'] ?? 'staff');

  // allow nulls safely
  $qid  = $queue_id;
  $qcod = $queue_code;
  $cid  = $category_id;
  $ctr  = $counter_id;
  $aid  = $appointment_id;

  $stmt->bind_param(
    "isssisiisi",
    $actor_user_id,
    $actor_name,
    $actor_role,
    $action,
    $qid,
    $qcod,
    $cid,
    $ctr,
    $details,
    $aid
  );

  if (!$stmt->execute()) {
    $err = $stmt->error;
    $stmt->close();
    throw new Exception("Audit Log Error: " . $err);
  }

  $stmt->close();
}