<?php
session_name('user_session');
session_start();

require_once __DIR__ . "/../config/db.php";
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'user') {
  http_response_code(401);
  echo json_encode(["ok" => false, "error" => "Unauthorized"]);
  exit;
}

$raw = file_get_contents("php://input");
$body = json_decode($raw, true);
if (!is_array($body)) $body = [];

$eventType = trim((string)($body['event_type'] ?? ''));
$payload = $body['payload'] ?? [];

if ($eventType === '') {
  http_response_code(400);
  echo json_encode(["ok" => false, "error" => "Missing event_type"]);
  exit;
}

$userId = (int)$_SESSION['user_id'];
$payloadJson = json_encode($payload, JSON_UNESCAPED_UNICODE);

$stmt = $conn->prepare("
  INSERT INTO chatbot_events (user_id, event_type, payload_json, created_at)
  VALUES (?, ?, ?, NOW())
");
$stmt->bind_param("iss", $userId, $eventType, $payloadJson);
$stmt->execute();

echo json_encode(["ok" => true], JSON_UNESCAPED_UNICODE);
exit;