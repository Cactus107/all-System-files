<?php
/**
 * user/chat_helper.php
 * Sagip Assistant - Chat Helper (STRICT OUT-OF-SCOPE + REALTIME QUEUE)
 *
 * - Loads .env (OPENAI_API_KEY, OPENAI_MODEL)
 * - HARD GATE: If question is NOT PhilHealth/system-related, return OUT_OF_SCOPE_REPLY
 * - REALTIME QUEUE: If user asks "my queue number today", return live queue status from DB (no OpenAI)
 * - Otherwise: Use OpenAI Responses API (fine-tuned) after passing domain gate
 * - Fallbacks: FAQ keyword match, Requirements match, Node-based canned answers
 *

 */

declare(strict_types=1);

session_name('user_session');
session_start();

require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../config/helpers.php";
require_once __DIR__ . "/../config/env.php";

// Load .env from project root: /philhealth_queue/.env
load_env(__DIR__ . "/../.env");

date_default_timezone_set('Asia/Manila');
header('Content-Type: application/json; charset=utf-8');

// Determine if a user is logged in
$isUser  = isset($_SESSION['user_id']) && (($_SESSION['role'] ?? '') === 'user');
$user_id = $isUser ? (int) $_SESSION['user_id'] : 0;

// Read JSON body ONCE
$raw  = file_get_contents("php://input");
$body = json_decode($raw, true);
if (!is_array($body)) $body = [];

$userMsg = trim((string)($body['message'] ?? ''));
$meta    = $body['meta'] ?? [];
if (!is_array($meta)) $meta = [];

// ============================================================
// OUT-OF-SCOPE REPLY (single source of truth)
// ============================================================
const OUT_OF_SCOPE_REPLY =
    "Paumanhin, ang inyong katanungan ay hindi sakop ng kasalukuyang FAQ database ng system. " .
    "Maaaring makipag-ugnayan sa pinakamalapit na PhilHealth Office o bisitahin ang opisyal na " .
    "website ng PhilHealth para sa mas detalyadong impormasyon.";

// Model signal
const OUT_OF_SCOPE_SIGNAL = "OUT_OF_SCOPE";

// If empty message
if ($userMsg === '') {
    http_response_code(400);
    echo json_encode([
        "response"      => "Hi! Please type your question or choose an option below.",
        "node_id"       => "root",
        "quick_replies" => quickReplies("root", $isUser),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/* --------------------------------------------------------------------------
   DOMAIN CHECKER (PhilHealth/system-related?)
   -------------------------------------------------------------------------- */
function isPhilhealthRelated(string $text): bool
{
    $t = mb_strtolower($text);

    // Allow simple navigation words (always pass)
    $nav = ['menu', 'main menu', 'back', 'login', 'register', 'sign in', 'magpatuloy', 'tapusin'];
    if (in_array(trim($t), $nav, true)) return true;

    // Comprehensive domain keywords
    $keywords = [
        // Core PhilHealth + System terms
        'philhealth','phic','yakap','konsulta','benefit','benepisyo',
        'membership','miyembro','premium','contribution','hulog',
        'appointment','book','booking','schedule','petsa','oras',
        'queue','kiosk','check in','check-in','counter','serving','done',
        'requirement','requirements','document','documents',
        'id','pin','mpr','dependent','principal','employed',
        'voluntary','indigent','senior','pwd','claims','z benefits',
        'gamot','oecb','lhio','nhip','uhc','ra 11223',

        // Your web app / portal words (still in-scope)
        'user login','register','account','username','password','portal','system','platform','website','online','walk-in',

        // Common PhilHealth acronyms & programs
        'pcu','upsc','pcc','mdr','pmrf','pan','acr','hci','fpe','e.e.c.l','eekl',
        'gamot availment slip','gas','outpatient emergency care benefit','oecb',
    ];

    foreach ($keywords as $kw) {
        if ($kw !== '' && str_contains($t, $kw)) return true;
    }

    return false;
}

/* --------------------------------------------------------------------------
   FAQ LOADING & MATCHING
   -------------------------------------------------------------------------- */
function loadFAQ(): array {
    $faqFile = __DIR__ . '/augmented_faq.jsonl';
    if (!file_exists($faqFile)) {
        error_log("FAQ file not found: $faqFile");
        return [];
    }
    $faq = [];
    $handle = fopen($faqFile, 'r');
    if ($handle) {
        while (($line = fgets($handle)) !== false) {
            $data = json_decode($line, true);
            if (isset($data['messages']) && is_array($data['messages']) && count($data['messages']) >= 2) {
                $question = $data['messages'][0]['content'] ?? '';
                $answer   = $data['messages'][1]['content'] ?? '';
                if ($question && $answer) {
                    $faq[] = ['question' => (string)$question, 'answer' => (string)$answer];
                }
            }
        }
        fclose($handle);
    }
    return $faq;
}

function findBestFAQ(string $userMsg, array $faq, float $threshold = 0.3): ?array {
    if (empty($faq)) return null;

    $userWords = array_filter(array_map('trim', preg_split('/\s+/', mb_strtolower($userMsg))));
    if (empty($userWords)) return null;

    $best = null;
    $bestScore = 0.0;

    foreach ($faq as $item) {
        $qWords = array_filter(array_map('trim', preg_split('/\s+/', mb_strtolower((string)$item['question']))));
        if (empty($qWords)) continue;

        $common = count(array_intersect($userWords, $qWords));
        $score  = $common / max(1, count($qWords));

        if ($score > $bestScore) {
            $bestScore = $score;
            $best = (string)$item['answer'];
        }
    }

    if ($best !== null && $bestScore >= $threshold) {
        return ['answer' => $best, 'confidence' => $bestScore];
    }
    return null;
}

/* --------------------------------------------------------------------------
   APPOINTMENT REQUIREMENTS LOADING & MATCHING
   -------------------------------------------------------------------------- */
function loadRequirements(): array {
    $reqFile = __DIR__ . '/../config/appointment_requirements.php';
    if (file_exists($reqFile)) {
        $data = require $reqFile;
        return is_array($data) ? $data : [];
    }
    error_log("Appointment requirements file not found: $reqFile");
    return [];
}

function findRequirements(string $userMsg, array $requirements): ?array {
    $userMsgLower = mb_strtolower($userMsg);
    $bestMatch = null;
    $bestScore = 0;

    foreach ($requirements as $key => $item) {
        if (!is_array($item)) continue;

        if (isset($item['keywords']) && is_array($item['keywords'])) {
            foreach ($item['keywords'] as $kw) {
                $kw = (string)$kw;
                if ($kw !== '' && str_contains($userMsgLower, mb_strtolower($kw))) {
                    $score = strlen($kw);
                    if ($score > $bestScore) {
                        $bestScore = $score;
                        $bestMatch = ['type' => $key, 'item' => $item];
                    }
                }
            }
        }

        if (isset($item['categories']) && is_array($item['categories'])) {
            foreach ($item['categories'] as $catKey => $category) {
                if (!is_array($category)) continue;

                foreach (($category['keywords'] ?? []) as $kw) {
                    $kw = (string)$kw;
                    if ($kw !== '' && str_contains($userMsgLower, mb_strtolower($kw))) {
                        $score = strlen($kw) + 5;
                        if ($score > $bestScore) {
                            $bestScore = $score;
                            $bestMatch = [
                                'type'          => $key,
                                'category'      => $catKey,
                                'item'          => $item,
                                'category_data' => $category
                            ];
                        }
                    }
                }

                if (isset($category['specific']) && is_array($category['specific'])) {
                    foreach ($category['specific'] as $subKey => $sub) {
                        if (!is_array($sub)) continue;

                        foreach (($sub['keywords'] ?? []) as $kw) {
                            $kw = (string)$kw;
                            if ($kw !== '' && str_contains($userMsgLower, mb_strtolower($kw))) {
                                $score = strlen($kw) + 10;
                                if ($score > $bestScore) {
                                    $bestScore = $score;
                                    $bestMatch = [
                                        'type'          => $key,
                                        'category'      => $catKey,
                                        'subcategory'   => $subKey,
                                        'item'          => $item,
                                        'category_data' => $category,
                                        'sub_data'      => $sub
                                    ];
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return ($bestMatch && $bestScore > 5) ? $bestMatch : null;
}

function formatRequirements(array $match, array $reqArray): string {
    $type = (string)$match['type'];
    $item = $reqArray[$type] ?? null;
    if (!is_array($item)) return OUT_OF_SCOPE_REPLY;

    $lines = [];
    $lines[] = '"' . (string)($item['label'] ?? $type) . '"';

    if (isset($match['sub_data']) && is_array($match['sub_data'])) {
        $sub = $match['sub_data'];
        $lines[] = '"' . (string)($sub['label'] ?? '') . '"';

        if (isset($match['category']) && isset($item['categories'][$match['category']]['general_requirements'])) {
            $gr = $item['categories'][$match['category']]['general_requirements'];
            if (is_array($gr)) $lines = array_merge($lines, $gr);
        }
        if (isset($sub['requirements']) && is_array($sub['requirements'])) {
            $lines = array_merge($lines, $sub['requirements']);
        }
    } elseif (isset($match['category_data']) && is_array($match['category_data'])) {
        $cat = $match['category_data'];
        $lines[] = '"' . (string)($cat['label'] ?? '') . '"';

        if (isset($cat['requirements']) && is_array($cat['requirements'])) {
            $lines = array_merge($lines, $cat['requirements']);
        }

        if (isset($match['category']) && isset($item['categories'][$match['category']]['general_requirements'])) {
            $gr = $item['categories'][$match['category']]['general_requirements'];
            if (is_array($gr)) $lines = array_merge($lines, $gr);
        }
    } elseif (isset($item['requirements']) && is_array($item['requirements'])) {
        $lines = array_merge($lines, $item['requirements']);
    } else {
        $lines[] = "Please specify your category (e.g., principal member, dependent, employed private, etc.).";
        if (isset($item['categories']) && is_array($item['categories'])) {
            $lines[] = "Available categories:";
            foreach ($item['categories'] as $cat) {
                if (is_array($cat)) $lines[] = "• " . (string)($cat['label'] ?? '');
            }
        }
    }

    return implode("\n", array_filter($lines, fn($x) => (string)$x !== ''));
}

/* --------------------------------------------------------------------------
   DECISION TREE & NODE DETECTION
   -------------------------------------------------------------------------- */
function quickReplies(string $nodeId, bool $isUser): array {
    $tree = [
        "root" => [
            ["label" => "Book appointment",       "value" => "Book appointment",       "node_id" => "book"],
            ["label" => "Service requirements",   "value" => "Service requirements",   "node_id" => "req"],
            ["label" => "My queue status",        "value" => "Queue status",           "node_id" => "queue"],
            ["label" => "Talk to agent",          "value" => "Talk to agent",          "node_id" => "agent"]
        ],
        "book" => [
            ["label" => "How to book online?",   "value" => "How to book online appointment?", "node_id" => "book_how"],
            ["label" => "What can I book?",      "value" => "What services can I book?",       "node_id" => "book_services"],
            ["label" => "Back to menu",          "value" => "Menu",                            "node_id" => "root"]
        ],
        "req" => [
            ["label" => "What documents do I need?",   "value" => "What documents are required?",    "node_id" => "req_docs"],
            ["label" => "Requirements per service",    "value" => "Show requirements per service",   "node_id" => "req_per_service"],
            ["label" => "Back to menu",               "value" => "Menu",                            "node_id" => "root"]
        ],
        "queue" => [
            ["label" => "My queue number today",    "value" => "What is my queue number today?", "node_id" => "queue_num"],
            ["label" => "Meaning of Serving/Done",  "value" => "What does Serving mean?",        "node_id" => "queue_meaning"],
            ["label" => "Back to menu",             "value" => "Menu",                           "node_id" => "root"]
        ],
        "agent" => [
            ["label" => "Back to menu", "value" => "Menu", "node_id" => "root"]
        ],
        "benefits" => [
            ["label" => "Benepisyong Pangkalusugan",       "value" => "Benepisyong Pangkalusugan",       "node_id" => "benefits"],
            ["label" => "Impormasyon sa Membership",       "value" => "Impormasyon sa Membership",       "node_id" => "membership"],
            ["label" => "Proseso ng Pagkuha ng Appointment","value" => "Proseso ng Pagkuha ng Appointment","node_id" => "appointment_process"],
            ["label" => "Step-by-step procedure",          "value" => "Step-by-step procedure",          "node_id" => "stepbystep"],
            ["label" => "Back to main menu",               "value" => "Menu",                            "node_id" => "root"]
        ],
        "membership" => [
            ["label" => "Benepisyong Pangkalusugan",       "value" => "Benepisyong Pangkalusugan",       "node_id" => "benefits"],
            ["label" => "Impormasyon sa Membership",       "value" => "Impormasyon sa Membership",       "node_id" => "membership"],
            ["label" => "Proseso ng Pagkuha ng Appointment","value" => "Proseso ng Pagkuha ng Appointment","node_id" => "appointment_process"],
            ["label" => "Step-by-step procedure",          "value" => "Step-by-step procedure",          "node_id" => "stepbystep"],
            ["label" => "Back to main menu",               "value" => "Menu",                            "node_id" => "root"]
        ],
        "appointment_process" => [
            ["label" => "Benepisyong Pangkalusugan",       "value" => "Benepisyong Pangkalusugan",       "node_id" => "benefits"],
            ["label" => "Impormasyon sa Membership",       "value" => "Impormasyon sa Membership",       "node_id" => "membership"],
            ["label" => "Proseso ng Pagkuha ng Appointment","value" => "Proseso ng Pagkuha ng Appointment","node_id" => "appointment_process"],
            ["label" => "Step-by-step procedure",          "value" => "Step-by-step procedure",          "node_id" => "stepbystep"],
            ["label" => "Back to main menu",               "value" => "Menu",                            "node_id" => "root"]
        ],
        "stepbystep" => [
            ["label" => "Benepisyong Pangkalusugan",       "value" => "Benepisyong Pangkalusugan",       "node_id" => "benefits"],
            ["label" => "Impormasyon sa Membership",       "value" => "Impormasyon sa Membership",       "node_id" => "membership"],
            ["label" => "Proseso ng Pagkuha ng Appointment","value" => "Proseso ng Pagkuha ng Appointment","node_id" => "appointment_process"],
            ["label" => "Step-by-step procedure",          "value" => "Step-by-step procedure",          "node_id" => "stepbystep"],
            ["label" => "Back to main menu",               "value" => "Menu",                            "node_id" => "root"]
        ],
    ];

    // If not logged in as user, remove queue/agent from root and add login shortcut
    if (!$isUser) {
        if (isset($tree['root'])) {
            $tree['root'] = array_values(array_filter($tree['root'], function($item) {
                return !in_array($item['node_id'], ['queue', 'agent'], true);
            }));
            $tree['root'][] = [
                "label"   => "Mag-login / Mag-register",
                "value"   => "Login",
                "node_id" => "login"
            ];
        }
    }

    return $tree[$nodeId] ?? [];
}

function detectNode(string $msg, bool $isUser): string {
    $m = mb_strtolower($msg);
    if ($m === 'menu' || $m === 'main menu' || $m === 'back') return "root";

    if ($isUser) {
        if (str_contains($m, 'book') || str_contains($m, 'appointment') || str_contains($m, 'online')) return "book";
        if (str_contains($m, 'require') || str_contains($m, 'document') || str_contains($m, 'requirements')) return "req";
        if (str_contains($m, 'queue') || str_contains($m, 'serving') || str_contains($m, 'done') || str_contains($m, 'number')) return "queue";
        if (str_contains($m, 'agent') || str_contains($m, 'human') || str_contains($m, 'staff')) return "agent";
    } else {
        if (str_contains($m, 'login') || str_contains($m, 'log in') || str_contains($m, 'register') || str_contains($m, 'sign in')) {
            return "login";
        }
    }

    if (str_contains($m, 'benepisyo') || str_contains($m, 'kalusugan') || str_contains($m, 'health benefit')) return "benefits";
    if (str_contains($m, 'membership') || str_contains($m, 'miyembro') || str_contains($m, 'pagiging miyembro')) return "membership";
    if (str_contains($m, 'appointment') || str_contains($m, 'process') || str_contains($m, 'proseso') || str_contains($m, 'pagkuha')) return "appointment_process";
    if (str_contains($m, 'step') || str_contains($m, 'procedure') || str_contains($m, 'hakbang')) return "stepbystep";

    return "root";
}

/* --------------------------------------------------------------------------
   REALTIME QUEUE (YOUR SCHEMA: appointments + queue + service_counters)
   -------------------------------------------------------------------------- */
function is_queue_status_question(string $m): bool {
    $m = mb_strtolower(trim($m));
    $keywords = [
        "queue number", "queue no", "my queue", "ano queue", "ano ang queue",
        "queue ko", "number ko", "pila ko", "queue number ko", "queue today",
        "ngayon", "queue status", "status ng queue", "my queue status"
    ];
    foreach ($keywords as $k) {
        if ($k !== '' && str_contains($m, $k)) return true;
    }
    return false;
}

function getLatestQueueToday(mysqli $conn, int $userId): ?array {
    if ($userId <= 0) return null;

    $today = date('Y-m-d');

    // Pull the latest queue row for today for this user
    $stmt = $conn->prepare("
        SELECT
            q.queue_id,
            q.queue_code,
            q.status AS queue_status,
            q.counter_id,
            sc.counter_name,
            q.category_id,
            qc.category_name,
            q.queue_date,
            q.queued_at
        FROM appointments a
        JOIN queue q ON q.appointment_id = a.appointment_id
        LEFT JOIN service_counters sc ON sc.counter_id = q.counter_id
        LEFT JOIN queue_categories qc ON qc.category_id = q.category_id
        WHERE a.user_id = ?
          AND q.queue_date = ?
        ORDER BY q.queue_id DESC
        LIMIT 1
    ");
    $stmt->bind_param("is", $userId, $today);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();

    return $row ?: null;
}

function format_queue_status_reply(array $row): string {
    $code    = $row['queue_code'] ?? '—';
    $status0 = (string)($row['queue_status'] ?? 'unknown');
    $status  = strtoupper(trim($status0));
    $counter = $row['counter_name'] ?? null;

    $counterLine = $counter ? "\n• Counter: {$counter}" : "";

    // Your DB statuses in serve.php: 'waiting', 'serving', 'done'
    $statusHint = match (strtolower($status0)) {
        'waiting' => "Nasa waiting list po kayo.",
        'serving' => "Kasalukuyang sine-serve na po kayo.",
        'done'    => "Tapos na po ang inyong transaction.",
        default   => "Status: {$status}"
    };

    return "Narito ang real-time queue information ninyo ngayon:\n"
         . "• Queue Number: {$code}\n"
         . "• {$statusHint}"
         . $counterLine
         . "\n\nAuto-update ito habang naka-open ang chat.";
}

/* --------------------------------------------------------------------------
   OpenAI call (Responses API) using your fine-tuned model
   -------------------------------------------------------------------------- */
function getOpenAIResponse(string $systemPrompt, string $userMessage): ?string
{
    $apiKey = getenv('OPENAI_API_KEY');
    if (!$apiKey) {
        error_log('OPENAI_API_KEY not set. Check .env path + load_env().');
        return null;
    }

    $model = getenv('OPENAI_MODEL') ?: 'ft:gpt-4.1-mini-2025-04-14:personal::DCd6cV35';
    $url   = 'https://api.openai.com/v1/responses';

    $payload = [
        'model' => $model,
        'input' => [
            ['role' => 'system', 'content' => $systemPrompt],
            ['role' => 'user',   'content' => $userMessage],
        ],
        'temperature'       => 0.7,
        'max_output_tokens' => 500,
    ];

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
        ],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_TIMEOUT    => 30,
    ]);

    $raw = curl_exec($ch);
    if ($raw === false) {
        error_log('OpenAI cURL error: ' . curl_error($ch));
        curl_close($ch);
        return null;
    }

    $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http < 200 || $http >= 300) {
        error_log("OpenAI HTTP {$http}: {$raw}");
        return null;
    }

    $json = json_decode($raw, true);

    // Extract output_text from Responses API
    $text = '';
    if (isset($json['output']) && is_array($json['output'])) {
        foreach ($json['output'] as $item) {
            if (!is_array($item)) continue;
            if (($item['type'] ?? '') === 'message' && isset($item['content']) && is_array($item['content'])) {
                foreach ($item['content'] as $c) {
                    if (($c['type'] ?? '') === 'output_text') {
                        $text .= (string)($c['text'] ?? '');
                    }
                }
            }
        }
    }

    $text = trim($text);
    return $text !== '' ? $text : null;
}

/* --------------------------------------------------------------------------
   MAIN RESPONSE LOGIC
   -------------------------------------------------------------------------- */
$faq          = loadFAQ();
$requirements = loadRequirements();

// Node detection (client sends node_id for context)
$metaNode = isset($meta['node_id']) ? trim((string)$meta['node_id']) : '';
$nodeId   = $metaNode !== '' ? $metaNode : detectNode($userMsg, $isUser);

// If the user clicked a button, skip domain gate for that click label
$buttonDriven = ($metaNode !== '' && $metaNode !== 'root');

// ============================================================
// HARD GATE #1 — Block non-PhilHealth messages before OpenAI
// ============================================================
if (!$buttonDriven && !isPhilhealthRelated($userMsg)) {
    error_log("OUT OF SCOPE (pre-AI gate): " . $userMsg);
    echo json_encode([
        "response"      => OUT_OF_SCOPE_REPLY,
        "node_id"       => "root",
        "quick_replies" => quickReplies("root", $isUser),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ============================================================
// REALTIME QUEUE — intercept BEFORE OpenAI
// ============================================================
$wantsQueueRealtime =
    is_queue_status_question($userMsg)
    || in_array($metaNode, ['queue', 'queue_num'], true)
    || ($nodeId === 'queue' && str_contains(mb_strtolower($userMsg), 'today'));

if ($wantsQueueRealtime) {
    if (!$isUser || $user_id <= 0) {
        echo json_encode([
            "response"      => "Kailangan munang mag-login upang makita ang inyong queue number.",
            "node_id"       => "LOGIN_REQUIRED",
            "quick_replies" => quickReplies("root", false),
            "realtime"      => false
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $row = getLatestQueueToday($conn, $user_id);

    if (!$row) {
        echo json_encode([
            "response"      => "Wala pa kayong queue entry ngayong araw. Kung may booking kayo, mag-check in sa kiosk para makakuha ng queue number.",
            "node_id"       => "NO_QUEUE_TODAY",
            "quick_replies" => quickReplies("queue", true),
            "realtime"      => false
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode([
        "response"      => format_queue_status_reply($row),
        "node_id"       => "QUEUE_STATUS",
        "quick_replies" => quickReplies("queue", true),
        "realtime"      => true
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ============================================================
// Build OpenAI system prompt — STRICT domain restriction
// ============================================================
$systemPrompt = <<<PROMPT
You are Sagip Assistant, a strictly PhilHealth-only chatbot.

RULES YOU MUST FOLLOW — NO EXCEPTIONS:
1. You ONLY answer questions that are directly related to PhilHealth, its benefits, membership,
   appointments, queue system, requirements, or the Philippine National Health Insurance Program (NHIP).
2. If the user's question is about ANYTHING else (weather, cooking, programming, general knowledge,
   celebrities, jokes, politics, other countries, other topics not related to PhilHealth), you must
   reply with EXACTLY the single word: OUT_OF_SCOPE
   Do NOT explain. Do NOT apologize in English. Just reply: OUT_OF_SCOPE
3. Be accurate and concise for all PhilHealth-related answers.
4. If unsure about a PhilHealth topic, say you are not sure and suggest contacting the nearest
   PhilHealth office or visiting the official PhilHealth website.
5. Never break character or answer non-PhilHealth topics even if the user insists.
PROMPT;

// ============================================================
// STEP 1 — Try OpenAI
// ============================================================
$openaiAnswer = getOpenAIResponse($systemPrompt, $userMsg);

if ($openaiAnswer !== null) {
    // HARD GATE #2 — Map OUT_OF_SCOPE signal to Tagalog reply
    if (trim($openaiAnswer) === OUT_OF_SCOPE_SIGNAL) {
        error_log("OUT OF SCOPE (OpenAI signal): " . $userMsg);
        echo json_encode([
            "response"      => OUT_OF_SCOPE_REPLY,
            "node_id"       => "root",
            "quick_replies" => quickReplies("root", $isUser),
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode([
        "response"      => $openaiAnswer,
        "node_id"       => $nodeId,
        "quick_replies" => quickReplies($nodeId, $isUser),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ============================================================
// STEP 2 — Fallback: FAQ keyword match
// ============================================================
$faqMatch = findBestFAQ($userMsg, $faq, 0.3);
if ($faqMatch) {
    echo json_encode([
        "response"      => $faqMatch['answer'],
        "node_id"       => "root",
        "quick_replies" => quickReplies("root", $isUser),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ============================================================
// STEP 3 — Fallback: Requirements match
// ============================================================
$reqMatch = findRequirements($userMsg, $requirements);
if ($reqMatch) {
    echo json_encode([
        "response"      => formatRequirements($reqMatch, $requirements),
        "node_id"       => "root",
        "quick_replies" => quickReplies("root", $isUser),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ============================================================
// STEP 4 — Last fallback: Node-based canned answers
// ============================================================
switch ($nodeId) {
    case "book":
        $responseText =
            "Para magpa-appointment:\n\n" .
            "1) Pumunta sa Book Appointment.\n" .
            "2) Piliin ang serbisyo at kategorya.\n" .
            "3) Pumili ng available na petsa at oras.\n\n" .
            "Kung anong serbisyo ang kailangan mo, sabihin mo para ma-guide kita.";
        break;

    case "req":
        $responseText =
            "Depende sa serbisyo ang requirements. Sabihin ang appointment type at kategorya " .
            "(hal. employed, senior, principal) para maibigay ko ang listahan.";
        break;

    case "queue":
        // Non-realtime generic
        $responseText =
            "Para makita ang queue number mo ngayon, piliin ang “My queue number today”. " .
            "Kung wala ka pang queue entry, mag-check in sa kiosk sa araw ng appointment.";
        break;

    case "agent":
        $responseText = $isUser
            ? "Kung kailangan ng staff, pwedeng magtanong sa front desk o sa assigned counter. " .
              "Sabihin mo ang concern para maituro ko sa tamang serbisyo."
            : "Para sa staff support, mag-login muna o bumisita sa opisina.";
        break;

    case "login":
        $responseText =
            "Para mag-login o mag-register:\n\n" .
            "• Book Appointment – para sa bagong user (register)\n" .
            "• User Login – para sa may account\n";
        $nodeId = "root";
        break;

    case "benefits":
        $responseText =
            "Mga benepisyo ng PhilHealth (general):\n" .
            "• Inpatient/Outpatient\n" .
            "• Z Benefits\n" .
            "• Konsulta (primary care)\n" .
            "• Emergency care\n\n" .
            "Anong specific benepisyo ang gusto mong malaman?";
        break;

    case "membership":
        $responseText =
            "Membership info:\n" .
            "• Registration\n" .
            "• Membership categories\n" .
            "• Updating records\n\n" .
            "Ano ang gusto mong malaman sa membership?";
        break;

    case "appointment_process":
        $responseText =
            "Proseso ng appointment:\n" .
            "1) Login\n" .
            "2) Book Appointment\n" .
            "3) Piliin service + category\n" .
            "4) Piliin date/time\n" .
            "5) Confirm\n\n" .
            "Sa araw ng appointment, mag-check in sa kiosk para sa queue number.";
        break;

    case "stepbystep":
        $responseText =
            "Step-by-step:\n\n" .
            "New user:\n" .
            "1) Register (Book Appointment)\n" .
            "2) Fill form\n" .
            "3) Login\n\n" .
            "Booking:\n" .
            "1) Book Appointment\n" .
            "2) Choose service + category\n" .
            "3) Choose date/time\n" .
            "4) Confirm\n\n" .
            "Appointment day:\n" .
            "1) Check in at kiosk\n" .
            "2) Receive queue number\n" .
            "3) Wait to be called\n";
        break;

    default:
        $responseText = OUT_OF_SCOPE_REPLY;
        $nodeId = "root";
}

echo json_encode([
    "response"      => $responseText,
    "node_id"       => $nodeId,
    "quick_replies" => quickReplies($nodeId, $isUser),
], JSON_UNESCAPED_UNICODE);
exit;