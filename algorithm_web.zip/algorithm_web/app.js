const el = (id) => document.getElementById(id);

let steps = [];
let stepIndex = 0;
let playTimer = null;

function showError(msg){
  el("err").textContent = msg || "";
}

function parseNumbers(raw){
  const cleaned = (raw || "").trim();
  if (!cleaned) return [];
  const parts = cleaned.split(",").map(s => s.trim()).filter(Boolean);
  const nums = [];
  for (const p of parts){
    if (!/^-?\d+$/.test(p)) throw new Error(`Invalid number: "${p}"`);
    nums.push(parseInt(p, 10));
  }
  return nums;
}

function renderViz(arr){
  const viz = el("viz");
  viz.innerHTML = "";
  if (!arr || !arr.length){
    viz.textContent = "—";
    return;
  }

  // Simple bar visualization (height based on value rank)
  const max = Math.max(...arr);
  const min = Math.min(...arr);
  const span = Math.max(1, max - min);

  for (const v of arr){
    const bar = document.createElement("div");
    bar.className = "bar";
    const h = 20 + Math.round(((v - min) / span) * 80);
    bar.style.height = `${h}px`;
    const label = document.createElement("span");
    label.textContent = v;
    bar.appendChild(label);
    viz.appendChild(bar);
  }
}

function renderSteps(){
  const box = el("steps");
  box.innerHTML = "";

  const maxLines = 120; // keep UI fast
  const start = Math.max(0, steps.length - maxLines);
  const view = steps.slice(start);

  for (let i = 0; i < view.length; i++){
    const line = document.createElement("div");
    line.className = "step-line";
    line.textContent = view[i];
    box.appendChild(line);
  }
}

function setKPIs(payload){
  el("kStatus").textContent = payload?.status ?? "—";
  el("kTime").textContent = payload?.metrics?.time_ms != null ? `${payload.metrics.time_ms} ms` : "—";
  el("kCmp").textContent = payload?.metrics?.comparisons != null ? payload.metrics.comparisons : "—";
  el("kSwp").textContent = payload?.metrics?.swaps != null ? payload.metrics.swaps : "—";
}

function setResult(text){
  el("result").textContent = text || "—";
}

function showCompareTable(rows){
  const wrap = el("compareWrap");
  const mount = el("compareTable");

  if (!rows || !rows.length){
    wrap.style.display = "none";
    mount.innerHTML = "";
    return;
  }

  wrap.style.display = "";
  const html = `
    <table>
      <thead>
        <tr>
          <th>Algorithm</th>
          <th>Type</th>
          <th>Time (ms)</th>
          <th>Comparisons</th>
          <th>Swaps/Moves</th>
          <th>Result</th>
        </tr>
      </thead>
      <tbody>
        ${rows.map(r => `
          <tr>
            <td>${escapeHtml(r.name)}</td>
            <td>${escapeHtml(r.kind)}</td>
            <td>${r.metrics?.time_ms ?? "—"}</td>
            <td>${r.metrics?.comparisons ?? "—"}</td>
            <td>${r.metrics?.swaps ?? "—"}</td>
            <td>${escapeHtml(r.summary ?? "—")}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
  mount.innerHTML = html;
}

function escapeHtml(s){
  return String(s ?? "")
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#039;");
}

async function requestRun({mode}){
  showError("");
  stopPlay();

  let nums;
  try{
    nums = parseNumbers(el("numbers").value);
  }catch(e){
    showError(e.message);
    return;
  }

  const algo = el("algorithm").value;
  const targetRaw = (el("target").value || "").trim();
  const showSteps = el("showSteps").checked ? "1" : "0";

  const fd = new URLSearchParams();
  fd.set("numbers", nums.join(","));
  fd.set("algo", algo);
  fd.set("target", targetRaw);
  fd.set("want_steps", showSteps);

  const res = await fetch("algorithms.php", {
    method: "POST",
    headers: {"Content-Type": "application/x-www-form-urlencoded"},
    body: fd.toString()
  });

  const payload = await res.json().catch(() => null);
  if (!payload || payload.ok !== true){
    showError(payload?.error || "Request failed.");
    return;
  }

  // Compare mode table
  showCompareTable(payload.compare_rows || null);

  // Standard output
  el("algoInfo").textContent = payload.algorithm_label || "—";
  setKPIs(payload);
  setResult(payload.summary || "—");

  steps = payload.steps || [];
  stepIndex = 0;
  el("stepInfo").textContent = steps.length ? `Steps: ${steps.length}` : "Steps: —";
  renderSteps();

  // Visualization: start state from first step snapshot if provided
  if (payload.viz && Array.isArray(payload.viz.current)){
    renderViz(payload.viz.current);
  } else {
    renderViz(nums);
  }

  // Auto-run (Run button) shows final state
  if (mode === "run"){
    if (payload.viz && Array.isArray(payload.viz.final)){
      renderViz(payload.viz.final);
    }
  }
}

function stepForward(){
  if (!steps.length) return;
  const box = el("steps");
  const idx = stepIndex;
  stepIndex = Math.min(steps.length, stepIndex + 1);

  // Show only last N already; just re-render
  renderSteps();

  // Update visualization if step contains a snapshot marker: "STATE: [..]"
  const line = steps[idx];
  const match = line && line.startsWith("STATE:");
  if (match){
    const arrStr = line.replace("STATE:", "").trim();
    try{
      const arr = JSON.parse(arrStr);
      if (Array.isArray(arr)) renderViz(arr);
    }catch(_){}
  }

  el("stepInfo").textContent = `Steps: ${steps.length} | At: ${stepIndex}/${steps.length}`;
  if (stepIndex >= steps.length) stopPlay();
}

function play(){
  stopPlay();
  playTimer = setInterval(() => stepForward(), 260);
}

function stopPlay(){
  if (playTimer){
    clearInterval(playTimer);
    playTimer = null;
  }
}

function generate(type){
  const size = Math.max(3, Math.min(500, parseInt(el("size").value || "12", 10)));
  const range = Math.max(10, Math.min(10000, parseInt(el("range").value || "50", 10)));

  let arr = [];
  for (let i = 0; i < size; i++){
    arr.push(1 + Math.floor(Math.random() * range));
  }

  if (type === "sorted"){
    arr.sort((a,b)=>a-b);
  } else if (type === "reverse"){
    arr.sort((a,b)=>b-a);
  }

  el("numbers").value = arr.join(",");
  // pick target automatically (use an element that exists)
  el("target").value = arr[Math.floor(arr.length/2)];
  renderViz(arr);
  showError("");
}

function clearAll(){
  el("numbers").value = "";
  el("target").value = "";
  steps = [];
  stepIndex = 0;
  stopPlay();
  renderViz([]);
  setKPIs(null);
  setResult("—");
  el("algoInfo").textContent = "—";
  el("stepInfo").textContent = "—";
  showCompareTable(null);
  showError("");
  el("steps").innerHTML = "";
}

// Wire up UI
el("btnRun").addEventListener("click", () => requestRun({mode:"run"}));
el("btnStep").addEventListener("click", () => stepForward());
el("btnPlay").addEventListener("click", () => play());
el("btnStop").addEventListener("click", () => stopPlay());
el("btnClear").addEventListener("click", () => clearAll());

document.querySelectorAll("[data-gen]").forEach(btn => {
  btn.addEventListener("click", () => generate(btn.getAttribute("data-gen")));
});

// Initial state
generate("random");