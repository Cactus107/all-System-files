<?php
header('Content-Type: application/json; charset=utf-8');

function fail(string $msg, int $http=200): void {
  http_response_code($http);
  echo json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
  exit;
}

function parse_numbers(string $raw): array {
  $raw = trim($raw);
  if ($raw === '') return [];
  $parts = array_filter(array_map('trim', explode(',', $raw)), fn($x) => $x !== '');
  $nums = [];
  foreach ($parts as $p) {
    if (!preg_match('/^-?\d+$/', $p)) fail('Invalid number: ' . $p);
    $nums[] = (int)$p;
  }
  return $nums;
}

function is_sorted_asc(array $a): bool {
  $n = count($a);
  for ($i=1; $i<$n; $i++){
    if ($a[$i] < $a[$i-1]) return false;
  }
  return true;
}

function ms_now(): float { return microtime(true); }
function ms_diff(float $start): int { return (int)round((microtime(true) - $start) * 1000); }

function push_step(array &$steps, bool $want, string $line): void {
  if (!$want) return;
  $steps[] = $line;
}

function push_state(array &$steps, bool $want, array $arr): void {
  if (!$want) return;
  // JSON so frontend can parse it
  $steps[] = 'STATE: ' . json_encode(array_values($arr));
}

/** Bubble Sort with step tracing */
function bubble_sort(array $arr, bool $want_steps): array {
  $steps = [];
  $cmp = 0; $swp = 0;
  $n = count($arr);
  push_step($steps, $want_steps, "Bubble Sort started. n={$n}");
  push_state($steps, $want_steps, $arr);

  for ($i=0; $i<$n; $i++){
    $didSwap = false;
    push_step($steps, $want_steps, "Pass " . ($i+1));
    for ($j=0; $j<$n-1-$i; $j++){
      $cmp++;
      if ($arr[$j] > $arr[$j+1]){
        $tmp = $arr[$j]; $arr[$j] = $arr[$j+1]; $arr[$j+1] = $tmp;
        $swp++;
        $didSwap = true;
        push_step($steps, $want_steps, "Swap index {$j} and " . ($j+1));
        push_state($steps, $want_steps, $arr);
      }
    }
    if (!$didSwap){
      push_step($steps, $want_steps, "No swaps in this pass. Array is sorted early.");
      break;
    }
  }

  return [
    'final' => $arr,
    'steps' => $steps,
    'metrics' => ['comparisons' => $cmp, 'swaps' => $swp],
  ];
}

/** Merge Sort with step tracing (counts comparisons and "moves") */
function merge_sort(array $arr, bool $want_steps): array {
  $steps = [];
  $cmp = 0; $mov = 0;

  push_step($steps, $want_steps, "Merge Sort started. n=" . count($arr));
  push_state($steps, $want_steps, $arr);

  $sort = function($a) use (&$sort, &$steps, $want_steps, &$cmp, &$mov) {
    $n = count($a);
    if ($n <= 1) return $a;

    $mid = intdiv($n, 2);
    $left = array_slice($a, 0, $mid);
    $right = array_slice($a, $mid);

    $left = $sort($left);
    $right = $sort($right);

    $i=0; $j=0; $out=[];
    while ($i < count($left) && $j < count($right)){
      $cmp++;
      if ($left[$i] <= $right[$j]){
        $out[] = $left[$i++]; $mov++;
      } else {
        $out[] = $right[$j++]; $mov++;
      }
    }
    while ($i < count($left)){ $out[] = $left[$i++]; $mov++; }
    while ($j < count($right)){ $out[] = $right[$j++]; $mov++; }

    push_step($steps, $want_steps, "Merged: " . json_encode($out));
    return $out;
  };

  $final = $sort($arr);
  push_step($steps, $want_steps, "Merge Sort completed.");
  push_state($steps, $want_steps, $final);

  return [
    'final' => $final,
    'steps' => $steps,
    'metrics' => ['comparisons' => $cmp, 'swaps' => $mov], // using moves as "swaps/moves"
  ];
}

/** Linear Search with step tracing */
function linear_search(array $arr, int $target, bool $want_steps): array {
  $steps = [];
  $cmp = 0;
  push_step($steps, $want_steps, "Linear Search started. target={$target}");
  push_state($steps, $want_steps, $arr);

  foreach ($arr as $i => $v){
    $cmp++;
    push_step($steps, $want_steps, "Check index {$i}: value={$v}");
    if ($v === $target){
      push_step($steps, $want_steps, "Found at index {$i}");
      return [
        'found' => true,
        'index' => $i,
        'steps' => $steps,
        'metrics' => ['comparisons' => $cmp, 'swaps' => 0],
      ];
    }
  }
  push_step($steps, $want_steps, "Not found");
  return [
    'found' => false,
    'index' => -1,
    'steps' => $steps,
    'metrics' => ['comparisons' => $cmp, 'swaps' => 0],
  ];
}

/** Binary Search with step tracing (requires sorted asc) */
function binary_search(array $arr, int $target, bool $want_steps): array {
  $steps = [];
  $cmp = 0;
  push_step($steps, $want_steps, "Binary Search started. target={$target}");
  push_state($steps, $want_steps, $arr);

  $low = 0;
  $high = count($arr) - 1;

  while ($low <= $high){
    $mid = intdiv($low + $high, 2);
    $cmp++;
    $midVal = $arr[$mid];
    push_step($steps, $want_steps, "low={$low}, high={$high}, mid={$mid}, midVal={$midVal}");

    if ($midVal === $target){
      push_step($steps, $want_steps, "Found at index {$mid}");
      return [
        'found' => true,
        'index' => $mid,
        'steps' => $steps,
        'metrics' => ['comparisons' => $cmp, 'swaps' => 0],
      ];
    }
    if ($target < $midVal){
      $high = $mid - 1;
    } else {
      $low = $mid + 1;
    }
  }

  push_step($steps, $want_steps, "Not found");
  return [
    'found' => false,
    'index' => -1,
    'steps' => $steps,
    'metrics' => ['comparisons' => $cmp, 'swaps' => 0],
  ];
}

/* -------------------- Controller -------------------- */

$numbers_raw = (string)($_POST['numbers'] ?? '');
$algo = trim((string)($_POST['algo'] ?? 'bubble'));
$target_raw = trim((string)($_POST['target'] ?? ''));
$want_steps = ((string)($_POST['want_steps'] ?? '1') === '1');

$nums = parse_numbers($numbers_raw);
if (count($nums) < 1) fail('Please input at least 1 number.');

if (count($nums) > 500) fail('Max 500 numbers allowed (performance limit).');

$start = ms_now();

$response = [
  'ok' => true,
  'algorithm_label' => '',
  'status' => 'OK',
  'summary' => '',
  'metrics' => ['time_ms' => 0, 'comparisons' => 0, 'swaps' => 0],
  'steps' => [],
  'viz' => ['current' => $nums, 'final' => $nums],
  'compare_rows' => null,
];

if ($algo === 'bubble'){
  $response['algorithm_label'] = 'Bubble Sort';
  $r = bubble_sort($nums, $want_steps);
  $response['viz']['final'] = $r['final'];
  $response['steps'] = $r['steps'];
  $response['metrics']['comparisons'] = $r['metrics']['comparisons'];
  $response['metrics']['swaps'] = $r['metrics']['swaps'];
  $response['summary'] = 'Sorted: ' . implode(', ', $r['final']);
}
elseif ($algo === 'merge'){
  $response['algorithm_label'] = 'Merge Sort';
  $r = merge_sort($nums, $want_steps);
  $response['viz']['final'] = $r['final'];
  $response['steps'] = $r['steps'];
  $response['metrics']['comparisons'] = $r['metrics']['comparisons'];
  $response['metrics']['swaps'] = $r['metrics']['swaps'];
  $response['summary'] = 'Sorted: ' . implode(', ', $r['final']);
}
elseif ($algo === 'linear'){
  if ($target_raw === '' || !preg_match('/^-?\d+$/', $target_raw)) fail('Please enter a valid target number for searching.');
  $target = (int)$target_raw;

  $response['algorithm_label'] = 'Linear Search';
  $r = linear_search($nums, $target, $want_steps);
  $response['steps'] = $r['steps'];
  $response['metrics']['comparisons'] = $r['metrics']['comparisons'];
  $response['metrics']['swaps'] = $r['metrics']['swaps'];
  $response['summary'] = $r['found']
    ? "Found target {$target} at index {$r['index']}."
    : "Target {$target} not found.";
}
elseif ($algo === 'binary'){
  if ($target_raw === '' || !preg_match('/^-?\d+$/', $target_raw)) fail('Please enter a valid target number for searching.');
  if (!is_sorted_asc($nums)) fail('Binary Search requires a sorted (ascending) array. Use Generate Sorted or sort first.');
  $target = (int)$target_raw;

  $response['algorithm_label'] = 'Binary Search';
  $r = binary_search($nums, $target, $want_steps);
  $response['steps'] = $r['steps'];
  $response['metrics']['comparisons'] = $r['metrics']['comparisons'];
  $response['metrics']['swaps'] = $r['metrics']['swaps'];
  $response['summary'] = $r['found']
    ? "Found target {$target} at index {$r['index']}."
    : "Target {$target} not found.";
}
elseif ($algo === 'compare'){
  // Compare mode: run sorting algorithms on the same input; searching on same input (linear) and on sorted input (binary)
  $rows = [];

  // Bubble
  $t0 = ms_now();
  $b = bubble_sort($nums, false);
  $rows[] = [
    'name' => 'Bubble Sort',
    'kind' => 'Sorting',
    'metrics' => ['time_ms' => ms_diff($t0), 'comparisons' => $b['metrics']['comparisons'], 'swaps' => $b['metrics']['swaps']],
    'summary' => 'Sorted output'
  ];

  // Merge
  $t1 = ms_now();
  $m = merge_sort($nums, false);
  $rows[] = [
    'name' => 'Merge Sort',
    'kind' => 'Sorting',
    'metrics' => ['time_ms' => ms_diff($t1), 'comparisons' => $m['metrics']['comparisons'], 'swaps' => $m['metrics']['swaps']],
    'summary' => 'Sorted output'
  ];

  // Searching: only if target exists
  if ($target_raw !== '' && preg_match('/^-?\d+$/', $target_raw)){
    $target = (int)$target_raw;

    $t2 = ms_now();
    $ls = linear_search($nums, $target, false);
    $rows[] = [
      'name' => 'Linear Search',
      'kind' => 'Searching',
      'metrics' => ['time_ms' => ms_diff($t2), 'comparisons' => $ls['metrics']['comparisons'], 'swaps' => 0],
      'summary' => $ls['found'] ? "Found at index {$ls['index']}" : 'Not found'
    ];

    // Binary uses sorted input
    $sorted = $m['final']; // merge output is sorted
    $t3 = ms_now();
    $bs = binary_search($sorted, $target, false);
    $rows[] = [
      'name' => 'Binary Search',
      'kind' => 'Searching',
      'metrics' => ['time_ms' => ms_diff($t3), 'comparisons' => $bs['metrics']['comparisons'], 'swaps' => 0],
      'summary' => $bs['found'] ? "Found at index {$bs['index']} (sorted array)" : 'Not found'
    ];
  } else {
    $rows[] = [
      'name' => 'Searching',
      'kind' => 'Note',
      'metrics' => ['time_ms' => '—', 'comparisons' => '—', 'swaps' => '—'],
      'summary' => 'Enter a target to include search comparisons.'
    ];
  }

  $response['algorithm_label'] = 'Compare All';
  $response['compare_rows'] = $rows;
  $response['summary'] = 'Comparison completed. See the table below.';
  $response['steps'] = $want_steps ? ["Compare mode does not produce step-by-step output. Select a single algorithm to view steps."] : [];
}
else{
  fail('Unknown algorithm selected.');
}

$response['metrics']['time_ms'] = ms_diff($start);

echo json_encode($response, JSON_UNESCAPED_UNICODE);