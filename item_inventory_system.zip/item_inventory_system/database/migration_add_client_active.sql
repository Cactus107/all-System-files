-- Migration script to add is_active column to clients table
-- Run this if you have existing data and need to update the schema

ALTER TABLE clients ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER email;

-- Update any existing clients to be active
UPDATE clients SET is_active = 1 WHERE is_active IS NULL;