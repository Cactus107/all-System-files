CREATE DATABASE IF NOT EXISTS item_inventory_system CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE item_inventory_system;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS clients;
DROP TABLE IF EXISTS items;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    username VARCHAR(60) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin','staff') NOT NULL DEFAULT 'staff',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255) DEFAULT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    item_code VARCHAR(60) NOT NULL UNIQUE,
    serial_barcode VARCHAR(120) DEFAULT NULL UNIQUE,
    item_name VARCHAR(150) NOT NULL,
    category_id INT NOT NULL,
    quantity_stock INT NOT NULL DEFAULT 0,
    quantity_borrowed INT NOT NULL DEFAULT 0,
    reorder_level INT NOT NULL DEFAULT 5,
    item_status ENUM('available','low_stock','out_of_stock','inactive') NOT NULL DEFAULT 'available',
    location VARCHAR(120) DEFAULT NULL,
    notes TEXT DEFAULT NULL,
    created_by INT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_items_category FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_items_user FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE clients (
    client_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    address TEXT DEFAULT NULL,
    contact_no VARCHAR(50) DEFAULT NULL,
    email VARCHAR(120) DEFAULT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_type ENUM('borrow','return') NOT NULL,
    item_id INT NOT NULL,
    client_id INT DEFAULT NULL,
    staff_id INT NOT NULL,
    quantity INT NOT NULL,
    item_status_details VARCHAR(255) DEFAULT NULL,
    remarks TEXT DEFAULT NULL,
    transacted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_tx_item FOREIGN KEY (item_id) REFERENCES items(item_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_tx_client FOREIGN KEY (client_id) REFERENCES clients(client_id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_tx_staff FOREIGN KEY (staff_id) REFERENCES users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(80) NOT NULL,
    record_id INT DEFAULT NULL,
    details TEXT DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT INTO categories (category_name, description) VALUES
('Electronics', 'Electronic devices and accessories'),
('Furniture', 'Office and room furniture'),
('Office Supplies', 'Daily office supplies'),
('Tools', 'Maintenance and utility tools');

-- Default admin account
-- Username: admin
-- Password: admin123
INSERT INTO users (full_name, username, password_hash, role, is_active)
VALUES (
    'System Administrator',
    'admin',
    '$2y$10$kM/KnSP5.6gwz8Nsl5l9HeB7lPz5mrgm4Nt8yqK1M0t6TQ4dK8R3S',
    'admin',
    1
);
