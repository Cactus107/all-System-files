<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/csrf.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare('SELECT user_id, full_name, username, password_hash, role, is_active FROM users WHERE username = ? LIMIT 1');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        $error = 'Invalid username or password.';
    } elseif ((int) $user['is_active'] !== 1) {
        $error = 'Your account is inactive. Please contact the administrator.';
    } else {
        $_SESSION['user_id']   = (int) $user['user_id'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['username']  = $user['username'];
        $_SESSION['role']      = $user['role'];

        if ($user['role'] === 'admin') {
            redirect('/item_inventory_system/admin/dashboard.php');
        }
        redirect('/item_inventory_system/staff/dashboard.php');
    }
}
require_once __DIR__ . '/../includes/header.php';
?>
<style>
    .login-wrap {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 2rem 1rem;
        background: linear-gradient(135deg, #f0f4ff 0%, #f8fafc 50%, #f0f9ff 100%);
        transition: background 0.3s ease;
    }
    [data-theme="dark"] .login-wrap {
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%);
    }
    .login-card {
        width: 100%;
        max-width: 420px;
        background: var(--surface);
        border-radius: 20px;
        border: 1px solid var(--border);
        box-shadow: var(--shadow-lg);
        padding: 2.5rem 2rem;
        transition: background-color 0.3s ease, border-color 0.3s ease;
    }
    .login-logo {
        width: 48px; height: 48px;
        background: var(--ink);
        border-radius: 12px;
        display: flex; align-items: center; justify-content: center;
        margin: 0 auto 1.5rem;
        transition: background-color 0.3s ease;
    }
    .login-logo svg { color: #fff; }
    .login-title {
        text-align: center;
        font-size: 1.5rem;
        font-weight: 700;
        letter-spacing: -.025em;
        margin-bottom: .375rem;
        color: var(--ink);
    }
    .login-sub {
        text-align: center;
        color: var(--ink-faint);
        font-size: 14px;
        margin-bottom: 2rem;
    }
    .form-label {
        display: block;
        font-size: 13px;
        font-weight: 600;
        margin-bottom: .5rem;
        color: var(--ink-soft);
    }
    .form-group { margin-bottom: 1.125rem; }
    .demo-box {
        margin-top: 1.5rem;
        background: var(--surface-2);
        border: 1px solid var(--border);
        border-radius: 12px;
        padding: 1rem 1.125rem;
        font-size: 13px;
        color: var(--ink-soft);
        transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease;
    }
    .demo-box strong { color: var(--ink); font-weight: 600; }
    .demo-title { font-weight: 700; color: var(--ink); margin-bottom: .5rem; font-size: 12px; text-transform: uppercase; letter-spacing: .05em; }

    /* Responsive adjustments */
    @media (max-width: 480px) {
        .login-wrap {
            padding: 1rem;
        }
        .login-card {
            padding: 2rem 1.5rem;
            border-radius: 16px;
        }
        .login-title {
            font-size: 1.375rem;
        }
        .login-logo {
            width: 44px;
            height: 44px;
            margin-bottom: 1.25rem;
        }
    }
</style>

<div class="login-wrap">
    <div class="login-card">
        <div class="login-logo">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
                <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
            </svg>
        </div>
        <h1 class="login-title">Sign In</h1>
        <p class="login-sub">Access the inventory management system.</p>

        <form method="POST" id="loginForm">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="form-label" for="username">Username</label>
                <input class="form-input" id="username" type="text" name="username" required
                       value="<?php echo old('username'); ?>" autocomplete="username" placeholder="Enter username">
            </div>
            <div class="form-group">
                <label class="form-label" for="password">Password</label>
                <input class="form-input" id="password" type="password" name="password" required
                       autocomplete="current-password" placeholder="Enter password">
            </div>
            <button class="btn btn-primary" type="submit" style="width:100%;margin-top:.375rem;padding:.875rem;">
                Sign In
            </button>
        </form>

        <p style="text-align:center;margin-top:1.25rem;font-size:13px;color:var(--ink-soft);">
            No account yet? <a href="register.php" style="font-weight:600;color:var(--ink);text-decoration:none;">Create one here</a>
        </p>

        <div class="demo-box">
            <div class="demo-title">Default Administrator</div>
            <div>Username: <strong>admin</strong></div>
            <div style="margin-top:.25rem;">Password: <strong>admin123</strong></div>
        </div>
    </div>
</div>

<?php if ($error): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    showAlert('error', 'Login Failed', <?php echo json_encode($error); ?>);
});
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>