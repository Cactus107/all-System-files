<?php
session_start();
session_unset();
session_destroy();
header('Location: /item_inventory_system/auth/login.php');
exit();