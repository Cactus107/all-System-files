<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/csrf.php';

$error   = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $fullName = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if ($fullName === '' || $username === '' || $password === '' || $confirm === '') {
        $error = 'All fields are required.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        $stmt = $conn->prepare('SELECT user_id FROM users WHERE username = ? LIMIT 1');
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $exists = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($exists) {
            $error = 'Username already exists.';
        } else {
            $hash   = password_hash($password, PASSWORD_DEFAULT);
            $role   = 'staff';
            $active = 1;

            $stmt = $conn->prepare('INSERT INTO users (full_name, username, password_hash, role, is_active) VALUES (?, ?, ?, ?, ?)');
            $stmt->bind_param('ssssi', $fullName, $username, $hash, $role, $active);
            $stmt->execute();
            $newId = $stmt->insert_id;
            $stmt->close();

            log_action($conn, $newId, 'Create staff account', 'users', $newId, 'Staff registered: ' . $username);
            $success = 'Staff account created successfully. You can now sign in.';
        }
    }
}
require_once __DIR__ . '/../includes/header.php';
?>
<style>
    .register-wrap {
        min-height: 100vh;
        display: flex; align-items: center; justify-content: center;
        padding: 2rem 1rem;
        background: linear-gradient(135deg, #f0f4ff 0%, #f8fafc 50%, #f0f9ff 100%);
    }
    .register-card {
        width: 100%; max-width: 480px;
        background: var(--surface);
        border-radius: 20px;
        border: 1px solid var(--border);
        box-shadow: var(--shadow-lg);
        padding: 2.5rem 2rem;
    }
    .form-label {
        display: block; font-size: 13px; font-weight: 600;
        margin-bottom: .5rem; color: var(--ink-soft);
    }
    .form-group { margin-bottom: 1.125rem; }
    .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
    @media (max-width: 480px) { .form-grid { grid-template-columns: 1fr; } }
</style>

<div class="register-wrap">
    <div class="register-card">
        <h1 style="font-size:1.5rem;font-weight:700;letter-spacing:-.025em;margin-bottom:.375rem;">Staff Registration</h1>
        <p style="color:var(--ink-faint);font-size:14px;margin-bottom:2rem;">Create a staff account for the inventory system.</p>

        <form method="POST" class="form-grid">
            <?php echo csrf_field(); ?>
            <div class="form-group" style="grid-column:1/-1">
                <label class="form-label" for="full_name">Full Name</label>
                <input class="form-input" id="full_name" type="text" name="full_name" required
                       value="<?php echo old('full_name'); ?>" placeholder="Your full name">
            </div>
            <div class="form-group" style="grid-column:1/-1">
                <label class="form-label" for="reg_username">Username</label>
                <input class="form-input" id="reg_username" type="text" name="username" required
                       value="<?php echo old('username'); ?>" placeholder="Choose a username">
            </div>
            <div class="form-group">
                <label class="form-label" for="reg_password">Password</label>
                <input class="form-input" id="reg_password" type="password" name="password" required placeholder="Min. 6 characters">
            </div>
            <div class="form-group">
                <label class="form-label" for="reg_confirm">Confirm Password</label>
                <input class="form-input" id="reg_confirm" type="password" name="confirm_password" required placeholder="Repeat password">
            </div>
            <div style="grid-column:1/-1;margin-top:.375rem;">
                <button class="btn btn-primary" type="submit" style="width:100%;padding:.875rem;">
                    Create Staff Account
                </button>
            </div>
        </form>

        <p style="text-align:center;margin-top:1.25rem;font-size:13px;color:var(--ink-soft);">
            Already have an account? <a href="login.php" style="font-weight:600;color:var(--ink);text-decoration:none;">Sign in</a>
        </p>
    </div>
</div>

<?php if ($error): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    showAlert('error', 'Registration Failed', <?php echo json_encode($error); ?>);
});
</script>
<?php endif; ?>

<?php if ($success): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    showAlert('success', 'Account Created', <?php echo json_encode($success); ?>, function() {
        window.location.href = 'login.php';
    });
});
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>