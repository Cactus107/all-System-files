        </main>
    </div>
</div>

<footer class="text-center py-6 text-xs text-[var(--ink-faint)] bg-[var(--surface-2)]">
    Item Inventory System &mdash; <?php echo date('Y'); ?>
</footer>

</div>
<script>
function openSidebar() {
    document.getElementById('appSidebar')?.classList.remove('-translate-x-full');
    document.getElementById('sidebarBackdrop')?.classList.remove('hidden');
    document.body.classList.add('overflow-hidden');
}
function closeSidebar() {
    document.getElementById('appSidebar')?.classList.add('-translate-x-full');
    document.getElementById('sidebarBackdrop')?.classList.add('hidden');
    document.body.classList.remove('overflow-hidden');
}
window.addEventListener('resize', function () {
    if (window.innerWidth >= 1024) {
        document.getElementById('sidebarBackdrop')?.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    }
});
</script>
</body>
</html>
