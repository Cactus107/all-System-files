<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Item Inventory System</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script>
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" referrerpolicy="no-referrer" />

    <script>
        tailwind.config = {
            darkMode: ['class', '[data-theme="dark"]'],
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['DM Sans', 'sans-serif'],
                        mono: ['DM Mono', 'monospace']
                    },
                    boxShadow: {
                        soft: '0 10px 30px rgba(15, 23, 42, .08), 0 2px 8px rgba(15, 23, 42, .04)',
                        softlg: '0 24px 48px rgba(15, 23, 42, .14)'
                    }
                }
            }
        };
    </script>

    <style>
        :root {
            --ink: #0f172a;
            --ink-soft: #475569;
            --ink-faint: #64748b;
            --surface: #ffffff;
            --surface-2: #f8fafc;
            --surface-3: #e2e8f0;
            --border: #e2e8f0;
            --border-strong: #cbd5e1;
            --accent: #2563eb;
            --accent-hover: #1d4ed8;
            --accent-soft: #eff6ff;
            --success: #059669;
            --success-soft: #ecfdf5;
            --success-border: #a7f3d0;
            --warning: #d97706;
            --warning-soft: #fffbeb;
            --warning-border: #fde68a;
            --danger: #dc2626;
            --danger-soft: #fef2f2;
            --danger-border: #fecaca;
            --radius: 12px;
            --radius-lg: 18px;
            --shadow-sm: 0 1px 2px rgba(15, 23, 42, .06), 0 1px 1px rgba(15, 23, 42, .04);
            --shadow: 0 10px 30px rgba(15, 23, 42, .08), 0 2px 8px rgba(15, 23, 42, .04);
            --shadow-lg: 0 24px 48px rgba(15, 23, 42, .14);
            --shadow-xl: 0 28px 60px rgba(15, 23, 42, .18);
        }
        [data-theme="dark"] {
            --ink: #f8fafc;
            --ink-soft: #cbd5e1;
            --ink-faint: #94a3b8;
            --surface: #0f172a;
            --surface-2: #111827;
            --surface-3: #1f2937;
            --border: #243041;
            --border-strong: #334155;
            --accent: #3b82f6;
            --accent-hover: #60a5fa;
            --accent-soft: #172554;
            --success: #10b981;
            --success-soft: #052e2b;
            --success-border: #065f46;
            --warning: #f59e0b;
            --warning-soft: #3b2a08;
            --warning-border: #92400e;
            --danger: #ef4444;
            --danger-soft: #3f1113;
            --danger-border: #7f1d1d;
            --shadow-sm: 0 1px 2px rgba(0,0,0,.24);
            --shadow: 0 10px 30px rgba(0,0,0,.28);
            --shadow-lg: 0 24px 48px rgba(0,0,0,.34);
            --shadow-xl: 0 28px 60px rgba(0,0,0,.42);
        }
        * { box-sizing: border-box; }
        html, body {
            margin: 0;
            padding: 0;
            min-height: 100%;
            font-family: 'DM Sans', sans-serif;
            background: var(--surface-2);
            color: var(--ink);
            font-size: 14px;
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
            transition: background-color .25s ease, color .25s ease;
        }
        body { min-height: 100vh; overflow-x: hidden; }
        .card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            transition: background-color .25s ease, border-color .25s ease, box-shadow .25s ease;
        }
        .stat-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            padding: 1.25rem 1.25rem;
            transition: .2s ease;
        }
        .stat-card:hover { transform: translateY(-2px); box-shadow: var(--shadow); }
        .stat-label { font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: var(--ink-faint); }
        .stat-value { font-size: clamp(1.5rem, 2.2vw, 1.9rem); font-weight: 700; line-height: 1.1; margin-top: .35rem; color: var(--ink); }
        .page-header { margin-bottom: 1.5rem; }
        .page-title { margin: 0; font-size: clamp(1.35rem, 2.4vw, 1.8rem); font-weight: 700; letter-spacing: -.02em; color: var(--ink); }
        .page-subtitle { margin-top: .25rem; color: var(--ink-faint); font-size: 14px; }
        .form-input, .form-select, .form-textarea {
            width: 100%; min-width: 0; background: var(--surface); color: var(--ink);
            border: 1.5px solid var(--border); border-radius: var(--radius); padding: .75rem .95rem; font: inherit; transition: .18s ease;
        }
        .form-input:focus, .form-select:focus, .form-textarea:focus { outline: none; border-color: var(--accent); box-shadow: 0 0 0 3px rgba(37, 99, 235, .12); }
        .btn {
            display: inline-flex; align-items: center; justify-content: center; gap: .5rem;
            border: none; border-radius: var(--radius); padding: .72rem 1rem; font: inherit; font-weight: 600; text-decoration: none;
            cursor: pointer; white-space: nowrap; transition: .18s ease;
        }
        .btn:active { transform: scale(.98); }
        .btn-primary { background: var(--ink); color: var(--surface); }
        .btn-primary:hover { opacity: .92; }
        .btn-accent { background: var(--accent); color: #fff; }
        .btn-accent:hover { background: var(--accent-hover); }
        .btn-success { background: var(--success); color: #fff; }
        .btn-warning { background: var(--warning); color: #fff; }
        .btn-danger  { background: var(--danger); color: #fff; }
        .btn-ghost { background: transparent; color: var(--ink-soft); border: 1.5px solid var(--border); }
        .btn-ghost:hover { background: var(--surface-2); color: var(--ink); }
        .btn-sm { padding: .48rem .8rem; font-size: 13px; border-radius: 10px; }
        .badge { display: inline-flex; align-items: center; gap: .35rem; padding: .22rem .65rem; border-radius: 999px; font-size: 12px; font-weight: 700; line-height: 1.2; }
        .status-available    { background: var(--success-soft); color: var(--success); border: 1px solid var(--success-border); }
        .status-low_stock    { background: var(--warning-soft); color: var(--warning); border: 1px solid var(--warning-border); }
        .status-out_of_stock { background: var(--danger-soft); color: var(--danger); border: 1px solid var(--danger-border); }
        .status-active       { background: var(--success-soft); color: var(--success); border: 1px solid var(--success-border); }
        .status-inactive     { background: var(--surface-3); color: var(--ink-soft); border: 1px solid var(--border); }
        .table-wrap { overflow-x: auto; -webkit-overflow-scrolling: touch; }
        table { width: 100%; border-collapse: collapse; min-width: 720px; }
        thead th { text-align: left; padding: .8rem 1rem .8rem 0; font-size: 12px; text-transform: uppercase; letter-spacing: .05em; color: var(--ink-faint); border-bottom: 1px solid var(--border); white-space: nowrap; }
        tbody td { padding: .9rem 1rem .9rem 0; border-bottom: 1px solid var(--border); vertical-align: middle; }
        tbody tr:last-child td { border-bottom: none; }
        .mono { font-family: 'DM Mono', monospace; }
        .text-muted { color: var(--ink-faint); }
        .no-image-placeholder { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background: var(--surface-3); color: var(--ink-faint); font-size: 12px; font-weight: 600; }
        .modal-overlay {
            position: fixed; inset: 0; background: rgba(15, 23, 42, .58); backdrop-filter: blur(4px); -webkit-backdrop-filter: blur(4px);
            z-index: 1000; display: flex; align-items: center; justify-content: center; padding: 1rem; opacity: 0; pointer-events: none; transition: opacity .2s ease;
        }
        .modal-overlay.is-open { opacity: 1; pointer-events: auto; }
        .modal-box {
            width: 100%; max-width: 480px; max-height: calc(100vh - 2rem); overflow-y: auto; background: var(--surface);
            border: 1px solid var(--border); border-radius: var(--radius-lg); box-shadow: var(--shadow-xl); padding: 1.5rem;
            transform: translateY(14px) scale(.98); transition: transform .2s ease, background-color .25s ease;
        }
        .modal-overlay.is-open .modal-box { transform: translateY(0) scale(1); }
        .modal-box-sm { max-width: 380px; }
        .modal-box-lg { max-width: 760px; }
        .alert-icon { width: 52px; height: 52px; margin: 0 auto 1rem; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 22px; }
        .alert-icon-success { background: var(--success-soft); color: var(--success); }
        .alert-icon-danger  { background: var(--danger-soft); color: var(--danger); }
        .alert-icon-warning { background: var(--warning-soft); color: var(--warning); }
        .alert-icon-info    { background: var(--accent-soft); color: var(--accent); }
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-thumb { background: var(--border-strong); border-radius: 999px; }
        @media (max-width: 1024px) {
            .page-header[style*="display:flex"] { align-items: stretch !important; }
        }
        @media (max-width: 768px) {
            .modal-box { padding: 1rem; width: calc(100vw - 1rem); }
            .btn, button.btn, a.btn { width: auto; max-width: 100%; }
            table { min-width: 640px; }
        }
    </style>
</head>
<body>
<div id="appShell" class="min-h-screen bg-[var(--surface-2)] text-[var(--ink)]">
<div id="alertModal" class="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="alertModalTitle">
    <div class="modal-box modal-box-sm text-center">
        <div class="alert-icon" id="alertIcon"><i class="fa-solid fa-circle-info"></i></div>
        <h3 id="alertModalTitle" style="font-size:1.1rem;font-weight:700;margin-bottom:.5rem;"></h3>
        <p id="alertModalMessage" style="color:var(--ink-soft);font-size:14px;line-height:1.6;margin-bottom:1.25rem;"></p>
        <button onclick="closeAlertModal()" class="btn btn-primary w-full">OK</button>
    </div>
</div>
<div id="confirmModal" class="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="confirmModalTitle">
    <div class="modal-box modal-box-sm text-center">
        <div class="alert-icon alert-icon-warning" id="confirmIcon"><i class="fa-solid fa-triangle-exclamation"></i></div>
        <h3 id="confirmModalTitle" style="font-size:1.1rem;font-weight:700;margin-bottom:.5rem;"></h3>
        <p id="confirmModalMessage" style="color:var(--ink-soft);font-size:14px;line-height:1.6;margin-bottom:1.25rem;"></p>
        <div class="flex gap-3">
            <button onclick="closeConfirmModal(false)" class="btn btn-ghost flex-1">Cancel</button>
            <button id="confirmOkBtn" onclick="closeConfirmModal(true)" class="btn btn-danger flex-1">Confirm</button>
        </div>
    </div>
</div>
<script>
function showAlert(type, title, message, onClose) {
    const modal = document.getElementById('alertModal');
    const icon = document.getElementById('alertIcon');
    const titleEl = document.getElementById('alertModalTitle');
    const msgEl = document.getElementById('alertModalMessage');
    const configs = {
        success: { cls: 'alert-icon-success', html: '<i class="fa-solid fa-circle-check"></i>' },
        error:   { cls: 'alert-icon-danger',  html: '<i class="fa-solid fa-circle-xmark"></i>' },
        warning: { cls: 'alert-icon-warning', html: '<i class="fa-solid fa-triangle-exclamation"></i>' },
        info:    { cls: 'alert-icon-info',    html: '<i class="fa-solid fa-circle-info"></i>' }
    };
    const cfg = configs[type] || configs.info;
    icon.className = 'alert-icon ' + cfg.cls;
    icon.innerHTML = cfg.html;
    titleEl.innerHTML = title;
    msgEl.textContent = message;
    modal._onClose = onClose || null;
    modal.classList.add('is-open');
}
function closeAlertModal() {
    const modal = document.getElementById('alertModal');
    modal.classList.remove('is-open');
    if (typeof modal._onClose === 'function') modal._onClose();
}
let _confirmResolve = null;
function showConfirm(title, message, confirmLabel, type) {
    return new Promise(resolve => {
        _confirmResolve = resolve;
        document.getElementById('confirmModalTitle').textContent = title;
        document.getElementById('confirmModalMessage').textContent = message;
        const btn = document.getElementById('confirmOkBtn');
        btn.textContent = confirmLabel || 'Confirm';
        btn.className = 'btn flex-1 ' + (type === 'danger' ? 'btn-danger' : type === 'success' ? 'btn-success' : type === 'warning' ? 'btn-warning' : 'btn-accent');
        document.getElementById('confirmModal').classList.add('is-open');
    });
}
function closeConfirmModal(confirmed) {
    document.getElementById('confirmModal').classList.remove('is-open');
    if (_confirmResolve) {
        _confirmResolve(confirmed);
        _confirmResolve = null;
    }
}
document.addEventListener('click', function(e) {
    if (e.target.id === 'alertModal') closeAlertModal();
    if (e.target.id === 'confirmModal') closeConfirmModal(false);
});
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('form[data-confirm]').forEach(form => {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            const msg = form.getAttribute('data-confirm') || 'Are you sure?';
            const title = form.getAttribute('data-confirm-title') || 'Confirm Action';
            const label = form.getAttribute('data-confirm-label') || 'Confirm';
            const type = form.getAttribute('data-confirm-type') || 'danger';
            const ok = await showConfirm(title, msg, label, type);
            if (ok) form.submit();
        });
    });
});
function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
}
function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme') || 'light';
    applyTheme(current === 'dark' ? 'light' : 'dark');
}
document.addEventListener('DOMContentLoaded', function() {
    applyTheme(localStorage.getItem('theme') || 'light');
});
</script>
