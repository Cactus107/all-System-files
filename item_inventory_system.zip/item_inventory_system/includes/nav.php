<?php
$role = $_SESSION['role'] ?? '';
$currentPath = $_SERVER['REQUEST_URI'] ?? '';

function nav_active(string $path): string {
    global $currentPath;
    return strpos($currentPath, $path) !== false
        ? 'bg-[var(--accent-soft)] text-[var(--accent)] font-semibold border border-[var(--border)] shadow-sm'
        : 'text-[var(--ink-soft)] hover:bg-[var(--surface-2)] hover:text-[var(--ink)]';
}
?>

<div class="min-h-screen lg:flex">
    <div id="sidebarBackdrop" class="fixed inset-0 z-30 hidden bg-slate-900/50 lg:hidden" onclick="closeSidebar()"></div>

    <aside id="appSidebar" class="fixed inset-y-0 left-0 z-40 flex w-[280px] max-w-[85vw] -translate-x-full flex-col border-r border-[var(--border)] bg-[var(--surface)] shadow-xl transition-transform duration-200 lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 lg:shadow-none">
        <div class="flex h-16 items-center justify-between border-b border-[var(--border)] px-5">
            <a href="/item_inventory_system/<?php echo $role === 'admin' ? 'admin' : 'staff'; ?>/dashboard.php" class="flex items-center gap-3 no-underline text-[var(--ink)]">
                <span class="flex h-10 w-10 items-center justify-center rounded-2xl bg-[var(--accent-soft)] text-[var(--accent)]">
                    <i class="fa-solid fa-boxes-stacked"></i>
                </span>
                <div class="min-w-0">
                    <div class="truncate text-sm font-bold sm:text-base">Inventory System</div>
                    <div class="text-xs text-[var(--ink-faint)]">Management Panel</div>
                </div>
            </a>
            <button type="button" class="btn btn-ghost btn-sm lg:hidden" onclick="closeSidebar()"><i class="fa-solid fa-xmark"></i></button>
        </div>

        <div class="flex-1 overflow-y-auto p-4">
            <div class="space-y-1.5">
                <?php if ($role === 'admin'): ?>
                    <a class="flex items-center gap-3 rounded-xl px-3 py-3 <?php echo nav_active('admin/dashboard'); ?>" href="/item_inventory_system/admin/dashboard.php"><i class="fa-solid fa-gauge min-w-[20px] text-center"></i><span>Dashboard</span></a>
                    <a class="flex items-center gap-3 rounded-xl px-3 py-3 <?php echo nav_active('admin/staff'); ?>" href="/item_inventory_system/admin/staff.php"><i class="fa-solid fa-users min-w-[20px] text-center"></i><span>Staff</span></a>
                    <a class="flex items-center gap-3 rounded-xl px-3 py-3 <?php echo nav_active('admin/logs'); ?>" href="/item_inventory_system/admin/logs.php"><i class="fa-solid fa-shield-halved min-w-[20px] text-center"></i><span>Logs</span></a>
                <?php endif; ?>

                <?php if ($role === 'staff'): ?>
                    <a class="flex items-center gap-3 rounded-xl px-3 py-3 <?php echo nav_active('staff/dashboard'); ?>" href="/item_inventory_system/staff/dashboard.php"><i class="fa-solid fa-gauge min-w-[20px] text-center"></i><span>Dashboard</span></a>
                    <a class="flex items-center gap-3 rounded-xl px-3 py-3 <?php echo nav_active('staff/categories'); ?>" href="/item_inventory_system/staff/categories.php"><i class="fa-solid fa-tags min-w-[20px] text-center"></i><span>Categories</span></a>
                    <a class="flex items-center gap-3 rounded-xl px-3 py-3 <?php echo nav_active('staff/items'); ?>" href="/item_inventory_system/staff/items.php"><i class="fa-solid fa-cubes min-w-[20px] text-center"></i><span>Items</span></a>
                    <a class="flex items-center gap-3 rounded-xl px-3 py-3 <?php echo nav_active('staff/clients'); ?>" href="/item_inventory_system/staff/clients.php"><i class="fa-solid fa-address-book min-w-[20px] text-center"></i><span>Clients</span></a>
                    <a class="flex items-center gap-3 rounded-xl px-3 py-3 <?php echo nav_active('staff/history'); ?>" href="/item_inventory_system/staff/history.php"><i class="fa-solid fa-arrow-right min-w-[20px] text-center"></i><span>Borrow</span></a>
                    <a class="flex items-center gap-3 rounded-xl px-3 py-3 <?php echo nav_active('staff/returns'); ?>" href="/item_inventory_system/staff/returns.php"><i class="fa-solid fa-rotate-left min-w-[20px] text-center"></i><span>Returns</span></a>
                <?php endif; ?>
            </div>
        </div>

        <div class="border-t border-[var(--border)] p-4">
            <div class="rounded-2xl border border-[var(--border)] bg-[var(--surface-2)] p-3">
                <div class="flex items-center gap-2">
                    <i class="fa-solid fa-circle-user text-[var(--ink-soft)]"></i>
                    <div class="min-w-0 truncate text-sm font-semibold text-[var(--ink)]"><?php echo htmlspecialchars($_SESSION['full_name'] ?? '', ENT_QUOTES, 'UTF-8'); ?></div>
                </div>
                <div class="ml-6 mt-1 text-[10px] font-bold uppercase tracking-[0.18em] text-[var(--ink-faint)]"><i class="fa-solid fa-id-badge mr-1"></i><?php echo htmlspecialchars($role ?: 'user', ENT_QUOTES, 'UTF-8'); ?></div>
                <div class="mt-3 grid grid-cols-2 gap-2">
                    <button type="button" onclick="toggleTheme()" class="btn btn-ghost btn-sm w-full"><i class="fa-solid fa-circle-half-stroke"></i>Theme</button>
                    <a href="/item_inventory_system/auth/logout.php" class="btn btn-danger btn-sm w-full"><i class="fa-solid fa-right-from-bracket"></i>Logout</a>
                </div>
            </div>
        </div>
    </aside>

    <div class="min-w-0 flex-1">
        <header class="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-[var(--border)] bg-[var(--surface)]/95 px-4 backdrop-blur lg:hidden">
            <button type="button" onclick="openSidebar()" class="btn btn-ghost btn-sm"><i class="fa-solid fa-bars"></i>Menu</button>
            <div class="truncate text-sm font-bold text-[var(--ink)] sm:text-base">Inventory System</div>
            <button type="button" onclick="toggleTheme()" class="btn btn-ghost btn-sm"><i class="fa-solid fa-circle-half-stroke"></i></button>
        </header>
        <main class="p-4 sm:p-6 lg:p-8">
