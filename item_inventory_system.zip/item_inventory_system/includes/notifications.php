<?php
if (session_status() === PHP_SESSION_NONE) session_start();

$flash_success = $_SESSION['flash']['success'] ?? '';
$flash_error   = $_SESSION['flash']['error']   ?? '';
$flash_info    = $_SESSION['flash']['info']    ?? '';

unset(
    $_SESSION['flash']['success'],
    $_SESSION['flash']['error'],
    $_SESSION['flash']['info'],
    $_SESSION['flash']['modal']
);
?>

<?php if ($flash_success || $flash_error || $flash_info): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    <?php if ($flash_success): ?>
        showAlert('success', '<i class="fa-solid fa-circle-check"></i> Success', <?php echo json_encode($flash_success); ?>);
    <?php elseif ($flash_error): ?>
        showAlert('error', '<i class="fa-solid fa-circle-xmark"></i> Error', <?php echo json_encode($flash_error); ?>);
    <?php elseif ($flash_info): ?>
        showAlert('info', '<i class="fa-solid fa-circle-info"></i> Notice', <?php echo json_encode($flash_info); ?>);
    <?php endif; ?>
});
</script>
<?php endif; ?>
