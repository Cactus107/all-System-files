<?php
session_start();
if (!empty($_SESSION['user_id'])) {
    if (($_SESSION['role'] ?? '') === 'admin') {
        header('Location: /item_inventory_system/admin/dashboard.php');
        exit();
    }
    header('Location: /item_inventory_system/staff/dashboard.php');
    exit();
}
header('Location: /item_inventory_system/auth/login.php');
exit();
