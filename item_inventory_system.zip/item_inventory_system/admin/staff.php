<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/csrf.php';
require_role(['admin']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $userId   = (int) ($_POST['user_id'] ?? 0);
    $isActive = (int) ($_POST['is_active'] ?? 0);

    $stmt = $conn->prepare("UPDATE users SET is_active = ? WHERE user_id = ? AND role='staff'");
    $stmt->bind_param('ii', $isActive, $userId);
    $stmt->execute();
    $stmt->close();

    log_action($conn, (int) $_SESSION['user_id'], 'Update staff status', 'users', $userId, 'Changed active status to ' . $isActive);
    set_flash('success', 'Staff account status updated successfully.');
    redirect('/item_inventory_system/admin/staff.php');
}

$staff = $conn->query("SELECT * FROM users WHERE role='staff' ORDER BY user_id DESC");

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/nav.php';
require_once __DIR__ . '/../includes/notifications.php';
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
    .page-title i { margin-right: 10px; color: var(--accent); }
    .table-wrap th i { margin-right: 5px; opacity: 0.7; font-size: 12px; }
    .btn i { margin-right: 5px; }
    .status-pill { display: inline-flex; align-items: center; gap: 5px; }
</style>

<div style="max-width:1280px;margin:0 auto;padding:2rem 1.5rem;">
    <div class="page-header">
        <h1 class="page-title"><i class="fa fa-users"></i> Staff Management</h1>
        <p class="page-subtitle">Activate or deactivate staff access to the system.</p>
    </div>

    <div class="card" style="padding:1.5rem;">
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th><i class="fa fa-hashtag"></i> ID</th>
                        <th><i class="fa fa-user"></i> Full Name</th>
                        <th><i class="fa fa-id-badge"></i> Username</th>
                        <th><i class="fa fa-calendar"></i> Created</th>
                        <th><i class="fa fa-toggle-on"></i> Status</th>
                        <th><i class="fa fa-cog"></i> Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($staff && $staff->num_rows > 0): ?>
                        <?php while ($row = $staff->fetch_assoc()): 
                            $isActive = (int) $row['is_active'] === 1;
                        ?>
                        <tr>
                            <td class="mono" style="font-size:12px;color:var(--ink-faint);">#<?php echo (int) $row['user_id']; ?></td>
                            <td style="font-weight:500;"><?php echo e($row['full_name']); ?></td>
                            <td class="mono" style="font-size:13px;">
                                <i class="fa fa-at" style="font-size:10px; opacity:0.5;"></i> <?php echo e($row['username']); ?>
                            </td>
                            <td style="font-size:13px;color:var(--ink-soft);white-space:nowrap;">
                                <?php echo date('M j, Y', strtotime($row['created_at'])); ?>
                            </td>
                            <td>
                                <span class="badge <?php echo $isActive ? 'status-active' : 'status-inactive'; ?> status-pill">
                                    <i class="fa <?php echo $isActive ? 'fa-check-circle' : 'fa-times-circle'; ?>"></i>
                                    <?php echo $isActive ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td>
                                <form method="POST" 
                                      data-confirm="<?php echo $isActive 
                                          ? 'This will prevent ' . htmlspecialchars($row['full_name'], ENT_QUOTES, 'UTF-8') . ' from logging in.' 
                                          : 'This will restore login access for ' . htmlspecialchars($row['full_name'], ENT_QUOTES, 'UTF-8') . '.'; ?>"
                                      data-confirm-title="<?php echo $isActive ? 'Deactivate Staff?' : 'Activate Staff?'; ?>"
                                      data-confirm-label="<?php echo $isActive ? 'Deactivate' : 'Activate'; ?>"
                                      data-confirm-type="<?php echo $isActive ? 'danger' : 'success'; ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="user_id" value="<?php echo (int) $row['user_id']; ?>">
                                    <input type="hidden" name="is_active" value="<?php echo $isActive ? 0 : 1; ?>">
                                    <button type="submit" class="btn btn-sm <?php echo $isActive ? 'btn-danger' : 'btn-success'; ?>">
                                        <?php if ($isActive): ?>
                                            <i class="fa fa-user-times"></i> Deactivate
                                        <?php else: ?>
                                            <i class="fa fa-user-plus"></i> Activate
                                        <?php endif; ?>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="empty-state" style="text-align:center; padding:3rem; color:var(--ink-faint);">
                                <i class="fa fa-user-secret" style="font-size:2rem; display:block; margin-bottom:1rem;"></i>
                                No staff accounts found in the system.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>