<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/helpers.php';
require_role(['admin']);

$q    = trim($_GET['q'] ?? '');
$sql  = "SELECT a.*, u.full_name FROM audit_logs a JOIN users u ON u.user_id = a.user_id";
$params = []; $types = '';
if ($q !== '') {
    $sql .= " WHERE u.full_name LIKE ? OR a.action LIKE ? OR a.table_name LIKE ? OR a.details LIKE ?";
    $like = '%' . $q . '%';
    $params = [$like, $like, $like, $like];
    $types  = 'ssss';
}
$sql .= " ORDER BY a.log_id DESC LIMIT 300";
$stmt = $conn->prepare($sql);
if ($types !== '') $stmt->bind_param($types, ...$params);
$stmt->execute();
$rows = $stmt->get_result();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/nav.php';
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
    .action-badge {
        display: inline-block; padding: .15rem .55rem; border-radius: 6px;
        font-size: 11px; font-weight: 600; font-family: 'DM Mono', monospace;
        background: var(--accent-soft); color: var(--accent);
    }
    .search-bar {
        display: grid; grid-template-columns: 1fr auto; gap: .75rem; align-items: center;
    }
    .page-title i { margin-right: 10px; color: var(--accent); }
    .form-group-icon { position: relative; }
    .form-group-icon i { 
        position: absolute; left: 12px; top: 50%; transform: translateY(-50%); 
        color: var(--ink-faint); 
    }
    .form-group-icon .form-input { padding-left: 35px; }
    
    @media (max-width: 480px) { .search-bar { grid-template-columns: 1fr; } }
</style>

<div style="max-width:1280px;margin:0 auto;padding:2rem 1.5rem;">
    <div class="page-header">
        <h1 class="page-title"><i class="fa fa-shield"></i> Audit Logs</h1>
        <p class="page-subtitle">Search and review all system activity and historical changes.</p>
    </div>

    <div class="card" style="padding:1.25rem 1.5rem;margin-bottom:1.5rem;">
        <form class="search-bar" method="GET">
            <div class="form-group-icon">
                <i class="fa fa-search"></i>
                <input class="form-input" type="text" name="q" placeholder="Search user, action, table, or details…" value="<?php echo e($q); ?>">
            </div>
            <button class="btn btn-primary" type="submit">
                <i class="fa fa-filter"></i> Search
            </button>
        </form>
    </div>

    <div class="card" style="padding:1.5rem;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem;">
            <div style="font-size:13px;color:var(--ink-soft);">
                <?php if ($q): ?>
                    <i class="fa fa-info-circle"></i> Showing results for "<strong><?php echo e($q); ?></strong>"
                <?php else: ?>
                    <i class="fa fa-list"></i> Showing latest 300 activities
                <?php endif; ?>
            </div>
            <div style="font-size:12px; color:var(--ink-faint);">
                <i class="fa fa-refresh"></i> Live View
            </div>
        </div>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th><i class="fa fa-calendar"></i> Date</th>
                        <th><i class="fa fa-user"></i> User</th>
                        <th><i class="fa fa-bolt"></i> Action</th>
                        <th><i class="fa fa-table"></i> Table</th>
                        <th><i class="fa fa-hashtag"></i> ID</th>
                        <th><i class="fa fa-file-text-o"></i> Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($rows->num_rows > 0): ?>
                        <?php while ($row = $rows->fetch_assoc()): ?>
                        <tr>
                            <td class="mono" style="font-size:12px;white-space:nowrap;color:var(--ink-soft);">
                                <?php echo e($row['created_at']); ?>
                            </td>
                            <td style="font-weight:500;">
                                <?php echo e($row['full_name']); ?>
                            </td>
                            <td>
                                <span class="action-badge">
                                    <?php 
                                        // Optional: Add small icons inside badges based on action type
                                        $icon = 'fa-cog';
                                        if(stripos($row['action'], 'create') !== false) $icon = 'fa-plus';
                                        if(stripos($row['action'], 'update') !== false) $icon = 'fa-pencil';
                                        if(stripos($row['action'], 'delete') !== false) $icon = 'fa-trash';
                                    ?>
                                    <i class="fa <?php echo $icon; ?>" style="font-size:9px; margin-right:3px;"></i>
                                    <?php echo e($row['action']); ?>
                                </span>
                            </td>
                            <td style="color:var(--ink-soft); font-size:13px;">
                                <i class="fa fa-database" style="font-size:10px; opacity:0.5;"></i> <?php echo e($row['table_name']); ?>
                            </td>
                            <td class="mono" style="font-size:12px;color:var(--ink-faint);">
                                <?php echo e((string) $row['record_id']); ?>
                            </td>
                            <td style="color:var(--ink-soft);max-width:280px;font-size:13px;">
                                <?php echo e($row['details']); ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="empty-state" style="text-align:center; padding:3rem; color:var(--ink-faint);">
                                <i class="fa fa-search-minus" style="font-size:2rem; display:block; margin-bottom:1rem;"></i>
                                No logs found matching your criteria.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>