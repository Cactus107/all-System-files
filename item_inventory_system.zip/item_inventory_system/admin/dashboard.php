<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/helpers.php';
require_role(['admin']);

/* -----------------------------
   Core counts
----------------------------- */
$totalStaff = (int)($conn->query("
    SELECT COUNT(*) AS c
    FROM users
    WHERE role = 'staff'
")->fetch_assoc()['c'] ?? 0);

$activeStaff = (int)($conn->query("
    SELECT COUNT(*) AS c
    FROM users
    WHERE role = 'staff' AND is_active = 1
")->fetch_assoc()['c'] ?? 0);

$inactiveStaff = max(0, $totalStaff - $activeStaff);

$totalItems = (int)($conn->query("
    SELECT COUNT(*) AS c
    FROM items
    WHERE COALESCE(is_archived, 0) = 0
")->fetch_assoc()['c'] ?? 0);

$archivedItems = (int)($conn->query("
    SELECT COUNT(*) AS c
    FROM items
    WHERE COALESCE(is_archived, 0) = 1
")->fetch_assoc()['c'] ?? 0);

$lowStock = (int)($conn->query("
    SELECT COUNT(*) AS c
    FROM items
    WHERE COALESCE(is_archived, 0) = 0
      AND quantity_stock > 0
      AND quantity_stock <= 5
")->fetch_assoc()['c'] ?? 0);

$outOfStock = (int)($conn->query("
    SELECT COUNT(*) AS c
    FROM items
    WHERE COALESCE(is_archived, 0) = 0
      AND quantity_stock <= 0
")->fetch_assoc()['c'] ?? 0);

$totalClients = (int)($conn->query("
    SELECT COUNT(*) AS c
    FROM clients
    WHERE COALESCE(is_active, 1) = 1
")->fetch_assoc()['c'] ?? 0);

$archivedClients = (int)($conn->query("
    SELECT COUNT(*) AS c
    FROM clients
    WHERE COALESCE(is_active, 1) = 0
")->fetch_assoc()['c'] ?? 0);

$totalCategories = (int)($conn->query("
    SELECT COUNT(*) AS c
    FROM categories
    WHERE COALESCE(is_active, 1) = 1
")->fetch_assoc()['c'] ?? 0);

$totalTx = (int)($conn->query("
    SELECT COUNT(*) AS c
    FROM transactions
")->fetch_assoc()['c'] ?? 0);

$totalBorrows = (int)($conn->query("
    SELECT COUNT(*) AS c
    FROM transactions
    WHERE transaction_type = 'borrow'
")->fetch_assoc()['c'] ?? 0);

$totalReturns = (int)($conn->query("
    SELECT COUNT(*) AS c
    FROM transactions
    WHERE transaction_type = 'return'
")->fetch_assoc()['c'] ?? 0);

$todayBorrows = (int)($conn->query("
    SELECT COUNT(*) AS c
    FROM transactions
    WHERE transaction_type = 'borrow'
      AND DATE(transacted_at) = CURDATE()
")->fetch_assoc()['c'] ?? 0);

$todayReturns = (int)($conn->query("
    SELECT COUNT(*) AS c
    FROM transactions
    WHERE transaction_type = 'return'
      AND DATE(transacted_at) = CURDATE()
")->fetch_assoc()['c'] ?? 0);

$itemsStillOut = (int)($conn->query("
    SELECT COALESCE(SUM(quantity_borrowed), 0) AS total
    FROM items
    WHERE COALESCE(is_archived, 0) = 0
")->fetch_assoc()['total'] ?? 0);

/* -----------------------------
   14-day chart
----------------------------- */
$chartMap = [];
$chartRes = $conn->query("
    SELECT
        DATE(transacted_at) AS d,
        SUM(CASE WHEN transaction_type = 'borrow' THEN quantity ELSE 0 END) AS b,
        SUM(CASE WHEN transaction_type = 'return' THEN quantity ELSE 0 END) AS r
    FROM transactions
    WHERE transacted_at >= DATE_SUB(CURDATE(), INTERVAL 13 DAY)
    GROUP BY DATE(transacted_at)
    ORDER BY DATE(transacted_at) ASC
");
while ($row = $chartRes->fetch_assoc()) {
    $chartMap[$row['d']] = [
        'borrow' => (int)$row['b'],
        'return' => (int)$row['r']
    ];
}

$chartLabels = [];
$chartBorrow = [];
$chartReturn = [];
for ($i = 13; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-{$i} days"));
    $chartLabels[] = date('M j', strtotime($date));
    $chartBorrow[] = $chartMap[$date]['borrow'] ?? 0;
    $chartReturn[] = $chartMap[$date]['return'] ?? 0;
}

/* -----------------------------
   Data Lists (Top Items, Staff, etc)
----------------------------- */
$topItems = $conn->query("
    SELECT i.item_name, i.item_code, cat.category_name, SUM(t.quantity) AS total_borrowed, i.quantity_stock
    FROM transactions t
    JOIN items i ON i.item_id = t.item_id
    JOIN categories cat ON cat.category_id = i.category_id
    WHERE t.transaction_type = 'borrow' AND COALESCE(i.is_archived, 0) = 0
    GROUP BY t.item_id, i.item_name, i.item_code, cat.category_name, i.quantity_stock
    ORDER BY total_borrowed DESC LIMIT 5
");

$topStaff = $conn->query("
    SELECT u.full_name, u.username, u.is_active, COUNT(t.transaction_id) AS tx_count,
           SUM(CASE WHEN t.transaction_type = 'borrow' THEN 1 ELSE 0 END) AS borrows,
           SUM(CASE WHEN t.transaction_type = 'return' THEN 1 ELSE 0 END) AS returns
    FROM users u
    LEFT JOIN transactions t ON t.staff_id = u.user_id
    WHERE u.role = 'staff'
    GROUP BY u.user_id, u.full_name, u.username, u.is_active
    ORDER BY tx_count DESC LIMIT 5
");

$alertItems = $conn->query("
    SELECT i.item_name, i.item_code, i.quantity_stock, cat.category_name,
           CASE WHEN i.quantity_stock <= 0 THEN 'out_of_stock' ELSE 'low_stock' END AS item_status
    FROM items i
    JOIN categories cat ON cat.category_id = i.category_id
    WHERE COALESCE(i.is_archived, 0) = 0 AND i.quantity_stock <= 5
    ORDER BY i.quantity_stock ASC LIMIT 10
");

$outstandingClients = $conn->query("
    SELECT c.full_name, c.contact_no, COUNT(DISTINCT t.item_id) AS distinct_items,
           SUM(CASE WHEN t.transaction_type = 'borrow' THEN t.quantity WHEN t.transaction_type = 'return' THEN -t.quantity ELSE 0 END) AS net_outstanding
    FROM transactions t
    JOIN clients c ON c.client_id = t.client_id
    GROUP BY t.client_id, c.full_name, c.contact_no
    HAVING net_outstanding > 0
    ORDER BY net_outstanding DESC LIMIT 8
");

$recentLogs = $conn->query("
    SELECT a.*, u.full_name FROM audit_logs a
    JOIN users u ON u.user_id = a.user_id
    ORDER BY a.log_id DESC LIMIT 8
");

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/nav.php';
require_once __DIR__ . '/../includes/notifications.php';
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
    .dash-wrap { max-width: 1280px; margin: 0 auto; padding: 2rem 1.5rem; }
    .grid-2, .grid-3 { display: grid; grid-template-columns: 1fr; gap: 1.25rem; }
    .kpi-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(155px, 1fr)); gap: .9rem; margin-bottom: 1.75rem; }
    .section-title { font-size: .82rem; font-weight: 700; letter-spacing: .06em; text-transform: uppercase; color: var(--ink-faint); margin-bottom: 1rem; display: flex; align-items: center; gap: 8px; }
    .section-title i { color: var(--accent); font-size: 14px; }
    .action-badge { display: inline-block; padding: .15rem .55rem; border-radius: 6px; font-size: 11px; font-weight: 600; font-family: 'DM Mono', monospace; background: var(--accent-soft); color: var(--accent); }
    .alert-row { display: flex; align-items: center; justify-content: space-between; gap: .75rem; padding: .7rem 0; border-bottom: 1px solid var(--border); }
    .alert-row:last-child { border-bottom: none; }
    .quick-btn { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: .5rem; padding: 1.1rem .75rem; border-radius: var(--radius-lg); border: 1.5px solid var(--border); background: var(--surface); cursor: pointer; text-decoration: none; transition: all .15s; color: var(--ink); text-align: center; box-shadow: var(--shadow-sm); }
    .quick-btn:hover { box-shadow: var(--shadow); transform: translateY(-2px); border-color: var(--border-strong); }
    .quick-btn-icon { width: 42px; height: 42px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 18px; }
    .quick-btn span { font-size: 12px; font-weight: 600; line-height: 1.3; }
    .prog-bar-bg { background: var(--surface-3); border-radius: 999px; height: 6px; overflow: hidden; }
    .prog-bar-fill { height: 100%; border-radius: 999px; transition: width .4s ease; }
    .pill { display: inline-flex; align-items: center; gap: .375rem; padding: .25rem .75rem; border-radius: 999px; font-size: 12px; font-weight: 600; }
    .scroll-table { overflow-x: auto; }
    .empty-state { text-align: center; padding: 2rem 0; color: var(--ink-faint); }
    @media (min-width: 900px) { .grid-2 { grid-template-columns: 1fr 1fr; } .grid-3 { grid-template-columns: 1fr 1fr 1fr; } }
</style>

<div class="dash-wrap">
    <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem;">
        <div>
            <h1 class="page-title"><i class="fa fa-th-large"></i> Admin Dashboard</h1>
            <p class="page-subtitle">System overview for staff, inventory, and activity.</p>
        </div>
        <div style="text-align:right;">
            <div style="font-size:14px;font-weight:600;color:var(--ink);"><i class="fa fa-calendar-o"></i> <?php echo date('l'); ?></div>
            <div style="font-size:13px;color:var(--ink-faint);"><?php echo date('F j, Y'); ?></div>
        </div>
    </div>

    <div class="kpi-grid">
        <?php
        $kpiIcons = [
            'Total Staff' => 'fa-users', 'Active Staff' => 'fa-user-circle', 'Inactive Staff' => 'fa-user-times',
            'Total Items' => 'fa-archive', 'Archived Items' => 'fa-file-archive-o', 'Items Out' => 'fa-external-link',
            'Low Stock' => 'fa-level-down', 'Out of Stock' => 'fa-exclamation-triangle', 'Active Clients' => 'fa-address-book-o',
            'Archived Clients' => 'fa-folder-o', 'Categories' => 'fa-tags', 'Transactions' => 'fa-exchange'
        ];
        $kpis = [
            ['Total Staff', $totalStaff], ['Active Staff', $activeStaff], ['Inactive Staff', $inactiveStaff],
            ['Total Items', $totalItems], ['Archived Items', $archivedItems], ['Items Out', $itemsStillOut],
            ['Low Stock', $lowStock], ['Out of Stock', $outOfStock], ['Active Clients', $totalClients],
            ['Archived Clients', $archivedClients], ['Categories', $totalCategories], ['Transactions', $totalTx],
        ];
        foreach ($kpis as $k):
            $icon = $kpiIcons[$k[0]] ?? 'fa-circle-o';
        ?>
            <div class="stat-card">
                <div class="stat-label"><i class="fa <?php echo $icon; ?>" style="opacity:0.6;"></i> <?php echo e($k[0]); ?></div>
                <div class="stat-value" style="font-size:1.75rem;"><?php echo (int)$k[1]; ?></div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="grid-3" style="margin-bottom:1.75rem;">
        <div class="card" style="padding:1.375rem 1.5rem;">
            <div class="section-title"><i class="fa fa-history"></i> Today's Activity</div>
            <div style="display:flex;flex-direction:column;gap:.9rem;">
                <div style="display:flex;align-items:center;justify-content:space-between;">
                    <div><div style="font-size:13px;font-weight:600;">Borrows</div><div style="font-size:12px;color:var(--ink-faint);">Today</div></div>
                    <div style="font-size:1.5rem;font-weight:700;color:var(--danger);"><?php echo $todayBorrows; ?></div>
                </div>
                <div style="display:flex;align-items:center;justify-content:space-between;">
                    <div><div style="font-size:13px;font-weight:600;">Returns</div><div style="font-size:12px;color:var(--ink-faint);">Today</div></div>
                    <div style="font-size:1.5rem;font-weight:700;color:var(--success);"><?php echo $todayReturns; ?></div>
                </div>
                <div style="display:flex;align-items:center;justify-content:space-between; border-top:1px solid var(--border); padding-top:10px;">
                    <div style="font-size:12px;font-weight:600;">All-time Borrows</div>
                    <div style="font-size:1.2rem;font-weight:700;color:var(--ink-soft);"><?php echo $totalBorrows; ?></div>
                </div>
            </div>
        </div>

        <div class="card" style="padding:1.375rem 1.5rem;">
            <div class="section-title"><i class="fa fa-heartbeat"></i> Staff Health</div>
            <div style="margin-bottom:1.25rem;">
                <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:.5rem;">
                    <span style="font-size:13px;font-weight:600;">Active Status</span>
                    <span style="font-size:13px;color:var(--ink-soft);"><?php echo $activeStaff; ?> / <?php echo $totalStaff; ?></span>
                </div>
                <div class="prog-bar-bg">
                    <div class="prog-bar-fill" style="width:<?php echo $totalStaff > 0 ? round($activeStaff / $totalStaff * 100) : 0; ?>%;background:var(--success);"></div>
                </div>
            </div>
            <div style="border-top:1px solid var(--border);padding-top:1rem;display:flex;justify-content:space-between;align-items:center;">
                <span class="pill" style="background:var(--success-soft);color:var(--success);"><i class="fa fa-check"></i> Healthy</span>
                <a href="/item_inventory_system/admin/staff.php" style="font-size:12px;font-weight:600;color:var(--accent);text-decoration:none;">Manage <i class="fa fa-angle-right"></i></a>
            </div>
        </div>

        <div class="card" style="padding:1.375rem 1.5rem;">
            <div class="section-title"><i class="fa fa-flash"></i> Quick Actions</div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:.625rem;">
                <a href="/item_inventory_system/admin/staff.php" class="quick-btn">
                    <div class="quick-btn-icon" style="background:var(--accent-soft); color:var(--accent);"><i class="fa fa-vcard-o"></i></div>
                    <span>Staff</span>
                </a>
                <a href="/item_inventory_system/admin/logs.php" class="quick-btn">
                    <div class="quick-btn-icon" style="background:var(--accent-soft); color:var(--accent);"><i class="fa fa-list-alt"></i></div>
                    <span>Logs</span>
                </a>
                <a href="/item_inventory_system/staff/items.php" class="quick-btn">
                    <div class="quick-btn-icon" style="background:var(--warning-soft); color:var(--warning);"><i class="fa fa-cubes"></i></div>
                    <span>Items</span>
                </a>
                <a href="/item_inventory_system/staff/clients.php" class="quick-btn">
                    <div class="quick-btn-icon" style="background:var(--success-soft); color:var(--success);"><i class="fa fa-address-book"></i></div>
                    <span>Clients</span>
                </a>
                <a href="/item_inventory_system/staff/history.php" class="quick-btn">
                    <div class="quick-btn-icon" style="background:var(--danger-soft); color:var(--danger);"><i class="fa fa-sign-out"></i></div>
                    <span>Borrows</span>
                </a>
                <a href="/item_inventory_system/staff/returns.php" class="quick-btn">
                    <div class="quick-btn-icon" style="background:var(--success-soft); color:var(--success);"><i class="fa fa-sign-in"></i></div>
                    <span>Returns</span>
                </a>
            </div>
        </div>
    </div>

    <div class="grid-2" style="margin-bottom:1.75rem;">
        <div class="card" style="padding:1.5rem;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;">
                <div class="section-title" style="margin:0;"><i class="fa fa-line-chart"></i> Activity Trends</div>
                <div style="display:flex;gap:.875rem;font-size:12px;">
                    <span style="color:var(--ink-soft);"><i class="fa fa-square" style="color:var(--danger);"></i> Borrow</span>
                    <span style="color:var(--ink-soft);"><i class="fa fa-square" style="color:var(--success);"></i> Return</span>
                </div>
            </div>
            <canvas id="txChart" height="190"></canvas>
        </div>

        <div class="card" style="padding:1.5rem;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;">
                <div class="section-title" style="margin:0;"><i class="fa fa-bell-o"></i> Inventory Alerts</div>
                <span class="pill" style="background:var(--danger-soft);color:var(--danger);">
                    <i class="fa fa-exclamation-circle"></i> <?php echo $lowStock + $outOfStock; ?> issues
                </span>
            </div>
            <?php if ($alertItems && $alertItems->num_rows > 0): ?>
                <?php while ($ai = $alertItems->fetch_assoc()): ?>
                    <div class="alert-row">
                        <div style="min-width:0;">
                            <div style="font-size:13px;font-weight:600;"><?php echo e($ai['item_name']); ?></div>
                            <div style="font-size:12px;color:var(--ink-faint);"><?php echo e($ai['item_code']); ?></div>
                        </div>
                        <div style="display:flex;align-items:center;gap:.625rem;">
                            <span style="font-size:13px;font-weight:700;"><?php echo (int)$ai['quantity_stock']; ?> in stock</span>
                            <span class="badge <?php echo $ai['item_status'] === 'out_of_stock' ? 'status-out_of_stock' : 'status-low_stock'; ?>">
                                <?php echo $ai['item_status'] === 'out_of_stock' ? 'OUT' : 'LOW'; ?>
                            </span>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state">No inventory alerts at this time.</div>
            <?php endif; ?>
        </div>
    </div>

    <div class="grid-2">
        <div class="card" style="padding:1.5rem;">
            <div class="section-title"><i class="fa fa-warning"></i> Outstanding Borrowers</div>
            <?php if ($outstandingClients && $outstandingClients->num_rows > 0): ?>
                <?php while ($oc = $outstandingClients->fetch_assoc()): ?>
                    <div class="alert-row">
                        <div style="min-width:0;">
                            <div style="font-size:13px;font-weight:600;"><?php echo e($oc['full_name']); ?></div>
                            <div style="font-size:12px;color:var(--ink-faint);"><i class="fa fa-phone"></i> <?php echo e($oc['contact_no'] ?: 'N/A'); ?></div>
                        </div>
                        <span class="pill" style="background:var(--warning-soft);color:var(--warning);">
                            <?php echo (int)$oc['net_outstanding']; ?> items out
                        </span>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty-state">No outstanding items.</div>
            <?php endif; ?>
        </div>

        <div class="card" style="padding:1.5rem;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem;">
                <div class="section-title" style="margin:0;"><i class="fa fa-file-text-o"></i> Recent Audit</div>
                <a href="/item_inventory_system/admin/logs.php" class="btn btn-ghost btn-sm">All Logs <i class="fa fa-angle-double-right"></i></a>
            </div>
            <div class="scroll-table">
                <table>
                    <tbody>
                        <?php if ($recentLogs && $recentLogs->num_rows > 0): ?>
                            <?php while ($log = $recentLogs->fetch_assoc()): ?>
                                <tr>
                                    <td class="mono" style="font-size:11px;color:var(--ink-faint);"><?php echo date('H:i', strtotime($log['created_at'])); ?></td>
                                    <td style="font-weight:600;font-size:13px;"><?php echo e($log['full_name']); ?></td>
                                    <td><span class="action-badge"><?php echo e($log['action']); ?></span></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
/* ... [Existing Chart.js logic remains the same] ... */
function cssVar(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }
let txChartInstance = null;
function renderAdminCharts() {
    const textColor = cssVar('--ink-soft'); const gridColor = cssVar('--border');
    const danger = cssVar('--danger'); const success = cssVar('--success');
    if (txChartInstance) txChartInstance.destroy();
    txChartInstance = new Chart(document.getElementById('txChart'), {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($chartLabels); ?>,
            datasets: [
                { label: 'Borrow', data: <?php echo json_encode($chartBorrow); ?>, backgroundColor: danger + '88', borderColor: danger, borderWidth: 1.5, borderRadius: 5 },
                { label: 'Return', data: <?php echo json_encode($chartReturn); ?>, backgroundColor: success + '88', borderColor: success, borderWidth: 1.5, borderRadius: 5 }
            ]
        },
        options: {
            responsive: true,
            scales: {
                x: { grid: { display: false }, ticks: { color: textColor } },
                y: { beginAtZero: true, grid: { color: gridColor }, ticks: { color: textColor } }
            }
        }
    });
}
document.addEventListener('DOMContentLoaded', renderAdminCharts);
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>