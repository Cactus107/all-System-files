<?php
/**
 * Escape HTML for output
 */
function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Redirect utility
 */
function redirect(string $url): void {
    header('Location: ' . $url);
    exit();
}

/**
 * Set a flash message for the next request
 */
function set_flash(string $key, string $message): void {
    $_SESSION['flash'][$key] = $message;
}

/**
 * Get and clear a flash message
 */
function get_flash(string $key): string {
    $value = $_SESSION['flash'][$key] ?? '';
    unset($_SESSION['flash'][$key]);
    return $value;
}

/**
 * Get old POST data for form repopulation
 */
function old(string $key, string $default = ''): string {
    return e($_POST[$key] ?? $default);
}

/**
 * Generate a unique item code (ITM-YYYY-001)
 */
function generate_item_code(mysqli $conn): string {
    $year = date('Y');
    $prefix = 'ITM-' . $year . '-';
    $stmt = $conn->prepare("SELECT item_code FROM items WHERE item_code LIKE ? ORDER BY item_id DESC LIMIT 1");
    $like = $prefix . '%';
    $stmt->bind_param('s', $like);
    $stmt->execute();
    $last = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $nextNumber = 1;
    if ($last && !empty($last['item_code'])) {
        $parts = explode('-', $last['item_code']);
        $lastNumber = (int) end($parts);
        $nextNumber = $lastNumber + 1;
    }

    return $prefix . str_pad((string) $nextNumber, 4, '0', STR_PAD_LEFT);
}

/**
 * Compute inventory status strings
 */
function compute_item_status(int $stock, int $reorderLevel = 5): string {
    if ($stock <= 0) {
        return 'out_of_stock';
    }
    if ($stock <= $reorderLevel) {
        return 'low_stock';
    }
    return 'available';
}

/**
 * Returns an HTML badge with an icon based on item status
 */
function get_status_badge(int $stock, int $reorderLevel = 5): string {
    $status = compute_item_status($stock, $reorderLevel);
    switch ($status) {
        case 'out_of_stock':
            return '<span class="badge status-out_of_stock"><i class="fa fa-times-circle"></i> Out of Stock</span>';
        case 'low_stock':
            return '<span class="badge status-low_stock"><i class="fa fa-exclamation-triangle"></i> Low Stock</span>';
        default:
            return '<span class="badge status-available"><i class="fa fa-check-circle"></i> Available</span>';
    }
}

/**
 * Log system actions to audit table
 */
function log_action(mysqli $conn, int $userId, string $action, string $tableName, ?int $recordId, string $details): void {
    // We clean the action string to ensure it follows our UI patterns if needed
    $stmt = $conn->prepare('INSERT INTO audit_logs (user_id, action, table_name, record_id, details) VALUES (?, ?, ?, ?, ?)');
    $stmt->bind_param('issis', $userId, $action, $tableName, $recordId, $details);
    $stmt->execute();
    $stmt->close();
}

/**
 * Helper for <select> elements
 */
function selected($a, $b): string {
    return (string) $a === (string) $b ? 'selected' : '';
}

/**
 * Format dates consistently with a calendar icon
 */
function f_date(string $date): string {
    return '<span class="text-nowrap"><i class="fa fa-calendar-o" style="opacity:0.5; font-size:0.9em;"></i> ' . date('M j, Y', strtotime($date)) . '</span>';
}