<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/helpers.php';

function require_login(): void {
    if (empty($_SESSION['user_id'])) {
        redirect('/item_inventory_system/auth/login.php');
    }
}

function require_role(array $roles): void {
    require_login();
    $role = $_SESSION['role'] ?? '';
    if (!in_array($role, $roles, true)) {
        http_response_code(403);
        exit('Access denied.');
    }
}