ITEM INVENTORY SYSTEM ENHANCED

Setup:
1. Copy the folder item_inventory_system_enhanced into C:\xampp\htdocs\
2. Open phpMyAdmin.
3. Create or import database using database/item_inventory_system.sql
4. Visit http://localhost/item_inventory_system_enhanced/

Default admin account:
Username: admin
Password: admin123

Main features:
- Separate admin and staff roles
- Staff registration and login
- Admin staff activation and deactivation
- Category management
- Item management with professional layout
- Auto item code generation
- Barcode field support
- Client management
- Borrow and return transactions
- Borrow and return history with search
- Audit logs
