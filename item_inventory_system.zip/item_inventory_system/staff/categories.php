<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/csrf.php';
require_role(['staff','admin']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    // CREATE CATEGORY
    if ($action === 'create') {
        $name        = trim($_POST['category_name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        if ($name !== '') {
            $stmt = $conn->prepare('INSERT INTO categories (category_name, description) VALUES (?, ?)');
            $stmt->bind_param('ss', $name, $description);
            $stmt->execute();
            $id = $stmt->insert_id;
            $stmt->close();
            log_action($conn, (int) $_SESSION['user_id'], 'Create category', 'categories', $id, 'Created category: ' . $name);
            set_flash('success', 'Category "' . $name . '" created successfully.');
        }
    }

    // UPDATE CATEGORY (New Edit Logic)
    if ($action === 'update') {
        $id          = (int) ($_POST['category_id'] ?? 0);
        $name        = trim($_POST['category_name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        
        if ($id > 0 && $name !== '') {
            $stmt = $conn->prepare('UPDATE categories SET category_name = ?, description = ? WHERE category_id = ?');
            $stmt->bind_param('ssi', $name, $description, $id);
            $stmt->execute();
            $stmt->close();
            log_action($conn, (int) $_SESSION['user_id'], 'Update category', 'categories', $id, 'Updated category: ' . $name);
            set_flash('success', 'Category updated successfully.');
        }
    }

    // TOGGLE STATUS
    if ($action === 'toggle') {
        $id     = (int) ($_POST['category_id'] ?? 0);
        $active = (int) ($_POST['is_active'] ?? 0);
        $stmt   = $conn->prepare('UPDATE categories SET is_active = ? WHERE category_id = ?');
        $stmt->bind_param('ii', $active, $id);
        $stmt->execute();
        $stmt->close();

        $statusText = $active ? 'activated' : 'deactivated';
        log_action($conn, (int) $_SESSION['user_id'], 'Toggle category status', 'categories', $id, 'Changed status to ' . $statusText);
        set_flash('success', 'Category status ' . $statusText . ' successfully.');
    }
    redirect('/item_inventory_system/staff/categories.php');
}

$categories = $conn->query("SELECT * FROM categories ORDER BY category_name ASC");

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/nav.php';
require_once __DIR__ . '/../includes/notifications.php';
?>

<style>
    /* Responsive Layout Grid */
    .responsive-container {
        display: grid;
        grid-template-columns: 1fr; /* Mobile: Single column */
        gap: 1.5rem;
        align-items: start;
    }

    @media (min-width: 1024px) {
        .responsive-container {
            grid-template-columns: 350px 1fr; /* Desktop: Sidebar + Table */
        }
        .sticky-sidebar {
            position: sticky;
            top: 1.5rem;
        }
    }

    /* Table Responsiveness */
    .table-responsive-wrapper {
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }

    .custom-table {
        width: 100%;
        min-width: 650px; /* Prevents squishing on small screens */
        border-collapse: collapse;
    }

    /* Status Badges */
    .badge-pill {
        padding: 4px 10px;
        border-radius: 999px;
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }

    /* Form Icons */
    .field-icon { margin-right: 6px; color: var(--ink-faint); font-size: 14px; }
    
    /* Edit Modal Styles */
    #editModal {
        display: none;
        position: fixed;
        inset: 0;
        background: rgba(0,0,0,0.5);
        z-index: 1000;
        align-items: center;
        justify-content: center;
        padding: 1rem;
    }
</style>

<div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
    <div class="mb-8">
        <h1 class="text-2xl font-bold flex items-center gap-3">
            <span class="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-[var(--accent-soft)] text-[var(--accent)]">
                <i class="fa-solid fa-tags"></i>
            </span>
            Category Management
        </h1>
        <p class="text-[var(--ink-soft)] mt-1">Manage inventory classifications for all devices.</p>
    </div>

    <div class="responsive-container">
        
        <div class="sticky-sidebar">
            <div class="card p-5">
                <h3 class="font-bold mb-4 flex items-center gap-2">
                    <i class="fa-solid fa-circle-plus text-[var(--accent)]"></i> Add New Category
                </h3>
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="create">
                    
                    <div class="mb-4">
                        <label class="form-label block mb-1"><i class="fa-solid fa-tag field-icon"></i> Name</label>
                        <input type="text" name="category_name" class="form-input w-full" placeholder="e.g. Tools" required>
                    </div>

                    <div class="mb-5">
                        <label class="form-label block mb-1"><i class="fa-solid fa-align-left field-icon"></i> Description</label>
                        <textarea name="description" class="form-input w-full" rows="3" placeholder="Optional details..."></textarea>
                    </div>

                    <button class="btn btn-primary w-full py-2.5" type="submit">
                        <i class="fa-solid fa-floppy-disk mr-2"></i> Save Category
                    </button>
                </form>
            </div>
        </div>

        <div class="card p-2 sm:p-5">
            <div class="table-responsive-wrapper">
                <table class="custom-table">
                    <thead>
                        <tr class="border-b text-[var(--ink-faint)] text-xs uppercase">
                            <th class="p-3 text-left">ID</th>
                            <th class="p-3 text-left">Category Name</th>
                            <th class="p-3 text-left">Description</th>
                            <th class="p-3 text-left">Status</th>
                            <th class="p-3 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $categories->fetch_assoc()): 
                            $isActive = (int) $row['is_active'] === 1;
                        ?>
                        <tr class="border-b hover:bg-gray-50 transition-colors">
                            <td class="p-3 text-xs mono text-gray-400">#<?php echo (int) $row['category_id']; ?></td>
                            <td class="p-3 font-bold"><?php echo e($row['category_name']); ?></td>
                            <td class="p-3 text-sm text-gray-500 italic max-w-xs truncate">
                                <?php echo $row['description'] ? e($row['description']) : 'None'; ?>
                            </td>
                            <td class="p-3">
                                <span class="badge-pill <?php echo $isActive ? 'status-active' : 'status-inactive'; ?>">
                                    <i class="fa-solid <?php echo $isActive ? 'fa-check' : 'fa-times'; ?>"></i>
                                    <?php echo $isActive ? 'Active' : 'Inactive'; ?>
                                </span>
                            </td>
                            <td class="p-3 text-right flex justify-end gap-2">
                                <button type="button" 
                                        class="btn btn-sm bg-blue-50 text-blue-600 border-blue-200 hover:bg-blue-600 hover:text-white"
                                        onclick="openEditModal(<?php echo (int)$row['category_id']; ?>, '<?php echo addslashes(e($row['category_name'])); ?>', '<?php echo addslashes(e($row['description'])); ?>')">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </button>

                                <form method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="action" value="toggle">
                                    <input type="hidden" name="category_id" value="<?php echo (int)$row['category_id']; ?>">
                                    <input type="hidden" name="is_active" value="<?php echo $isActive ? 0 : 1; ?>">
                                    <button class="btn btn-sm <?php echo $isActive ? 'btn-danger' : 'btn-success'; ?>" type="submit">
                                        <i class="fa-solid <?php echo $isActive ? 'fa-ban' : 'fa-power-off'; ?>"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div id="editModal">
    <div class="card p-6 w-full max-w-md shadow-2xl">
        <h3 class="text-xl font-bold mb-4 flex items-center justify-between">
            Update Category
            <button onclick="closeEditModal()" class="text-gray-400 hover:text-gray-600 text-2xl">&times;</button>
        </h3>
        <form method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="category_id" id="edit_id">
            
            <div class="mb-4">
                <label class="form-label block mb-1">Category Name</label>
                <input type="text" name="category_name" id="edit_name" class="form-input w-full" required>
            </div>
            <div class="mb-6">
                <label class="form-label block mb-1">Description</label>
                <textarea name="description" id="edit_desc" class="form-input w-full" rows="3"></textarea>
            </div>
            <div class="flex gap-3">
                <button type="button" onclick="closeEditModal()" class="btn flex-1 bg-gray-100">Cancel</button>
                <button type="submit" class="btn btn-primary flex-1">Update Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditModal(id, name, desc) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_desc').value = desc;
    document.getElementById('editModal').style.display = 'flex';
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

// Close modal if user clicks outside the content
window.onclick = function(event) {
    const modal = document.getElementById('editModal');
    if (event.target == modal) closeEditModal();
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>