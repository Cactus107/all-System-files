<?php
session_start();

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/helpers.php';

require_role(['staff']);

/**
 * Fetch a single integer value from a query
 */
function fetch_scalar(mysqli $conn, string $sql, string $alias = 'total'): int
{
    $result = $conn->query($sql);
    if (!$result) return 0;
    $row = $result->fetch_assoc();
    return (int)($row[$alias] ?? 0);
}

/**
 * Fetch all rows from a result set into an array
 */
function fetch_all_rows($result): array
{
    if (!$result) return [];
    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
    return $rows;
}

/* --- Summary Stats --- */
$totalItems = fetch_scalar($conn, "SELECT COUNT(*) AS total FROM items");
$totalCategories = fetch_scalar($conn, "SELECT COUNT(*) AS total FROM categories");
$totalClients = fetch_scalar($conn, "SELECT COUNT(*) AS total FROM clients");
$lowStock = fetch_scalar($conn, "SELECT COUNT(*) AS total FROM items WHERE quantity_stock <= 5");
$borrowedItems = fetch_scalar($conn, "SELECT COALESCE(SUM(quantity_borrowed), 0) AS total FROM items");
$returnedToday = fetch_scalar(
    $conn,
    "SELECT COALESCE(SUM(quantity), 0) AS total
     FROM transactions
     WHERE transaction_type = 'return'
       AND DATE(transacted_at) = CURDATE()"
);

/* --- Chart Data --- */
$categoryLabels = [];
$categoryCounts = [];
$catRes = $conn->query("SELECT c.category_name, COUNT(i.item_id) AS total_items FROM categories c LEFT JOIN items i ON i.category_id = c.category_id GROUP BY c.category_id, c.category_name ORDER BY c.category_name ASC");
if ($catRes) {
    while ($row = $catRes->fetch_assoc()) {
        $categoryLabels[] = $row['category_name'];
        $categoryCounts[] = (int)$row['total_items'];
    }
}

$movementLabels = [];
$borrowSeries = [];
$returnSeries = [];
$movRes = $conn->query("SELECT DATE(transacted_at) AS tx_date, SUM(CASE WHEN transaction_type = 'borrow' THEN quantity ELSE 0 END) AS borrow_total, SUM(CASE WHEN transaction_type = 'return' THEN quantity ELSE 0 END) AS return_total FROM transactions WHERE transacted_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) GROUP BY DATE(transacted_at) ORDER BY DATE(transacted_at) ASC");
if ($movRes) {
    while ($row = $movRes->fetch_assoc()) {
        $movementLabels[] = date('M d', strtotime($row['tx_date']));
        $borrowSeries[] = (int)$row['borrow_total'];
        $returnSeries[] = (int)$row['return_total'];
    }
}

/* --- Activity Lists --- */
$recentBorrowers = fetch_all_rows($conn->query("SELECT t.transacted_at, COALESCE(c.full_name, 'N/A') AS client_name, i.item_name, t.quantity FROM transactions t LEFT JOIN clients c ON c.client_id = t.client_id INNER JOIN items i ON i.item_id = t.item_id WHERE t.transaction_type = 'borrow' ORDER BY t.transaction_id DESC LIMIT 8"));
$recentReturners = fetch_all_rows($conn->query("SELECT t.transacted_at, COALESCE(c.full_name, 'N/A') AS client_name, i.item_name, t.item_status_details FROM transactions t LEFT JOIN clients c ON c.client_id = t.client_id INNER JOIN items i ON i.item_id = t.item_id WHERE t.transaction_type = 'return' ORDER BY t.transaction_id DESC LIMIT 8"));

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/nav.php';
require_once __DIR__ . '/../includes/notifications.php';
?>

<style>
    /* 1. Global & Responsive Layout */
    .dashboard-shell { width: 100%; max-width: 100%; }

    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
        gap: 1rem;
        margin-bottom: 1.5rem;
    }

    .charts-grid {
        display: grid;
        grid-template-columns: 1fr;
        gap: 1.25rem;
        margin-bottom: 1.5rem;
    }

    .tables-grid {
        display: grid;
        grid-template-columns: 1fr;
        gap: 1.25rem;
    }

    /* Tablet/Desktop adjustments */
    @media (min-width: 768px) { .charts-grid { grid-template-columns: repeat(2, 1fr); } }
    @media (min-width: 1280px) { .tables-grid { grid-template-columns: 1fr 1fr; } }

    /* 2. Cards and UI Components */
    .dashboard-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-sm);
        overflow: hidden;
    }

    .stat-card {
        padding: 1.25rem;
        position: relative;
        overflow: hidden;
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: var(--radius-lg);
    }

    .stat-icon-bg {
        position: absolute;
        right: -8px;
        bottom: -8px;
        font-size: 2.5rem;
        opacity: 0.07;
        transform: rotate(-12deg);
    }

    /* 3. Responsive Table Styles (QTY/STATUS closer to ITEM) */
    .table-container {
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }

    .dashboard-table {
        width: 100%;
        border-collapse: collapse;
        table-layout: auto; /* Dynamic layout to allow columns to hug content */
        min-width: 500px;
    }

    .dashboard-table thead th {
        background: var(--surface-2);
        color: var(--ink-faint);
        font-size: 10.5px;
        font-weight: 800;
        text-transform: uppercase;
        padding: 0.85rem 0.6rem;
        text-align: left;
        border-bottom: 1px solid var(--border);
    }

    .dashboard-table td {
        padding: 0.85rem 0.6rem;
        font-size: 12.5px;
        color: var(--ink);
        border-bottom: 1px solid var(--border);
        vertical-align: middle;
    }

    /* Responsive Column Width Management */
    .col-date   { width: 22%; }
    .col-client { width: 25%; }
    .col-item   { width: auto; } /* Expands to fill available space */
    .col-compact { 
        width: 1%; /* Shrinks column to minimum required width */
        white-space: nowrap; 
        padding-left: 2rem !important; /* Visual gap between Item and Qty/Status */
    }

    /* UI Badges */
    .qty-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 28px;
        padding: 2px 8px;
        background: var(--warning-soft);
        color: var(--warning);
        border: 1px solid var(--warning-border);
        border-radius: 999px;
        font-weight: 800;
        font-size: 11px;
    }

    .status-text {
        font-size: 11px;
        color: var(--ink-soft);
        background: var(--surface-2);
        padding: 3px 8px;
        border-radius: 4px;
    }
</style>

<div class="dashboard-shell mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
    
    <div class="flex flex-col gap-4 mb-6 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h1 class="text-2xl font-bold flex items-center gap-3">
                <span class="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-[var(--accent-soft)] text-[var(--accent)]">
                    <i class="fa-solid fa-gauge"></i>
                </span>
                Staff Dashboard
            </h1>
        </div>
        <div class="text-sm text-[var(--ink-faint)]">
            Welcome, <strong class="text-[var(--ink)]"><?php echo e($_SESSION['full_name'] ?? 'Staff'); ?></strong>
        </div>
    </div>

    <div class="stats-grid">
        <?php
        $stats = [
            ['Total Items', $totalItems, 'var(--accent)', 'fa-cubes'],
            ['Categories', $totalCategories, '#6366f1', 'fa-tags'],
            ['Clients', $totalClients, '#0891b2', 'fa-users'],
            ['Low Stock', $lowStock, 'var(--warning)', 'fa-triangle-exclamation'],
            ['Borrowed', $borrowedItems, '#dc2626', 'fa-arrow-up-right-from-square'],
            ['Returned Today', $returnedToday, 'var(--success)', 'fa-rotate-left'],
        ];
        foreach ($stats as $s):
        ?>
        <div class="stat-card">
            <i class="fa-solid <?php echo $s[3]; ?> stat-icon-bg"></i>
            <div class="stat-label"><?php echo $s[0]; ?></div>
            <div class="stat-value" style="color: <?php echo $s[2]; ?>;"><?php echo $s[1]; ?></div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="charts-grid">
        <div class="dashboard-card p-4">
            <h2 class="text-sm font-bold mb-4 flex items-center gap-2">
                <i class="fa-solid fa-chart-column text-[var(--accent)]"></i> Items per Category
            </h2>
            <div style="height: 250px;"><canvas id="categoryChart"></canvas></div>
        </div>
        <div class="dashboard-card p-4">
            <h2 class="text-sm font-bold mb-4 flex items-center gap-2">
                <i class="fa-solid fa-chart-line text-[var(--accent)]"></i> Activity (Last 7 Days)
            </h2>
            <div style="height: 250px;"><canvas id="movementChart"></canvas></div>
        </div>
    </div>

    <div class="tables-grid">
        <section class="dashboard-card">
            <div class="px-4 py-3 border-b flex items-center gap-2 font-bold text-sm">
                <i class="fa-solid fa-history text-orange-500"></i> Recent Borrowers
            </div>
            <div class="table-container">
                <table class="dashboard-table">
                    <thead>
                        <tr>
                            <th class="col-date">DATE</th>
                            <th class="col-client">CLIENT</th>
                            <th class="col-item">ITEM</th>
                            <th class="col-compact" style="text-align: center;">QTY</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recentBorrowers)): ?>
                            <tr><td colspan="4" class="text-center py-6 text-gray-400">No activity found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($recentBorrowers as $row): ?>
                            <tr>
                                <td class="text-xs text-gray-500"><?php echo date('M d, H:i', strtotime($row['transacted_at'])); ?></td>
                                <td class="font-semibold"><?php echo e($row['client_name']); ?></td>
                                <td><?php echo e($row['item_name']); ?></td>
                                <td class="col-compact" style="text-align: center;"><span class="qty-badge"><?php echo $row['quantity']; ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <section class="dashboard-card">
            <div class="px-4 py-3 border-b flex items-center gap-2 font-bold text-sm">
                <i class="fa-solid fa-rotate-left text-emerald-500"></i> Recent Returns
            </div>
            <div class="table-container">
                <table class="dashboard-table">
                    <thead>
                        <tr>
                            <th class="col-date">DATE</th>
                            <th class="col-client">CLIENT</th>
                            <th class="col-item">ITEM</th>
                            <th class="col-compact">STATUS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recentReturners)): ?>
                            <tr><td colspan="4" class="text-center py-6 text-gray-400">No activity found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($recentReturners as $row): ?>
                            <tr>
                                <td class="text-xs text-gray-500"><?php echo date('M d, H:i', strtotime($row['transacted_at'])); ?></td>
                                <td class="font-semibold"><?php echo e($row['client_name']); ?></td>
                                <td><?php echo e($row['item_name']); ?></td>
                                <td class="col-compact"><span class="status-text"><?php echo e($row['item_status_details'] ?: 'Goods'); ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
(function() {
    const accent = '#2563eb';
    const textFaint = '#94a3b8';

    // Category Chart
    new Chart(document.getElementById('categoryChart'), {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($categoryLabels); ?>,
            datasets: [{
                data: <?php echo json_encode($categoryCounts); ?>,
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                borderColor: accent,
                borderWidth: 2,
                borderRadius: 4
            }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
    });

    // Movement Chart
    new Chart(document.getElementById('movementChart'), {
        type: 'line',
        data: {
            labels: <?php echo json_encode($movementLabels); ?>,
            datasets: [
                { label: 'Borrow', data: <?php echo json_encode($borrowSeries); ?>, borderColor: '#dc2626', backgroundColor: 'rgba(220, 38, 38, 0.05)', fill: true, tension: 0.3 },
                { label: 'Return', data: <?php echo json_encode($returnSeries); ?>, borderColor: '#059669', backgroundColor: 'rgba(5, 150, 105, 0.05)', fill: true, tension: 0.3 }
            ]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'top', labels: { boxWidth: 10 } } } }
    });
})();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>