<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/csrf.php';

require_role(['staff','admin']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        try {
            $full_name  = trim($_POST['full_name'] ?? '');
            $address    = trim($_POST['address'] ?? '');
            $contact_no = trim($_POST['contact_no'] ?? '');
            $email      = trim($_POST['email'] ?? '');

            if ($full_name === '') {
                throw new RuntimeException('Full name is required.');
            }
            if (mb_strlen($full_name) < 2) {
                throw new RuntimeException('Full name must be at least 2 characters long.');
            }
            if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new RuntimeException('Please enter a valid email address.');
            }
            if ($contact_no !== '' && !preg_match('/^[0-9+\-\s()]{7,20}$/', $contact_no)) {
                throw new RuntimeException('Please enter a valid contact number.');
            }

            if ($email !== '') {
                $stmt = $conn->prepare("SELECT client_id FROM clients WHERE email = ? LIMIT 1");
                $stmt->bind_param('s', $email);
                $stmt->execute();
                if ($stmt->get_result()->num_rows > 0) {
                    $stmt->close();
                    throw new RuntimeException('A client with this email address already exists.');
                }
                $stmt->close();
            }

            $stmt = $conn->prepare("
                INSERT INTO clients (full_name, address, contact_no, email, is_active)
                VALUES (?, ?, ?, ?, 1)
            ");
            $stmt->bind_param('ssss', $full_name, $address, $contact_no, $email);
            $stmt->execute();
            $newId = $stmt->insert_id;
            $stmt->close();

            log_action($conn, (int)$_SESSION['user_id'], 'Create client', 'clients', $newId, 'Created client: ' . $full_name);
            set_flash('success', 'Client "' . $full_name . '" added successfully.');
        } catch (Throwable $e) {
            set_flash('error', $e->getMessage());
        }

        header('Location: /item_inventory_system/staff/clients.php');
        exit();
    }

    if ($action === 'update') {
        try {
            $client_id  = (int)($_POST['client_id'] ?? 0);
            $full_name  = trim($_POST['full_name'] ?? '');
            $address    = trim($_POST['address'] ?? '');
            $contact_no = trim($_POST['contact_no'] ?? '');
            $email      = trim($_POST['email'] ?? '');

            if ($client_id <= 0) {
                throw new RuntimeException('Invalid client ID.');
            }
            if ($full_name === '') {
                throw new RuntimeException('Full name is required.');
            }
            if (mb_strlen($full_name) < 2) {
                throw new RuntimeException('Full name must be at least 2 characters long.');
            }
            if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new RuntimeException('Please enter a valid email address.');
            }
            if ($contact_no !== '' && !preg_match('/^[0-9+\-\s()]{7,20}$/', $contact_no)) {
                throw new RuntimeException('Please enter a valid contact number.');
            }

            $stmt = $conn->prepare("SELECT client_id FROM clients WHERE client_id = ? LIMIT 1");
            $stmt->bind_param('i', $client_id);
            $stmt->execute();
            $exists = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$exists) {
                throw new RuntimeException('Client not found.');
            }

            if ($email !== '') {
                $stmt = $conn->prepare("SELECT client_id FROM clients WHERE email = ? AND client_id != ? LIMIT 1");
                $stmt->bind_param('si', $email, $client_id);
                $stmt->execute();
                if ($stmt->get_result()->num_rows > 0) {
                    $stmt->close();
                    throw new RuntimeException('Another client with this email address already exists.');
                }
                $stmt->close();
            }

            $stmt = $conn->prepare("
                UPDATE clients
                SET full_name = ?, address = ?, contact_no = ?, email = ?
                WHERE client_id = ?
            ");
            $stmt->bind_param('ssssi', $full_name, $address, $contact_no, $email, $client_id);
            $stmt->execute();
            $stmt->close();

            log_action($conn, (int)$_SESSION['user_id'], 'Update client', 'clients', $client_id, 'Updated client: ' . $full_name);
            set_flash('success', 'Client updated successfully.');
        } catch (Throwable $e) {
            set_flash('error', $e->getMessage());
        }

        header('Location: /item_inventory_system/staff/clients.php');
        exit();
    }

    if ($action === 'archive') {
        try {
            $client_id = (int)($_POST['client_id'] ?? 0);
            if ($client_id <= 0) {
                throw new RuntimeException('Invalid client ID.');
            }

            $stmt = $conn->prepare("SELECT full_name FROM clients WHERE client_id = ? LIMIT 1");
            $stmt->bind_param('i', $client_id);
            $stmt->execute();
            $client = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$client) {
                throw new RuntimeException('Client not found.');
            }

            $stmt = $conn->prepare("UPDATE clients SET is_active = 0 WHERE client_id = ?");
            $stmt->bind_param('i', $client_id);
            $stmt->execute();
            $stmt->close();

            log_action($conn, (int)$_SESSION['user_id'], 'Archive client', 'clients', $client_id, 'Archived client: ' . $client['full_name']);
            set_flash('success', 'Client "' . $client['full_name'] . '" has been archived.');
        } catch (Throwable $e) {
            set_flash('error', $e->getMessage());
        }

        header('Location: /item_inventory_system/staff/clients.php');
        exit();
    }

    if ($action === 'delete') {
        try {
            $client_id = (int)($_POST['client_id'] ?? 0);
            if ($client_id <= 0) {
                throw new RuntimeException('Invalid client ID.');
            }

            $stmt = $conn->prepare("
                SELECT c.full_name, COUNT(t.transaction_id) AS transaction_count
                FROM clients c
                LEFT JOIN transactions t ON t.client_id = c.client_id
                WHERE c.client_id = ?
                GROUP BY c.client_id, c.full_name
                LIMIT 1
            ");
            $stmt->bind_param('i', $client_id);
            $stmt->execute();
            $client = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$client) {
                throw new RuntimeException('Client not found.');
            }

            if ((int)$client['transaction_count'] > 0) {
                throw new RuntimeException('Cannot delete client with transaction history. Archive instead.');
            }

            $stmt = $conn->prepare("DELETE FROM clients WHERE client_id = ?");
            $stmt->bind_param('i', $client_id);
            $stmt->execute();
            $stmt->close();

            log_action($conn, (int)$_SESSION['user_id'], 'Delete client', 'clients', $client_id, 'Deleted client: ' . $client['full_name']);
            set_flash('success', 'Client "' . $client['full_name'] . '" has been permanently deleted.');
        } catch (Throwable $e) {
            set_flash('error', $e->getMessage());
        }

        header('Location: /item_inventory_system/staff/clients.php');
        exit();
    }
}

$q = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 12;
$offset = ($page - 1) * $per_page;

/* summary stats */
$stats = $conn->query("
    SELECT
        SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) AS active_total,
        SUM(CASE WHEN is_active = 0 THEN 1 ELSE 0 END) AS archived_total
    FROM clients
")->fetch_assoc();

$activeTotal = (int)($stats['active_total'] ?? 0);
$archivedTotal = (int)($stats['archived_total'] ?? 0);

/* main list */
$sql = "
    SELECT
        c.*,
        COUNT(t.transaction_id) AS transaction_count
    FROM clients c
    LEFT JOIN transactions t ON t.client_id = c.client_id
    WHERE c.is_active = 1
";
$count_sql = "SELECT COUNT(*) AS total FROM clients c WHERE c.is_active = 1";
$params = [];
$types = '';

if ($q !== '') {
    $sql .= " AND (c.full_name LIKE ? OR c.address LIKE ? OR c.contact_no LIKE ? OR c.email LIKE ?)";
    $count_sql .= " AND (c.full_name LIKE ? OR c.address LIKE ? OR c.contact_no LIKE ? OR c.email LIKE ?)";
    $like = "%{$q}%";
    $params = [$like, $like, $like, $like];
    $types = 'ssss';
}

$sql .= "
    GROUP BY c.client_id
    ORDER BY c.client_id DESC
    LIMIT ? OFFSET ?
";
$params[] = $per_page;
$params[] = $offset;
$types .= 'ii';

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$clients = $stmt->get_result();

$count_stmt = $conn->prepare($count_sql);
if ($q !== '') {
    $count_stmt->bind_param('ssss', $like, $like, $like, $like);
}
$count_stmt->execute();
$total_clients = (int)($count_stmt->get_result()->fetch_assoc()['total'] ?? 0);
$count_stmt->close();

$total_pages = max(1, (int)ceil($total_clients / $per_page));

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/nav.php';
require_once __DIR__ . '/../includes/notifications.php';
?>


<style>
    .summary-grid{
        display:grid;
        grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
        gap:1rem;
        margin-bottom:1.5rem;
    }
    .client-grid{
        display:grid;
        grid-template-columns:repeat(auto-fill,minmax(320px,1fr));
        gap:1rem;
        margin-top:1rem;
    }
    .client-card{
        background:var(--surface);
        border:1px solid var(--border);
        border-radius:var(--radius-lg);
        box-shadow:var(--shadow-sm);
        padding:1.25rem;
        transition:.18s ease;
        position: relative;
        overflow: hidden;
    }
    .client-card:hover{
        transform:translateY(-2px);
        box-shadow:var(--shadow);
    }
    .card-icon-bg {
        position: absolute;
        right: -5px;
        top: -5px;
        font-size: 4rem;
        opacity: 0.03;
        transform: rotate(15deg);
        pointer-events: none;
    }
    .client-actions{
        display:flex;
        flex-wrap:wrap;
        gap:.5rem;
        margin-top:1.25rem;
        padding-top: 1rem;
        border-top: 1px solid var(--border);
    }
    .search-bar{
        display:grid;
        grid-template-columns:1fr auto;
        gap:.75rem;
    }
    .form-label{
        display:block;
        font-size:13px;
        font-weight:600;
        margin-bottom:.45rem;
        color:var(--ink-soft);
    }
    .form-group{ margin-bottom:1rem; }
    .modal-grid{
        display:grid;
        grid-template-columns:1fr 1fr;
        gap:1rem;
    }
    .meta-row{
        display:grid;
        gap:.45rem;
        font-size:13px;
        color:var(--ink-soft);
        margin-top:.85rem;
    }
    .meta-item { display: flex; align-items: center; gap: 8px; }
    .meta-item i { width: 14px; text-align: center; color: var(--accent); opacity: 0.8; }

    .pagination{
        display:flex;
        justify-content:center;
        gap:.4rem;
        flex-wrap:wrap;
        margin-top:2rem;
    }
    @media (max-width:768px){
        .search-bar,.modal-grid{ grid-template-columns:1fr; }
        .client-grid{ grid-template-columns:1fr; }
        .client-actions .btn{ width:100%; justify-content:center; }
    }
</style>

<div style="max-width:1280px;margin:0 auto;padding:2rem 1.5rem;">
    <div class="page-header" style="display:flex;justify-content:space-between;gap:1rem;flex-wrap:wrap;align-items:flex-start;">
        <div>
            <h1 class="page-title"><i class="fa-solid fa-address-book"></i> Clients</h1>
            <p class="page-subtitle">Manage active clients and track their transaction history.</p>
        </div>
        <div class="flex flex-wrap gap-3">
            <button type="button" onclick="openAddClientModal()" class="btn btn-primary">
                <i class="fa-solid fa-plus"></i> Add Client
            </button>
            <a href="archived_clients.php" class="btn btn-ghost">
                <i class="fa-solid fa-box-archive"></i> Archived
            </a>
        </div>
    </div>

    <div class="summary-grid">
        <div class="stat-card">
            <div class="stat-label"><i class="fa-solid fa-circle-check"></i> Active Clients</div>
            <div class="stat-value"><?php echo $activeTotal; ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label"><i class="fa-solid fa-box-archive"></i> Archived</div>
            <div class="stat-value"><?php echo $archivedTotal; ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label"><i class="fa-solid fa-magnifying-glass"></i> Found</div>
            <div class="stat-value"><?php echo $total_clients; ?></div>
        </div>
    </div>

    <div class="card" style="padding:1.25rem 1.5rem;margin-bottom:1.5rem;">
        <form method="GET" class="search-bar">
            <div style="position:relative;">
                <i class="fa-solid fa-magnifying-glass" style="position:absolute; left:12px; top:50%; transform:translateY(-50%); color:var(--ink-faint);"></i>
                <input name="q" value="<?php echo e($q); ?>" class="form-input" placeholder="Search name, contact, email..." style="padding-left:35px;">
            </div>
            <button class="btn btn-primary" type="submit">Search</button>
        </form>
    </div>

    <?php if ($total_clients > 0): ?>
        <div class="client-grid">
            <?php while ($row = $clients->fetch_assoc()): ?>
                <?php $has_transactions = (int)$row['transaction_count'] > 0; ?>
                <div class="client-card">
                    <i class="fa-solid fa-user card-icon-bg"></i>
                    <div style="display:flex;justify-content:space-between;gap:1rem;align-items:flex-start;">
                        <div>
                            <div style="font-size:1.05rem;font-weight:700;color:var(--ink);"><?php echo e($row['full_name']); ?></div>
                            <div style="font-size:12px;color:var(--ink-faint);margin-top:2px;">
                                <i class="fa-solid fa-id-badge"></i> ID: #<?php echo str_pad($row['client_id'], 5, '0', STR_PAD_LEFT); ?>
                            </div>
                        </div>
                        <span class="badge <?php echo $has_transactions ? 'status-active' : 'status-inactive'; ?>" style="font-size:10px;">
                            <?php echo $has_transactions ? '<i class="fa-solid fa-clock-rotate-left"></i> Active' : '<i class="fa-regular fa-circle"></i> New'; ?>
                        </span>
                    </div>

                    <div class="meta-row">
                        <div class="meta-item">
                            <i class="fa-regular fa-envelope"></i> 
                            <span><?php echo e($row['email'] ?: 'No email provided'); ?></span>
                        </div>
                        <div class="meta-item">
                            <i class="fa-solid fa-phone"></i> 
                            <span><?php echo e($row['contact_no'] ?: 'No contact'); ?></span>
                        </div>
                        <div class="meta-item">
                            <i class="fa-solid fa-location-dot"></i> 
                            <span><?php echo e($row['address'] ?: 'No address'); ?></span>
                        </div>
                        <div class="meta-item" style="margin-top:4px;">
                            <i class="fa-solid fa-right-left"></i> 
                            <strong style="color:var(--ink);"><?php echo (int)$row['transaction_count']; ?></strong> 
                            <span style="font-size:12px;">Transactions</span>
                        </div>
                    </div>

                    <div class="client-actions">
                        <a href="/item_inventory_system/staff/history.php?q=<?php echo urlencode($row['full_name']); ?>" class="btn btn-ghost btn-sm" title="View History">
                            <i class="fa-solid fa-clipboard-list"></i> History
                        </a>

                        <button type="button" class="btn btn-ghost btn-sm"
                            onclick='openEditClientModal(<?php echo json_encode([
                                "client_id"  => (int)$row["client_id"],
                                "full_name"  => $row["full_name"],
                                "address"    => $row["address"],
                                "contact_no" => $row["contact_no"],
                                "email"      => $row["email"]
                            ], JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>)'>
                            <i class="fa-solid fa-pen-to-square"></i> Edit
                        </button>

                        <?php if ($has_transactions): ?>
                            <form method="POST" class="inline-block"
                                  data-confirm="Client has history. Archive instead of deleting?"
                                  data-confirm-title="Archive Client?"
                                  data-confirm-label="Archive"
                                  data-confirm-type="warning">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="action" value="archive">
                                <input type="hidden" name="client_id" value="<?php echo (int)$row['client_id']; ?>">
                                <button class="btn btn-warning btn-sm" type="submit"><i class="fa-solid fa-box-archive"></i></button>
                            </form>
                        <?php else: ?>
                            <form method="POST" class="inline-block"
                                  data-confirm="Permanently delete <?php echo htmlspecialchars($row['full_name'], ENT_QUOTES, 'UTF-8'); ?>?"
                                  data-confirm-title="Delete Client?"
                                  data-confirm-label="Delete"
                                  data-confirm-type="danger">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="client_id" value="<?php echo (int)$row['client_id']; ?>">
                                <button class="btn btn-danger btn-sm" type="submit"><i class="fa-solid fa-trash"></i></button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a class="btn btn-ghost btn-sm" href="?page=<?php echo $page - 1; ?><?php echo $q !== '' ? '&q=' . urlencode($q) : ''; ?>"><i class="fa-solid fa-chevron-left"></i></a>
                <?php endif; ?>

                <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                    <a class="btn <?php echo $i === $page ? 'btn-primary' : 'btn-ghost'; ?> btn-sm"
                       href="?page=<?php echo $i; ?><?php echo $q !== '' ? '&q=' . urlencode($q) : ''; ?>">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <a class="btn btn-ghost btn-sm" href="?page=<?php echo $page + 1; ?><?php echo $q !== '' ? '&q=' . urlencode($q) : ''; ?>"><i class="fa-solid fa-chevron-right"></i></a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="card" style="padding:4rem 1rem;text-align:center;color:var(--ink-faint);">
            <i class="fa-solid fa-users" style="font-size:3rem; margin-bottom:1rem; opacity:0.2;"></i>
            <div style="font-size:1.1rem;font-weight:700;color:var(--ink);margin-bottom:.5rem;">
                <?php echo $q !== '' ? 'No clients found' : 'Start your client list'; ?>
            </div>
            <div style="font-size:14px;">
                <?php echo $q !== '' ? 'Try a different search term.' : 'Add a client to begin tracking loans and returns.'; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<div id="addClientModal" class="modal-overlay">
    <div class="modal-box modal-box-lg">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;">
            <h2 style="font-size:1.125rem;font-weight:700;"><i class="fa-solid fa-user-plus text-[var(--accent)]"></i> Add New Client</h2>
            <button type="button" onclick="closeAddClientModal()" class="btn btn-ghost btn-sm"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <form method="POST" class="modal-grid">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="create">

            <div class="form-group" style="grid-column:1/-1;">
                <label class="form-label">Full Name</label>
                <div style="position:relative;">
                    <i class="fa-solid fa-user" style="position:absolute; left:12px; top:12px; color:var(--ink-faint);"></i>
                    <input name="full_name" class="form-input" required minlength="2" placeholder="e.g. John Doe" style="padding-left:35px;">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Contact Number</label>
                <div style="position:relative;">
                    <i class="fa-solid fa-phone" style="position:absolute; left:12px; top:12px; color:var(--ink-faint);"></i>
                    <input name="contact_no" class="form-input" pattern="[0-9+\-\s()]{7,20}" placeholder="Phone number" style="padding-left:35px;">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Email Address</label>
                <div style="position:relative;">
                    <i class="fa-solid fa-envelope" style="position:absolute; left:12px; top:12px; color:var(--ink-faint);"></i>
                    <input name="email" type="email" class="form-input" placeholder="email@example.com" style="padding-left:35px;">
                </div>
            </div>

            <div class="form-group" style="grid-column:1/-1;">
                <label class="form-label">Address</label>
                <div style="position:relative;">
                    <i class="fa-solid fa-location-dot" style="position:absolute; left:12px; top:12px; color:var(--ink-faint);"></i>
                    <input name="address" class="form-input" placeholder="Home or Office address" style="padding-left:35px;">
                </div>
            </div>

            <div style="grid-column:1/-1; margin-top:0.5rem;">
                <button class="btn btn-primary" type="submit" style="width:100%;">Create Client Account</button>
            </div>
        </form>
    </div>
</div>

<div id="editClientModal" class="modal-overlay">
    <div class="modal-box modal-box-lg">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;">
            <h2 style="font-size:1.125rem;font-weight:700;"><i class="fa-solid fa-pen-to-square text-[var(--accent)]"></i> Edit Client Details</h2>
            <button type="button" onclick="closeEditClientModal()" class="btn btn-ghost btn-sm"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <form method="POST" class="modal-grid">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="client_id" id="edit_client_id">

            <div class="form-group" style="grid-column:1/-1;">
                <label class="form-label">Full Name</label>
                <input name="full_name" id="edit_full_name" class="form-input" required minlength="2">
            </div>

            <div class="form-group">
                <label class="form-label">Contact Number</label>
                <input name="contact_no" id="edit_contact_no" class="form-input">
            </div>

            <div class="form-group">
                <label class="form-label">Email Address</label>
                <input name="email" id="edit_email" type="email" class="form-input">
            </div>

            <div class="form-group" style="grid-column:1/-1;">
                <label class="form-label">Address</label>
                <input name="address" id="edit_address" class="form-input">
            </div>

            <div style="grid-column:1/-1; margin-top:0.5rem;">
                <button class="btn btn-primary" type="submit" style="width:100%;">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
function openAddClientModal() {
    const modal = document.getElementById('addClientModal');
    modal.classList.add('is-open');
    const form = modal.querySelector('form');
    form.reset();
    form.querySelector('[name="full_name"]').focus();
}
function closeAddClientModal() {
    document.getElementById('addClientModal').classList.remove('is-open');
}
function openEditClientModal(client) {
    document.getElementById('edit_client_id').value = client.client_id || '';
    document.getElementById('edit_full_name').value = client.full_name || '';
    document.getElementById('edit_address').value = client.address || '';
    document.getElementById('edit_contact_no').value = client.contact_no || '';
    document.getElementById('edit_email').value = client.email || '';
    document.getElementById('editClientModal').classList.add('is-open');
}
function closeEditClientModal() {
    document.getElementById('editClientModal').classList.remove('is-open');
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>