<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/helpers.php';

require_role(['staff']);

$item_id = (int)($_GET['item_id'] ?? 0);

$stmt = $conn->prepare("
    SELECT item_name, item_code, serial_barcode
    FROM items
    WHERE item_id = ?
    LIMIT 1
");
$stmt->bind_param('i', $item_id);
$stmt->execute();
$item = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$item) {
    exit('Item not found.');
}

$barcodeValue = $item['serial_barcode'] ?: $item['item_code'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Barcode</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script>
    <style>
        @media print {
            .no-print { display: none !important; }
        }
    </style>
</head>
<body class="bg-slate-100 p-6">
    <div class="max-w-sm mx-auto">
        <div class="bg-white rounded-2xl shadow-xl p-6 text-center" id="printArea">
            <!-- Logo path updated -->
            <img src="/item_inventory_system/img/logo.png" alt="Company Logo" class="h-14 mx-auto mb-4"
                 onerror="this.style.display='none'">

            <div class="font-bold text-lg mb-4"><?php echo e($item['item_name']); ?></div>

            <div class="flex justify-center">
                <svg id="barcode"></svg>
            </div>
        </div>

        <div class="mt-4 flex gap-2 justify-center no-print">
            <button onclick="window.print()" class="px-4 py-3 rounded-xl bg-slate-900 text-white font-semibold">Print</button>
            <a href="/item_inventory_system/staff/items.php" class="px-4 py-3 rounded-xl bg-slate-300 font-semibold">Back</a>
        </div>
    </div>

    <script>
    JsBarcode("#barcode", "<?php echo e($barcodeValue); ?>", {
        format: "CODE128",
        width: 2,
        height: 70,
        displayValue: true
    });
    </script>
</body>
</html>