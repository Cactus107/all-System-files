<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/csrf.php';
require_role(['staff','admin']);

/* ═══════════════════════════════════════
   AJAX — barcode lookup for return modal
═══════════════════════════════════════ */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'return_lookup') {
    header('Content-Type: application/json; charset=utf-8');

    $barcode = trim($_GET['barcode'] ?? '');
    if ($barcode === '') {
        echo json_encode(['ok' => false, 'message' => 'Barcode is required.']);
        exit();
    }

    $stmt = $conn->prepare("
        SELECT i.item_id, i.item_name, i.item_code, i.serial_barcode,
               i.quantity_stock, i.quantity_borrowed, i.image_path, cat.category_name
        FROM items i
        JOIN categories cat ON cat.category_id = i.category_id
        WHERE i.serial_barcode = ? OR i.item_code = ?
        LIMIT 1
    ");
    $stmt->bind_param('ss', $barcode, $barcode);
    $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$item) {
        echo json_encode(['ok' => false, 'message' => 'No item found for this barcode.']);
        exit();
    }

    $stmt = $conn->prepare("
        SELECT
            t.client_id,
            c.full_name,
            SUM(CASE
                WHEN t.transaction_type = 'borrow' THEN t.quantity
                WHEN t.transaction_type = 'return' THEN -t.quantity
                ELSE 0
            END) AS outstanding_qty,
            MAX(t.transacted_at) AS last_tx
        FROM transactions t
        JOIN clients c ON c.client_id = t.client_id
        WHERE t.item_id = ? AND t.client_id IS NOT NULL
        GROUP BY t.client_id, c.full_name
        HAVING outstanding_qty > 0
        ORDER BY outstanding_qty DESC, last_tx DESC
    ");
    $stmt->bind_param('i', $item['item_id']);
    $stmt->execute();
    $outstanding = $stmt->get_result();

    $clients = [];
    while ($row = $outstanding->fetch_assoc()) {
        $clients[] = [
            'client_id'       => (int) $row['client_id'],
            'full_name'       => $row['full_name'],
            'outstanding_qty' => (int) $row['outstanding_qty'],
        ];
    }
    $stmt->close();

    if (count($clients) === 0) {
        echo json_encode(['ok' => false, 'message' => 'This item has no outstanding borrower record to return.']);
        exit();
    }

    echo json_encode([
        'ok'             => true,
        'item'           => [
            'item_id'           => (int) $item['item_id'],
            'item_name'         => $item['item_name'],
            'item_code'         => $item['item_code'],
            'serial_barcode'    => $item['serial_barcode'],
            'category_name'     => $item['category_name'],
            'quantity_stock'    => (int) $item['quantity_stock'],
            'quantity_borrowed' => (int) $item['quantity_borrowed'],
            'image_path'        => $item['image_path'],
        ],
        'clients'        => $clients,
        'auto_client_id' => $clients[0]['client_id'],
        'suggested_qty'  => $clients[0]['outstanding_qty'],
    ]);
    exit();
}

/* ═══════════════════════════════════════
   POST — save return transaction
═══════════════════════════════════════ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    if (($_POST['action'] ?? '') === 'return') {
        $item_id             = (int) ($_POST['item_id'] ?? 0);
        $client_id           = (int) ($_POST['client_id'] ?? 0);
        $quantity            = (int) ($_POST['quantity'] ?? 0);
        $item_status_details = trim($_POST['item_status_details'] ?? '');
        $remarks             = trim($_POST['remarks'] ?? '');
        $staff_id            = (int) $_SESSION['user_id'];

        if ($item_id > 0 && $client_id > 0 && $quantity > 0) {
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("SELECT quantity_stock, quantity_borrowed FROM items WHERE item_id = ? FOR UPDATE");
                $stmt->bind_param('i', $item_id);
                $stmt->execute();
                $item = $stmt->get_result()->fetch_assoc();
                $stmt->close();

                if (!$item) throw new Exception('Item not found.');

                $stmt = $conn->prepare("
                    SELECT COALESCE(SUM(
                        CASE
                            WHEN transaction_type = 'borrow' THEN quantity
                            WHEN transaction_type = 'return' THEN -quantity
                            ELSE 0
                        END
                    ), 0) AS outstanding_qty
                    FROM transactions
                    WHERE item_id = ? AND client_id = ?
                ");
                $stmt->bind_param('ii', $item_id, $client_id);
                $stmt->execute();
                $outstanding       = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                $clientOutstanding = (int) ($outstanding['outstanding_qty'] ?? 0);

                if ($clientOutstanding <= 0) throw new Exception('This client has no outstanding borrowed quantity for the scanned item.');
                if ($quantity > $clientOutstanding) throw new Exception('Return quantity exceeds this client\'s outstanding borrowed quantity of ' . $clientOutstanding . '.');
                if ((int) $item['quantity_borrowed'] < $quantity) throw new Exception('Return quantity exceeds current borrowed inventory.');

                $newStock    = (int) $item['quantity_stock'] + $quantity;
                $newBorrowed = (int) $item['quantity_borrowed'] - $quantity;
                $status      = compute_item_status($newStock);

                $stmt = $conn->prepare("UPDATE items SET quantity_stock = ?, quantity_borrowed = ?, item_status = ? WHERE item_id = ?");
                $stmt->bind_param('iisi', $newStock, $newBorrowed, $status, $item_id);
                $stmt->execute();
                $stmt->close();

                $type = 'return';
                $stmt = $conn->prepare("
                    INSERT INTO transactions (transaction_type, item_id, client_id, staff_id, quantity, item_status_details, remarks)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->bind_param('siiiiss', $type, $item_id, $client_id, $staff_id, $quantity, $item_status_details, $remarks);
                $stmt->execute();
                $txId = $stmt->insert_id;
                $stmt->close();

                log_action($conn, $staff_id, 'Return item', 'transactions', $txId,
                    'Returned quantity ' . $quantity . ' for item_id ' . $item_id . ' by client_id ' . $client_id);

                $conn->commit();
                set_flash('success', 'Return transaction saved — ' . $quantity . ' unit(s) returned successfully.');
            } catch (Throwable $e) {
                $conn->rollback();
                set_flash('error', $e->getMessage());
            }
        } else {
            set_flash('error', 'Please scan the item barcode first and complete all required fields.');
        }

        header('Location: /item_inventory_system/staff/returns.php');
        exit();
    }
}

/* ═══════════════════════════════════════
   GET — fetch return history
═══════════════════════════════════════ */
$q = trim($_GET['q'] ?? '');

$sql = "
    SELECT
        t.transacted_at,
        COALESCE(c.full_name, 'N/A') AS client_name,
        u.full_name AS staff_name,
        i.item_name,
        i.serial_barcode,
        i.image_path,
        cat.category_name,
        t.item_status_details,
        t.quantity
    FROM transactions t
    LEFT JOIN clients c ON c.client_id = t.client_id
    JOIN users u ON u.user_id = t.staff_id
    JOIN items i ON i.item_id = t.item_id
    JOIN categories cat ON cat.category_id = i.category_id
    WHERE t.transaction_type = 'return'
";
$params = []; $types = '';
if ($q !== '') {
    $sql .= " AND (
        c.full_name LIKE ? OR u.full_name LIKE ? OR i.item_name LIKE ?
        OR i.serial_barcode LIKE ? OR cat.category_name LIKE ? OR t.item_status_details LIKE ?
    )";
    $like   = "%{$q}%";
    $params = [$like, $like, $like, $like, $like, $like];
    $types  = 'ssssss';
}
$sql .= " ORDER BY t.transaction_id DESC";
$stmt = $conn->prepare($sql);
if ($types !== '') $stmt->bind_param($types, ...$params);
$stmt->execute();
$rows = $stmt->get_result();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/nav.php';
require_once __DIR__ . '/../includes/notifications.php';
?>

<style>
    .search-bar { display:grid; grid-template-columns:1fr auto; gap:.75rem; }
    @media(max-width:480px) { .search-bar { grid-template-columns:1fr; } }

    .form-label { display:block; font-size:13px; font-weight:600; margin-bottom:.5rem; color:var(--ink-soft); }
    .form-group  { margin-bottom:1rem; }

    .modal-grid { display:grid; grid-template-columns:1fr 1fr; gap:1rem; }
    @media(max-width:520px) { .modal-grid { grid-template-columns:1fr; } }

    /* Item preview card inside the return modal */
    .item-preview {
        border-radius: var(--radius);
        border: 1px solid var(--border);
        background: var(--surface-2);
        padding: 1rem;
        display: flex; gap: 1rem; align-items: flex-start;
    }
    .item-preview-thumb {
        flex-shrink: 0; width: 80px; height: 80px;
        border-radius: 10px; border: 1px solid var(--border);
        background: var(--surface-3); overflow: hidden;
        display: flex; align-items: center; justify-content: center;
    }
    .item-preview-thumb img { width:100%; height:100%; object-fit:cover; }
    .item-preview-label { font-size:12px; color:var(--ink-faint); margin-bottom:.1rem; }
    .item-preview-value { font-size:13px; font-weight:500; }

    /* Table thumbnails */
    .thumb-sm {
        width:40px; height:40px; border-radius:8px;
        border:1px solid var(--border); object-fit:cover; display:block;
    }
    .thumb-empty {
        width:40px; height:40px; border-radius:8px;
        border:1px solid var(--border); background:var(--surface-3);
        display:flex; align-items:center; justify-content:center;
        font-size:10px; color:var(--ink-faint);
    }
</style>

<div style="max-width:1280px; margin:0 auto; padding:2rem 1.5rem;">

    <!-- Page header -->
    <div class="page-header" style="display:flex; align-items:flex-start; justify-content:space-between; flex-wrap:wrap; gap:1rem;">
        <div>
            <h1 class="page-title">Return History</h1>
            <p class="page-subtitle">Filter returns by client, staff, item, barcode, category, or status details.</p>
        </div>
        <button type="button" onclick="openReturnModal()" class="btn btn-primary">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                <polyline points="1 4 1 10 7 10"/>
                <path d="M3.51 15a9 9 0 1 0 .49-3.82"/>
            </svg>
            Return Item
        </button>
    </div>

    <!-- Search -->
    <div class="card" style="padding:1.25rem 1.5rem; margin-bottom:1.5rem;">
        <form method="GET" class="search-bar">
            <input name="q" value="<?php echo e($q); ?>" class="form-input"
                   placeholder="Search client, staff, item, barcode, category, or status details…">
            <button class="btn btn-primary" type="submit">Search</button>
        </form>
    </div>

    <!-- Results table -->
    <div class="card" style="padding:1.5rem;">
        <?php if ($q): ?>
            <p style="font-size:13px; color:var(--ink-soft); margin-bottom:1rem;">
                Results for "<strong><?php echo e($q); ?></strong>"
            </p>
        <?php endif; ?>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Date & Time</th>
                        <th>Client</th>
                        <th>Staff</th>
                        <th>Item</th>
                        <th>Barcode</th>
                        <th>Category</th>
                        <th>Status Details</th>
                        <th>Qty</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $rows->fetch_assoc()): ?>
                    <tr>
                        <td>
                            <?php if (!empty($row['image_path'])): ?>
                                <img src="/item_inventory_system/<?php echo e($row['image_path']); ?>"
                                     alt="<?php echo e($row['item_name']); ?>" class="thumb-sm">
                            <?php else: ?>
                                <div class="thumb-empty">—</div>
                            <?php endif; ?>
                        </td>
                        <td class="mono" style="font-size:12px; white-space:nowrap; color:var(--ink-soft);">
                            <?php echo e($row['transacted_at']); ?>
                        </td>
                        <td style="font-weight:500;"><?php echo e($row['client_name']); ?></td>
                        <td style="color:var(--ink-soft);"><?php echo e($row['staff_name']); ?></td>
                        <td style="font-weight:500;"><?php echo e($row['item_name']); ?></td>
                        <td class="mono" style="font-size:12px;"><?php echo e($row['serial_barcode']); ?></td>
                        <td style="color:var(--ink-soft);"><?php echo e($row['category_name']); ?></td>
                        <td>
                            <?php if ($row['item_status_details']): ?>
                                <span class="badge status-low_stock"><?php echo e($row['item_status_details']); ?></span>
                            <?php else: ?>
                                <span style="color:var(--ink-faint);">—</span>
                            <?php endif; ?>
                        </td>
                        <td style="font-weight:700; color:var(--success);"><?php echo (int) $row['quantity']; ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ═══════════════════════════════════════
     RETURN MODAL
═══════════════════════════════════════ -->
<div id="returnModal" class="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="returnModalTitle">
    <div class="modal-box modal-box-lg" style="max-height:90vh; overflow-y:auto;">

        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:1.5rem;">
            <h2 id="returnModalTitle" style="font-size:1.125rem; font-weight:700;">Return Item</h2>
            <button type="button" onclick="closeReturnModal()" class="btn btn-ghost btn-sm">✕ Close</button>
        </div>

        <form method="POST" class="modal-grid">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action"    value="return">
            <input type="hidden" name="item_id"   id="return_item_id">
            <input type="hidden" name="client_id" id="return_client_id">

            <!-- Barcode row -->
            <div class="form-group" style="grid-column:1/-1;">
                <label class="form-label">Scan or Enter Barcode</label>
                <div style="display:flex; gap:.5rem;">
                    <input id="return_barcode" class="form-input" placeholder="Scan or type a barcode…">
                    <button type="button" onclick="openScanner('return_barcode','return')"
                            class="btn btn-accent" style="white-space:nowrap;">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <rect x="1" y="4" width="5" height="16" rx="1"/>
                            <rect x="8" y="4" width="2" height="16" rx="1"/>
                            <rect x="12" y="4" width="4" height="16" rx="1"/>
                            <rect x="18" y="4" width="5" height="16" rx="1"/>
                        </svg>
                        Scan
                    </button>
                    <button type="button" onclick="lookupReturnBarcode()"
                            class="btn btn-primary" style="white-space:nowrap;">Find</button>
                </div>
            </div>

            <!-- Item preview (hidden until lookup) -->
            <div id="return_item_info_wrap" class="form-group" style="grid-column:1/-1; display:none;">
                <div class="item-preview">
                    <div class="item-preview-thumb">
                        <img id="return_item_image" src="" alt="" style="display:none;">
                        <span id="return_item_image_placeholder"
                              style="font-size:11px; color:var(--ink-faint);">No Image</span>
                    </div>
                    <div style="flex:1;">
                        <div style="font-weight:700; font-size:1rem; margin-bottom:.5rem;" id="return_item_name">—</div>
                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:.375rem .875rem;">
                            <div>
                                <div class="item-preview-label">Code</div>
                                <div class="item-preview-value mono" id="return_item_code">—</div>
                            </div>
                            <div>
                                <div class="item-preview-label">Barcode</div>
                                <div class="item-preview-value mono" id="return_item_barcode">—</div>
                            </div>
                            <div>
                                <div class="item-preview-label">Category</div>
                                <div class="item-preview-value" id="return_item_category">—</div>
                            </div>
                            <div>
                                <div class="item-preview-label">Currently Borrowed</div>
                                <div class="item-preview-value"
                                     style="color:var(--warning); font-weight:700;"
                                     id="return_item_borrowed">0</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Borrower selector (hidden until lookup) -->
            <div id="return_client_wrap" class="form-group" style="grid-column:1/-1; display:none;">
                <label class="form-label">Borrower</label>
                <select id="return_client_select" class="form-input"></select>
                <p style="font-size:12px; color:var(--ink-faint); margin-top:.375rem;">
                    The first matched borrower is selected automatically.
                </p>
            </div>

            <!-- Quantity -->
            <div class="form-group">
                <label class="form-label">Quantity <span style="color:var(--danger);">*</span></label>
                <input type="number" name="quantity" id="return_quantity"
                       min="1" class="form-input" required placeholder="0">
            </div>

            <!-- Status details -->
            <div class="form-group">
                <label class="form-label">Item Status Details</label>
                <input name="item_status_details" class="form-input"
                       placeholder="Good, damaged, incomplete…">
            </div>

            <!-- Remarks -->
            <div class="form-group" style="grid-column:1/-1;">
                <label class="form-label">Remarks</label>
                <input name="remarks" class="form-input" placeholder="Optional remarks">
            </div>

            <!-- Submit -->
            <div style="grid-column:1/-1;">
                <button class="btn btn-primary" type="submit"
                        style="width:100%; padding:.875rem; font-size:15px;">
                    Save Return Transaction
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ═══════════════════════════════════════
     SCANNER MODAL
═══════════════════════════════════════ -->
<div id="scannerModal" class="modal-overlay" role="dialog" aria-modal="true">
    <div class="modal-box" style="max-width:500px;">
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:1.25rem;">
            <h2 style="font-size:1.125rem; font-weight:700;">Scan Barcode</h2>
            <button onclick="closeScanner()" class="btn btn-ghost btn-sm">✕ Close</button>
        </div>
        <div id="reader" style="width:100%;"></div>
        <p style="font-size:13px; color:var(--ink-faint); margin-top:.875rem; text-align:center;">
            Point the camera at the barcode.
        </p>
    </div>
</div>

<script>
let html5QrCode        = null;
let currentTargetInput = null;
let currentLookupMode  = null;

/* ── Modal open / close ── */
function openReturnModal() {
    document.getElementById('returnModal').classList.add('is-open');
}
function closeReturnModal() {
    document.getElementById('returnModal').classList.remove('is-open');
    // Reset so a re-open always starts clean
    document.getElementById('return_barcode').value               = '';
    document.getElementById('return_item_id').value               = '';
    document.getElementById('return_client_id').value             = '';
    document.getElementById('return_quantity').value              = '';
    document.getElementById('return_item_info_wrap').style.display = 'none';
    document.getElementById('return_client_wrap').style.display   = 'none';
}

/* ── Barcode lookup ── */
async function lookupReturnBarcode() {
    const barcode = document.getElementById('return_barcode').value.trim();
    if (!barcode) {
        showAlert('warning', 'No Barcode', 'Please scan or enter a barcode first.');
        return;
    }

    const res  = await fetch(
        `/item_inventory_system/staff/returns.php?ajax=return_lookup&barcode=${encodeURIComponent(barcode)}`
    );
    const data = await res.json();

    if (!data.ok) {
        showAlert('error', 'Not Found', data.message || 'Unable to find return information.');
        return;
    }

    /* Item preview */
    document.getElementById('return_item_id').value             = data.item.item_id;
    document.getElementById('return_item_name').textContent     = data.item.item_name;
    document.getElementById('return_item_code').textContent     = data.item.item_code;
    document.getElementById('return_item_barcode').textContent  = data.item.serial_barcode;
    document.getElementById('return_item_category').textContent = data.item.category_name;
    document.getElementById('return_item_borrowed').textContent = data.item.quantity_borrowed;
    document.getElementById('return_item_info_wrap').style.display = 'block';

    const img = document.getElementById('return_item_image');
    const ph  = document.getElementById('return_item_image_placeholder');
    if (data.item.image_path) {
        img.src           = `/item_inventory_system/${data.item.image_path}`;
        img.style.display = 'block';
        ph.style.display  = 'none';
    } else {
        img.src           = '';
        img.style.display = 'none';
        ph.style.display  = 'block';
    }

    /* Borrower dropdown */
    const select = document.getElementById('return_client_select');
    select.innerHTML = '';
    data.clients.forEach((client, index) => {
        const opt       = document.createElement('option');
        opt.value       = client.client_id;
        opt.textContent = `${client.full_name} — Outstanding: ${client.outstanding_qty}`;
        if (index === 0) opt.selected = true;
        select.appendChild(opt);
    });
    document.getElementById('return_client_id').value           = data.auto_client_id;
    document.getElementById('return_client_wrap').style.display = 'block';

    /* Pre-fill quantity */
    const qty = document.getElementById('return_quantity');
    qty.value = data.suggested_qty;
    qty.max   = data.suggested_qty;
}

/* Update client_id + qty cap when borrower changes */
document.addEventListener('change', function (e) {
    if (e.target && e.target.id === 'return_client_select') {
        document.getElementById('return_client_id').value = e.target.value;
        const text  = e.target.options[e.target.selectedIndex]?.textContent || '';
        const match = text.match(/Outstanding:\s*(\d+)/);
        if (match) {
            const outstanding = parseInt(match[1], 10);
            const qty = document.getElementById('return_quantity');
            qty.value = outstanding;
            qty.max   = outstanding;
        }
    }
});

/* ── Camera scanner ── */
function openScanner(targetInputId, lookupMode = null) {
    currentTargetInput = targetInputId;
    currentLookupMode  = lookupMode;

    document.getElementById('scannerModal').classList.add('is-open');

    html5QrCode = new Html5Qrcode('reader');
    Html5Qrcode.getCameras()
        .then(devices => {
            if (devices && devices.length) {
                html5QrCode.start(
                    { facingMode: 'environment' },
                    { fps: 10, qrbox: 250 },
                    async (decodedText) => {
                        const input = document.getElementById(currentTargetInput);
                        if (input) input.value = decodedText;
                        closeScanner();
                        if (currentLookupMode === 'return') await lookupReturnBarcode();
                    },
                    () => {}
                );
            } else {
                showAlert('warning', 'No Camera', 'No camera device was found.');
            }
        })
        .catch(() => showAlert('error', 'Camera Error', 'Unable to access the camera.'));
}

function closeScanner() {
    document.getElementById('scannerModal').classList.remove('is-open');
    if (html5QrCode) {
        html5QrCode.stop()
            .then(() => { html5QrCode.clear(); html5QrCode = null; })
            .catch(() => {});
    }
    document.getElementById('reader').innerHTML = '';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>