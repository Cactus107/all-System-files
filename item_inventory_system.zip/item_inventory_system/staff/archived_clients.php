<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/csrf.php';
require_role(['staff','admin']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'restore') {
        try {
            $client_id = (int)($_POST['client_id'] ?? 0);
            if ($client_id <= 0) {
                throw new RuntimeException('Invalid client ID.');
            }

            $stmt = $conn->prepare("SELECT full_name FROM clients WHERE client_id = ? LIMIT 1");
            $stmt->bind_param('i', $client_id);
            $stmt->execute();
            $client = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$client) {
                throw new RuntimeException('Client not found.');
            }

            $stmt = $conn->prepare("UPDATE clients SET is_active = 1 WHERE client_id = ?");
            $stmt->bind_param('i', $client_id);
            $stmt->execute();
            $stmt->close();
            log_action($conn, (int)$_SESSION['user_id'], 'Restore client', 'clients', $client_id, 'Restored client: ' . $client['full_name']);
            set_flash('success', 'Client "' . $client['full_name'] . '" has been restored to active status.');
        } catch (RuntimeException $e) {
            set_flash('error', $e->getMessage());
        } catch (Exception $e) {
            error_log('Client restore error: ' . $e->getMessage());
            set_flash('error', 'An unexpected error occurred. Please try again.');
        }
        header('Location: /item_inventory_system/staff/archived_clients.php'); exit();
    }

    if ($action === 'delete_permanently') {
        try {
            $client_id = (int)($_POST['client_id'] ?? 0);
            if ($client_id <= 0) {
                throw new RuntimeException('Invalid client ID.');
            }

            $stmt = $conn->prepare("SELECT full_name FROM clients WHERE client_id = ? LIMIT 1");
            $stmt->bind_param('i', $client_id);
            $stmt->execute();
            $client = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$client) {
                throw new RuntimeException('Client not found.');
            }

            // Allow permanent deletion of archived clients, but still check for active transactions
            $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM transactions WHERE client_id = ?");
            $stmt->bind_param('i', $client_id);
            $stmt->execute();
            $usage = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if ((int)($usage['total'] ?? 0) > 0) {
                // For archived clients, we still prevent deletion if they have transactions
                // This maintains data integrity
                throw new RuntimeException('Cannot permanently delete this client — they have existing transactions. Transaction history must be preserved.');
            }

            $stmt = $conn->prepare("DELETE FROM clients WHERE client_id = ?");
            $stmt->bind_param('i', $client_id);
            $stmt->execute();
            $stmt->close();
            log_action($conn, (int)$_SESSION['user_id'], 'Permanently delete client', 'clients', $client_id, 'Permanently deleted client: ' . $client['full_name']);
            set_flash('success', 'Client permanently deleted from the system.');
        } catch (RuntimeException $e) {
            set_flash('error', $e->getMessage());
        } catch (Exception $e) {
            error_log('Client permanent deletion error: ' . $e->getMessage());
            set_flash('error', 'An unexpected error occurred. Please try again.');
        }
        header('Location: /item_inventory_system/staff/archived_clients.php'); exit();
    }
}

$q = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = 12; // Show 12 clients per page
$offset = ($page - 1) * $per_page;

$sql = "SELECT * FROM clients WHERE is_active = 0";
$count_sql = "SELECT COUNT(*) as total FROM clients WHERE is_active = 0";
$params = []; $types = '';

if ($q !== '') {
    $sql .= " AND (full_name LIKE ? OR address LIKE ? OR contact_no LIKE ? OR email LIKE ?)";
    $count_sql .= " AND (full_name LIKE ? OR address LIKE ? OR contact_no LIKE ? OR email LIKE ?)";
    $like = "%{$q}%";
    $params = [$like, $like, $like, $like];
    $types = 'ssss';
}

$sql .= " ORDER BY client_id DESC LIMIT ? OFFSET ?";
$params[] = $per_page;
$params[] = $offset;
$types .= 'ii';

$stmt = $conn->prepare($sql);
if ($types !== '') $stmt->bind_param($types, ...$params);
$stmt->execute();
$clients = $stmt->get_result();

// Get total count for pagination
$count_stmt = $conn->prepare($count_sql);
if ($q !== '') {
    $count_stmt->bind_param('ssss', $like, $like, $like, $like);
}
$count_stmt->execute();
$total_clients = (int)$count_stmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($total_clients / $per_page);
$count_stmt->close();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/nav.php';
require_once __DIR__ . '/../includes/notifications.php';
?>

<style>
    .client-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:1rem; }
    .client-card { background:var(--surface); border-radius:var(--radius-lg); border:1px solid var(--border); box-shadow:var(--shadow-sm); padding:1.25rem 1.375rem; transition:box-shadow .15s,transform .15s; }
    .client-card:hover { box-shadow:var(--shadow); transform:translateY(-2px); }
    .client-card.archived-card { border-color: var(--warning-border); background: var(--warning-soft); }
    .modal-overlay.is-open { opacity:1; pointer-events:all; }
    .form-label { display:block; font-size:13px; font-weight:600; margin-bottom:.5rem; color:var(--ink-soft); }
    .form-group { margin-bottom:1rem; }
    .modal-grid { display:grid; grid-template-columns:1fr 1fr; gap:1rem; }
    @media (max-width:520px) { .modal-grid { grid-template-columns:1fr; } }
    .search-bar { display:grid; grid-template-columns:1fr auto; gap:.75rem; }
    @media (max-width:480px) { .search-bar { grid-template-columns:1fr; } }

    /* Form validation styles */
    .form-input:invalid { border-color: var(--danger); }
    .form-input:valid { border-color: var(--success); }
    .form-input:placeholder-shown { border-color: var(--border); }

    /* Pagination styles */
    .pagination { display:flex; gap:.5rem; align-items:center; }
    .pagination .btn { min-width:2.5rem; text-align:center; }
</style>

<div style="max-width:1280px;margin:0 auto;padding:2rem 1.5rem;">
    <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem;">
        <div>
            <h1 class="page-title">Archived Clients</h1>
            <p class="page-subtitle">View and manage previously archived clients. These clients had transaction history that required preservation.</p>
        </div>
        <div style="display:flex;gap:.75rem;flex-wrap:wrap;">
            <a href="clients.php" class="btn btn-ghost">
                ← Back to Active Clients
            </a>
        </div>
    </div>

    <!-- Search -->
    <div class="card" style="padding:1.25rem 1.5rem;margin-bottom:1.5rem;">
        <form method="GET" class="search-bar">
            <input name="q" value="<?php echo e($q); ?>" class="form-input" placeholder="Search archived clients by name, contact, email, or address…">
            <button class="btn btn-primary">Search</button>
        </form>
        <?php if ($q !== ''): ?>
        <div style="margin-top:1rem;font-size:14px;color:var(--ink-faint);">
            Found <?php echo $total_clients; ?> archived client<?php echo $total_clients !== 1 ? 's' : ''; ?> matching "<?php echo e($q); ?>"
            <a href="archived_clients.php" style="color:var(--accent);text-decoration:underline;">Clear search</a>
        </div>
        <?php endif; ?>
    </div>

    <!-- Client Cards -->
    <div class="client-grid">
        <?php while ($row = $clients->fetch_assoc()):
            // Check if client has transactions
            $stmt = $conn->prepare("SELECT COUNT(*) as transaction_count FROM transactions WHERE client_id = ?");
            $stmt->bind_param('i', $row['client_id']);
            $stmt->execute();
            $has_transactions = (int)$stmt->get_result()->fetch_assoc()['transaction_count'] > 0;
            $stmt->close();
        ?>
        <div class="client-card archived-card">
            <div style="margin-bottom:.875rem;">
                <div style="font-size:1rem;font-weight:700;margin-bottom:.25rem;"><?php echo e($row['full_name']); ?></div>
                <div style="font-size:13px;color:var(--ink-faint);"><?php echo e($row['email'] ?: '—'); ?></div>
                <div style="font-size:12px;color:var(--warning);font-weight:600;margin-top:.25rem;">ARCHIVED</div>
            </div>
            <div style="display:flex;flex-direction:column;gap:.375rem;font-size:13px;color:var(--ink-soft);margin-bottom:1.125rem;">
                <div><span style="font-weight:600;color:var(--ink);">Address:</span> <?php echo e($row['address'] ?: '—'); ?></div>
                <div><span style="font-weight:600;color:var(--ink);">Contact:</span> <?php echo e($row['contact_no'] ?: '—'); ?></div>
            </div>
            <div style="display:flex;gap:.5rem;flex-wrap:wrap;">
                <a href="/item_inventory_system/staff/history.php?q=<?php echo urlencode($row['full_name']); ?>" class="btn btn-ghost btn-sm">
                    View History
                </a>
                <form method="POST"
                      data-confirm="This will restore <?php echo htmlspecialchars($row['full_name'], ENT_QUOTES, 'UTF-8'); ?> to active status."
                      data-confirm-title="Restore Client?"
                      data-confirm-label="Restore"
                      data-confirm-type="success">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="restore">
                    <input type="hidden" name="client_id" value="<?php echo (int)$row['client_id']; ?>">
                    <button class="btn btn-success btn-sm" type="submit">Restore</button>
                </form>
                <?php if (!$has_transactions): ?>
                <form method="POST"
                      data-confirm="This will permanently and irreversibly delete <?php echo htmlspecialchars($row['full_name'], ENT_QUOTES, 'UTF-8'); ?> from the system. This action cannot be undone."
                      data-confirm-title="Permanently Delete?"
                      data-confirm-label="Delete Forever"
                      data-confirm-type="danger">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="action" value="delete_permanently">
                    <input type="hidden" name="client_id" value="<?php echo (int)$row['client_id']; ?>">
                    <button class="btn btn-danger btn-sm" type="submit">Delete Permanently</button>
                </form>
                <?php else: ?>
                <div style="font-size:12px;color:var(--ink-faint);padding:.25rem .5rem;background:var(--surface-3);border-radius:4px;">
                    Has transaction history - Cannot be deleted
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endwhile; ?>
    </div>

    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
    <div style="display:flex;justify-content:center;margin-top:2rem;">
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?><?php echo $q ? '&q=' . urlencode($q) : ''; ?>" class="btn btn-ghost btn-sm">← Previous</a>
            <?php endif; ?>

            <?php
            $start_page = max(1, $page - 2);
            $end_page = min($total_pages, $page + 2);
            if ($start_page > 1): ?>
                <a href="?page=1<?php echo $q ? '&q=' . urlencode($q) : ''; ?>" class="btn btn-ghost btn-sm">1</a>
                <?php if ($start_page > 2): ?><span style="padding:0 .5rem;color:var(--ink-faint);">…</span><?php endif; ?>
            <?php endif; ?>

            <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                <a href="?page=<?php echo $i; ?><?php echo $q ? '&q=' . urlencode($q) : ''; ?>"
                   class="btn <?php echo $i === $page ? 'btn-primary' : 'btn-ghost'; ?> btn-sm">
                    <?php echo $i; ?>
                </a>
            <?php endfor; ?>

            <?php if ($end_page < $total_pages): ?>
                <?php if ($end_page < $total_pages - 1): ?><span style="padding:0 .5rem;color:var(--ink-faint);">…</span><?php endif; ?>
                <a href="?page=<?php echo $total_pages; ?><?php echo $q ? '&q=' . urlencode($q) : ''; ?>" class="btn btn-ghost btn-sm"><?php echo $total_pages; ?></a>
            <?php endif; ?>

            <?php if ($page < $total_pages): ?>
                <a href="?page=<?php echo $page + 1; ?><?php echo $q ? '&q=' . urlencode($q) : ''; ?>" class="btn btn-ghost btn-sm">Next →</a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($total_clients === 0): ?>
    <div style="text-align:center;padding:3rem 1rem;color:var(--ink-faint);">
        <div style="font-size:3rem;margin-bottom:1rem;">📦</div>
        <div style="font-size:1.125rem;font-weight:600;margin-bottom:.5rem;">
            <?php echo $q ? 'No archived clients found matching your search.' : 'No archived clients.'; ?>
        </div>
        <div style="font-size:14px;">
            <?php echo $q ? 'Try adjusting your search terms.' : 'Archived clients will appear here when clients with transaction history are archived from the active clients page.'; ?>
        </div>
        <?php if (!$q): ?>
        <div style="margin-top:1rem;">
            <a href="clients.php" class="btn btn-ghost btn-sm">View Active Clients</a>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>