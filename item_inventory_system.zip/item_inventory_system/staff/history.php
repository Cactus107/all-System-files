<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/csrf.php';
require_role(['staff','admin']);

// Ajax lookup
if (isset($_GET['ajax']) && $_GET['ajax'] === 'borrow_lookup') {
    header('Content-Type: application/json; charset=utf-8');
    $barcode = trim($_GET['barcode'] ?? '');
    if ($barcode === '') { echo json_encode(['ok'=>false,'message'=>'Barcode is required.']); exit(); }
    $stmt = $conn->prepare("SELECT i.item_id,i.item_name,i.item_code,i.serial_barcode,i.quantity_stock,i.quantity_borrowed,i.item_status,i.image_path,c.category_name FROM items i JOIN categories c ON c.category_id=i.category_id WHERE i.serial_barcode=? OR i.item_code=? LIMIT 1");
    $stmt->bind_param('ss',$barcode,$barcode); $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$item) { echo json_encode(['ok'=>false,'message'=>'No item found for this barcode.']); exit(); }
    echo json_encode(['ok'=>true,'item'=>['item_id'=>(int)$item['item_id'],'item_name'=>$item['item_name'],'item_code'=>$item['item_code'],'serial_barcode'=>$item['serial_barcode'],'category_name'=>$item['category_name'],'quantity_stock'=>(int)$item['quantity_stock'],'quantity_borrowed'=>(int)$item['quantity_borrowed'],'item_status'=>$item['item_status'],'image_path'=>$item['image_path']]]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (($_POST['action'] ?? '') === 'borrow') {
        $item_id   = (int)($_POST['item_id'] ?? 0);
        $client_id = (int)($_POST['client_id'] ?? 0);
        $quantity  = (int)($_POST['quantity'] ?? 0);
        $remarks   = trim($_POST['remarks'] ?? '');
        $staff_id  = (int)$_SESSION['user_id'];
        if ($item_id > 0 && $client_id > 0 && $quantity > 0) {
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("SELECT item_name,quantity_stock,quantity_borrowed FROM items WHERE item_id=? FOR UPDATE");
                $stmt->bind_param('i',$item_id); $stmt->execute();
                $item = $stmt->get_result()->fetch_assoc(); $stmt->close();
                if (!$item) throw new Exception('Item not found.');
                if ((int)$item['quantity_stock'] < $quantity) throw new Exception('Insufficient stock. Only ' . $item['quantity_stock'] . ' available.');
                $newStock    = (int)$item['quantity_stock'] - $quantity;
                $newBorrowed = (int)$item['quantity_borrowed'] + $quantity;
                $status      = compute_item_status($newStock);
                $stmt = $conn->prepare("UPDATE items SET quantity_stock=?,quantity_borrowed=?,item_status=? WHERE item_id=?");
                $stmt->bind_param('iisi',$newStock,$newBorrowed,$status,$item_id); $stmt->execute(); $stmt->close();
                $type = 'borrow';
                $stmt = $conn->prepare("INSERT INTO transactions (transaction_type,item_id,client_id,staff_id,quantity,remarks) VALUES (?,?,?,?,?,?)");
                $stmt->bind_param('siiiis',$type,$item_id,$client_id,$staff_id,$quantity,$remarks);
                $stmt->execute(); $txId = $stmt->insert_id; $stmt->close();
                log_action($conn,$staff_id,'Borrow item','transactions',$txId,'Borrowed qty '.$quantity.' for item_id '.$item_id);
                $conn->commit();
                set_flash('success', 'Borrow transaction saved — ' . $quantity . ' unit(s) of "' . $item['item_name'] . '".');
            } catch (Throwable $e) { $conn->rollback(); set_flash('error', $e->getMessage()); }
        } else {
            set_flash('error', 'Please scan the item barcode and fill all required fields.');
        }
        header('Location: /item_inventory_system/staff/history.php'); exit();
    }
}

$q = trim($_GET['q'] ?? '');
$clients = $conn->query("SELECT client_id, full_name FROM clients ORDER BY full_name ASC");

$sql = "SELECT t.transacted_at,u.full_name AS staff_name,c.full_name AS client_name,i.item_name,i.serial_barcode,i.image_path,cat.category_name,i.quantity_stock,t.quantity AS quantity_borrowed FROM transactions t JOIN users u ON u.user_id=t.staff_id LEFT JOIN clients c ON c.client_id=t.client_id JOIN items i ON i.item_id=t.item_id JOIN categories cat ON cat.category_id=i.category_id WHERE t.transaction_type='borrow'";
$params=[]; $types='';
if ($q !== '') {
    $sql .= " AND (u.full_name LIKE ? OR c.full_name LIKE ? OR i.item_name LIKE ? OR i.serial_barcode LIKE ? OR cat.category_name LIKE ?)";
    $like="%{$q}%"; $params=[$like,$like,$like,$like,$like]; $types='sssss';
}
$sql .= " ORDER BY t.transaction_id DESC";
$stmt = $conn->prepare($sql);
if ($types !== '') $stmt->bind_param($types,...$params);
$stmt->execute(); $rows = $stmt->get_result();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/nav.php';
require_once __DIR__ . '/../includes/notifications.php';
?>


<style>
    .search-bar{display:grid;grid-template-columns:1fr auto;gap:.75rem;}
    @media(max-width:480px){.search-bar{grid-template-columns:1fr;}}
    .form-label{display:block;font-size:13px;font-weight:600;margin-bottom:.5rem;color:var(--ink-soft);}
    .form-group{margin-bottom:1rem;}
    .modal-grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem;}
    @media(max-width:520px){.modal-grid{grid-template-columns:1fr;}}
    .item-info-card{border-radius:var(--radius);border:1px solid var(--border);background:var(--surface-2);padding:1rem;}
    .item-info-card img{width:80px;height:80px;object-fit:cover;border-radius:8px;border:1px solid var(--border);}
    .title-icon-box { background:var(--surface-3); color:var(--ink-soft); padding:0.75rem; border-radius:12px; display:flex; align-items:center; justify-content:center; border:1px solid var(--border); }
    .rotate-180 { transform: rotate(180deg); }
</style>

<div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
    <div class="page-header" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;">
        <div style="display:flex;align-items:center;gap:1rem;">
            <div class="title-icon-box">
                <i class="fa-solid fa-clipboard" aria-hidden="true" style="font-size:24px;"></i>
            </div>
            <div>
                <h1 class="page-title">Borrow History</h1>
                <p class="page-subtitle">Filter item releases by staff, client, item, barcode, or category.</p>
            </div>
        </div>
        <button type="button" onclick="openBorrowModal()" class="btn btn-primary">
            <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
            Borrow Item
        </button>
    </div>

    <div class="card" style="padding:1.25rem 1.5rem;margin-bottom:1.5rem;">
        <form method="GET" class="search-bar">
            <input name="q" value="<?php echo e($q); ?>" class="form-input" placeholder="Search staff, client, item, barcode, or category…">
            <button class="btn btn-primary">Search</button>
        </form>
    </div>

    <div class="card" style="padding:1.5rem;">
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Date & Time</th>
                        <th>Staff</th>
                        <th>Client</th>
                        <th>Item</th>
                        <th>Barcode</th>
                        <th>Category</th>
                        <th>Stock</th>
                        <th>Qty Borrowed</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $rows->fetch_assoc()): ?>
                    <tr>
                        <td>
                            <?php if (!empty($row['image_path'])): ?>
                                <img src="/item_inventory_system/<?php echo e($row['image_path']); ?>" alt="" style="width:40px;height:40px;object-fit:cover;border-radius:8px;border:1px solid var(--border);">
                            <?php else: ?>
                                <div style="width:40px;height:40px;border-radius:8px;background:var(--surface-3);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:10px;color:var(--ink-faint);">—</div>
                            <?php endif; ?>
                        </td>
                        <td class="mono" style="font-size:12px;white-space:nowrap;color:var(--ink-soft);"><?php echo e($row['transacted_at']); ?></td>
                        <td style="font-weight:500;"><?php echo e($row['staff_name']); ?></td>
                        <td><?php echo e($row['client_name'] ?: 'N/A'); ?></td>
                        <td style="font-weight:500;"><?php echo e($row['item_name']); ?></td>
                        <td class="mono" style="font-size:12px;"><?php echo e($row['serial_barcode']); ?></td>
                        <td style="color:var(--ink-soft);"><?php echo e($row['category_name']); ?></td>
                        <td style="font-weight:600;"><?php echo (int)$row['quantity_stock']; ?></td>
                        <td style="font-weight:600;color:var(--warning);"><?php echo (int)$row['quantity_borrowed']; ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="borrowModal" class="modal-overlay">
    <div class="modal-box modal-box-lg" style="max-height:90vh;overflow-y:auto;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;">
            <h2 style="font-size:1.125rem;font-weight:700;">Borrow Item</h2>
            <button type="button" onclick="closeBorrowModal()" class="btn btn-ghost btn-sm">✕ Close</button>
        </div>
        <form method="POST" class="modal-grid">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="borrow">
            <input type="hidden" name="item_id" id="borrow_item_id">

            <div class="form-group" style="grid-column:1/-1">
                <label class="form-label">Scan or Enter Barcode</label>
                <div style="display:flex;gap:.5rem;">
                    <input id="borrow_barcode" class="form-input" placeholder="Scan barcode first…">
                    <button type="button" onclick="openScanner('borrow_barcode','borrow')" class="btn btn-accent" style="white-space:nowrap;">
                        <i class="fa-solid fa-barcode" aria-hidden="true"></i>
                        Scan
                    </button>
                    <button type="button" onclick="lookupBorrowBarcode()" class="btn btn-primary" style="white-space:nowrap;">Find</button>
                </div>
            </div>

            <div class="form-group" style="grid-column:1/-1;display:none;" id="borrow_item_info_wrap">
                <div class="item-info-card" style="display:flex;gap:1rem;align-items:flex-start;">
                    <div style="flex-shrink:0;width:80px;height:80px;border-radius:8px;border:1px solid var(--border);background:var(--surface-3);overflow:hidden;display:flex;align-items:center;justify-content:center;">
                        <img id="borrow_item_image" src="" style="display:none;width:100%;height:100%;object-fit:cover;" alt="">
                        <span id="borrow_item_image_placeholder" style="font-size:11px;color:var(--ink-faint);">No Image</span>
                    </div>
                    <div style="flex:1;">
                        <div style="font-weight:700;font-size:1rem;" id="borrow_item_name">—</div>
                        <div style="font-size:12px;color:var(--ink-faint);margin-top:.25rem;">Code: <span id="borrow_item_code">—</span></div>
                        <div style="font-size:12px;color:var(--ink-faint);">Barcode: <span id="borrow_item_barcode">—</span></div>
                        <div style="font-size:12px;color:var(--ink-faint);">Category: <span id="borrow_item_category">—</span></div>
                        <div style="font-size:13px;font-weight:600;margin-top:.375rem;">Available: <span id="borrow_item_stock" style="color:var(--success);">0</span></div>
                    </div>
                </div>
            </div>

            <div class="form-group" style="grid-column:1/-1">
                <label class="form-label">Client <span style="color:var(--danger)">*</span></label>
                <select name="client_id" class="form-input" required>
                    <option value="">Select Client</option>
                    <?php while ($client = $clients->fetch_assoc()): ?>
                    <option value="<?php echo (int)$client['client_id']; ?>"><?php echo e($client['full_name']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Quantity <span style="color:var(--danger)">*</span></label>
                <input type="number" name="quantity" id="borrow_quantity" min="1" class="form-input" required placeholder="0">
            </div>
            <div class="form-group">
                <label class="form-label">Remarks</label>
                <input name="remarks" class="form-input" placeholder="Optional">
            </div>
            <div style="grid-column:1/-1;">
                <button class="btn btn-primary" type="submit" style="width:100%;padding:.875rem;">Save Borrow Transaction</button>
            </div>
        </form>
    </div>
</div>

<div id="scannerModal" class="modal-overlay">
    <div class="modal-box" style="max-width:500px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.25rem;">
            <h2 style="font-size:1.125rem;font-weight:700;">Scan Barcode</h2>
            <button onclick="closeScanner()" class="btn btn-ghost btn-sm">✕ Close</button>
        </div>
        <div id="reader" style="width:100%;"></div>
    </div>
</div>

<script>
let html5QrCode = null, currentTargetInput = null, currentLookupMode = null;

function openBorrowModal()  { document.getElementById('borrowModal').classList.add('is-open'); }
function closeBorrowModal() { document.getElementById('borrowModal').classList.remove('is-open'); }

async function lookupBorrowBarcode() {
    const barcode = document.getElementById('borrow_barcode').value.trim();
    if (!barcode) { showAlert('warning','No Barcode','Please scan or enter a barcode first.'); return; }
    const res  = await fetch(`/item_inventory_system/staff/history.php?ajax=borrow_lookup&barcode=${encodeURIComponent(barcode)}`);
    const data = await res.json();
    if (!data.ok) { showAlert('error','Not Found', data.message || 'Item not found.'); return; }
    document.getElementById('borrow_item_id').value           = data.item.item_id;
    document.getElementById('borrow_item_name').textContent   = data.item.item_name;
    document.getElementById('borrow_item_code').textContent   = data.item.item_code;
    document.getElementById('borrow_item_barcode').textContent = data.item.serial_barcode;
    document.getElementById('borrow_item_category').textContent = data.item.category_name;
    document.getElementById('borrow_item_stock').textContent  = data.item.quantity_stock;
    document.getElementById('borrow_item_info_wrap').style.display = 'block';
    const img = document.getElementById('borrow_item_image');
    const ph  = document.getElementById('borrow_item_image_placeholder');
    if (data.item.image_path) { img.src = `/item_inventory_system/${data.item.image_path}`; img.style.display='block'; ph.style.display='none'; }
    else { img.src=''; img.style.display='none'; ph.style.display='block'; }
    const qty = document.getElementById('borrow_quantity');
    qty.max = data.item.quantity_stock;
    if (!qty.value) qty.value = 1;
}

function openScanner(targetInputId, lookupMode = null) {
    currentTargetInput = targetInputId; currentLookupMode = lookupMode;
    document.getElementById('scannerModal').classList.add('is-open');
    html5QrCode = new Html5Qrcode("reader");
    Html5Qrcode.getCameras().then(devices => {
        if (devices && devices.length) {
            html5QrCode.start({ facingMode:"environment" }, { fps:10, qrbox:250 }, async (decodedText) => {
                const input = document.getElementById(currentTargetInput);
                if (input) input.value = decodedText;
                closeScanner();
                if (currentLookupMode === 'borrow') await lookupBorrowBarcode();
            }, () => {});
        } else { showAlert('warning','No Camera','No camera device was found.'); }
    }).catch(() => { showAlert('error','Camera Error','Unable to access camera.'); });
}
function closeScanner() {
    document.getElementById('scannerModal').classList.remove('is-open');
    if (html5QrCode) { html5QrCode.stop().then(() => { html5QrCode.clear(); html5QrCode = null; }).catch(() => {}); }
    document.getElementById('reader').innerHTML = '';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>