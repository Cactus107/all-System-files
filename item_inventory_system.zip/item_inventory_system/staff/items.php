<?php
session_start();
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/csrf.php';
require_role(['staff','admin']);

function upload_item_image(array $file): ?string {
    if (!isset($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) return null;
    $allowedMime = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $file['tmp_name']); finfo_close($finfo);
    if (!isset($allowedMime[$mime])) throw new RuntimeException('Invalid image type. Allowed: JPG, PNG, WEBP, GIF.');
    if (($file['size'] ?? 0) > 5 * 1024 * 1024) throw new RuntimeException('Image too large. Maximum 5MB.');
    $uploadDir = dirname(__DIR__) . '/uploads/items/';
    if (!is_dir($uploadDir) && !mkdir($uploadDir, 0777, true) && !is_dir($uploadDir)) throw new RuntimeException('Failed to create upload directory.');
    $ext = $allowedMime[$mime];
    $newName = 'item_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $uploadDir . $newName)) throw new RuntimeException('Failed to upload image.');
    return 'uploads/items/' . $newName;
}
function delete_item_image(?string $path): void {
    if (!$path) return;
    $full = dirname(__DIR__) . '/' . ltrim($path, '/');
    if (is_file($full)) @unlink($full);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        try {
            $item_name      = trim($_POST['item_name'] ?? '');
            $category_id    = (int)($_POST['category_id'] ?? 0);
            $serial_barcode = trim($_POST['serial_barcode'] ?? '');
            $quantity_stock = (int)($_POST['quantity_stock'] ?? 0);
            $created_by     = (int)$_SESSION['user_id'];
            if ($item_name === '' || $category_id <= 0) throw new RuntimeException('Item name and category are required.');
            $item_code = generate_item_code($conn);
            $status    = compute_item_status($quantity_stock);
            if ($serial_barcode === '') $serial_barcode = $item_code;
            $image_path = null;
            if (!empty($_FILES['item_image']['name'])) $image_path = upload_item_image($_FILES['item_image']);
            $stmt = $conn->prepare("INSERT INTO items (item_code,serial_barcode,item_name,category_id,quantity_stock,quantity_borrowed,item_status,created_by,image_path) VALUES (?,?,?,?,?,0,?,?,?)");
            $stmt->bind_param('sssissis', $item_code,$serial_barcode,$item_name,$category_id,$quantity_stock,$status,$created_by,$image_path);
            $stmt->execute(); $newId = $stmt->insert_id; $stmt->close();
            log_action($conn, $created_by, 'Create item', 'items', $newId, 'Created: ' . $item_name . ' [' . $item_code . ']');
            set_flash('success', 'Item "' . $item_name . '" added successfully.');
        } catch (Throwable $e) { set_flash('error', $e->getMessage()); }
        header('Location: /item_inventory_system/staff/items.php'); exit();
    }

    if ($action === 'update') {
        try {
            $item_id        = (int)($_POST['item_id'] ?? 0);
            $item_name      = trim($_POST['item_name'] ?? '');
            $category_id    = (int)($_POST['category_id'] ?? 0);
            $serial_barcode = trim($_POST['serial_barcode'] ?? '');
            $quantity_stock = (int)($_POST['quantity_stock'] ?? 0);
            $remove_image   = (int)($_POST['remove_image'] ?? 0);
            if ($item_id <= 0 || $item_name === '' || $category_id <= 0) throw new RuntimeException('Invalid update request.');
            $stmt = $conn->prepare("SELECT image_path FROM items WHERE item_id = ? LIMIT 1");
            $stmt->bind_param('i', $item_id); $stmt->execute();
            $existing = $stmt->get_result()->fetch_assoc(); $stmt->close();
            if (!$existing) throw new RuntimeException('Item not found.');
            $image_path = $existing['image_path'] ?? null;
            if ($remove_image === 1 && $image_path) { delete_item_image($image_path); $image_path = null; }
            if (!empty($_FILES['item_image']['name'])) { $np = upload_item_image($_FILES['item_image']); if ($image_path) delete_item_image($image_path); $image_path = $np; }
            if ($serial_barcode === '') { $stmt = $conn->prepare("SELECT item_code FROM items WHERE item_id=? LIMIT 1"); $stmt->bind_param('i',$item_id); $stmt->execute(); $r=$stmt->get_result()->fetch_assoc(); $stmt->close(); $serial_barcode=$r['item_code']??''; }
            $status = compute_item_status($quantity_stock);
            $stmt = $conn->prepare("UPDATE items SET item_name=?,category_id=?,serial_barcode=?,quantity_stock=?,item_status=?,image_path=? WHERE item_id=?");
            $stmt->bind_param('sisissi',$item_name,$category_id,$serial_barcode,$quantity_stock,$status,$image_path,$item_id);
            $stmt->execute(); $stmt->close();
            log_action($conn, (int)$_SESSION['user_id'], 'Update item', 'items', $item_id, 'Updated: ' . $item_name);
            set_flash('success', 'Item updated successfully.');
        } catch (Throwable $e) { set_flash('error', $e->getMessage()); }
        header('Location: /item_inventory_system/staff/items.php'); exit();
    }

    if ($action === 'generate_barcode') {
        try {
            $item_id = (int)($_POST['item_id'] ?? 0);
            $stmt = $conn->prepare("SELECT item_code FROM items WHERE item_id=? LIMIT 1");
            $stmt->bind_param('i',$item_id); $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
            if (!$row) throw new RuntimeException('Item not found.');
            $barcode = $row['item_code'];
            $stmt = $conn->prepare("UPDATE items SET serial_barcode=? WHERE item_id=?");
            $stmt->bind_param('si',$barcode,$item_id); $stmt->execute(); $stmt->close();
            log_action($conn,(int)$_SESSION['user_id'],'Generate barcode','items',$item_id,'Generated: '.$barcode);
            set_flash('success', 'Barcode generated: ' . $barcode);
        } catch (Throwable $e) { set_flash('error', $e->getMessage()); }
        header('Location: /item_inventory_system/staff/items.php'); exit();
    }

    if ($action === 'delete') {
        try {
            $item_id = (int)($_POST['item_id'] ?? 0);
            $stmt = $conn->prepare("SELECT image_path, item_name FROM items WHERE item_id=? LIMIT 1");
            $stmt->bind_param('i',$item_id); $stmt->execute();
            $item = $stmt->get_result()->fetch_assoc(); $stmt->close();
            if (!$item) throw new RuntimeException('Item not found.');

            $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM transactions WHERE item_id=?");
            $stmt->bind_param('i',$item_id); $stmt->execute();
            $usage = $stmt->get_result()->fetch_assoc(); $stmt->close();

            if ((int)($usage['total'] ?? 0) > 0) {
                // Soft delete: archive to preserve transaction history
                $stmt = $conn->prepare("UPDATE items SET is_archived=1 WHERE item_id=?");
                $stmt->bind_param('i',$item_id); $stmt->execute(); $stmt->close();
                log_action($conn,(int)$_SESSION['user_id'],'Archive item','items',$item_id,'Archived: '.($item['item_name']??''));
                set_flash('success', '"' . $item['item_name'] . '" archived — it has transaction history so it cannot be permanently deleted. You can restore it anytime.');
            } else {
                // Hard delete: no transactions, safe to remove entirely
                $stmt = $conn->prepare("DELETE FROM items WHERE item_id=?");
                $stmt->bind_param('i',$item_id); $stmt->execute(); $stmt->close();
                delete_item_image($item['image_path'] ?? null);
                log_action($conn,(int)$_SESSION['user_id'],'Delete item','items',$item_id,'Deleted: '.($item['item_name']??''));
                set_flash('success', 'Item "' . $item['item_name'] . '" permanently deleted.');
            }
        } catch (Throwable $e) { set_flash('error', $e->getMessage()); }
        header('Location: /item_inventory_system/staff/items.php'); exit();
    }

    if ($action === 'restore') {
        try {
            $item_id = (int)($_POST['item_id'] ?? 0);
            $stmt = $conn->prepare("SELECT item_name FROM items WHERE item_id=? LIMIT 1");
            $stmt->bind_param('i',$item_id); $stmt->execute();
            $item = $stmt->get_result()->fetch_assoc(); $stmt->close();
            if (!$item) throw new RuntimeException('Item not found.');
            $stmt = $conn->prepare("UPDATE items SET is_archived=0 WHERE item_id=?");
            $stmt->bind_param('i',$item_id); $stmt->execute(); $stmt->close();
            log_action($conn,(int)$_SESSION['user_id'],'Restore item','items',$item_id,'Restored: '.($item['item_name']??''));
            set_flash('success', '"' . $item['item_name'] . '" has been restored to active inventory.');
        } catch (Throwable $e) { set_flash('error', $e->getMessage()); }
        header('Location: /item_inventory_system/staff/items.php'); exit();
    }

    if ($action === 'force_delete') {
        try {
            $item_id = (int)($_POST['item_id'] ?? 0);
            $stmt = $conn->prepare("SELECT image_path, item_name FROM items WHERE item_id=? AND COALESCE(is_archived,0)=1 LIMIT 1");
            $stmt->bind_param('i',$item_id); $stmt->execute();
            $item = $stmt->get_result()->fetch_assoc(); $stmt->close();
            if (!$item) throw new RuntimeException('Archived item not found.');

            // Delete all linked transactions first, then the item
            $stmt = $conn->prepare("DELETE FROM transactions WHERE item_id=?");
            $stmt->bind_param('i',$item_id); $stmt->execute(); $stmt->close();

            $stmt = $conn->prepare("DELETE FROM items WHERE item_id=?");
            $stmt->bind_param('i',$item_id); $stmt->execute(); $stmt->close();

            delete_item_image($item['image_path'] ?? null);
            log_action($conn,(int)$_SESSION['user_id'],'Force delete item','items',$item_id,'Permanently deleted archived item: '.($item['item_name']??'').' including all transaction records.');
            set_flash('success', '"' . $item['item_name'] . '" and all its transaction records have been permanently deleted.');
        } catch (Throwable $e) { set_flash('error', $e->getMessage()); }
        header('Location: /item_inventory_system/staff/items.php'); exit();
    }
}

$q = trim($_GET['q'] ?? '');
$category_id = (int)($_GET['category_id'] ?? 0);
$catRes = $conn->query("SELECT category_id, category_name FROM categories ORDER BY category_name ASC");
$categories = [];
while ($cat = $catRes->fetch_assoc()) $categories[] = $cat;

// Active items (not archived)
$sql = "SELECT i.*, c.category_name FROM items i JOIN categories c ON c.category_id=i.category_id WHERE COALESCE(i.is_archived,0)=0";
$params=[]; $types='';
if ($q !== '') {
    $sql .= " AND (i.item_name LIKE ? OR i.item_code LIKE ? OR i.serial_barcode LIKE ? OR c.category_name LIKE ?)";
    $like="%{$q}%"; $params=[$like,$like,$like,$like]; $types='ssss';
}
if ($category_id > 0) {
    $sql .= " AND i.category_id = ?";
    $params[] = $category_id;
    $types .= 'i';
}
$sql .= " ORDER BY i.item_id DESC";
$stmt = $conn->prepare($sql);
if ($types !== '') $stmt->bind_param($types,...$params);
$stmt->execute();
$items = $stmt->get_result();

// Archived items
$archivedStmt = $conn->prepare("SELECT i.*, c.category_name FROM items i JOIN categories c ON c.category_id=i.category_id WHERE COALESCE(i.is_archived,0)=1 ORDER BY i.item_id DESC");
$archivedStmt->execute();
$archivedItems = $archivedStmt->get_result();
$archivedCount = $archivedItems->num_rows;

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/nav.php';
require_once __DIR__ . '/../includes/notifications.php';
?>

<style>
    .items-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:1rem; }
    .item-card { background:var(--surface); border-radius:var(--radius-lg); border:1px solid var(--border); box-shadow:var(--shadow-sm); overflow:hidden; transition:box-shadow .15s,transform .15s; }
    .item-card:hover { box-shadow:var(--shadow); transform:translateY(-2px); }
    .item-img { aspect-ratio:4/3; background:var(--surface-3); overflow:hidden; position:relative; }
    .item-img img { width:100%;height:100%;object-fit:cover; }
    .item-body { padding:1.125rem 1.25rem; }
    .form-label { display:block;font-size:13px;font-weight:600;margin-bottom:.5rem;color:var(--ink-soft); }
    .form-group { margin-bottom:1rem; }
    .modal-grid { display:grid;grid-template-columns:1fr 1fr;gap:1rem; }
    @media(max-width:520px){.modal-grid{grid-template-columns:1fr;}}
    .upload-zone {
        border:2px dashed var(--border); border-radius:var(--radius); padding:2rem 1rem;
        text-align:center; cursor:pointer; background:var(--surface-2);
        transition:border-color .15s,background .15s;
        position:relative; min-height:120px;
    }
    .upload-zone:hover { border-color:var(--accent); background:var(--accent-soft); }
    .search-bar{display:grid;grid-template-columns:1fr 200px auto;gap:.75rem;}
    @media(max-width:768px){.search-bar{grid-template-columns:1fr 200px;}}
    @media(max-width:480px){.search-bar{grid-template-columns:1fr;}}
</style>

<div style="max-width:1280px;margin:0 auto;padding:2rem 1.5rem;">
    <div class="page-header" style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem;">
        <div>
            <h1 class="page-title">Items</h1>
            <p class="page-subtitle">Manage inventory items, barcodes, and stock levels.</p>
        </div>
        <button type="button" onclick="openAddModal()" class="btn btn-primary">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Add Item
        </button>
    </div>

    <div class="card" style="padding:1.25rem 1.5rem;margin-bottom:1.5rem;">
        <form method="GET" class="search-bar" style="grid-template-columns: 1fr 200px auto;">
            <input name="q" value="<?php echo e($q); ?>" class="form-input" placeholder="Search item, code, barcode, or category…">
            <select name="category_id" class="form-input">
                <option value="">All Categories</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo $cat['category_id']; ?>" <?php echo $category_id == $cat['category_id'] ? 'selected' : ''; ?>><?php echo e($cat['category_name']); ?></option>
                <?php endforeach; ?>
            </select>
            <button class="btn btn-primary">Search</button>
        </form>
    </div>

    <div class="items-grid">
        <?php while ($row = $items->fetch_assoc()):
            $statusClass = [
                'available'    => 'status-available',
                'low_stock'    => 'status-low_stock',
                'out_of_stock' => 'status-out_of_stock',
            ][$row['item_status']] ?? 'status-inactive';
        ?>
        <div class="item-card">
            <div class="item-img">
                <?php if (!empty($row['image_path'])): ?>
                    <img src="/item_inventory_system/<?php echo e($row['image_path']); ?>" alt="<?php echo e($row['item_name']); ?>">
                <?php else: ?>
                    <div class="no-image-placeholder">No Image</div>
                <?php endif; ?>
                <span class="badge <?php echo $statusClass; ?>" style="position:absolute;top:.625rem;right:.625rem;">
                    <?php echo e($row['item_status']); ?>
                </span>
            </div>
            <div class="item-body">
                <div style="font-size:1rem;font-weight:700;margin-bottom:.2rem;"><?php echo e($row['item_name']); ?></div>
                <div style="font-size:12px;color:var(--ink-faint);margin-bottom:.875rem;"><?php echo e($row['category_name']); ?></div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:.375rem;font-size:12px;margin-bottom:1rem;">
                    <div><span style="color:var(--ink-faint);">Code</span><br><span class="mono" style="font-weight:500;font-size:11px;"><?php echo e($row['item_code']); ?></span></div>
                    <div><span style="color:var(--ink-faint);">Barcode</span><br><span class="mono" style="font-weight:500;font-size:11px;"><?php echo e($row['serial_barcode'] ?: '—'); ?></span></div>
                    <div><span style="color:var(--ink-faint);">Stock</span><br><strong style="font-size:1rem;"><?php echo (int)$row['quantity_stock']; ?></strong></div>
                    <div><span style="color:var(--ink-faint);">Borrowed</span><br><strong style="font-size:1rem;"><?php echo (int)$row['quantity_borrowed']; ?></strong></div>
                </div>
                <div style="display:flex;flex-wrap:wrap;gap:.5rem;">
                    <button type="button" class="btn btn-ghost btn-sm"
                        onclick='openEditModal(<?php echo json_encode(["item_id"=>(int)$row["item_id"],"item_name"=>$row["item_name"],"category_id"=>(int)$row["category_id"],"serial_barcode"=>$row["serial_barcode"],"quantity_stock"=>(int)$row["quantity_stock"],"image_path"=>$row["image_path"]], JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>)'>
                        Edit
                    </button>
                    <?php if (empty($row['serial_barcode'])): ?>
                        <form method="POST" data-confirm="Generate a barcode for this item?" data-confirm-title="Generate Barcode" data-confirm-label="Generate" data-confirm-type="accent">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="action" value="generate_barcode">
                            <input type="hidden" name="item_id" value="<?php echo (int)$row['item_id']; ?>">
                            <button class="btn btn-sm btn-accent" type="submit">Generate Barcode</button>
                        </form>
                    <?php else: ?>
                        <a target="_blank" href="/item_inventory_system/staff/barcode_print.php?item_id=<?php echo (int)$row['item_id']; ?>" class="btn btn-sm" style="background:#6366f1;color:#fff;">
                            Print Barcode
                        </a>
                    <?php endif; ?>
                    <form method="POST"
                          data-confirm="This will permanently delete &quot;<?php echo htmlspecialchars($row['item_name'], ENT_QUOTES, 'UTF-8'); ?>&quot; from inventory."
                          data-confirm-title="Delete Item?"
                          data-confirm-label="Delete"
                          data-confirm-type="danger">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="item_id" value="<?php echo (int)$row['item_id']; ?>">
                        <button class="btn btn-danger btn-sm" type="submit">Delete</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>

    <?php if ($archivedCount > 0): ?>
    <!-- Archived Items Section -->
    <div style="margin-top:2.5rem;">
        <button type="button"
            onclick="this.nextElementSibling.classList.toggle('hidden');this.querySelector('.chevron').classList.toggle('rotate-180');"
            style="display:flex;align-items:center;gap:.625rem;background:none;border:none;cursor:pointer;padding:0;margin-bottom:1rem;">
            <span style="font-size:1rem;font-weight:700;color:var(--ink);">Archived Items</span>
            <span style="background:var(--warning-soft);color:var(--warning);border:1px solid var(--warning-border);border-radius:9999px;padding:.15rem .625rem;font-size:12px;font-weight:700;"><?php echo $archivedCount; ?></span>
            <svg class="chevron" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="color:var(--ink-faint);transition:transform .2s;"><polyline points="6 9 12 15 18 9"/></svg>
        </button>
        <div class="hidden">
            <p style="font-size:13px;color:var(--ink-faint);margin-bottom:1rem;">These items were archived because they have transaction history. You can restore them to active inventory at any time.</p>
            <div class="items-grid">
                <?php while ($row = $archivedItems->fetch_assoc()): ?>
                <div class="item-card" style="opacity:.7;border-style:dashed;">
                    <div class="item-img" style="filter:grayscale(60%);">
                        <?php if (!empty($row['image_path'])): ?>
                            <img src="/item_inventory_system/<?php echo e($row['image_path']); ?>" alt="<?php echo e($row['item_name']); ?>">
                        <?php else: ?>
                            <div class="no-image-placeholder">No Image</div>
                        <?php endif; ?>
                        <span class="badge status-inactive" style="position:absolute;top:.625rem;right:.625rem;">Archived</span>
                    </div>
                    <div class="item-body">
                        <div style="font-size:1rem;font-weight:700;margin-bottom:.2rem;"><?php echo e($row['item_name']); ?></div>
                        <div style="font-size:12px;color:var(--ink-faint);margin-bottom:.875rem;"><?php echo e($row['category_name']); ?></div>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:.375rem;font-size:12px;margin-bottom:1rem;">
                            <div><span style="color:var(--ink-faint);">Code</span><br><span class="mono" style="font-weight:500;font-size:11px;"><?php echo e($row['item_code']); ?></span></div>
                            <div><span style="color:var(--ink-faint);">Barcode</span><br><span class="mono" style="font-weight:500;font-size:11px;"><?php echo e($row['serial_barcode'] ?: '—'); ?></span></div>
                        </div>
                        <div style="display:flex;gap:.5rem;">
                            <form method="POST" style="flex:1;"
                                  data-confirm="Restore &quot;<?php echo htmlspecialchars($row['item_name'], ENT_QUOTES, 'UTF-8'); ?>&quot; back to active inventory?"
                                  data-confirm-title="Restore Item?"
                                  data-confirm-label="Restore"
                                  data-confirm-type="accent">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="action" value="restore">
                                <input type="hidden" name="item_id" value="<?php echo (int)$row['item_id']; ?>">
                                <button class="btn btn-accent btn-sm" type="submit" style="width:100%;">↩ Restore</button>
                            </form>
                            <form method="POST"
                                  data-confirm="This will permanently delete &quot;<?php echo htmlspecialchars($row['item_name'], ENT_QUOTES, 'UTF-8'); ?>&quot; AND all its transaction history. This cannot be undone."
                                  data-confirm-title="Delete Permanently?"
                                  data-confirm-label="Delete Forever"
                                  data-confirm-type="danger">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="action" value="force_delete">
                                <input type="hidden" name="item_id" value="<?php echo (int)$row['item_id']; ?>">
                                <button class="btn btn-danger btn-sm" type="submit">🗑</button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Add Item Modal -->
<div id="addItemModal" class="modal-overlay">
    <div class="modal-box modal-box-lg" style="max-height:90vh;overflow-y:auto;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;">
            <h2 style="font-size:1.125rem;font-weight:700;">Add Item</h2>
            <button type="button" onclick="closeAddModal()" class="btn btn-ghost btn-sm">✕ Close</button>
        </div>
        <form method="POST" enctype="multipart/form-data" class="modal-grid">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="create">
            <div class="form-group">
                <label class="form-label">Item Name <span style="color:var(--danger)">*</span></label>
                <input name="item_name" class="form-input" required placeholder="Item name">
            </div>
            <div class="form-group">
                <label class="form-label">Category <span style="color:var(--danger)">*</span></label>
                <select name="category_id" class="form-input" required>
                    <option value="">Select Category</option>
                    <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo (int)$cat['category_id']; ?>"><?php echo e($cat['category_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="grid-column:1/-1">
                <label class="form-label">Barcode</label>
                <div style="display:flex;gap:.5rem;">
                    <input id="add_serial_barcode" name="serial_barcode" class="form-input" placeholder="Scan or enter barcode (auto-generated if empty)">
                    <button type="button" onclick="openScanner('add_serial_barcode')" class="btn btn-accent" style="white-space:nowrap;">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="5" height="16" rx="1"/><rect x="8" y="4" width="2" height="16" rx="1"/><rect x="12" y="4" width="4" height="16" rx="1"/><rect x="18" y="4" width="5" height="16" rx="1"/></svg>
                        Scan
                    </button>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Quantity <span style="color:var(--danger)">*</span></label>
                <input type="number" min="0" name="quantity_stock" class="form-input" required placeholder="0">
            </div>
            <div class="form-group" style="grid-column:1/-1">
                <label class="form-label">Upload Image</label>
                <div class="upload-zone" id="add-upload-zone">
                    <div id="add-upload-content">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin:0 auto .75rem;display:block;color:var(--ink-faint);"><path stroke-linecap="round" stroke-linejoin="round" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>
                        <p style="font-size:14px;font-weight:500;color:var(--ink-soft);">Drag & drop an image here, or click to browse</p>
                        <p style="font-size:12px;color:var(--ink-faint);margin-top:.25rem;">JPG, PNG, WEBP, GIF — max 5MB</p>
                    </div>
                    <div id="add-image-preview" style="display:none;width:100%;height:100%;position:absolute;top:0;left:0;border-radius:var(--radius);overflow:hidden;">
                        <img id="add-preview-img" style="width:100%;height:100%;object-fit:cover;" alt="Preview">
                        <button type="button" id="add-remove-preview" style="position:absolute;top:8px;right:8px;background:rgba(0,0,0,0.7);color:white;border:none;border-radius:50%;width:24px;height:24px;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:12px;">×</button>
                    </div>
                    <input type="file" name="item_image" id="add-item-image" accept="image/*" style="display:none;">
                </div>
            </div>
            <div style="grid-column:1/-1;">
                <button class="btn btn-primary" type="submit" style="width:100%;padding:.875rem;">Save Item</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Item Modal -->
<div id="editItemModal" class="modal-overlay">
    <div class="modal-box modal-box-lg" style="max-height:90vh;overflow-y:auto;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.5rem;">
            <h2 style="font-size:1.125rem;font-weight:700;">Update Item</h2>
            <button type="button" onclick="closeEditModal()" class="btn btn-ghost btn-sm">✕ Close</button>
        </div>
        <form method="POST" enctype="multipart/form-data" class="modal-grid">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="item_id" id="edit_item_id">
            <div class="form-group">
                <label class="form-label">Item Name <span style="color:var(--danger)">*</span></label>
                <input name="item_name" id="edit_item_name" class="form-input" required>
            </div>
            <div class="form-group">
                <label class="form-label">Category <span style="color:var(--danger)">*</span></label>
                <select name="category_id" id="edit_category_id" class="form-input" required>
                    <option value="">Select Category</option>
                    <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo (int)$cat['category_id']; ?>"><?php echo e($cat['category_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="grid-column:1/-1">
                <label class="form-label">Barcode</label>
                <div style="display:flex;gap:.5rem;">
                    <input name="serial_barcode" id="edit_serial_barcode" class="form-input" required>
                    <button type="button" onclick="openScanner('edit_serial_barcode')" class="btn btn-accent" style="white-space:nowrap;">Scan</button>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Quantity <span style="color:var(--danger)">*</span></label>
                <input type="number" min="0" name="quantity_stock" id="edit_quantity_stock" class="form-input" required>
            </div>
            <div class="form-group" style="grid-column:1/-1">
                <label class="form-label">Current Image</label>
                <div id="edit_image_preview" style="width:100%;height:160px;border-radius:var(--radius);border:1px solid var(--border);overflow:hidden;background:var(--surface-3);display:flex;align-items:center;justify-content:center;color:var(--ink-faint);font-size:13px;">No Image</div>
            </div>
            <div class="form-group" style="grid-column:1/-1">
                <label class="form-label">Replace Image</label>
                <div class="upload-zone" id="edit-upload-zone">
                    <div id="edit-upload-content">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin:0 auto .75rem;display:block;color:var(--ink-faint);"><path stroke-linecap="round" stroke-linejoin="round" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"/></svg>
                        <p style="font-size:14px;font-weight:500;color:var(--ink-soft);">Drag & drop a new image here, or click to browse</p>
                        <p style="font-size:12px;color:var(--ink-faint);margin-top:.25rem;">JPG, PNG, WEBP, GIF — max 5MB</p>
                    </div>
                    <div id="edit-image-preview" style="display:none;width:100%;height:100%;position:absolute;top:0;left:0;border-radius:var(--radius);overflow:hidden;">
                        <img id="edit-preview-img" style="width:100%;height:100%;object-fit:cover;" alt="Preview">
                        <button type="button" id="edit-remove-preview" style="position:absolute;top:8px;right:8px;background:rgba(0,0,0,0.7);color:white;border:none;border-radius:50%;width:24px;height:24px;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:12px;">×</button>
                    </div>
                    <input type="file" name="item_image" id="edit-item-image" accept="image/*" style="display:none;">
                </div>
            </div>
            <div class="form-group" style="display:flex;align-items:center;gap:.625rem;padding-top:1.5rem;">
                <input type="checkbox" name="remove_image" value="1" id="remove_image_check" style="width:16px;height:16px;cursor:pointer;">
                <label for="remove_image_check" style="font-size:13px;cursor:pointer;">Remove current image</label>
            </div>
            <div style="grid-column:1/-1;">
                <button class="btn btn-primary" type="submit" style="width:100%;padding:.875rem;">Update Item</button>
            </div>
        </form>
    </div>
</div>

<!-- Scanner Modal -->
<div id="scannerModal" class="modal-overlay">
    <div class="modal-box" style="max-width:500px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.25rem;">
            <h2 style="font-size:1.125rem;font-weight:700;">Scan Barcode</h2>
            <button onclick="closeScanner()" class="btn btn-ghost btn-sm">✕ Close</button>
        </div>
        <div id="reader" style="width:100%;"></div>
        <p style="font-size:13px;color:var(--ink-faint);margin-top:.875rem;text-align:center;">Point the camera at the barcode.</p>
    </div>
</div>

<script>
let html5QrCode = null;
let currentTargetInput = null;

// Image upload functionality
function initializeImageUpload(zoneId, fileInputId, previewId, contentId, imgId, removeBtnId) {
    const zone = document.getElementById(zoneId);
    const fileInput = document.getElementById(fileInputId);
    const preview = document.getElementById(previewId);
    const content = document.getElementById(contentId);
    const img = document.getElementById(imgId);
    const removeBtn = document.getElementById(removeBtnId);

    // Click to browse
    zone.addEventListener('click', () => fileInput.click());

    // Drag and drop
    zone.addEventListener('dragover', (e) => {
        e.preventDefault();
        zone.style.borderColor = 'var(--accent)';
        zone.style.background = 'var(--accent-soft)';
    });

    zone.addEventListener('dragleave', () => {
        zone.style.borderColor = 'var(--border)';
        zone.style.background = 'var(--surface-2)';
    });

    zone.addEventListener('drop', (e) => {
        e.preventDefault();
        zone.style.borderColor = 'var(--border)';
        zone.style.background = 'var(--surface-2)';
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFileSelect(files[0], fileInput, preview, content, img);
        }
    });

    // File input change
    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFileSelect(e.target.files[0], fileInput, preview, content, img);
        }
    });

    // Remove preview
    removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        fileInput.value = '';
        preview.style.display = 'none';
        content.style.display = 'block';
    });
}

function handleFileSelect(file, fileInput, preview, content, img) {
    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    if (!allowedTypes.includes(file.type)) {
        showAlert('error', 'Invalid File Type', 'Please select a JPG, PNG, WEBP, or GIF image.');
        return;
    }

    // Validate file size (5MB)
    if (file.size > 5 * 1024 * 1024) {
        showAlert('error', 'File Too Large', 'Please select an image smaller than 5MB.');
        return;
    }

    // Show preview
    const reader = new FileReader();
    reader.onload = (e) => {
        img.src = e.target.result;
        preview.style.display = 'block';
        content.style.display = 'none';
    };
    reader.readAsDataURL(file);
}

function openAddModal() { 
    document.getElementById('addItemModal').classList.add('is-open'); 
    // Reset image upload
    document.getElementById('add-item-image').value = '';
    document.getElementById('add-image-preview').style.display = 'none';
    document.getElementById('add-upload-content').style.display = 'block';
}
function closeAddModal() { document.getElementById('addItemModal').classList.remove('is-open'); }

function openEditModal(item) {
    document.getElementById('edit_item_id').value         = item.item_id;
    document.getElementById('edit_item_name').value       = item.item_name ?? '';
    document.getElementById('edit_category_id').value     = item.category_id ?? '';
    document.getElementById('edit_serial_barcode').value  = item.serial_barcode ?? '';
    document.getElementById('edit_quantity_stock').value  = item.quantity_stock ?? 0;
    document.getElementById('remove_image_check').checked = false;
    
    const preview = document.getElementById('edit_image_preview');
    if (item.image_path) {
        preview.innerHTML = `<img src="/item_inventory_system/${item.image_path}" style="width:100%;height:100%;object-fit:cover;" alt="">`;
    } else {
        preview.textContent = 'No Image';
    }
    
    // Reset replace image upload
    document.getElementById('edit-item-image').value = '';
    document.getElementById('edit-image-preview').style.display = 'none';
    document.getElementById('edit-upload-content').style.display = 'block';
    
    document.getElementById('editItemModal').classList.add('is-open');
}
function closeEditModal() { document.getElementById('editItemModal').classList.remove('is-open'); }

function openScanner(targetInputId) {
    currentTargetInput = targetInputId;
    document.getElementById('scannerModal').classList.add('is-open');
    html5QrCode = new Html5Qrcode("reader");
    Html5Qrcode.getCameras().then(devices => {
        if (devices && devices.length) {
            html5QrCode.start({ facingMode:"environment" }, { fps:10, qrbox:250 }, (decodedText) => {
                const input = document.getElementById(currentTargetInput);
                if (input) input.value = decodedText;
                closeScanner();
            }, () => {});
        } else { showAlert('warning','No Camera','No camera device was found.'); }
    }).catch(() => { showAlert('error','Camera Error','Unable to access camera.'); });
}
function closeScanner() {
    document.getElementById('scannerModal').classList.remove('is-open');
    if (html5QrCode) { html5QrCode.stop().then(() => { html5QrCode.clear(); html5QrCode = null; }).catch(() => {}); }
    document.getElementById('reader').innerHTML = '';
}

// Initialize image upload zones when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    initializeImageUpload('add-upload-zone', 'add-item-image', 'add-image-preview', 'add-upload-content', 'add-preview-img', 'add-remove-preview');
    initializeImageUpload('edit-upload-zone', 'edit-item-image', 'edit-image-preview', 'edit-upload-content', 'edit-preview-img', 'edit-remove-preview');
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>