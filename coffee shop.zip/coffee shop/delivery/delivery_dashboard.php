<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'delivery') {
    header("Location: ../auth.php"); exit();
}

$driver_name = htmlspecialchars($_SESSION['user_name'] ?? 'Driver');
$driver_id   = (int)$_SESSION['user_id'];

if (isset($_POST['complete_delivery'])) {
    $bid = (int)$_POST['batch_id'];
    $conn->query("UPDATE order_batches SET status='completed', assigned_delivery_id=$driver_id WHERE id=$bid AND status='delivering'");
    $conn->query("UPDATE orders SET status='completed', assigned_delivery_id=$driver_id WHERE batch_id=$bid");
    header("Location: delivery_dashboard.php"); exit();
}

function getBatchItems($conn, int $bid): array {
    $r = $conn->query("SELECT item_name, quantity, total_price FROM orders WHERE batch_id=$bid");
    $items = []; while ($row = $r->fetch_assoc()) $items[] = $row;
    return $items;
}

$ready_batches    = $conn->query("SELECT * FROM order_batches WHERE status='delivering' ORDER BY order_date ASC");
$today_delivered  = $conn->query("SELECT COUNT(*) as c FROM order_batches WHERE status='completed' AND assigned_delivery_id=$driver_id AND DATE(order_date)=CURDATE()")->fetch_assoc()['c'];
$all_delivered    = $conn->query("SELECT COUNT(*) as c FROM order_batches WHERE status='completed' AND assigned_delivery_id=$driver_id")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery | Roast & Revel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'DM Sans', sans-serif; background: #0f172a; color: #f1f5f9; }
        .serif { font-family: 'Playfair Display', serif; }
        .glass { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); }
        .card { background: #1e293b; border: 1px solid #334155; transition: border-color 0.2s; }
        .card:hover { border-color: #6366f1; }
    </style>
</head>
<body class="min-h-screen p-6 md:p-10">
<div class="max-w-2xl mx-auto">
    <div class="flex justify-between items-start mb-10">
        <div>
            <h1 class="serif text-4xl">Delivery Run</h1>
            <p class="text-slate-400 mt-1">Driver: <span class="text-indigo-400 font-semibold"><?php echo $driver_name; ?></span></p>
        </div>
        <div class="flex gap-3">
            <div class="glass px-5 py-4 rounded-2xl text-center">
                <div class="text-xs text-slate-500 mb-1 uppercase tracking-widest">Today</div>
                <div class="text-2xl font-bold text-indigo-400"><?php echo $today_delivered; ?></div>
            </div>
            <a href="../logout.php" class="flex items-center bg-red-950/30 border border-red-900/40 text-red-400 hover:bg-red-950/60 px-5 rounded-2xl text-sm font-semibold transition">Log Out</a>
        </div>
    </div>

    <h2 class="text-sm font-bold uppercase tracking-widest text-slate-400 mb-4">
        Ready for Delivery
        <span class="ml-2 bg-indigo-900/40 text-indigo-400 px-2.5 py-1 rounded-full"><?php echo $ready_batches->num_rows; ?></span>
    </h2>

    <?php if ($ready_batches->num_rows > 0): ?>
    <div class="space-y-5">
        <?php while ($b = $ready_batches->fetch_assoc()): ?>
        <?php $items = getBatchItems($conn, $b['id']); ?>
        <div class="card p-6 rounded-3xl">
            <div class="flex justify-between items-start mb-4">
                <div>
                    <span class="text-xs text-indigo-400 font-bold uppercase tracking-widest">Batch #<?php echo $b['id']; ?></span>
                    <h3 class="text-xl font-semibold mt-1"><?php echo htmlspecialchars($b['customer_name']); ?></h3>
                </div>
                <div class="text-xs text-slate-500 text-right">
                    <?php echo date('g:i A', strtotime($b['order_date'])); ?>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-3 mb-4">
                <div class="bg-slate-900/60 rounded-xl px-3 py-2.5 border border-slate-700/50">
                    <div class="text-[10px] text-slate-500 uppercase tracking-wider mb-0.5">📱 Phone</div>
                    <a href="tel:<?php echo htmlspecialchars($b['phone']); ?>" class="text-sm font-semibold text-indigo-400 hover:text-indigo-300 hover:underline transition"><?php echo htmlspecialchars($b['phone']); ?></a>
                </div>
                <div class="bg-slate-900/60 rounded-xl px-3 py-2.5 border border-slate-700/50">
                    <div class="text-[10px] text-slate-500 uppercase tracking-wider mb-0.5">📍 Address</div>
                    <div class="text-sm font-semibold text-slate-200 line-clamp-1"><?php echo htmlspecialchars($b['address'].($b['city']?', '.$b['city']:'')); ?></div>
                </div>
            </div>

            <div class="bg-slate-900/50 rounded-xl p-4 mb-4 border border-slate-700/50">
                <div class="text-[10px] text-slate-500 uppercase tracking-widest mb-3 font-bold">Order Contents</div>
                <div class="space-y-2">
                    <?php foreach ($items as $li): ?>
                    <div class="flex items-center gap-3 text-sm">
                        <span class="w-6 h-6 rounded-full bg-indigo-900/40 text-indigo-400 text-xs font-bold flex items-center justify-center"><?php echo $li['quantity']; ?></span>
                        <span class="text-slate-300"><?php echo htmlspecialchars($li['item_name']); ?></span>
                        <span class="ml-auto font-mono text-slate-500">$<?php echo number_format($li['total_price']*$li['quantity'],2); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="flex justify-between mt-3 pt-3 border-t border-slate-700 text-sm font-bold">
                    <span class="text-slate-400">Total</span>
                    <span class="text-indigo-400">$<?php echo number_format($b['batch_total'],2); ?></span>
                </div>
            </div>

            <?php if ($b['notes']): ?>
            <div class="bg-indigo-950/30 border border-indigo-900/40 rounded-xl px-4 py-2.5 mb-4 text-sm text-indigo-200">
                <strong class="text-indigo-400">Note: </strong><?php echo htmlspecialchars($b['notes']); ?>
            </div>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="batch_id" value="<?php echo $b['id']; ?>">
                <button name="complete_delivery" class="w-full bg-indigo-700 hover:bg-indigo-600 text-white py-3.5 rounded-xl font-bold transition">
                    ✓ Mark as Delivered
                </button>
            </form>
        </div>
        <?php endwhile; ?>
    </div>
    <?php else: ?>
    <div class="glass rounded-3xl py-20 text-center">
        <div class="text-4xl mb-4">🛵</div>
        <p class="text-slate-500 italic">No active deliveries. Standing by...</p>
    </div>
    <?php endif; ?>
</div>
</body>
</html>