<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'staff') {
    header("Location: ../auth.php"); exit();
}

$staff_name = htmlspecialchars($_SESSION['user_name'] ?? 'Barista');
$staff_id   = (int)$_SESSION['user_id'];

// ── Accept batch (pending → preparing, assign this staff) ────────────────────
if (isset($_POST['accept_batch'])) {
    $bid = (int)$_POST['batch_id'];
    $conn->query("UPDATE order_batches SET status='preparing', assigned_staff_id=$staff_id WHERE id=$bid AND status='pending'");
    $conn->query("UPDATE orders SET status='preparing', assigned_staff_id=$staff_id WHERE batch_id=$bid");
    header("Location: staff_dashboard.php"); exit();
}

// ── Mark batch ready (preparing → delivering) ─────────────────────────────────
if (isset($_POST['ready_batch'])) {
    $bid = (int)$_POST['batch_id'];
    $conn->query("UPDATE order_batches SET status='delivering' WHERE id=$bid AND status='preparing' AND assigned_staff_id=$staff_id");
    $conn->query("UPDATE orders SET status='delivering' WHERE batch_id=$bid");
    header("Location: staff_dashboard.php"); exit();
}

// ── Fetch batches ─────────────────────────────────────────────────────────────
$pending_batches   = $conn->query("SELECT * FROM order_batches WHERE status='pending' ORDER BY order_date ASC");
$preparing_batches = $conn->query("SELECT * FROM order_batches WHERE status='preparing' AND assigned_staff_id=$staff_id ORDER BY order_date ASC");

// Helper: fetch items for a batch
function getBatchItems($conn, int $batch_id): array {
    $r = $conn->query("SELECT item_name, quantity, total_price FROM orders WHERE batch_id=$batch_id");
    $items = [];
    while ($row = $r->fetch_assoc()) $items[] = $row;
    return $items;
}

// Stats
$my_done     = $conn->query("SELECT COUNT(*) as c FROM order_batches WHERE status IN ('delivering','completed') AND assigned_staff_id=$staff_id")->fetch_assoc()['c'];
$done_today  = $conn->query("SELECT COUNT(*) as c FROM order_batches WHERE status='completed' AND DATE(order_date)=CURDATE()")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barista Station | Roast & Revel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'DM Sans', sans-serif; background: #1c1917; color: #f5f4f1; }
        .serif { font-family: 'Playfair Display', serif; }
        .glass { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); }
        .order-card { background: #242120; border: 1px solid #3c3330; transition: border-color 0.2s; }
        .order-card:hover { border-color: rgba(251,191,36,0.5); }
        .order-card.active-border { border-color: #fbbf24; }
        .pulse { animation: pulse 2s infinite; }
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
        @keyframes slideUp { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
        .slide-up { animation: slideUp 0.3s ease forwards; }
        /* badge */
        .type-delivery { background:rgba(99,102,241,0.15); color:#a5b4fc; }
        .type-takeout  { background:rgba(245,158,11,0.15); color:#fcd34d; }
        .type-dine-in  { background:rgba(52,211,153,0.15); color:#6ee7b7; }
    </style>
</head>
<body class="min-h-screen">
<div class="max-w-6xl mx-auto p-6 md:p-10">

    <!-- Header -->
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
        <div>
            <div class="flex items-center gap-2 mb-1">
                <span class="w-2 h-2 rounded-full bg-emerald-400 pulse"></span>
                <span class="text-xs text-stone-500 uppercase tracking-widest">Shift Active</span>
            </div>
            <h1 class="serif text-4xl">Barista Station</h1>
            <p class="text-stone-400 mt-1">Welcome, <span class="text-amber-400 font-semibold"><?php echo $staff_name; ?></span></p>
        </div>
        <div class="flex gap-3 flex-wrap">
            <div class="glass px-5 py-4 rounded-2xl text-center min-w-[80px]">
                <div class="text-[10px] text-stone-500 uppercase tracking-widest mb-1">My Batches</div>
                <div class="text-2xl font-bold text-amber-400"><?php echo $my_done; ?></div>
            </div>
            <div class="glass px-5 py-4 rounded-2xl text-center min-w-[80px]">
                <div class="text-[10px] text-stone-500 uppercase tracking-widest mb-1">Done Today</div>
                <div class="text-2xl font-bold text-emerald-400"><?php echo $done_today; ?></div>
            </div>
            <a href="../logout.php" class="flex items-center gap-2 bg-red-900/20 hover:bg-red-900/40 border border-red-900/40 text-red-400 px-5 py-4 rounded-2xl font-semibold transition text-sm">
                End Shift
            </a>
        </div>
    </div>

    <div class="grid lg:grid-cols-5 gap-8">

        <!-- ── Pending Queue (Accept) ───────────────────────────────────── -->
        <div class="lg:col-span-3 space-y-5">
            <div class="flex items-center justify-between">
                <h2 class="serif text-2xl">Incoming Queue</h2>
                <span class="text-xs bg-yellow-900/30 text-yellow-400 px-3 py-1 rounded-full border border-yellow-900/40">
                    <?php echo $pending_batches->num_rows; ?> waiting
                </span>
            </div>

            <?php if ($pending_batches->num_rows > 0): ?>
                <?php while ($b = $pending_batches->fetch_assoc()): ?>
                <?php $items = getBatchItems($conn, $b['id']); ?>
                <div class="order-card active-border p-6 rounded-3xl slide-up">

                    <!-- Batch top row -->
                    <div class="flex justify-between items-start mb-4 gap-3">
                        <div>
                            <div class="flex items-center gap-2 flex-wrap mb-1">
                                <span class="text-xs font-bold uppercase tracking-wider text-yellow-500">Order #<?php echo $b['id']; ?></span>
                                <span class="text-[10px] px-2 py-0.5 rounded-full font-bold type-<?php echo str_replace('-','_',$b['order_type']); ?>">
                                    <?php echo strtoupper(str_replace('-',' ',$b['order_type'])); ?>
                                </span>
                            </div>
                            <h3 class="text-xl font-semibold"><?php echo htmlspecialchars($b['customer_name']); ?></h3>
                        </div>
                        <div class="text-right shrink-0">
                            <div class="text-xs text-stone-500">Placed</div>
                            <div class="font-mono text-amber-400 text-sm"><?php echo date('g:i A', strtotime($b['order_date'])); ?></div>
                        </div>
                    </div>

                    <!-- Customer details -->
                    <div class="grid grid-cols-2 gap-3 mb-4">
                        <div class="bg-stone-900/50 rounded-xl px-3 py-2.5 border border-stone-800/80">
                            <div class="text-[10px] text-stone-500 uppercase tracking-wider mb-0.5">📱 Phone</div>
                            <div class="text-sm font-semibold text-stone-200"><?php echo htmlspecialchars($b['phone']); ?></div>
                        </div>
                        <div class="bg-stone-900/50 rounded-xl px-3 py-2.5 border border-stone-800/80">
                            <div class="text-[10px] text-stone-500 uppercase tracking-wider mb-0.5">📍 Address</div>
                            <div class="text-sm font-semibold text-stone-200 line-clamp-1">
                                <?php echo htmlspecialchars($b['address'] . ($b['city'] ? ', '.$b['city'] : '')); ?>
                            </div>
                        </div>
                    </div>

                    <!-- All items in this batch -->
                    <div class="bg-stone-900/60 rounded-2xl p-4 mb-4 border border-stone-800">
                        <div class="text-[10px] font-bold uppercase tracking-widest text-stone-500 mb-3">Items to Prepare</div>
                        <div class="space-y-2">
                            <?php
                            $batch_total = 0;
                            foreach ($items as $li):
                                $subtotal = $li['total_price'] * $li['quantity'];
                                $batch_total += $subtotal;
                            ?>
                            <div class="flex justify-between items-center">
                                <div class="flex items-center gap-3">
                                    <span class="w-6 h-6 rounded-full bg-amber-900/40 text-amber-400 text-xs font-bold flex items-center justify-center shrink-0">
                                        <?php echo $li['quantity']; ?>
                                    </span>
                                    <span class="text-stone-200 text-sm font-medium"><?php echo htmlspecialchars($li['item_name']); ?></span>
                                </div>
                                <span class="text-stone-400 font-mono text-sm">$<?php echo number_format($subtotal, 2); ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="flex justify-between mt-3 pt-3 border-t border-stone-800 text-sm font-bold">
                            <span class="text-stone-400">Batch Total</span>
                            <span class="text-amber-400">$<?php echo number_format($b['batch_total'], 2); ?></span>
                        </div>
                    </div>

                    <!-- Special notes -->
                    <?php if ($b['notes']): ?>
                    <div class="bg-amber-900/10 border border-amber-900/30 rounded-xl px-4 py-2.5 mb-4 text-sm text-amber-200">
                        <span class="font-bold text-amber-400">Note: </span><?php echo htmlspecialchars($b['notes']); ?>
                    </div>
                    <?php endif; ?>

                    <form method="POST">
                        <input type="hidden" name="batch_id" value="<?php echo $b['id']; ?>">
                        <button name="accept_batch" class="w-full bg-blue-700 hover:bg-blue-600 text-white py-3.5 rounded-xl font-bold transition active:scale-[0.98]">
                            Accept & Start Preparing
                        </button>
                    </form>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="text-center py-16 glass rounded-3xl border-2 border-dashed border-stone-800/60">
                    <p class="text-stone-500 italic">Queue is clear. Enjoy the calm! ☕</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- ── Right column ─────────────────────────────────────────────── -->
        <div class="lg:col-span-2 space-y-5">

            <!-- My In-Progress -->
            <div class="flex items-center justify-between">
                <h2 class="serif text-xl text-stone-300">In Progress</h2>
                <span class="text-xs bg-blue-900/30 text-blue-400 px-3 py-1 rounded-full border border-blue-900/30">
                    <?php echo $preparing_batches->num_rows; ?> preparing
                </span>
            </div>

            <?php if ($preparing_batches->num_rows > 0): ?>
                <?php while ($b = $preparing_batches->fetch_assoc()): ?>
                <?php $items = getBatchItems($conn, $b['id']); ?>
                <div class="glass rounded-2xl p-5">
                    <div class="flex justify-between items-start mb-3">
                        <div>
                            <span class="text-xs text-blue-400 font-bold uppercase tracking-wide">Order #<?php echo $b['id']; ?></span>
                            <div class="text-stone-200 font-semibold mt-0.5"><?php echo htmlspecialchars($b['customer_name']); ?></div>
                            <div class="text-stone-500 text-xs"><?php echo htmlspecialchars($b['phone']); ?></div>
                        </div>
                        <div class="text-xs text-stone-500"><?php echo date('g:i A', strtotime($b['order_date'])); ?></div>
                    </div>

                    <!-- Items summary -->
                    <div class="bg-stone-900/40 rounded-xl p-3 mb-4 space-y-1">
                        <?php foreach ($items as $li): ?>
                        <div class="flex items-center gap-2 text-sm">
                            <span class="w-5 h-5 rounded-full bg-amber-900/40 text-amber-400 text-[10px] font-bold flex items-center justify-center shrink-0"><?php echo $li['quantity']; ?></span>
                            <span class="text-stone-300"><?php echo htmlspecialchars($li['item_name']); ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <form method="POST">
                        <input type="hidden" name="batch_id" value="<?php echo $b['id']; ?>">
                        <button name="ready_batch" class="w-full bg-amber-700 hover:bg-amber-600 text-white py-2.5 rounded-xl text-sm font-bold transition">
                            ✓ Mark as Ready for Delivery
                        </button>
                    </form>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="glass rounded-2xl p-6 text-center">
                    <p class="text-stone-600 text-sm italic">Nothing in progress</p>
                </div>
            <?php endif; ?>

            <!-- Shift notice -->
            <div class="bg-amber-950/20 border border-amber-900/30 rounded-2xl p-5 mt-2">
                <h3 class="text-amber-500 font-bold text-xs uppercase tracking-wider mb-2">☀ Shift Notice</h3>
                <p class="text-stone-400 text-sm leading-relaxed">Ethiopia beans running low. Switch to House Blend once current hopper is empty.</p>
            </div>

            <!-- Checklist -->
            <div class="glass rounded-2xl p-5">
                <h3 class="text-stone-400 font-bold text-xs uppercase tracking-wider mb-4">Shift Checklist</h3>
                <div class="space-y-3">
                    <?php foreach (['Refill Espresso Hopper','Clean Portafilters','Empty Grounds Bin','Wipe Steam Wand'] as $task): ?>
                    <label class="flex items-center gap-3 cursor-pointer group">
                        <input type="checkbox" class="w-4 h-4 rounded accent-amber-500">
                        <span class="text-stone-400 group-hover:text-stone-200 text-sm transition"><?php echo $task; ?></span>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>