<?php
/**
 * Roast & Revel - Order Processor v2
 * Handles: add to cart, remove from cart, batch checkout (with address/phone/order_type)
 */
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth.php"); exit();
}

$user_id = (int)$_SESSION['user_id'];

// helper: detect AJAX requests
function is_ajax() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) &&
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

// helper: fetch current cart info
function fetch_cart($conn, $user_id) {
    $cart  = [];
    $res   = $conn->query("SELECT * FROM orders WHERE user_id=$user_id AND status='pending' AND batch_id IS NULL ORDER BY order_date ASC");
    $total = 0;
    while ($r = $res->fetch_assoc()) {
        $r['subtotal'] = $r['total_price'] * $r['quantity'];
        $total        += $r['subtotal'];
        $cart[]        = $r;
    }
    return ['data' => $cart, 'grand_total' => $total, 'count' => count($cart)];
}

/**
 * Renders the cart HTML using the dark-theme CSS classes defined in user_dashboard.php.
 * $mobile = true  → wraps in .mobile-cart-inner (no header)
 * $mobile = false → wraps in .cart-sidebar-inner (includes header)
 */
function renderCartHTML(array $cart_data, float $grand_total, int $cart_count, bool $mobile): string {
    ob_start();
    $wrapper = $mobile ? 'mobile-cart-inner' : 'cart-sidebar-inner';
    ?>
    <div class="<?php echo $wrapper; ?>">

        <?php if (!$mobile): ?>
        <div class="cart-header">
            <h2 class="cart-title">Your Cart</h2>
            <?php if ($cart_count > 0): ?>
            <span id="cart-summary-count" class="cart-count-badge"><?php echo $cart_count; ?> item<?php echo $cart_count !== 1 ? 's' : ''; ?></span>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if (empty($cart_data)): ?>
            <div class="cart-empty">
                <div class="cart-empty-icon">☕</div>
                <p class="cart-empty-text">Your cart is empty.<br><em>Add something delicious!</em></p>
            </div>

        <?php else: ?>
            <div class="cart-items">
                <?php foreach ($cart_data as $row): ?>
                <div class="cart-row">
                    <div class="cart-row-info">
                        <p class="cart-item-name"><?php echo htmlspecialchars($row['item_name']); ?></p>
                        <p class="cart-item-sub">
                            $<?php echo number_format($row['total_price'], 2); ?> × <?php echo (int)$row['quantity']; ?>
                        </p>
                    </div>
                    <div class="cart-row-actions">
                        <span class="cart-item-subtotal">$<?php echo number_format($row['subtotal'], 2); ?></span>
                        <a href="process_order.php?remove_id=<?php echo (int)$row['id']; ?>&ajax=1"
                           class="cart-remove remove-cart-item" title="Remove item">
                            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                            </svg>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="cart-total-row">
                <span class="cart-total-label">Total</span>
                <span class="cart-total-amount">$<?php echo number_format($grand_total, 2); ?></span>
            </div>

            <button onclick="openCheckout()" class="btn-place-order">
                Place Order →
            </button>

        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}


// ─── ADD TO CART ──────────────────────────────────────────────────────────────
if (isset($_POST['add_to_cart'])) {
    $item_name      = trim($_POST['item_name'] ?? '');
    $quantity_to_add = max(1, (int)($_POST['quantity'] ?? 1));

    // Verify product exists and is available (prevents price tampering)
    $stmt = $conn->prepare("SELECT id, name, price FROM products WHERE name=? AND is_available=1 LIMIT 1");
    $stmt->bind_param("s", $item_name);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($product) {
        // Check if same item already in pending cart (not yet batched)
        $check = $conn->prepare(
            "SELECT id, quantity FROM orders
             WHERE user_id=? AND item_name=? AND status='pending' AND batch_id IS NULL
             LIMIT 1"
        );
        $check->bind_param("is", $user_id, $product['name']);
        $check->execute();
        $existing = $check->get_result()->fetch_assoc();
        $check->close();

        if ($existing) {
            $new_qty = $existing['quantity'] + $quantity_to_add;
            $upd = $conn->prepare("UPDATE orders SET quantity=? WHERE id=?");
            $upd->bind_param("ii", $new_qty, $existing['id']);
            $upd->execute();
            $upd->close();
        } else {
            $cname = $_SESSION['user_name'] ?? 'Guest';
            $ins = $conn->prepare(
                "INSERT INTO orders (user_id, item_name, total_price, quantity, status, customer_name)
                 VALUES (?, ?, ?, ?, 'pending', ?)"
            );
            $ins->bind_param("isdis", $user_id, $product['name'], $product['price'], $quantity_to_add, $cname);
            $ins->execute();
            $ins->close();
        }
        $ajaxSuccess = true;
    } else {
        $ajaxSuccess = false;
    }

    if (is_ajax()) {
        $cart = fetch_cart($conn, $user_id);
        $resp = [
            'success'      => $ajaxSuccess,
            'cart_desktop' => renderCartHTML($cart['data'], $cart['grand_total'], $cart['count'], false),
            'cart_mobile'  => renderCartHTML($cart['data'], $cart['grand_total'], $cart['count'], true),
            'cart_count'   => $cart['count'],
            'grand_total'  => $cart['grand_total'],
        ];
        if (!$ajaxSuccess) {
            $resp['error'] = 'product_not_found';
        }
        header('Content-Type: application/json');
        echo json_encode($resp);
        exit();
    }

    header("Location: user_dashboard.php"); exit();
}

// ─── REMOVE FROM CART ─────────────────────────────────────────────────────────
if (isset($_GET['remove_id'])) {
    $id   = (int)$_GET['remove_id'];
    $stmt = $conn->prepare(
        "DELETE FROM orders WHERE id=? AND user_id=? AND status='pending' AND batch_id IS NULL"
    );
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
    $stmt->close();

    if (is_ajax()) {
        $cart = fetch_cart($conn, $user_id);
        $resp = [
            'success'      => true,
            'cart_desktop' => renderCartHTML($cart['data'], $cart['grand_total'], $cart['count'], false),
            'cart_mobile'  => renderCartHTML($cart['data'], $cart['grand_total'], $cart['count'], true),
            'cart_count'   => $cart['count'],
            'grand_total'  => $cart['grand_total'],
        ];
        header('Content-Type: application/json');
        echo json_encode($resp);
        exit();
    }

    header("Location: user_dashboard.php"); exit();
}

// ─── BATCH CHECKOUT ───────────────────────────────────────────────────────────
if (isset($_POST['checkout'])) {

    // 1. Collect & validate delivery details
    $customer_name = trim($_POST['customer_name'] ?? '');
    $phone         = trim($_POST['phone']         ?? '');
    $address       = trim($_POST['address']       ?? '');
    $city          = trim($_POST['city']          ?? '');
    $notes         = trim($_POST['notes']         ?? '');
    $order_type    = in_array($_POST['order_type'] ?? '', ['delivery', 'takeout', 'dine-in'])
                     ? $_POST['order_type'] : 'delivery';

    // If the user selected a saved address, load it
    $used_saved_address = false;
    if (!empty($_POST['address_id']) && is_numeric($_POST['address_id'])) {
        $used_saved_address = true;
        $aid    = (int)$_POST['address_id'];
        $addr_q = $conn->prepare(
            "SELECT address, city FROM user_addresses WHERE id=? AND user_id=? LIMIT 1"
        );
        $addr_q->bind_param("ii", $aid, $user_id);
        $addr_q->execute();
        $found = $addr_q->get_result()->fetch_assoc();
        $addr_q->close();
        if ($found) {
            $address = $found['address'];
            $city    = $found['city'];
        }
    }

    // For dine-in / takeout, address not required
    if ($order_type !== 'delivery' && empty($address)) {
        $address = ucfirst($order_type);
    }

    if (empty($customer_name) || empty($phone)) {
        if (is_ajax()) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'missing_fields']);
            exit();
        }
        header("Location: user_dashboard.php?error=missing_fields"); exit();
    }

    // 2. Fetch pending cart items
    $items_stmt = $conn->prepare(
        "SELECT id, item_name, total_price, quantity FROM orders
         WHERE user_id=? AND status='pending' AND batch_id IS NULL"
    );
    $items_stmt->bind_param("i", $user_id);
    $items_stmt->execute();
    $items_result = $items_stmt->get_result();

    if ($items_result->num_rows === 0) {
        if (is_ajax()) {
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'empty_cart']);
            exit();
        }
        header("Location: user_dashboard.php"); exit();
    }

    $items       = [];
    $batch_total = 0;
    while ($row = $items_result->fetch_assoc()) {
        $row['subtotal'] = $row['total_price'] * $row['quantity'];
        $batch_total    += $row['subtotal'];
        $items[]         = $row;
    }
    $items_stmt->close();

    // 3. Create order batch record
    $batch_stmt = $conn->prepare(
        "INSERT INTO order_batches
            (user_id, customer_name, phone, address, city, notes, order_type, batch_total, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')"
    );
    $batch_stmt->bind_param(
        "issssssd",
        $user_id, $customer_name, $phone, $address, $city, $notes, $order_type, $batch_total
    );
    $batch_stmt->execute();
    $batch_id = $conn->insert_id;
    $batch_stmt->close();

    // 4. Link each order line to this batch
    $upd_stmt = $conn->prepare(
        "UPDATE orders
         SET batch_id=?, status='pending', customer_name=?, order_type=?
         WHERE id=? AND user_id=?"
    );
    foreach ($items as $item) {
        $upd_stmt->bind_param("issii", $batch_id, $customer_name, $order_type, $item['id'], $user_id);
        $upd_stmt->execute();
    }
    $upd_stmt->close();

    // 5. Persist phone on user profile for pre-fill next time
    $upd_user = $conn->prepare("UPDATE users SET phone=? WHERE id=?");
    $upd_user->bind_param("si", $phone, $user_id);
    $upd_user->execute();
    $upd_user->close();

    // 6. Auto-save new delivery address (avoid duplicates)
    $newAddressInserted = false;
    if ($order_type === 'delivery' && !$used_saved_address && !empty($address)) {
        $chk = $conn->prepare(
            "SELECT id FROM user_addresses WHERE user_id=? AND address=? AND city=? LIMIT 1"
        );
        $chk->bind_param("iss", $user_id, $address, $city);
        $chk->execute();
        $exists = $chk->get_result()->fetch_assoc();
        $chk->close();

        if (!$exists) {
            $cntRes = $conn->prepare("SELECT COUNT(*) AS cnt FROM user_addresses WHERE user_id=?");
            $cntRes->bind_param("i", $user_id);
            $cntRes->execute();
            $cnt     = $cntRes->get_result()->fetch_assoc()['cnt'];
            $defFlag = ($cnt == 0) ? 1 : 0;
            $cntRes->close();

            $insAddr = $conn->prepare(
                "INSERT INTO user_addresses (user_id, address, city, is_default) VALUES (?, ?, ?, ?)"
            );
            $insAddr->bind_param("issi", $user_id, $address, $city, $defFlag);
            $insAddr->execute();
            $insAddr->close();
            $newAddressInserted = true;
        }
    }

    if (is_ajax()) {
        $resp = [
            'success'      => true,
            'cart_desktop' => renderCartHTML([], 0, 0, false),
            'cart_mobile'  => renderCartHTML([], 0, 0, true),
            'cart_count'   => 0,
            'grand_total'  => 0,
        ];
        if ($newAddressInserted) {
            $list = [];
            $res  = $conn->query(
                "SELECT * FROM user_addresses WHERE user_id=$user_id ORDER BY is_default DESC, id DESC"
            );
            while ($r = $res->fetch_assoc()) { $list[] = $r; }
            $resp['addresses'] = $list;
        }
        header('Content-Type: application/json');
        echo json_encode($resp);
        exit();
    }

    header("Location: user_dashboard.php?success=1"); exit();
}

// ─── ADDRESS MANAGEMENT ───────────────────────────────────────────────────────
if (isset($_POST['action'])) {

    $action = $_POST['action'];

    // ADD ADDRESS
    if ($action === 'add_address') {
        $addr         = trim($_POST['address'] ?? '');
        $city         = trim($_POST['city']    ?? '');
        $label        = trim($_POST['label']   ?? '');
        $make_default = !empty($_POST['is_default']) ? 1 : 0;

        if ($addr === '') {
            if (is_ajax()) {
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'error' => 'empty_address']);
                exit();
            }
            header("Location: user_dashboard.php?error=empty_address"); exit();
        }

        if ($make_default) {
            $conn->query("UPDATE user_addresses SET is_default=0 WHERE user_id=$user_id");
        }

        $stmt = $conn->prepare(
            "INSERT INTO user_addresses (user_id, label, address, city, is_default) VALUES (?, ?, ?, ?, ?)"
        );
        $stmt->bind_param("isssi", $user_id, $label, $addr, $city, $make_default);
        $stmt->execute();
        $stmt->close();

        if (is_ajax()) {
            $list = [];
            $res  = $conn->query(
                "SELECT * FROM user_addresses WHERE user_id=$user_id ORDER BY is_default DESC, id DESC"
            );
            while ($r = $res->fetch_assoc()) { $list[] = $r; }
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'addresses' => $list]);
            exit();
        }
        header("Location: user_dashboard.php?msg=address_added"); exit();
    }

    // EDIT ADDRESS
    if ($action === 'edit_address') {
        $id           = (int)($_POST['id'] ?? 0);
        $addr         = trim($_POST['address'] ?? '');
        $city         = trim($_POST['city']    ?? '');
        $label        = trim($_POST['label']   ?? '');
        $make_default = !empty($_POST['is_default']) ? 1 : 0;

        if ($id && $addr !== '') {
            if ($make_default) {
                $conn->query("UPDATE user_addresses SET is_default=0 WHERE user_id=$user_id");
            }
            $stmt = $conn->prepare(
                "UPDATE user_addresses SET label=?, address=?, city=?, is_default=?
                 WHERE id=? AND user_id=?"
            );
            $stmt->bind_param("sssiii", $label, $addr, $city, $make_default, $id, $user_id);
            $stmt->execute();
            $stmt->close();
        }

        if (is_ajax()) {
            $list = [];
            $res  = $conn->query(
                "SELECT * FROM user_addresses WHERE user_id=$user_id ORDER BY is_default DESC, id DESC"
            );
            while ($r = $res->fetch_assoc()) { $list[] = $r; }
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'addresses' => $list]);
            exit();
        }
        header("Location: user_dashboard.php"); exit();
    }

    // DELETE ADDRESS
    if ($action === 'delete_address') {
        $id   = (int)($_POST['id'] ?? 0);
        $stmt = $conn->prepare("DELETE FROM user_addresses WHERE id=? AND user_id=?");
        $stmt->bind_param("ii", $id, $user_id);
        $stmt->execute();
        $stmt->close();

        if (is_ajax()) {
            $list = [];
            $res  = $conn->query(
                "SELECT * FROM user_addresses WHERE user_id=$user_id ORDER BY is_default DESC, id DESC"
            );
            while ($r = $res->fetch_assoc()) { $list[] = $r; }
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'addresses' => $list]);
            exit();
        }
        header("Location: user_dashboard.php"); exit();
    }
}

// Fallback
header("Location: user_dashboard.php"); exit();