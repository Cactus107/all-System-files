<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) { header("Location: ../auth.php"); exit(); }

$user_id   = (int)$_SESSION['user_id'];
$user_name = htmlspecialchars($_SESSION['user_name'] ?? 'Guest');

// Profile for checkout pre-fill (including phone now)
$profile = $conn->prepare("SELECT first_name, last_name, phone FROM users WHERE id = ?");
$profile->bind_param("i", $user_id);
$profile->execute();
$profile_data = $profile->get_result()->fetch_assoc();
$full_name = trim(($profile_data['first_name'] ?? '') . ' ' . ($profile_data['last_name'] ?? ''));
$profile_phone = htmlspecialchars($profile_data['phone'] ?? '');

// SAVED ADDRESSES (for checkout modal)
$addr_result = $conn->query("SELECT * FROM user_addresses WHERE user_id=$user_id ORDER BY is_default DESC, id DESC");
$addresses = [];
while ($a = $addr_result->fetch_assoc()) { $addresses[] = $a; }

// Menu grouped by category
$menu_result = $conn->query("SELECT * FROM products WHERE is_available=1 ORDER BY category, name");
$categories  = [];
while ($item = $menu_result->fetch_assoc()) {
    $categories[$item['category']][] = $item;
}

// Pending cart items (not yet in a batch)
$cart_result = $conn->query("SELECT * FROM orders WHERE user_id=$user_id AND status='pending' AND batch_id IS NULL ORDER BY order_date ASC");
$cart_data   = [];
$grand_total = 0;
while ($row = $cart_result->fetch_assoc()) {
    $row['subtotal'] = $row['total_price'] * $row['quantity'];
    $grand_total    += $row['subtotal'];
    $cart_data[]     = $row;
}
$cart_count = count($cart_data);

// Past batch orders with all items
$batches_result = $conn->query("SELECT * FROM order_batches WHERE user_id=$user_id ORDER BY order_date DESC LIMIT 20");
$past_batches   = [];
while ($b = $batches_result->fetch_assoc()) {
    $bid = (int)$b['id'];
    $it  = $conn->query("SELECT item_name, quantity, total_price FROM orders WHERE batch_id=$bid");
    $b['items'] = [];
    while ($i = $it->fetch_assoc()) { $b['items'][] = $i; }
    $past_batches[] = $b;
}
$history_count = count($past_batches);

$status_cfg = [
    'pending'    => ['label'=>'Pending',    'dot'=>'#f59e0b'],
    'preparing'  => ['label'=>'Preparing',  'dot'=>'#3b82f6'],
    'delivering' => ['label'=>'Delivering', 'dot'=>'#8b5cf6'],
    'completed'  => ['label'=>'Completed',  'dot'=>'#10b981'],
    'cancelled'  => ['label'=>'Cancelled',  'dot'=>'#ef4444'],
];

// helper: render cart fragment (desktop/mobile)
function renderCartHTML(array $cart_data, float $grand_total, int $cart_count, bool $mobile): string {
    ob_start(); ?>
    <div class="<?php echo $mobile ? 'mobile-cart-inner' : 'cart-sidebar-inner'; ?>">
        <?php if (!$mobile): ?>
        <div class="cart-header">
            <h2 class="cart-title">Your Cart</h2>
            <?php if ($cart_count > 0): ?>
            <span id="cart-summary-count" class="cart-count-badge"><?php echo $cart_count; ?> items</span>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if (empty($cart_data)): ?>
            <div class="cart-empty">
                <div class="cart-empty-icon">☕</div>
                <p class="cart-empty-text">Your cart is empty.<br><em>Add something delicious!</em></p>
            </div>
        <?php else: ?>
            <div class="cart-items">
                <?php foreach ($cart_data as $row): ?>
                <div class="cart-row">
                    <div class="cart-row-info">
                        <p class="cart-item-name"><?php echo htmlspecialchars($row['item_name']); ?></p>
                        <p class="cart-item-sub">$<?php echo number_format($row['total_price'], 2); ?> × <?php echo $row['quantity']; ?></p>
                    </div>
                    <div class="cart-row-actions">
                        <span class="cart-item-subtotal">$<?php echo number_format($row['subtotal'], 2); ?></span>
                        <a href="process_order.php?remove_id=<?php echo $row['id']; ?>&ajax=1"
                           class="cart-remove remove-cart-item" title="Remove">
                            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="cart-total-row">
                <span class="cart-total-label">Total</span>
                <span class="cart-total-amount">$<?php echo number_format($grand_total, 2); ?></span>
            </div>

            <button onclick="openCheckout()" class="btn-place-order">
                Place Order →
            </button>
        <?php endif; ?>
    </div>
    <?php return ob_get_clean();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order | Roast &amp; Revel</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Cormorant+Garamond:wght@300;400;500;600&family=Josefin+Sans:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
    :root {
        --cream: #f5f0e8;
        --cream-muted: rgba(245,240,232,0.55);
        --cream-faint: rgba(245,240,232,0.18);
        --espresso: #1e120a;
        --espresso-mid: #2c1a0e;
        --espresso-light: #3a2418;
        --caramel: #c07c3a;
        --gold: #d4a843;
        --gold-dim: rgba(212,168,67,0.35);
        --gold-faint: rgba(212,168,67,0.12);
        --rose: #c4796a;
        --sage: #7a8c6e;
        --border: rgba(212,168,67,0.18);
        --border-hover: rgba(212,168,67,0.5);
    }

    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    html { scroll-behavior: smooth; }

    body {
        font-family: 'Cormorant Garamond', serif;
        background-color: var(--espresso);
        background-image:
            radial-gradient(ellipse at 15% 40%, rgba(192,124,58,0.07) 0%, transparent 55%),
            radial-gradient(ellipse at 85% 70%, rgba(44,26,14,0.6) 0%, transparent 50%);
        color: var(--cream);
        min-height: 100vh;
    }

    /* ── NAVBAR ───────────────────────────────────────────────────── */
    .navbar {
        position: fixed; top: 0; left: 0; right: 0; z-index: 40;
        height: 68px;
        background: rgba(18,9,4,0.88);
        backdrop-filter: blur(18px);
        border-bottom: 1px solid var(--border);
        display: flex; align-items: center;
    }
    .navbar-inner {
        max-width: 1440px; margin: 0 auto;
        width: 100%; padding: 0 28px;
        display: flex; align-items: center; justify-content: space-between; gap: 16px;
    }
    .brand {
        font-family: 'Playfair Display', serif;
        font-size: 22px; font-weight: 700;
        color: var(--cream);
        text-decoration: none;
        letter-spacing: 0.02em;
    }
    .brand em { font-style: italic; color: var(--gold); }

    .nav-right { display: flex; align-items: center; gap: 10px; }

    .nav-greeting {
        font-family: 'Josefin Sans', sans-serif;
        font-size: 11px; letter-spacing: 2px; text-transform: uppercase;
        color: var(--cream-muted);
    }
    .nav-greeting strong { color: var(--cream); }

    .nav-btn {
        display: flex; align-items: center; gap: 7px;
        background: none; border: 1px solid var(--border);
        color: var(--cream-muted);
        font-family: 'Josefin Sans', sans-serif;
        font-size: 10px; letter-spacing: 2px; text-transform: uppercase;
        padding: 8px 16px; border-radius: 30px; cursor: pointer;
        transition: all 0.25s;
    }
    .nav-btn:hover, .nav-btn.active {
        color: var(--gold); border-color: var(--gold-dim);
        background: var(--gold-faint);
    }
    .nav-btn svg { width: 14px; height: 14px; }

    .nav-badge {
        background: var(--gold); color: var(--espresso);
        font-size: 9px; font-weight: 700;
        border-radius: 50%; width: 16px; height: 16px;
        display: flex; align-items: center; justify-content: center;
    }
    .nav-chevron {
        transition: transform 0.3s;
        opacity: 0.5;
    }
    .nav-chevron.rotated { transform: rotate(180deg); }

    .nav-logout {
        font-family: 'Josefin Sans', sans-serif;
        font-size: 10px; letter-spacing: 2px; text-transform: uppercase;
        color: var(--cream-muted); text-decoration: none; padding: 8px 4px;
        transition: color 0.2s;
    }
    .nav-logout:hover { color: var(--rose); }

    /* mobile nav items */
    .nav-mobile-cart-btn {
        background: var(--espresso-light); border: 1px solid var(--border);
        color: var(--cream); width: 38px; height: 38px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        cursor: pointer; position: relative; transition: border-color 0.2s;
    }
    .nav-mobile-cart-btn:hover { border-color: var(--gold-dim); }
    .nav-mobile-cart-btn svg { width: 16px; height: 16px; }

    .ham-btn {
        background: none; border: 1px solid var(--border);
        width: 38px; height: 38px; border-radius: 50%;
        display: flex; flex-direction: column; align-items: center; justify-content: center;
        gap: 5px; cursor: pointer; transition: border-color 0.2s;
    }
    .ham-btn:hover { border-color: var(--gold-dim); }
    .ham-line {
        display: block; width: 18px; height: 1.5px;
        background: var(--cream); border-radius: 2px;
        transition: transform 0.25s ease, opacity 0.2s;
    }
    #hamburger.open .ham-line:nth-child(1) { transform: translateY(6.5px) rotate(45deg); }
    #hamburger.open .ham-line:nth-child(2) { opacity: 0; transform: scaleX(0); }
    #hamburger.open .ham-line:nth-child(3) { transform: translateY(-6.5px) rotate(-45deg); }

    /* ── MOBILE NAV DRAWER ────────────────────────────────────────── */
    #mobile-nav {
        position: fixed; top: 68px; left: 0; right: 0; z-index: 45;
        background: #160d06; border-bottom: 1px solid var(--border);
        box-shadow: 0 24px 64px rgba(0,0,0,0.7);
        transform: translateY(-12px); opacity: 0; pointer-events: none;
        transition: transform 0.28s cubic-bezier(0.4,0,0.2,1), opacity 0.22s ease;
    }
    #mobile-nav.open { transform: translateY(0); opacity: 1; pointer-events: all; }
    .mobile-nav-inner { padding: 20px; }
    .mobile-nav-greeting {
        display: flex; align-items: center; gap: 12px;
        padding: 14px 16px; margin-bottom: 10px;
        background: var(--espresso-light); border: 1px solid var(--border); border-radius: 12px;
    }
    .mobile-nav-avatar {
        width: 36px; height: 36px; border-radius: 50%;
        background: var(--gold-faint); border: 1px solid var(--gold-dim);
        display: flex; align-items: center; justify-content: center;
        font-family: 'Josefin Sans', sans-serif; font-size: 13px; font-weight: 600; color: var(--gold);
    }
    .mobile-nav-name { font-size: 15px; font-weight: 600; color: var(--cream); }
    .mobile-nav-role { font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 2px; text-transform: uppercase; color: var(--cream-muted); }

    .mobile-nav-item {
        display: flex; align-items: center; gap: 12px;
        width: 100%; background: none; border: none; text-align: left;
        padding: 12px 14px; border-radius: 10px; cursor: pointer;
        text-decoration: none; transition: background 0.18s; color: var(--cream);
    }
    .mobile-nav-item:hover { background: var(--gold-faint); }
    .mobile-nav-icon {
        width: 32px; height: 32px; border-radius: 8px;
        display: flex; align-items: center; justify-content: center;
        flex-shrink: 0;
    }
    .mobile-nav-icon svg { width: 15px; height: 15px; }
    .mobile-nav-label { font-size: 14px; font-weight: 500; color: var(--cream); flex: 1; }
    .mobile-nav-sub { font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 1px; text-transform: uppercase; color: var(--cream-muted); }
    .mobile-nav-sep { height: 1px; background: var(--border); margin: 8px 0; }
    #mobile-nav-bg { position: fixed; inset: 0; z-index: 44; background: rgba(0,0,0,0.4); display: none; }

    /* ── HISTORY DRAWER ───────────────────────────────────────────── */
    #history-drawer {
        position: fixed; top: 68px; left: 0; right: 0; z-index: 35;
        background: #160d06; border-bottom: 1px solid var(--border);
        box-shadow: 0 24px 64px rgba(0,0,0,0.7);
        transform: translateY(-12px); opacity: 0; pointer-events: none;
        transition: transform 0.3s cubic-bezier(0.4,0,0.2,1), opacity 0.25s ease;
        max-height: calc(100vh - 68px); overflow-y: auto;
    }
    #history-drawer.open { transform: translateY(0); opacity: 1; pointer-events: all; }
    #history-drawer::-webkit-scrollbar { width: 4px; }
    #history-drawer::-webkit-scrollbar-track { background: transparent; }
    #history-drawer::-webkit-scrollbar-thumb { background: var(--gold-dim); border-radius: 2px; }
    .history-inner { max-width: 1440px; margin: 0 auto; padding: 32px 28px 40px; }
    .history-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 28px; }
    .history-heading { font-family: 'Playfair Display', serif; font-size: 36px; font-weight: 400; color: var(--cream); }
    .history-subhead { font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 2px; text-transform: uppercase; color: var(--cream-muted); margin-top: 6px; }
    .history-close-btn {
        background: none; border: 1px solid var(--border); border-radius: 50%;
        width: 36px; height: 36px; display: flex; align-items: center; justify-content: center;
        color: var(--cream-muted); cursor: pointer; transition: all 0.2s;
    }
    .history-close-btn:hover { border-color: var(--gold-dim); color: var(--gold); }

    .history-tabs { display: flex; gap: 4px; margin-bottom: 24px; background: var(--espresso-light); border: 1px solid var(--border); border-radius: 30px; padding: 4px; width: fit-content; }
    .history-tab {
        font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 2px; text-transform: uppercase;
        padding: 8px 20px; border-radius: 25px; cursor: pointer; border: none; background: none;
        color: var(--cream-muted); transition: all 0.2s;
    }
    .history-tab.active { background: var(--gold); color: var(--espresso); font-weight: 600; }

    .history-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; }
    .history-card {
        background: var(--espresso-light); border: 1px solid var(--border); border-radius: 16px;
        padding: 18px; transition: border-color 0.2s, box-shadow 0.2s;
    }
    .history-card:hover { border-color: var(--gold-dim); box-shadow: 0 8px 32px rgba(0,0,0,0.4); }
    .hc-top { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px; }
    .hc-batch-id {
        font-family: 'Josefin Sans', sans-serif; font-size: 9px; letter-spacing: 2px; text-transform: uppercase; color: var(--cream-muted);
        display: flex; align-items: center; gap: 6px;
    }
    .hc-dot { width: 7px; height: 7px; border-radius: 50%; display: inline-block; }
    .hc-date { font-family: 'Josefin Sans', sans-serif; font-size: 10px; color: var(--cream-muted); margin-top: 3px; }
    .hc-status {
        font-family: 'Josefin Sans', sans-serif; font-size: 9px; letter-spacing: 1.5px; text-transform: uppercase;
        padding: 3px 10px; border-radius: 20px; font-weight: 700;
    }
    .hcs-pending    { background: rgba(245,158,11,0.15); color: #f59e0b; }
    .hcs-preparing  { background: rgba(59,130,246,0.15); color: #60a5fa; }
    .hcs-delivering { background: rgba(139,92,246,0.15); color: #a78bfa; }
    .hcs-completed  { background: rgba(16,185,129,0.15); color: #34d399; }
    .hcs-cancelled  { background: rgba(239,68,68,0.15);  color: #f87171; }

    .hc-type-badge {
        font-family: 'Josefin Sans', sans-serif; font-size: 9px; text-transform: uppercase; letter-spacing: 1.5px;
        padding: 3px 10px; border-radius: 20px; background: var(--gold-faint); border: 1px solid var(--gold-dim);
        color: var(--gold); display: inline-block; margin-bottom: 12px;
    }
    .hc-items-box {
        background: rgba(0,0,0,0.25); border: 1px solid var(--border); border-radius: 10px;
        padding: 12px; margin-bottom: 12px;
    }
    .hc-items-label { font-family: 'Josefin Sans', sans-serif; font-size: 9px; letter-spacing: 2px; text-transform: uppercase; color: var(--cream-muted); margin-bottom: 8px; }
    .hc-item-row { display: flex; justify-content: space-between; align-items: center; gap: 8px; margin-bottom: 6px; }
    .hc-item-row:last-of-type { margin-bottom: 0; }
    .hc-item-qty {
        width: 20px; height: 20px; border-radius: 50%;
        background: var(--gold-faint); border: 1px solid var(--gold-dim);
        color: var(--gold); font-family: 'Josefin Sans', sans-serif; font-size: 9px; font-weight: 700;
        display: flex; align-items: center; justify-content: center; flex-shrink: 0;
    }
    .hc-item-name { font-size: 13px; color: var(--cream); flex: 1; }
    .hc-item-price { font-family: 'Josefin Sans', sans-serif; font-size: 11px; color: var(--cream-muted); font-weight: 500; }
    .hc-items-footer { display: flex; justify-content: space-between; padding-top: 8px; border-top: 1px solid var(--border); margin-top: 8px; }
    .hc-items-count { font-family: 'Josefin Sans', sans-serif; font-size: 9px; letter-spacing: 1px; text-transform: uppercase; color: var(--cream-muted); }
    .hc-items-total { font-family: 'Josefin Sans', sans-serif; font-size: 12px; font-weight: 700; color: var(--cream); }
    .hc-address { display: flex; align-items: flex-start; gap: 6px; font-size: 12px; color: var(--cream-muted); margin-bottom: 8px; }
    .hc-address svg { width: 13px; height: 13px; flex-shrink: 0; margin-top: 1px; color: var(--caramel); }
    .hc-notes { font-size: 12px; color: var(--caramel); background: rgba(192,124,58,0.08); border: 1px solid rgba(192,124,58,0.2); border-radius: 8px; padding: 8px 12px; margin-bottom: 8px; font-style: italic; }
    .hc-footer { display: flex; justify-content: space-between; align-items: center; padding-top: 10px; border-top: 1px solid var(--border); }
    .hc-phone { display: flex; align-items: center; gap: 5px; font-family: 'Josefin Sans', sans-serif; font-size: 10px; color: var(--cream-muted); }
    .hc-phone svg { width: 11px; height: 11px; }
    .hc-grand { font-family: 'Josefin Sans', sans-serif; font-size: 14px; font-weight: 700; color: var(--gold); }

    /* Addresses panel */
    .addr-card { display: flex; justify-content: space-between; align-items: center; padding: 14px 16px; background: var(--espresso-light); border: 1px solid var(--border); border-radius: 12px; margin-bottom: 8px; }
    .addr-card-info p { font-size: 14px; color: var(--cream); }
    .addr-card-info .addr-label { font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 1px; text-transform: uppercase; color: var(--cream-muted); margin-top: 2px; }
    .addr-default-badge { font-family: 'Josefin Sans', sans-serif; font-size: 10px; color: var(--gold); font-weight: 700; }
    .addr-card-btns { display: flex; gap: 6px; flex-shrink: 0; margin-left: 12px; }
    .addr-btn {
        font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 1px; text-transform: uppercase;
        padding: 5px 12px; border-radius: 20px; border: 1px solid var(--border);
        background: none; color: var(--cream-muted); cursor: pointer; transition: all 0.18s;
    }
    .addr-btn:hover { border-color: var(--gold-dim); color: var(--gold); }
    .addr-btn.del:hover { border-color: rgba(196,121,106,0.4); color: var(--rose); }
    .add-addr-btn {
        display: flex; align-items: center; gap: 6px;
        background: none; border: none; color: var(--gold);
        font-family: 'Josefin Sans', sans-serif; font-size: 11px; letter-spacing: 1.5px; text-transform: uppercase;
        cursor: pointer; padding: 4px 0; transition: opacity 0.2s;
    }
    .add-addr-btn:hover { opacity: 0.75; }
    .addr-form {
        background: var(--espresso-light); border: 1px solid var(--border); border-radius: 14px;
        padding: 18px; margin-top: 12px; display: none;
    }
    .addr-form.visible { display: block; }

    #history-backdrop { position: fixed; inset: 0; z-index: 30; background: rgba(0,0,0,0.25); display: none; }

    /* ── MAIN LAYOUT ──────────────────────────────────────────────── */
    .main-wrapper {
        padding-top: 88px;
        max-width: 1440px; margin: 0 auto; padding-left: 28px; padding-right: 28px;
        padding-bottom: 60px;
        display: flex; gap: 32px; align-items: flex-start;
    }

    .menu-area { flex: 1; min-width: 0; }

    .page-heading-block { margin-bottom: 36px; padding-bottom: 24px; border-bottom: 1px solid var(--border); }
    .page-brand-tag { font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 4px; text-transform: uppercase; color: var(--gold); margin-bottom: 10px; }
    .page-title { font-family: 'Playfair Display', serif; font-size: clamp(36px, 4vw, 56px); font-weight: 400; color: var(--cream); line-height: 1.05; }
    .page-title em { font-style: italic; color: var(--gold); }
    .page-hint { font-family: 'Josefin Sans', sans-serif; font-size: 11px; letter-spacing: 2px; text-transform: uppercase; color: var(--cream-muted); margin-top: 10px; }

    /* ── CATEGORY FILTER ─────────────────────────────────────────── */
    .filter-bar {
        display: flex; flex-wrap: wrap; gap: 8px;
        margin-bottom: 36px;
        padding-bottom: 24px;
        border-bottom: 1px solid var(--border);
    }
    .filter-pill {
        font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 2px; text-transform: uppercase;
        padding: 8px 18px; border-radius: 30px; cursor: pointer;
        border: 1px solid var(--border); background: none; color: var(--cream-muted);
        transition: all 0.22s;
        white-space: nowrap;
    }
    .filter-pill:hover { color: var(--cream); border-color: var(--gold-dim); }
    .filter-pill.active {
        background: var(--gold); color: var(--espresso);
        border-color: var(--gold); font-weight: 600;
    }

    /* ── CATEGORY SECTIONS ───────────────────────────────────────── */
    .category-section {
        margin-bottom: 52px;
        animation: fadeUp 0.35s ease forwards;
    }
    .category-section.hidden {
        display: none !important;
    }
    .category-section.filter-reveal {
        animation: fadeUp 0.35s ease forwards;
    }
    @keyframes fadeUp { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }

    .category-label-row {
        display: flex; align-items: center; gap: 16px; margin-bottom: 20px;
    }
    .category-label {
        font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 4px; text-transform: uppercase;
        color: var(--gold); white-space: nowrap; flex-shrink: 0;
    }
    .category-rule { flex: 1; height: 1px; background: linear-gradient(90deg, var(--gold-dim), transparent); }
    .category-count { font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 1px; color: var(--cream-muted); flex-shrink: 0; }

    /* 3-column product grid */
    .menu-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 16px;
    }
    @media (max-width: 900px) { .menu-grid { grid-template-columns: repeat(2, 1fr); } }
    @media (max-width: 580px) { .menu-grid { grid-template-columns: 1fr; } }

    .menu-card {
        background: rgba(255,255,255,0.03); border: 1px solid var(--border); border-radius: 14px;
        padding: 18px 18px 16px;
        display: flex; justify-content: space-between; align-items: flex-start; gap: 12px;
        transition: transform 0.22s, border-color 0.22s, box-shadow 0.22s;
    }
    .menu-card:hover {
        transform: translateY(-3px);
        border-color: var(--gold-dim);
        box-shadow: 0 12px 40px rgba(0,0,0,0.45);
    }
    .menu-card-body { flex: 1; min-width: 0; }
    .menu-item-name { font-family: 'Playfair Display', serif; font-size: 17px; font-weight: 400; color: var(--cream); line-height: 1.25; margin-bottom: 5px; }
    .menu-item-desc { font-size: 13px; color: var(--cream-muted); line-height: 1.55; margin-bottom: 10px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
    .menu-item-price { font-family: 'Josefin Sans', sans-serif; font-size: 15px; color: var(--gold); letter-spacing: 1px; }

    .btn-add {
        width: 38px; height: 38px; border-radius: 50%; border: none; flex-shrink: 0;
        background: rgba(212,168,67,0.1); border: 1px solid var(--gold-dim);
        color: var(--gold); font-size: 22px; font-weight: 300;
        display: flex; align-items: center; justify-content: center;
        cursor: pointer; transition: all 0.2s; line-height: 1;
    }
    .btn-add:hover { background: var(--gold); color: var(--espresso); transform: scale(1.1); }

    /* ── CART SIDEBAR (desktop) ───────────────────────────────────── */
    .cart-sidebar-wrap {
        width: 300px; flex-shrink: 0;
        position: sticky; top: 88px;
        max-height: calc(100vh - 108px); overflow-y: auto;
        display: none;
    }
    .cart-sidebar-wrap::-webkit-scrollbar { width: 3px; }
    .cart-sidebar-wrap::-webkit-scrollbar-thumb { background: var(--gold-dim); border-radius: 2px; }
    @media (min-width: 1100px) { .cart-sidebar-wrap { display: block; } }

    .cart-sidebar-inner {
        background: rgba(255,255,255,0.03); border: 1px solid var(--border); border-radius: 18px;
        padding: 22px;
    }
    .cart-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .cart-title { font-family: 'Playfair Display', serif; font-size: 22px; font-weight: 400; color: var(--cream); }
    .cart-count-badge { font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 1.5px; text-transform: uppercase; padding: 4px 10px; border-radius: 20px; background: var(--gold-faint); border: 1px solid var(--gold-dim); color: var(--gold); }
    .cart-empty { text-align: center; padding: 40px 16px; }
    .cart-empty-icon { font-size: 40px; margin-bottom: 12px; opacity: 0.5; }
    .cart-empty-text { font-size: 14px; color: var(--cream-muted); line-height: 1.6; }

    .cart-items { margin-bottom: 16px; }
    .cart-row {
        display: flex; justify-content: space-between; align-items: center;
        padding: 10px 0; border-bottom: 1px solid var(--gold-faint);
    }
    .cart-row:last-child { border-bottom: none; }
    .cart-row-info { flex: 1; min-width: 0; padding-right: 10px; }
    .cart-item-name { font-size: 14px; font-weight: 500; color: var(--cream); line-height: 1.3; }
    .cart-item-sub { font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 1px; color: var(--cream-muted); margin-top: 2px; }
    .cart-row-actions { display: flex; align-items: center; gap: 8px; flex-shrink: 0; }
    .cart-item-subtotal { font-family: 'Josefin Sans', sans-serif; font-size: 13px; font-weight: 600; color: var(--cream); }
    .cart-remove {
        color: rgba(245,240,232,0.2); cursor: pointer; padding: 3px;
        display: flex; align-items: center; text-decoration: none;
        transition: color 0.2s;
    }
    .cart-remove:hover { color: var(--rose); }

    .cart-total-row {
        display: flex; justify-content: space-between; align-items: center;
        padding: 14px 0; border-top: 1px solid var(--gold-dim); border-bottom: 1px solid var(--gold-dim);
        margin-bottom: 16px;
    }
    .cart-total-label { font-family: 'Josefin Sans', sans-serif; font-size: 11px; letter-spacing: 3px; text-transform: uppercase; color: var(--cream-muted); }
    .cart-total-amount { font-family: 'Playfair Display', serif; font-size: 24px; color: var(--gold); }

    .btn-place-order {
        width: 100%; padding: 14px;
        background: var(--gold); color: var(--espresso);
        border: none; border-radius: 10px; cursor: pointer;
        font-family: 'Josefin Sans', sans-serif; font-size: 11px; letter-spacing: 3px; text-transform: uppercase; font-weight: 600;
        transition: all 0.22s;
    }
    .btn-place-order:hover { background: var(--caramel); box-shadow: 0 8px 24px rgba(212,168,67,0.25); }

    /* ── MOBILE CART PANEL ────────────────────────────────────────── */
    #mobile-cart {
        position: fixed; inset-y-0: 0; right: 0; top: 0; bottom: 0;
        width: min(100%, 360px); background: var(--espresso-mid);
        border-left: 1px solid var(--border); z-index: 50;
        display: flex; flex-direction: column;
        transform: translateX(100%); transition: transform 0.3s ease;
        box-shadow: -16px 0 48px rgba(0,0,0,0.5);
    }
    #mobile-cart.open { transform: translateX(0); }
    #mobile-cart.open ~ #mobile-cart-bg { display: block; }
    #mobile-cart-bg { position: fixed; inset: 0; z-index: 49; background: rgba(0,0,0,0.5); display: none; }
    .mobile-cart-header { display: flex; justify-content: space-between; align-items: center; padding: 20px 22px; border-bottom: 1px solid var(--border); }
    .mobile-cart-title { font-family: 'Playfair Display', serif; font-size: 22px; color: var(--cream); }
    .mobile-cart-close { background: none; border: 1px solid var(--border); border-radius: 50%; width: 34px; height: 34px; color: var(--cream-muted); cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s; }
    .mobile-cart-close:hover { border-color: var(--gold-dim); color: var(--gold); }
    .mobile-cart-body { flex: 1; overflow-y: auto; padding: 16px 22px; }
    .mobile-cart-inner .cart-empty { padding: 60px 16px; }

    .nav-float-badge {
        position: absolute; top: -4px; right: -4px;
        background: var(--gold); color: var(--espresso);
        font-family: 'Josefin Sans', sans-serif; font-size: 9px; font-weight: 700;
        width: 16px; height: 16px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
    }

    /* ── MODALS shared ───────────────────────────────────────────── */
    .modal-overlay {
        position: fixed; inset: 0; z-index: 50;
        background: rgba(0,0,0,0.7); backdrop-filter: blur(6px);
        display: none; align-items: flex-end; justify-content: center;
        padding: 0;
    }
    @media (min-width: 600px) { .modal-overlay { align-items: center; padding: 16px; } }
    .modal-overlay.open { display: flex; }

    .modal-box {
        background: var(--espresso-mid); border: 1px solid var(--border);
        width: 100%; max-width: 500px;
        border-radius: 24px 24px 0 0; overflow: hidden;
        animation: popIn 0.32s cubic-bezier(0.34,1.56,0.64,1) forwards;
        max-height: 95vh; display: flex; flex-direction: column;
    }
    @media (min-width: 600px) { .modal-box { border-radius: 22px; } }
    @keyframes popIn { from{opacity:0;transform:scale(0.94) translateY(18px)} to{opacity:1;transform:scale(1) translateY(0)} }

    .modal-header {
        display: flex; justify-content: space-between; align-items: flex-start;
        padding: 22px 24px 18px; border-bottom: 1px solid var(--border);
        flex-shrink: 0;
    }
    .modal-title { font-family: 'Playfair Display', serif; font-size: 26px; font-weight: 400; color: var(--cream); }
    .modal-subtitle { font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 2px; text-transform: uppercase; color: var(--cream-muted); margin-top: 4px; }
    .modal-close { background: none; border: 1px solid var(--border); border-radius: 50%; width: 34px; height: 34px; color: var(--cream-muted); cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s; flex-shrink: 0; margin-top: 2px; }
    .modal-close:hover { border-color: var(--gold-dim); color: var(--gold); }

    .modal-body { overflow-y: auto; flex: 1; }
    .modal-body::-webkit-scrollbar { width: 3px; }
    .modal-body::-webkit-scrollbar-thumb { background: var(--gold-dim); border-radius: 2px; }

    .checkout-summary-block { padding: 16px 24px; background: rgba(0,0,0,0.2); border-bottom: 1px solid var(--border); }
    .checkout-items-label { font-family: 'Josefin Sans', sans-serif; font-size: 9px; letter-spacing: 3px; text-transform: uppercase; color: var(--cream-muted); margin-bottom: 12px; }
    .checkout-item-row { display: flex; justify-content: space-between; font-size: 14px; margin-bottom: 6px; }
    .checkout-item-row .item-qty { color: var(--cream-muted); font-size: 13px; }
    .checkout-grand { display: flex; justify-content: space-between; align-items: center; padding-top: 12px; border-top: 1px solid var(--border); margin-top: 6px; }
    .checkout-grand-label { font-family: 'Josefin Sans', sans-serif; font-size: 11px; letter-spacing: 2px; text-transform: uppercase; color: var(--cream-muted); }
    .checkout-grand-amount { font-family: 'Playfair Display', serif; font-size: 26px; color: var(--gold); }

    .checkout-form-body { padding: 20px 24px; }
    .field-label { display: block; font-family: 'Josefin Sans', sans-serif; font-size: 9px; letter-spacing: 2.5px; text-transform: uppercase; color: var(--cream-muted); margin-bottom: 7px; }
    .field {
        width: 100%; padding: 11px 14px;
        background: rgba(0,0,0,0.25); border: 1px solid var(--border); border-radius: 10px;
        color: var(--cream); font-family: 'Cormorant Garamond', serif; font-size: 16px;
        transition: border-color 0.18s, box-shadow 0.18s;
    }
    .field::placeholder { color: rgba(245,240,232,0.25); }
    .field:focus { outline: none; border-color: var(--gold-dim); box-shadow: 0 0 0 3px rgba(212,168,67,0.1); }
    .field-group { margin-bottom: 16px; }
    .seg-pills { display: flex; gap: 8px; flex-wrap: wrap; }
    .seg-pill {
        font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 1.5px; text-transform: uppercase;
        padding: 8px 16px; border-radius: 25px; cursor: pointer;
        border: 1px solid var(--border); color: var(--cream-muted); background: none;
        transition: all 0.18s;
    }
    .seg-pill:has(input:checked) { background: var(--gold); color: var(--espresso); border-color: var(--gold); font-weight: 600; }
    .checkout-submit {
        width: 100%; padding: 15px;
        background: var(--gold); color: var(--espresso); border: none; border-radius: 12px;
        font-family: 'Josefin Sans', sans-serif; font-size: 12px; letter-spacing: 3px; text-transform: uppercase; font-weight: 700;
        cursor: pointer; margin-top: 6px; transition: all 0.22s;
    }
    .checkout-submit:hover { background: var(--caramel); box-shadow: 0 8px 24px rgba(212,168,67,0.3); }

    /* Order type faded */
    #address-fields { transition: opacity 0.2s; }

    /* Saved address rows in checkout */
    .saved-addr-row { display: flex; justify-content: space-between; align-items: center; padding: 10px 12px; background: rgba(0,0,0,0.2); border: 1px solid var(--border); border-radius: 10px; margin-bottom: 8px; }
    .saved-addr-text { font-size: 14px; color: var(--cream); }
    .saved-addr-sub { font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 1px; color: var(--cream-muted); margin-top: 2px; }
    .use-addr-btn {
        font-family: 'Josefin Sans', sans-serif; font-size: 10px; letter-spacing: 1.5px; text-transform: uppercase;
        padding: 6px 14px; border-radius: 20px; border: 1px solid var(--gold-dim);
        background: none; color: var(--gold); cursor: pointer; transition: all 0.18s; flex-shrink: 0; margin-left: 10px;
    }
    .use-addr-btn:hover { background: var(--gold-faint); }

    /* Notes field */
    textarea.field { resize: none; min-height: 70px; }

    /* ── SUCCESS MODAL ────────────────────────────────────────────── */
    #success-overlay { position: fixed; inset: 0; z-index: 60; background: rgba(0,0,0,0.8); backdrop-filter: blur(8px); display: none; align-items: center; justify-content: center; padding: 16px; }
    #success-overlay.open { display: flex; }
    .success-box { background: var(--espresso-mid); border: 1px solid var(--border); border-radius: 24px; padding: 40px 32px; text-align: center; max-width: 360px; width: 100%; animation: popIn 0.35s cubic-bezier(0.34,1.56,0.64,1); }
    .success-icon { width: 64px; height: 64px; border-radius: 50%; background: rgba(16,185,129,0.12); border: 1px solid rgba(16,185,129,0.3); display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; }
    .success-icon svg { width: 32px; height: 32px; color: #34d399; }
    .success-title { font-family: 'Playfair Display', serif; font-size: 34px; font-weight: 400; color: var(--cream); margin-bottom: 8px; }
    .success-msg { font-size: 15px; color: var(--cream-muted); line-height: 1.55; margin-bottom: 24px; }
    .success-btn { width: 100%; padding: 14px; background: var(--gold); color: var(--espresso); border: none; border-radius: 12px; font-family: 'Josefin Sans', sans-serif; font-size: 11px; letter-spacing: 3px; text-transform: uppercase; font-weight: 700; cursor: pointer; transition: background 0.2s; }
    .success-btn:hover { background: var(--caramel); }

    /* ── QUANTITY MODAL ───────────────────────────────────────────── */
    #quantity-modal { position: fixed; inset: 0; z-index: 55; background: rgba(0,0,0,0.75); backdrop-filter: blur(6px); display: none; align-items: flex-end; justify-content: center; }
    @media(min-width:600px){ #quantity-modal { align-items: center; padding: 16px; } }
    #quantity-modal.flex { display: flex; }
    .qty-modal-box { background: var(--espresso-mid); border: 1px solid var(--border); border-radius: 22px 22px 0 0; padding: 28px 24px; width: 100%; max-width: 380px; animation: popIn 0.3s cubic-bezier(0.34,1.56,0.64,1); }
    @media(min-width:600px){ .qty-modal-box { border-radius: 22px; } }
    .qty-modal-title { font-family: 'Playfair Display', serif; font-size: 24px; color: var(--cream); margin-bottom: 4px; }
    .qty-modal-item { font-family: 'Josefin Sans', sans-serif; font-size: 11px; letter-spacing: 1.5px; text-transform: uppercase; color: var(--cream-muted); margin-bottom: 24px; }
    .qty-control { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
    .qty-label { font-family: 'Josefin Sans', sans-serif; font-size: 11px; letter-spacing: 2px; text-transform: uppercase; color: var(--cream-muted); }
    .qty-stepper { display: flex; align-items: center; gap: 0; background: rgba(0,0,0,0.3); border: 1px solid var(--border); border-radius: 30px; padding: 4px 8px; }
    .qty-stepper button { background: none; border: none; color: var(--cream); font-size: 18px; font-weight: 300; width: 30px; height: 30px; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: color 0.18s; }
    .qty-stepper button:hover { color: var(--gold); }
    .qty-stepper input { width: 44px; text-align: center; background: none; border: none; color: var(--cream); font-family: 'Cormorant Garamond', serif; font-size: 20px; font-weight: 500; outline: none; }
    .qty-price-row { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; background: rgba(212,168,67,0.07); border: 1px solid var(--gold-faint); border-radius: 10px; margin-bottom: 20px; }
    .qty-price-label { font-family: 'Josefin Sans', sans-serif; font-size: 11px; letter-spacing: 2px; text-transform: uppercase; color: var(--cream-muted); }
    .qty-price-val { font-family: 'Playfair Display', serif; font-size: 26px; color: var(--gold); }
    .qty-add-btn { width: 100%; padding: 14px; background: var(--gold); color: var(--espresso); border: none; border-radius: 12px; font-family: 'Josefin Sans', sans-serif; font-size: 11px; letter-spacing: 3px; text-transform: uppercase; font-weight: 700; cursor: pointer; margin-bottom: 10px; transition: background 0.2s; }
    .qty-add-btn:hover { background: var(--caramel); }
    .qty-cancel-btn { width: 100%; background: none; border: none; color: var(--cream-muted); font-family: 'Josefin Sans', sans-serif; font-size: 11px; letter-spacing: 2px; text-transform: uppercase; cursor: pointer; padding: 8px; transition: color 0.18s; }
    .qty-cancel-btn:hover { color: var(--cream); }

    /* Divider in checkout form */
    .form-divider { height: 1px; background: var(--border); margin: 4px 0 16px; }

    /* Fade-up animation for section reveal */
    .category-section { opacity: 1; }
    .category-section.hidden { display: none; }

    /* responsive adjustments */
    @media (max-width: 768px) {
        .main-wrapper { padding-left: 16px; padding-right: 16px; }
        .history-inner { padding: 24px 16px 32px; }
    }
    @media (min-width: 1100px) { .nav-mobile-items { display: none !important; } }
    @media (max-width: 1099px) { .nav-desktop-items { display: none !important; } }
    </style>
</head>
<body>

<!-- ══ NAVBAR ══════════════════════════════════════════════════════════════ -->
<nav class="navbar">
    <div class="navbar-inner">
        <a href="../index.php" class="brand">Roast<em>&amp;</em>Revel</a>

        <!-- Desktop -->
        <div class="nav-right nav-desktop-items">
            <span class="nav-greeting">Hi, <strong><?php echo $user_name; ?></strong></span>

            <button id="hist-btn" onclick="toggleHistory()" class="nav-btn">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                My Orders
                <?php if ($history_count > 0): ?>
                <span class="nav-badge"><?php echo min($history_count, 9); ?></span>
                <?php endif; ?>
                <svg id="hist-chevron" class="nav-chevron" width="12" height="12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M19 9l-7 7-7-7"/></svg>
            </button>

            <a href="../logout.php" class="nav-logout">Logout</a>
        </div>

        <!-- Mobile -->
        <div class="nav-right nav-mobile-items">
            <button onclick="document.getElementById('mobile-cart').classList.toggle('open')" class="nav-mobile-cart-btn">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                <?php if ($cart_count > 0): ?>
                <span id="nav-cart-count" class="nav-float-badge"><?php echo $cart_count; ?></span>
                <?php endif; ?>
            </button>
            <button id="hamburger" onclick="toggleMobileNav()" class="ham-btn">
                <span class="ham-line"></span>
                <span class="ham-line"></span>
                <span class="ham-line"></span>
            </button>
        </div>
    </div>
</nav>

<!-- ══ MOBILE NAV DRAWER ═══════════════════════════════════════════════════ -->
<div id="mobile-nav">
    <div class="mobile-nav-inner">
        <div class="mobile-nav-greeting">
            <div class="mobile-nav-avatar"><?php echo mb_strtoupper(mb_substr($user_name,0,1)); ?></div>
            <div>
                <div class="mobile-nav-name"><?php echo $user_name; ?></div>
                <div class="mobile-nav-role">Customer</div>
            </div>
        </div>

        <button onclick="closeMobileNav(); toggleHistory();" class="mobile-nav-item">
            <span class="mobile-nav-icon" style="background:rgba(212,168,67,0.12)">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color:var(--gold)"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            </span>
            <div>
                <div class="mobile-nav-label">My Orders</div>
                <div class="mobile-nav-sub"><?php echo $history_count; ?> order<?php echo $history_count!==1?'s':''; ?></div>
            </div>
            <?php if ($history_count > 0): ?><span class="nav-badge"><?php echo min($history_count,9); ?></span><?php endif; ?>
        </button>

        <button onclick="closeMobileNav(); toggleHistory(); switchHistoryTab('addresses');" class="mobile-nav-item">
            <span class="mobile-nav-icon" style="background:rgba(139,180,212,0.12)">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color:#8bb4d4"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
            </span>
            <div>
                <div class="mobile-nav-label">My Addresses</div>
                <div class="mobile-nav-sub"><?php echo count($addresses); ?> saved</div>
            </div>
        </button>

        <button onclick="closeMobileNav(); document.getElementById('mobile-cart').classList.add('open');" class="mobile-nav-item">
            <span class="mobile-nav-icon" style="background:rgba(245,240,232,0.05)">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color:var(--cream-muted)"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
            </span>
            <div>
                <div class="mobile-nav-label">View Cart</div>
                <div class="mobile-nav-sub"><?php echo $cart_count; ?> item<?php echo $cart_count!==1?'s':''; ?></div>
            </div>
            <?php if ($cart_count > 0): ?><span class="nav-badge"><?php echo $cart_count; ?></span><?php endif; ?>
        </button>

        <div class="mobile-nav-sep"></div>

        <a href="../logout.php" class="mobile-nav-item" style="color:var(--rose)">
            <span class="mobile-nav-icon" style="background:rgba(196,121,106,0.1)">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="color:var(--rose)"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/></svg>
            </span>
            <div class="mobile-nav-label" style="color:var(--rose)">Logout</div>
        </a>
    </div>
</div>
<div id="mobile-nav-bg" onclick="closeMobileNav()"></div>

<!-- ══ HISTORY DRAWER ══════════════════════════════════════════════════════ -->
<div id="history-drawer">
    <div class="history-inner">
        <div class="history-top">
            <div>
                <h2 class="history-heading">Order History</h2>
                <p class="history-subhead">
                    <?php echo $history_count > 0
                        ? $history_count.' order'.($history_count!==1?'s':'').' placed'
                        : 'No orders yet'; ?>
                </p>
            </div>
            <button onclick="toggleHistory()" class="history-close-btn">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>

        <div class="history-tabs">
            <button id="tab-orders"    class="history-tab active" onclick="switchHistoryTab('orders')">Orders</button>
            <button id="tab-addresses" class="history-tab"        onclick="switchHistoryTab('addresses')">Addresses</button>
        </div>

        <!-- Orders -->
        <div id="history-orders">
            <?php if (empty($past_batches)): ?>
            <div style="text-align:center;padding:60px 0">
                <div style="font-size:48px;margin-bottom:16px;opacity:0.3">🧾</div>
                <p style="font-family:'Josefin Sans',sans-serif;font-size:11px;letter-spacing:2px;text-transform:uppercase;color:var(--cream-muted)">No orders placed yet</p>
            </div>
            <?php else: ?>
            <div class="history-grid">
                <?php foreach ($past_batches as $idx => $b):
                    $status = $b['status'];
                    $sc     = $status_cfg[$status] ?? $status_cfg['pending'];
                    $is_active = in_array($status, ['pending','preparing','delivering']);
                    $ti = ['delivery'=>'🛵 Delivery','takeout'=>'🥡 Takeout','dine-in'=>'☕ Dine-in'];
                ?>
                <div class="history-card">
                    <div class="hc-top">
                        <div>
                            <div class="hc-batch-id">
                                <span class="hc-dot <?php echo $is_active?'animate-pulse':''; ?>" style="background:<?php echo $sc['dot']; ?>"></span>
                                Batch #<?php echo $b['id']; ?>
                            </div>
                            <div class="hc-date"><?php echo date('M j, Y · g:i A', strtotime($b['order_date'])); ?></div>
                        </div>
                        <span class="hc-status hcs-<?php echo $status; ?>"><?php echo strtoupper($sc['label']); ?></span>
                    </div>
                    <div class="hc-type-badge"><?php echo $ti[$b['order_type']] ?? $b['order_type']; ?></div>
                    <div class="hc-items-box">
                        <div class="hc-items-label">Items Ordered</div>
                        <?php foreach ($b['items'] as $li): ?>
                        <div class="hc-item-row">
                            <span class="hc-item-qty"><?php echo $li['quantity']; ?></span>
                            <span class="hc-item-name"><?php echo htmlspecialchars($li['item_name']); ?></span>
                            <span class="hc-item-price">$<?php echo number_format($li['total_price']*$li['quantity'],2); ?></span>
                        </div>
                        <?php endforeach; ?>
                        <div class="hc-items-footer">
                            <span class="hc-items-count"><?php echo count($b['items']); ?> type<?php echo count($b['items'])!==1?'s':''; ?></span>
                            <span class="hc-items-total">$<?php echo number_format($b['batch_total'],2); ?></span>
                        </div>
                    </div>
                    <?php if ($b['order_type']==='delivery' && !empty($b['address'])): ?>
                    <div class="hc-address">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                        <?php echo htmlspecialchars($b['address'].($b['city']?', '.$b['city']:'')); ?>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($b['notes'])): ?>
                    <div class="hc-notes">"<?php echo htmlspecialchars($b['notes']); ?>"</div>
                    <?php endif; ?>
                    <div class="hc-footer">
                        <span class="hc-phone">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                            <?php echo htmlspecialchars($b['phone']); ?>
                        </span>
                        <span class="hc-grand">$<?php echo number_format($b['batch_total'],2); ?></span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Addresses -->
        <div id="history-addresses" class="hidden">
            <div id="history-addresses-list" style="margin-bottom:12px">
                <?php if (empty($addresses)): ?>
                    <p style="font-family:'Josefin Sans',sans-serif;font-size:11px;letter-spacing:1px;color:var(--cream-muted);font-style:italic">No saved addresses.</p>
                <?php else: ?>
                    <?php foreach ($addresses as $a): ?>
                    <div class="addr-card">
                        <div class="addr-card-info">
                            <p><?php echo htmlspecialchars($a['address'].($a['city']?', '.$a['city']:'')); ?></p>
                            <?php if (!empty($a['label'])): ?><p class="addr-label"><?php echo htmlspecialchars($a['label']); ?></p><?php endif; ?>
                            <?php if ($a['is_default']): ?><span class="addr-default-badge">★ Default</span><?php endif; ?>
                        </div>
                        <div class="addr-card-btns">
                            <button class="addr-btn history-use-address-btn" data-addr='<?php echo json_encode($a,JSON_HEX_APOS); ?>'>Use</button>
                            <button class="addr-btn history-edit-address-btn" data-addr='<?php echo json_encode($a,JSON_HEX_APOS); ?>'>Edit</button>
                            <button class="addr-btn del history-delete-address-btn" data-id="<?php echo $a['id']; ?>">Delete</button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <button id="history-add-address-btn" class="add-addr-btn">
                <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4"/></svg>
                Add new address
            </button>
            <div id="history-new-address-form" class="addr-form" style="margin-top:12px">
                <input type="hidden" id="history-edit-id">
                <div class="field-group"><label class="field-label">Label</label><input type="text" id="history-new-label" class="field" placeholder="e.g. Home"></div>
                <div class="field-group"><label class="field-label">Address</label><input type="text" id="history-new-address" class="field" placeholder="Street address"></div>
                <div class="field-group"><label class="field-label">City</label><input type="text" id="history-new-city" class="field" placeholder="City / Municipality"></div>
                <div class="field-group" style="display:flex;align-items:center;gap:8px">
                    <input type="checkbox" id="history-new-default" style="accent-color:var(--gold);width:16px;height:16px">
                    <label for="history-new-default" style="font-family:'Josefin Sans',sans-serif;font-size:11px;letter-spacing:1px;text-transform:uppercase;color:var(--cream-muted);cursor:pointer">Set as default</label>
                </div>
                <div style="display:flex;gap:8px;margin-top:4px">
                    <button id="history-save-address" class="checkout-submit" style="width:auto;padding:10px 22px;margin-top:0">Save</button>
                    <button id="history-cancel-edit" class="qty-cancel-btn" style="width:auto;display:none">Cancel</button>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="history-backdrop" onclick="toggleHistory()"></div>

<!-- ══ SUCCESS MODAL ═══════════════════════════════════════════════════════ -->
<div id="success-overlay">
    <div class="success-box">
        <div class="success-icon">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>
        </div>
        <h2 class="success-title">Order Placed!</h2>
        <p class="success-msg">Thank you! We'll start preparing it right away.<br><span style="font-size:13px;color:var(--cream-muted)">Track your order under "My Orders"</span></p>
        <button onclick="closeSuccessModal()" class="success-btn">Continue Shopping</button>
    </div>
</div>

<!-- ══ QUANTITY MODAL ══════════════════════════════════════════════════════ -->
<div id="quantity-modal">
    <div class="qty-modal-box">
        <div class="qty-modal-title">Select Quantity</div>
        <div class="qty-modal-item" id="modal-item-name">Item</div>
        <div class="qty-control">
            <span class="qty-label">Quantity</span>
            <div class="qty-stepper">
                <button id="qty-minus">−</button>
                <input type="number" id="qty-input" min="1" value="1">
                <button id="qty-plus">+</button>
            </div>
        </div>
        <div class="qty-price-row">
            <span class="qty-price-label">Total Price</span>
            <span class="qty-price-val">$<span id="modal-item-price">0.00</span></span>
        </div>
        <button id="modal-add-btn" class="qty-add-btn">Add to Cart</button>
        <button onclick="closeQuantityModal()" class="qty-cancel-btn">Cancel</button>
    </div>
</div>

<!-- ══ MAIN LAYOUT ══════════════════════════════════════════════════════════ -->
<div class="main-wrapper">

    <!-- Menu area -->
    <div class="menu-area">
        <div class="page-heading-block">
            <div class="page-brand-tag">Est. 2024 · Specialty Café</div>
            <h1 class="page-title">Our <em>Menu</em></h1>
            <p class="page-hint">Select quantity · Add to cart · Place order</p>
        </div>

        <!-- Category Filter -->
        <div class="filter-bar">
            <button class="filter-pill active" onclick="filterCategory('all', this)">All</button>
            <?php foreach (array_keys($categories) as $cat): ?>
            <button class="filter-pill" onclick="filterCategory(<?php echo json_encode($cat); ?>, this)"><?php echo htmlspecialchars($cat); ?></button>
            <?php endforeach; ?>
        </div>

        <!-- Category Sections -->
        <?php foreach ($categories as $category => $items): ?>
        <div class="category-section" data-category="<?php echo htmlspecialchars($category); ?>">
            <div class="category-label-row">
                <span class="category-label"><?php echo htmlspecialchars($category); ?></span>
                <span class="category-rule"></span>
                <span class="category-count"><?php echo count($items); ?> item<?php echo count($items)!==1?'s':''; ?></span>
            </div>
            <div class="menu-grid">
                <?php foreach ($items as $item): ?>
                <div class="menu-card">
                    <div class="menu-card-body">
                        <h3 class="menu-item-name"><?php echo htmlspecialchars($item['name']); ?></h3>
                        <?php if (!empty($item['description'])): ?>
                        <p class="menu-item-desc"><?php echo htmlspecialchars($item['description']); ?></p>
                        <?php endif; ?>
                        <p class="menu-item-price">$<?php echo number_format($item['price'], 2); ?></p>
                    </div>
                    <button class="btn-add btn-add-quantity"
                        data-item-name="<?php echo htmlspecialchars($item['name']); ?>"
                        data-item-price="<?php echo $item['price']; ?>">+</button>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Desktop Cart Sidebar -->
    <div class="cart-sidebar-wrap">
        <?php echo renderCartHTML($cart_data, $grand_total, $cart_count, false); ?>
    </div>
</div>

<!-- ══ MOBILE CART PANEL ═══════════════════════════════════════════════════ -->
<div id="mobile-cart">
    <div class="mobile-cart-header">
        <span class="mobile-cart-title">Your Cart</span>
        <button onclick="document.getElementById('mobile-cart').classList.remove('open')" class="mobile-cart-close">
            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>
    </div>
    <div class="mobile-cart-body">
        <?php echo renderCartHTML($cart_data, $grand_total, $cart_count, true); ?>
    </div>
</div>
<div id="mobile-cart-bg" onclick="document.getElementById('mobile-cart').classList.remove('open')"></div>

<!-- ══ CHECKOUT MODAL ══════════════════════════════════════════════════════ -->
<div id="checkout-overlay" class="modal-overlay">
    <div class="modal-box">
        <div class="modal-header">
            <div>
                <div class="modal-title">Confirm Order</div>
                <div class="modal-subtitle">Fill in your delivery details</div>
            </div>
            <button onclick="closeCheckout()" class="modal-close">
                <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
            </button>
        </div>
        <div class="modal-body">
            <div class="checkout-summary-block" id="checkout-summary">
                <div class="checkout-items-label">Your Items</div>
                <div class="checkout-items-list">
                    <?php foreach ($cart_data as $row): ?>
                    <div class="checkout-item-row">
                        <span><?php echo htmlspecialchars($row['item_name']); ?> <span class="item-qty">× <?php echo $row['quantity']; ?></span></span>
                        <span>$<?php echo number_format($row['subtotal'], 2); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="checkout-grand">
                    <span class="checkout-grand-label">Total</span>
                    <span class="checkout-grand-amount">$<?php echo number_format($grand_total, 2); ?></span>
                </div>
            </div>

            <form action="process_order.php" method="POST" class="checkout-form-body" id="checkout-form">
                <input type="hidden" name="checkout" value="1">

                <div class="field-group">
                    <label class="field-label">Order Type</label>
                    <div class="seg-pills">
                        <label class="seg-pill"><input type="radio" name="order_type" value="delivery" class="hidden" checked> 🛵 Delivery</label>
                        <label class="seg-pill"><input type="radio" name="order_type" value="takeout"  class="hidden"> 🥡 Takeout</label>
                        <label class="seg-pill"><input type="radio" name="order_type" value="dine-in"  class="hidden"> ☕ Dine-in</label>
                    </div>
                </div>

                <div class="field-group">
                    <label class="field-label">Full Name *</label>
                    <input type="text" name="customer_name" required class="field" value="<?php echo htmlspecialchars($full_name); ?>" placeholder="Juan dela Cruz">
                </div>
                <div class="field-group">
                    <label class="field-label">Cellphone *</label>
                    <input type="tel" name="phone" required class="field" value="<?php echo $profile_phone; ?>" placeholder="09171234567" pattern="[0-9+\-\s]{7,20}">
                </div>

                <?php if (!empty($addresses)): ?>
                <div id="saved-addresses" style="margin-bottom:14px">
                    <?php foreach ($addresses as $a): ?>
                    <div class="saved-addr-row">
                        <div>
                            <div class="saved-addr-text"><?php echo htmlspecialchars($a['address'].($a['city']?', '.$a['city']:'')); ?></div>
                            <?php if (!empty($a['label'])): ?><div class="saved-addr-sub"><?php echo htmlspecialchars($a['label']); ?></div><?php endif; ?>
                            <?php if ($a['is_default']): ?><span style="font-family:'Josefin Sans',sans-serif;font-size:10px;color:var(--gold);font-weight:700">★ Default</span><?php endif; ?>
                        </div>
                        <button type="button" class="use-address-btn use-addr-btn" data-addr='<?php echo json_encode($a, JSON_HEX_APOS); ?>'>Use</button>
                    </div>
                    <?php endforeach; ?>
                    <button type="button" id="add-address-btn" class="add-addr-btn" style="margin-top:8px">
                        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4"/></svg>
                        Add new address
                    </button>
                </div>
                <div id="new-address-form" class="addr-form" style="margin-bottom:14px">
                    <div class="field-group"><label class="field-label">Label</label><input type="text" id="new-label" class="field" placeholder="e.g. Home"></div>
                    <div class="field-group"><label class="field-label">Address</label><input type="text" id="new-address" class="field" placeholder="Street address"></div>
                    <div class="field-group"><label class="field-label">City</label><input type="text" id="new-city" class="field" placeholder="City / Municipality"></div>
                    <div class="field-group" style="display:flex;align-items:center;gap:8px">
                        <input type="checkbox" id="new-default" style="accent-color:var(--gold);width:16px;height:16px">
                        <label for="new-default" style="font-family:'Josefin Sans',sans-serif;font-size:11px;letter-spacing:1px;text-transform:uppercase;color:var(--cream-muted);cursor:pointer">Set as default</label>
                    </div>
                    <button type="button" id="save-new-address" class="checkout-submit" style="width:auto;padding:10px 22px;margin-top:4px">Save</button>
                </div>
                <?php else: ?>
                <div id="saved-addresses"></div>
                <div id="new-address-form" class="addr-form" style="display:none;margin-bottom:14px">
                    <div class="field-group"><label class="field-label">Label</label><input type="text" id="new-label" class="field" placeholder="e.g. Home"></div>
                    <div class="field-group"><label class="field-label">Address</label><input type="text" id="new-address" class="field" placeholder="Street address"></div>
                    <div class="field-group"><label class="field-label">City</label><input type="text" id="new-city" class="field" placeholder="City / Municipality"></div>
                    <div class="field-group" style="display:flex;align-items:center;gap:8px">
                        <input type="checkbox" id="new-default" style="accent-color:var(--gold);width:16px;height:16px">
                        <label for="new-default" style="font-family:'Josefin Sans',sans-serif;font-size:11px;letter-spacing:1px;text-transform:uppercase;color:var(--cream-muted);cursor:pointer">Set as default</label>
                    </div>
                    <button type="button" id="save-new-address" class="checkout-submit" style="width:auto;padding:10px 22px;margin-top:4px">Save</button>
                </div>
                <?php endif; ?>

                <div id="address-fields" class="field-group">
                    <label class="field-label">Delivery Address *</label>
                    <input type="text" name="address" id="address-input" class="field" required placeholder="House No., Street, Barangay">
                    <div style="margin-top:8px">
                        <input type="text" name="city" class="field" placeholder="City / Municipality">
                    </div>
                </div>

                <div class="field-group">
                    <label class="field-label">Special Instructions <span style="text-transform:none;font-weight:400;letter-spacing:0;color:var(--cream-muted)">(optional)</span></label>
                    <textarea name="notes" rows="2" class="field" placeholder="e.g. Less ice, extra shot, gate code…"></textarea>
                </div>

                <button type="submit" class="checkout-submit" id="checkout-submit-btn">
                    Place Order — $<?php echo number_format($grand_total, 2); ?> →
                </button>
            </form>
        </div>
    </div>
</div>

<!-- ══ SCRIPTS ══════════════════════════════════════════════════════════════ -->
<script>
var historyOpen   = false;
var mobileNavOpen = false;

// ── Mobile nav ────────────────────────────────────────────────────────────
function toggleMobileNav() {
    mobileNavOpen = !mobileNavOpen;
    document.getElementById('mobile-nav').classList.toggle('open', mobileNavOpen);
    document.getElementById('hamburger').classList.toggle('open', mobileNavOpen);
    document.getElementById('mobile-nav-bg').style.display = mobileNavOpen ? 'block' : 'none';
    document.body.style.overflow = mobileNavOpen ? 'hidden' : '';
}
function closeMobileNav() {
    mobileNavOpen = false;
    document.getElementById('mobile-nav').classList.remove('open');
    document.getElementById('hamburger').classList.remove('open');
    document.getElementById('mobile-nav-bg').style.display = 'none';
    document.body.style.overflow = '';
}

// ── History drawer ────────────────────────────────────────────────────────
function toggleHistory() {
    historyOpen = !historyOpen;
    document.getElementById('history-drawer').classList.toggle('open', historyOpen);
    document.getElementById('history-backdrop').style.display = historyOpen ? 'block' : 'none';
    var chevron = document.getElementById('hist-chevron');
    if (chevron) chevron.classList.toggle('rotated', historyOpen);
    var btn = document.getElementById('hist-btn');
    if (btn) btn.classList.toggle('active', historyOpen);
    document.body.style.overflow = historyOpen ? 'hidden' : '';
}
function switchHistoryTab(tab) {
    var isOrders = (tab === 'orders');
    document.getElementById('tab-orders').classList.toggle('active', isOrders);
    document.getElementById('tab-addresses').classList.toggle('active', !isOrders);
    document.getElementById('history-orders').classList.toggle('hidden', !isOrders);
    document.getElementById('history-addresses').classList.toggle('hidden', isOrders);
}

// ── Category filter ───────────────────────────────────────────────────────
function filterCategory(cat, btn) {
    // Update active pill
    document.querySelectorAll('.filter-pill').forEach(function(p) {
        p.classList.remove('active');
    });
    btn.classList.add('active');

    // Show/hide sections with animation replay
    document.querySelectorAll('.category-section').forEach(function(sec) {
        var match = (cat === 'all' || sec.getAttribute('data-category') === cat);
        if (match) {
            sec.classList.remove('hidden');
            // Force animation replay by removing and re-adding the class
            sec.classList.remove('filter-reveal');
            void sec.offsetWidth; // reflow trigger
            sec.classList.add('filter-reveal');
        } else {
            sec.classList.add('hidden');
            sec.classList.remove('filter-reveal');
        }
    });
}

// ── Checkout ──────────────────────────────────────────────────────────────
function openCheckout() {
    // Count cart rows from either desktop or mobile cart
    var rows = document.querySelectorAll('.cart-sidebar-inner .cart-row, .mobile-cart-inner .cart-row');
    if (rows.length === 0) { alert('Your cart is empty! Add some items first.'); return; }

    document.getElementById('checkout-overlay').classList.add('open');
    document.body.style.overflow = 'hidden';

    // Refresh the summary from live cart DOM
    refreshCheckoutSummary([], 0);

    // Auto-select default address
    document.querySelectorAll('#saved-addresses .use-address-btn').forEach(function(btn){
        try {
            var a = JSON.parse(btn.getAttribute('data-addr'));
            if (a.is_default) { btn.click(); }
        } catch(e) {}
    });
}
function closeCheckout() {
    document.getElementById('checkout-overlay').classList.remove('open');
    document.body.style.overflow = '';
}
function showSuccessModal() {
    document.getElementById('success-overlay').classList.add('open');
    document.getElementById('success-overlay').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}
function closeSuccessModal() {
    document.getElementById('success-overlay').classList.remove('open');
    document.getElementById('success-overlay').style.display = 'none';
    document.body.style.overflow = '';
}

// ── Quantity modal ────────────────────────────────────────────────────────
var currentAddingItem = null;
function openQuantityModal(itemName, itemPrice) {
    document.getElementById('modal-item-name').textContent = itemName;
    document.getElementById('modal-item-price').textContent = parseFloat(itemPrice).toFixed(2);
    document.getElementById('qty-input').value = '1';
    currentAddingItem = { name: itemName, price: parseFloat(itemPrice) };
    document.getElementById('quantity-modal').classList.add('flex');
    document.getElementById('quantity-modal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}
function closeQuantityModal() {
    document.getElementById('quantity-modal').style.display = 'none';
    document.getElementById('quantity-modal').classList.remove('flex');
    document.body.style.overflow = '';
    currentAddingItem = null;
}
function updateModalPrice() {
    if (!currentAddingItem) return;
    var qty = parseInt(document.getElementById('qty-input').value) || 1;
    if (qty < 1) { qty = 1; document.getElementById('qty-input').value = 1; }
    document.getElementById('modal-item-price').textContent = (currentAddingItem.price * qty).toFixed(2);
}
document.getElementById('qty-minus').addEventListener('click', function(){
    var inp = document.getElementById('qty-input');
    var v = parseInt(inp.value)||1;
    if (v > 1) inp.value = v-1;
    updateModalPrice();
});
document.getElementById('qty-plus').addEventListener('click', function(){
    var inp = document.getElementById('qty-input');
    inp.value = (parseInt(inp.value)||1)+1;
    updateModalPrice();
});
document.getElementById('qty-input').addEventListener('input', updateModalPrice);

// ── Cart AJAX ─────────────────────────────────────────────────────────────
function updateCartFromResponse(data) {
    if (!data.success) return;

    // Desktop sidebar — replace the inner box only, preserve sticky wrapper
    var desktopWrap = document.querySelector('.cart-sidebar-wrap');
    if (desktopWrap) desktopWrap.innerHTML = data.cart_desktop;

    // Mobile cart body
    var mobileBody = document.querySelector('#mobile-cart .mobile-cart-body');
    if (mobileBody) mobileBody.innerHTML = data.cart_mobile;

    // Nav badge (mobile)
    var navCount = document.getElementById('nav-cart-count');
    if (data.cart_count > 0) {
        if (navCount) {
            navCount.textContent = data.cart_count;
        } else {
            var mobileCartBtn = document.querySelector('.nav-mobile-cart-btn');
            if (mobileCartBtn) {
                var badge = document.createElement('span');
                badge.id = 'nav-cart-count';
                badge.className = 'nav-float-badge';
                badge.textContent = data.cart_count;
                mobileCartBtn.appendChild(badge);
            }
        }
    } else {
        if (navCount) navCount.remove();
    }

    // Update checkout summary live if modal is open
    if (document.getElementById('checkout-overlay').classList.contains('open')) {
        refreshCheckoutSummary(data.cart_data || [], data.grand_total || 0);
    }

    if (data.cart_count === 0) closeCheckout();
    if (data.addresses) rebuildAddressUI(data.addresses);
}

function refreshCheckoutSummary(items, grandTotal) {
    // Re-build items list inside checkout modal from live cart DOM
    var summaryBlock = document.getElementById('checkout-summary');
    if (!summaryBlock) return;

    // Pull items from the current desktop cart DOM (already updated)
    var cartRows = document.querySelectorAll('.cart-sidebar-wrap .cart-row');
    var itemsHTML = '';
    var total = 0;
    cartRows.forEach(function(row) {
        var name = row.querySelector('.cart-item-name');
        var sub  = row.querySelector('.cart-item-sub');
        var subt = row.querySelector('.cart-item-subtotal');
        if (name && subt) {
            var subtotalVal = parseFloat((subt.textContent||'').replace('$','')) || 0;
            total += subtotalVal;
            itemsHTML += '<div class="checkout-item-row">'
                + '<span>' + escHtml(name.textContent||'') + (sub ? ' <span class="item-qty">' + escHtml(sub.textContent||'') + '</span>' : '') + '</span>'
                + '<span>' + escHtml(subt.textContent||'') + '</span>'
                + '</div>';
        }
    });

    var listEl = summaryBlock.querySelector('.checkout-items-list');
    if (listEl) listEl.innerHTML = itemsHTML;

    var amtEl = summaryBlock.querySelector('.checkout-grand-amount');
    if (amtEl) amtEl.textContent = '$' + (grandTotal || total).toFixed(2);

    // Update submit button total
    var submitBtn = document.getElementById('checkout-submit-btn');
    if (submitBtn) submitBtn.textContent = 'Place Order — $' + (grandTotal || total).toFixed(2) + ' →';
}

function rebuildAddressUI(addresses) {
    var checkout = document.getElementById('saved-addresses');
    if (checkout) {
        var h = '';
        addresses.forEach(function(a){
            h += '<div class="saved-addr-row"><div>'
               + '<div class="saved-addr-text">'+escHtml(a.address+(a.city?', '+a.city:''))+'</div>'
               + (a.label?'<div class="saved-addr-sub">'+escHtml(a.label)+'</div>':'')
               + (a.is_default?'<span style="font-family:\'Josefin Sans\',sans-serif;font-size:10px;color:var(--gold);font-weight:700">★ Default</span>':'')
               + '</div><button type="button" class="use-address-btn use-addr-btn" data-addr=\''+JSON.stringify(a)+'\'>Use</button></div>';
        });
        h += '<button type="button" id="add-address-btn" class="add-addr-btn" style="margin-top:8px">'
           + '<svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4"/></svg>'
           + 'Add new address</button>';
        checkout.innerHTML = h;
    }
    var histList = document.getElementById('history-addresses-list');
    if (histList) {
        var h2 = addresses.length === 0 ? '<p style="font-family:\'Josefin Sans\',sans-serif;font-size:11px;letter-spacing:1px;color:var(--cream-muted);font-style:italic">No saved addresses.</p>' : '';
        addresses.forEach(function(a){
            h2 += '<div class="addr-card"><div class="addr-card-info">'
               + '<p>'+escHtml(a.address+(a.city?', '+a.city:''))+'</p>'
               + (a.label?'<p class="addr-label">'+escHtml(a.label)+'</p>':'')
               + (a.is_default?'<span class="addr-default-badge">★ Default</span>':'')
               + '</div><div class="addr-card-btns">'
               + '<button class="addr-btn history-use-address-btn" data-addr=\''+JSON.stringify(a)+'\'>Use</button>'
               + '<button class="addr-btn history-edit-address-btn" data-addr=\''+JSON.stringify(a)+'\'>Edit</button>'
               + '<button class="addr-btn del history-delete-address-btn" data-id="'+a.id+'">Delete</button>'
               + '</div></div>';
        });
        histList.innerHTML = h2;
    }
}
function escHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

// ── Delegated events ──────────────────────────────────────────────────────
document.addEventListener('click', function(e){
    // Open quantity modal
    var addBtn = e.target.closest('.btn-add-quantity');
    if (addBtn) {
        e.preventDefault();
        openQuantityModal(addBtn.getAttribute('data-item-name'), addBtn.getAttribute('data-item-price'));
        return;
    }
    // Confirm add from modal
    if (e.target.id === 'modal-add-btn') {
        e.preventDefault();
        if (!currentAddingItem) return;
        var qty = parseInt(document.getElementById('qty-input').value)||1;
        var fd = new FormData();
        fd.append('add_to_cart','1'); fd.append('item_name',currentAddingItem.name);
        fd.append('price',currentAddingItem.price); fd.append('quantity',qty);
        fetch('process_order.php',{method:'POST',body:fd,headers:{'X-Requested-With':'XMLHttpRequest'}})
            .then(r=>r.json()).then(function(d){ updateCartFromResponse(d); closeQuantityModal(); })
            .catch(function(){ alert('Failed to add item. Please try again.'); });
        return;
    }
    // Remove item
    var removeLink = e.target.closest('a.remove-cart-item');
    if (removeLink) {
        e.preventDefault();
        fetch(removeLink.href,{headers:{'X-Requested-With':'XMLHttpRequest'}})
            .then(r=>r.json()).then(updateCartFromResponse);
        return;
    }
    // Use saved address in checkout
    if (e.target.classList.contains('use-address-btn') || e.target.classList.contains('use-addr-btn')) {
        try {
            var a = JSON.parse(e.target.getAttribute('data-addr'));
            var ai = document.getElementById('address-input');
            if (ai) ai.value = a.address;
            var cf = document.querySelector('input[name="city"]');
            if (cf) cf.value = a.city||'';
            var hid = document.querySelector('input[name="address_id"]');
            if (!hid) { hid = document.createElement('input'); hid.type='hidden'; hid.name='address_id'; document.getElementById('checkout-form').appendChild(hid); }
            hid.value = a.id;
        } catch(err){}
        return;
    }
    // Toggle add address form
    if (e.target.id==='add-address-btn'||e.target.closest('#add-address-btn')) {
        var f = document.getElementById('new-address-form');
        if (f) f.classList.toggle('visible'), f.style.display = (f.style.display==='block'?'none':'block');
        return;
    }
    // Save address from checkout
    if (e.target.id==='save-new-address') {
        var addr=document.getElementById('new-address').value.trim();
        if (!addr){alert('Please enter address');return;}
        var fd=new FormData();
        fd.append('action','add_address');
        fd.append('label',document.getElementById('new-label').value.trim());
        fd.append('address',addr);
        fd.append('city',document.getElementById('new-city').value.trim());
        if(document.getElementById('new-default').checked) fd.append('is_default','1');
        fetch('process_order.php',{method:'POST',body:fd,headers:{'X-Requested-With':'XMLHttpRequest'}})
            .then(r=>r.json()).then(function(res){
                if(res.success){ rebuildAddressUI(res.addresses); document.getElementById('new-address-form').style.display='none'; }
                else alert('Could not save address');
            });
        return;
    }
    // History: use address
    if (e.target.classList.contains('history-use-address-btn')) {
        try{ var a=JSON.parse(e.target.getAttribute('data-addr')); openCheckout(); document.getElementById('address-input').value=a.address; var cf=document.querySelector('input[name="city"]'); if(cf)cf.value=a.city||''; }catch(err){}
        return;
    }
    // History: edit address
    if (e.target.classList.contains('history-edit-address-btn')) {
        try{
            var a=JSON.parse(e.target.getAttribute('data-addr'));
            document.getElementById('history-new-address-form').style.display='block';
            document.getElementById('history-edit-id').value=a.id;
            document.getElementById('history-new-label').value=a.label||'';
            document.getElementById('history-new-address').value=a.address;
            document.getElementById('history-new-city').value=a.city||'';
            document.getElementById('history-new-default').checked=!!a.is_default;
            document.getElementById('history-cancel-edit').style.display='inline-block';
        }catch(err){}
        return;
    }
    // History: delete address
    if (e.target.classList.contains('history-delete-address-btn')) {
        if (!confirm('Delete this address?')) return;
        var fd=new FormData(); fd.append('action','delete_address'); fd.append('id',e.target.getAttribute('data-id'));
        fetch('process_order.php',{method:'POST',body:fd,headers:{'X-Requested-With':'XMLHttpRequest'}})
            .then(r=>r.json()).then(function(r){ if(r.success) rebuildAddressUI(r.addresses); });
        return;
    }
    // History: open add address form
    if (e.target.id==='history-add-address-btn'||e.target.closest('#history-add-address-btn')) {
        var f=document.getElementById('history-new-address-form');
        f.style.display=f.style.display==='block'?'none':'block';
        document.getElementById('history-edit-id').value='';
        document.getElementById('history-new-label').value='';
        document.getElementById('history-new-address').value='';
        document.getElementById('history-new-city').value='';
        document.getElementById('history-new-default').checked=false;
        document.getElementById('history-cancel-edit').style.display='none';
        return;
    }
    // History: cancel edit
    if (e.target.id==='history-cancel-edit') {
        document.getElementById('history-new-address-form').style.display='none';
        return;
    }
});

// History save address
document.getElementById('history-save-address').addEventListener('click', function(){
    var aid=document.getElementById('history-edit-id').value;
    var addr=document.getElementById('history-new-address').value.trim();
    if (!addr){alert('Please enter address');return;}
    var fd=new FormData();
    fd.append('action',aid?'edit_address':'add_address');
    if(aid) fd.append('id',aid);
    fd.append('label',document.getElementById('history-new-label').value.trim());
    fd.append('address',addr);
    fd.append('city',document.getElementById('history-new-city').value.trim());
    if(document.getElementById('history-new-default').checked) fd.append('is_default','1');
    fetch('process_order.php',{method:'POST',body:fd,headers:{'X-Requested-With':'XMLHttpRequest'}})
        .then(r=>r.json()).then(function(res){
            if(res.success){ rebuildAddressUI(res.addresses); document.getElementById('history-new-address-form').style.display='none'; document.getElementById('history-cancel-edit').style.display='none'; }
            else alert('Could not save address');
        });
});

// Checkout form submit
var checkoutForm = document.getElementById('checkout-form');
if (checkoutForm) {
    checkoutForm.addEventListener('submit', function(e){
        e.preventDefault();
        fetch('process_order.php',{method:'POST',body:new FormData(this),headers:{'X-Requested-With':'XMLHttpRequest'}})
            .then(r=>r.json())
            .then(function(resp){ if(resp.success){ updateCartFromResponse(resp); closeCheckout(); showSuccessModal(); } else alert('Unable to place order.'); })
            .catch(function(){ alert('Could not submit order.'); });
    });
}

// Order type → toggle address required
document.querySelectorAll('input[name="order_type"]').forEach(function(r){
    r.addEventListener('change', function(){
        var af=document.getElementById('address-fields');
        var ai=document.getElementById('address-input');
        if(this.value!=='delivery'){ af.style.opacity='0.4'; ai.removeAttribute('required'); }
        else { af.style.opacity='1'; ai.setAttribute('required','required'); }
    });
});

// Mobile cart backdrop visibility via class observer
var mc = document.getElementById('mobile-cart');
new MutationObserver(function(){
    document.getElementById('mobile-cart-bg').style.display = mc.classList.contains('open') ? 'block' : 'none';
}).observe(mc,{attributes:true,attributeFilter:['class']});

// Escape key
document.addEventListener('keydown', function(e){
    if(e.key==='Escape'){
        if(document.getElementById('quantity-modal').style.display==='flex') closeQuantityModal();
        else if(mobileNavOpen) closeMobileNav();
        else if(historyOpen) toggleHistory();
        else closeCheckout();
    }
});

// Qty modal backdrop
document.getElementById('quantity-modal').addEventListener('click', function(e){ if(e.target===this) closeQuantityModal(); });
</script>
</body>
</html>