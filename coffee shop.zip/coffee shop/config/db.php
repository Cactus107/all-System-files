<?php
// Database Configuration
$host = "localhost";
$db_user = "root"; // Default XAMPP user
$db_pass = "";     // Default XAMPP password
$db_name = "roast_and_revel";

// Create Database Connection
$conn = new mysqli($host, $db_user, $db_pass, $db_name);

// Check Connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8mb4 for better character support
$conn->set_charset("utf8mb4");
?>