-- ============================================================
-- ROAST & REVEL - Full Database Schema v2
-- Run this in phpMyAdmin or MySQL CLI
-- ============================================================

CREATE DATABASE IF NOT EXISTS roast_and_revel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE roast_and_revel;

-- USERS TABLE
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(30) DEFAULT '',
    role ENUM('admin','staff','delivery','user') NOT NULL DEFAULT 'user',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- PRODUCTS / MENU TABLE
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    category ENUM('Coffee','Tea','Pastry','Merchandise','Cold Drinks') NOT NULL DEFAULT 'Coffee',
    is_available TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ORDER BATCHES — one record per checkout (groups all items together)
CREATE TABLE IF NOT EXISTS order_batches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    customer_name VARCHAR(200) NOT NULL,
    phone VARCHAR(30) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(100) DEFAULT '',
    notes TEXT DEFAULT NULL,
    order_type ENUM('dine-in','takeout','delivery') DEFAULT 'delivery',
    batch_total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status ENUM('pending','preparing','delivering','completed','cancelled') DEFAULT 'pending',
    assigned_staff_id INT DEFAULT NULL,
    assigned_delivery_id INT DEFAULT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ORDERS TABLE — individual line items; each belongs to one batch
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    batch_id INT DEFAULT NULL,
    user_id INT NOT NULL,
    item_name VARCHAR(200) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    total_price DECIMAL(10,2) NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (batch_id) REFERENCES order_batches(id) ON DELETE SET NULL
);

-- SAMPLE ADMIN (password: admin123)
INSERT IGNORE INTO users (first_name, last_name, email, password, role) VALUES
('Admin', 'User', 'admin@roast.ph', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- SAMPLE PRODUCTS
INSERT IGNORE INTO products (name, description, price, category) VALUES
('Midnight Velvet Espresso', 'Our darkest roast with notes of smoked chocolate and black cherry.', 5.50, 'Coffee'),
('Honey Lavender Latte',     'Locally sourced wildflower honey infused with dried lavender.',     6.25, 'Coffee'),
('Seasonal Pour Over',       'Single-origin beans brewed to order. Ask your barista for today''s origin.', 7.00, 'Coffee'),
('Cold Brew Nitro',          'Steeped for 18 hours and served on tap for a creamy finish.',       5.75, 'Cold Drinks'),
('Matcha Ceremony',          'Ceremonial grade matcha with oat milk and a hint of vanilla.',      6.00, 'Tea'),
('Butter Croissant',         'Flaky, golden, and buttery — baked fresh every morning.',           3.75, 'Pastry');

-- SAVED ADDRESSES TABLE (users can store multiple delivery locations)
CREATE TABLE IF NOT EXISTS user_addresses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    label VARCHAR(100) DEFAULT NULL,
    address TEXT NOT NULL,
    city VARCHAR(100) DEFAULT '',
    is_default TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Optionally initialize with a default blank record for test users

