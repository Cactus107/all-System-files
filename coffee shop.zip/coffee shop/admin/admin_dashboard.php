<?php
session_start();
require_once '../config/db.php';

// Access Control
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth.php"); exit();
}

$message = "";
$msg_type = "success";

// ─── CSRF ─────────────────────────────────────────────────────────────────────
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ─── CRUD: ADD PRODUCT ────────────────────────────────────────────────────────
if (isset($_POST['add_product'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $message = "Invalid request."; $msg_type = "error";
    } else {
        $name     = trim($_POST['name']);
        $desc     = trim($_POST['description'] ?? '');
        $price    = (float)$_POST['price'];
        $category = $_POST['category'];
        $stmt = $conn->prepare("INSERT INTO products (name, description, price, category) VALUES (?,?,?,?)");
        $stmt->bind_param("ssds", $name, $desc, $price, $category);
        $message = $stmt->execute() ? "✓ Product \"{$name}\" added successfully." : "Error: " . $conn->error;
    }
}

// ─── CRUD: TOGGLE PRODUCT AVAILABILITY ───────────────────────────────────────
if (isset($_GET['toggle_product'])) {
    $id = (int)$_GET['toggle_product'];
    $conn->query("UPDATE products SET is_available = NOT is_available WHERE id = $id");
    header("Location: admin_dashboard.php?tab=inventory"); exit();
}

// ─── CRUD: DELETE PRODUCT ─────────────────────────────────────────────────────
if (isset($_GET['delete_product'])) {
    $id = (int)$_GET['delete_product'];
    $conn->query("DELETE FROM products WHERE id = $id");
    header("Location: admin_dashboard.php?tab=inventory"); exit();
}

// ─── CRUD: UPDATE ORDER STATUS ────────────────────────────────────────────────
if (isset($_POST['update_order_status'])) {
    $order_id   = (int)$_POST['order_id'];
    $new_status = $_POST['new_status'];
    $allowed    = ['pending','preparing','delivering','completed','cancelled'];
    if (in_array($new_status, $allowed)) {
        $conn->query("UPDATE orders SET status='$new_status' WHERE id=$order_id");
        $qs = 'tab=orders';
        if (!empty($_POST['filter_name'])) $qs .= '&filter_name=' . urlencode($_POST['filter_name']);
        if (!empty($_POST['filter_date'])) $qs .= '&filter_date=' . urlencode($_POST['filter_date']);
        header("Location: admin_dashboard.php?$qs"); exit();
    }
}

// ─── CRUD: TOGGLE USER ACTIVE STATE ──────────────────────────────────────────
if (isset($_GET['toggle_user'])) {
    $id = (int)$_GET['toggle_user'];
    $conn->query("UPDATE users SET is_active = NOT is_active WHERE id = $id AND role != 'admin'");
    header("Location: admin_dashboard.php?tab=staff"); exit();
}

// ─── DATA FETCHING ─────────────────────────────────────────────────────────────
$total_revenue  = $conn->query("SELECT COALESCE(SUM(batch_total), 0) as t FROM order_batches WHERE status='completed'")->fetch_assoc()['t'];
$total_orders   = $conn->query("SELECT COUNT(*) as c FROM order_batches")->fetch_assoc()['c'];
$pending_orders = $conn->query("SELECT COUNT(*) as c FROM order_batches WHERE status='pending'")->fetch_assoc()['c'];
$total_products = $conn->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'];
$today_orders   = $conn->query("SELECT COUNT(*) as c FROM order_batches WHERE DATE(order_date)=CURDATE()")->fetch_assoc()['c'];

$filter_cat  = $_GET['filter_cat'] ?? '';
$cat_list    = [];
$cat_res     = $conn->query("SELECT DISTINCT category FROM products ORDER BY category");
while ($c = $cat_res->fetch_assoc()) $cat_list[] = $c['category'];
$where_inv   = $filter_cat !== '' ? "category='" . $conn->real_escape_string($filter_cat) . "'" : '1';
$products    = $conn->query("SELECT * FROM products WHERE $where_inv ORDER BY category, name");

$filter_name = trim($_GET['filter_name'] ?? '');
$filter_date = $_GET['filter_date'] ?? '';
$where_clauses = ['1'];
if ($filter_name !== '') {
    $fn = $conn->real_escape_string($filter_name);
    $where_clauses[] = "(b.customer_name LIKE '%$fn%' OR u.first_name LIKE '%$fn%' OR u.last_name LIKE '%$fn%')";
}
if ($filter_date !== '') {
    $fd = $conn->real_escape_string($filter_date);
    $where_clauses[] = "DATE(b.order_date) = '$fd'";
}
$where_sql   = implode(' AND ', $where_clauses);
$batch_result = $conn->query("SELECT b.*, u.first_name, u.last_name FROM order_batches b LEFT JOIN users u ON b.user_id = u.id WHERE $where_sql ORDER BY b.order_date DESC LIMIT 20");
$staff_list   = $conn->query("SELECT * FROM users WHERE role IN ('staff','delivery') ORDER BY role, first_name");

$top_products = [];
$prod_q = $conn->query("SELECT item_name, SUM(quantity) as qty FROM orders GROUP BY item_name ORDER BY qty DESC LIMIT 5");
while ($r = $prod_q->fetch_assoc()) $top_products[] = $r;

$staff_sales = [];
$staff_q = $conn->query("SELECT u.first_name,u.last_name,COUNT(b.id) as cnt FROM order_batches b LEFT JOIN users u ON b.assigned_staff_id=u.id WHERE b.assigned_staff_id IS NOT NULL GROUP BY b.assigned_staff_id ORDER BY cnt DESC LIMIT 5");
while ($r = $staff_q->fetch_assoc()) $staff_sales[] = $r;

$delivery_sales = [];
$del_q = $conn->query("SELECT u.first_name,u.last_name,COUNT(b.id) as cnt FROM order_batches b LEFT JOIN users u ON b.assigned_delivery_id=u.id WHERE b.assigned_delivery_id IS NOT NULL GROUP BY b.assigned_delivery_id ORDER BY cnt DESC LIMIT 5");
while ($r = $del_q->fetch_assoc()) $delivery_sales[] = $r;

$tab = $_GET['tab'] ?? 'overview';

$nav = [
    'overview'  => ['label' => 'Dashboard',       'icon' => 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6'],
    'inventory' => ['label' => 'Menu / Products',  'icon' => 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2'],
    'orders'    => ['label' => 'All Orders',       'icon' => 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z'],
    'staff'     => ['label' => 'Staff & Delivery', 'icon' => 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Console | Roast & Revel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'DM Sans', sans-serif; background: #0c0a09; color: #e7e5e4; }
        .serif { font-family: 'Playfair Display', serif; }

        /* Sidebar */
        .sidebar-link { transition: all 0.2s; border-left: 3px solid transparent; }
        .sidebar-link.active { background: rgba(251,191,36,0.1); color: #fbbf24; border-left-color: #fbbf24; }
        .sidebar-link:not(.active):hover { background: rgba(255,255,255,0.04); color: #e7e5e4; }

        /* Mobile sidebar slide-in */
        #sidebar {
            transition: transform 0.28s cubic-bezier(0.4,0,0.2,1);
        }

        /* Top mobile navbar */
        .mobile-topbar { backdrop-filter: blur(14px); background: rgba(12,10,9,0.92); }

        /* Hamburger animation */
        .ham-line { display:block; width:22px; height:2px; background:#e7e5e4; border-radius:2px;
                    transition: transform 0.25s ease, opacity 0.2s ease; }
        #hamburger.open .ham-line:nth-child(1) { transform: translateY(7px) rotate(45deg); }
        #hamburger.open .ham-line:nth-child(2) { opacity:0; transform:scaleX(0); }
        #hamburger.open .ham-line:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }

        .stat-card { background: linear-gradient(145deg, #1c1917, #171412); border: 1px solid #292524; }
        .glass { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.07); }
        .badge-pending    { background:rgba(251,191,36,0.15);  color:#fbbf24; }
        .badge-preparing  { background:rgba(59,130,246,0.15);  color:#93c5fd; }
        .badge-delivering { background:rgba(168,85,247,0.15);  color:#d8b4fe; }
        .badge-completed  { background:rgba(52,211,153,0.15);  color:#6ee7b7; }
        .badge-cancelled  { background:rgba(248,113,113,0.15); color:#fca5a5; }
        input, select, textarea { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); color: #e7e5e4; }
        input:focus, select:focus { outline:none; border-color:#b45309; box-shadow:0 0 0 3px rgba(180,83,9,0.2); }
        option { background: #1c1917; }
        ::-webkit-scrollbar { width:6px; }
        ::-webkit-scrollbar-track { background:#1c1917; }
        ::-webkit-scrollbar-thumb { background:#44403c; border-radius:3px; }
    </style>
</head>
<body class="flex min-h-screen">

<!-- ═══════════════════════════════════════════════════
     SIDEBAR  (desktop: always visible | mobile: slide-in)
═══════════════════════════════════════════════════ -->
<aside id="sidebar"
    class="fixed md:static inset-y-0 left-0 z-50
           w-72 md:w-64
           border-r border-stone-800 bg-stone-950
           flex flex-col shrink-0
           -translate-x-full md:translate-x-0">

    <!-- Brand -->
    <div class="p-7 border-b border-stone-800 flex items-center justify-between">
        <div>
            <div class="serif text-2xl text-amber-500">Roast & Revel</div>
            <div class="text-[10px] uppercase tracking-[0.25em] text-stone-600 mt-1">Admin Console</div>
        </div>
        <!-- Close button (mobile only) -->
        <button onclick="closeSidebar()" class="md:hidden text-stone-500 hover:text-stone-200 p-1 -mr-1">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
            </svg>
        </button>
    </div>

    <!-- Nav links -->
    <nav class="flex-1 p-3 space-y-1 mt-2 overflow-y-auto">
        <?php foreach ($nav as $key => $item):
            $active = $tab === $key ? 'active' : '';
        ?>
        <a href="?tab=<?php echo $key; ?>" onclick="closeSidebar()"
            class="sidebar-link <?php echo $active; ?> flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium text-stone-400">
            <svg class="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="<?php echo $item['icon']; ?>"/>
            </svg>
            <?php echo $item['label']; ?>
        </a>
        <?php endforeach; ?>
    </nav>

    <!-- Footer -->
    <div class="p-4 border-t border-stone-800 space-y-3">
        <div class="px-4 py-3 rounded-xl glass">
            <div class="text-xs text-stone-500 uppercase tracking-widest">Logged in as</div>
            <div class="text-sm font-semibold text-stone-200 mt-0.5"><?php echo htmlspecialchars($_SESSION['user_name']); ?></div>
        </div>
        <a href="../logout.php" class="flex items-center gap-2 px-4 py-3 text-red-400 hover:text-red-300 text-sm rounded-xl hover:bg-red-950/30 transition">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
            </svg>
            Logout
        </a>
    </div>
</aside>

<!-- Sidebar backdrop (mobile) -->
<div id="sidebar-backdrop"
    onclick="closeSidebar()"
    class="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm hidden md:hidden">
</div>

<!-- ═══════════════════════════════════════════════════
     MOBILE TOP BAR  (hidden on md+)
═══════════════════════════════════════════════════ -->
<div class="mobile-topbar fixed top-0 left-0 right-0 z-30 h-14 flex items-center justify-between px-4 border-b border-stone-800 md:hidden">

    <!-- Hamburger -->
    <button id="hamburger" onclick="openSidebar()"
        class="w-9 h-9 flex flex-col justify-center items-center gap-[5px] rounded-xl hover:bg-stone-800 transition">
        <span class="ham-line"></span>
        <span class="ham-line"></span>
        <span class="ham-line"></span>
    </button>

    <!-- Brand (centred) -->
    <div class="absolute left-1/2 -translate-x-1/2 serif text-lg text-amber-500 pointer-events-none">
        Roast <span class="text-stone-400">&</span> Revel
    </div>

    <!-- Current tab label (right side) -->
    <span class="text-xs font-semibold uppercase tracking-widest text-stone-500">
        <?php echo $nav[$tab]['label'] ?? ''; ?>
    </span>
</div>

<!-- ═══════════════════════════════════════════════════
     MAIN CONTENT
═══════════════════════════════════════════════════ -->
<main class="flex-1 overflow-y-auto p-5 md:p-10 pt-20 md:pt-10">

    <?php if ($message): ?>
    <div class="mb-6 px-5 py-4 rounded-2xl text-sm flex items-center gap-3
        <?php echo $msg_type === 'error'
            ? 'bg-red-950/50 border border-red-800/50 text-red-300'
            : 'bg-emerald-950/50 border border-emerald-800/50 text-emerald-300'; ?>">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <?php endif; ?>

    <!-- ══ OVERVIEW ══════════════════════════════════════════════ -->
    <?php if ($tab === 'overview'): ?>
    <div class="mb-8">
        <h1 class="serif text-3xl md:text-4xl text-stone-100">Executive Overview</h1>
        <p class="text-stone-500 mt-1">Everything at a glance.</p>
    </div>

    <!-- Stat cards -->
    <div class="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-10">
        <?php
        $stats = [
            ['label'=>'Total Revenue', 'value'=>'$'.number_format($total_revenue,2), 'color'=>'text-amber-400'],
            ['label'=>'Total Orders',  'value'=>$total_orders,                        'color'=>'text-sky-400'],
            ['label'=>'Today',         'value'=>$today_orders,                        'color'=>'text-indigo-400'],
            ['label'=>'Pending Now',   'value'=>$pending_orders,                      'color'=>'text-yellow-400'],
            ['label'=>'Menu Items',    'value'=>$total_products,                      'color'=>'text-emerald-400'],
        ];
        foreach ($stats as $s): ?>
        <div class="stat-card p-5 rounded-2xl">
            <p class="text-stone-500 text-[10px] uppercase tracking-widest mb-2"><?php echo $s['label']; ?></p>
            <p class="text-2xl md:text-3xl font-bold <?php echo $s['color']; ?>"><?php echo $s['value']; ?></p>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Charts -->
    <h2 class="text-xl md:text-2xl text-stone-200 mb-4">Sales Overview</h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <div class="bg-stone-800 p-4 rounded-2xl">
            <h3 class="text-sm text-stone-400 mb-3">Top Products</h3>
            <canvas id="chart-products"></canvas>
        </div>
        <div class="bg-stone-800 p-4 rounded-2xl">
            <h3 class="text-sm text-stone-400 mb-3">Top Staff</h3>
            <canvas id="chart-staff"></canvas>
        </div>
        <div class="bg-stone-800 p-4 rounded-2xl">
            <h3 class="text-sm text-stone-400 mb-3">Top Delivery</h3>
            <canvas id="chart-delivery"></canvas>
        </div>
    </div>

    <!-- ══ INVENTORY ═════════════════════════════════════════════ -->
    <?php elseif ($tab === 'inventory'): ?>
    <div class="flex flex-wrap justify-between items-center mb-8 gap-4">
        <div>
            <h1 class="serif text-3xl md:text-4xl text-stone-100">Menu Management</h1>
            <p class="text-stone-500 mt-1">Add, toggle, or remove menu items.</p>
        </div>
        <div class="flex items-center gap-2">
            <form method="GET">
                <input type="hidden" name="tab" value="inventory">
                <select name="filter_cat" onchange="this.form.submit()" class="px-3 py-2 rounded-lg bg-stone-800 text-stone-200 text-sm">
                    <option value="">All categories</option>
                    <?php foreach ($cat_list as $cat): ?>
                    <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo $filter_cat===$cat?'selected':''; ?>><?php echo htmlspecialchars($cat); ?></option>
                    <?php endforeach; ?>
                </select>
            </form>
            <button onclick="document.getElementById('addModal').classList.remove('hidden')"
                class="bg-amber-700 hover:bg-amber-600 text-white px-5 py-2.5 rounded-xl font-semibold text-sm transition shrink-0">
                + New Item
            </button>
        </div>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <?php while ($item = $products->fetch_assoc()): ?>
        <div class="glass rounded-2xl p-6 flex justify-between items-start gap-4 <?php echo !$item['is_available'] ? 'opacity-50' : ''; ?>">
            <div class="flex-1 min-w-0">
                <span class="text-[10px] font-bold uppercase tracking-widest text-amber-600"><?php echo $item['category']; ?></span>
                <h3 class="text-lg font-semibold mt-1 text-stone-100 leading-snug"><?php echo htmlspecialchars($item['name']); ?></h3>
                <?php if ($item['description']): ?>
                <p class="text-stone-500 text-xs mt-1 line-clamp-2"><?php echo htmlspecialchars($item['description']); ?></p>
                <?php endif; ?>
                <p class="font-mono text-amber-400 font-bold mt-2">$<?php echo number_format($item['price'],2); ?></p>
            </div>
            <div class="flex flex-col gap-2 shrink-0">
                <a href="?tab=inventory&toggle_product=<?php echo $item['id']; ?><?php echo $filter_cat?'&filter_cat='.urlencode($filter_cat):''; ?>"
                    class="text-xs px-3 py-1.5 rounded-lg text-center transition <?php echo $item['is_available'] ? 'bg-emerald-900/30 text-emerald-400 hover:bg-emerald-900/50' : 'bg-stone-800 text-stone-400 hover:bg-stone-700'; ?>">
                    <?php echo $item['is_available'] ? 'Available' : 'Hidden'; ?>
                </a>
                <a href="?tab=inventory&delete_product=<?php echo $item['id']; ?><?php echo $filter_cat?'&filter_cat='.urlencode($filter_cat):''; ?>"
                    class="text-xs px-3 py-1.5 rounded-lg bg-red-950/30 text-red-400 hover:bg-red-950/50 text-center transition"
                    onclick="return confirm('Remove this item permanently?')">Delete</a>
            </div>
        </div>
        <?php endwhile; ?>
    </div>

    <!-- Add Product Modal -->
    <div id="addModal" class="hidden fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
        <div class="bg-stone-900 border border-stone-700 p-8 rounded-3xl w-full max-w-md shadow-2xl">
            <h2 class="serif text-2xl mb-6 text-stone-100">New Menu Item</h2>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div>
                    <label class="text-xs uppercase tracking-widest text-stone-500 mb-2 block">Name *</label>
                    <input type="text" name="name" required placeholder="e.g. Caramel Macchiato" class="w-full px-4 py-3 rounded-xl">
                </div>
                <div>
                    <label class="text-xs uppercase tracking-widest text-stone-500 mb-2 block">Description</label>
                    <textarea name="description" rows="2" placeholder="Brief description..." class="w-full px-4 py-3 rounded-xl resize-none"></textarea>
                </div>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="text-xs uppercase tracking-widest text-stone-500 mb-2 block">Price *</label>
                        <input type="number" step="0.01" min="0" name="price" required placeholder="0.00" class="w-full px-4 py-3 rounded-xl">
                    </div>
                    <div>
                        <label class="text-xs uppercase tracking-widest text-stone-500 mb-2 block">Category</label>
                        <select name="category" class="w-full px-4 py-3 rounded-xl">
                            <option>Coffee</option><option>Tea</option><option>Cold Drinks</option>
                            <option>Pastry</option><option>Merchandise</option>
                        </select>
                    </div>
                </div>
                <div class="flex gap-3 pt-2">
                    <button type="button" onclick="document.getElementById('addModal').classList.add('hidden')"
                        class="flex-1 bg-stone-800 hover:bg-stone-700 py-3 rounded-xl text-sm transition">Cancel</button>
                    <button type="submit" name="add_product"
                        class="flex-1 bg-amber-700 hover:bg-amber-600 py-3 rounded-xl font-bold text-sm transition">Save Item</button>
                </div>
            </form>
        </div>
    </div>

    <!-- ══ ORDERS ════════════════════════════════════════════════ -->
    <?php elseif ($tab === 'orders'): ?>
    <div class="mb-8">
        <h1 class="serif text-3xl md:text-4xl text-stone-100">Order History</h1>
        <p class="text-stone-500 mt-1">View and manage all orders.</p>
    </div>

    <!-- Filters -->
    <form method="GET" class="flex flex-wrap gap-3 items-end mb-4">
        <input type="hidden" name="tab" value="orders">
        <div>
            <label class="text-xs text-stone-500 block mb-1">Customer</label>
            <input type="text" name="filter_name" value="<?php echo htmlspecialchars($filter_name); ?>" placeholder="Name" class="px-3 py-2 rounded-lg bg-stone-900 text-stone-200 text-sm">
        </div>
        <div>
            <label class="text-xs text-stone-500 block mb-1">Date</label>
            <input type="date" name="filter_date" value="<?php echo htmlspecialchars($filter_date); ?>" class="px-3 py-2 rounded-lg bg-stone-900 text-stone-200 text-sm">
        </div>
        <button type="submit" class="bg-amber-700 hover:bg-amber-600 text-white px-4 py-2 rounded-lg text-sm">Apply</button>
        <?php if ($filter_name || $filter_date): ?>
        <a href="?tab=orders" class="text-sm text-stone-400 underline self-end">Clear</a>
        <?php endif; ?>
    </form>
    <p class="text-sm text-stone-400 mb-6">Today's orders: <strong class="text-amber-400"><?php echo $today_orders; ?></strong></p>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        <?php while ($batch = $batch_result->fetch_assoc()):
            $items = $conn->query("SELECT item_name, quantity, total_price FROM orders WHERE batch_id=".(int)$batch['id']);
        ?>
        <div class="glass rounded-2xl p-6">
            <div class="flex justify-between items-start mb-4">
                <div>
                    <div class="text-xs text-amber-500 font-bold uppercase tracking-wider">Batch #<?php echo $batch['id']; ?></div>
                    <div class="text-lg font-semibold text-stone-100 mt-1 leading-tight"><?php echo htmlspecialchars($batch['customer_name']); ?></div>
                    <div class="text-xs text-stone-400 mt-0.5"><?php echo htmlspecialchars(($batch['first_name']??'').' '.($batch['last_name']??'')); ?></div>
                </div>
                <div class="text-right shrink-0 ml-2">
                    <div class="text-xs text-stone-500 mb-2"><?php echo date('M j, Y · g:i A', strtotime($batch['order_date'])); ?></div>
                    <span class="px-2.5 py-1 rounded-full text-xs font-bold badge-<?php echo $batch['status']; ?>"><?php echo strtoupper($batch['status']); ?></span>
                </div>
            </div>

            <div class="grid grid-cols-3 gap-2 mb-4 text-xs">
                <div class="bg-stone-900/50 rounded-lg px-2 py-2 border border-stone-800/50">
                    <div class="text-stone-500 mb-0.5">📱 Phone</div>
                    <a href="tel:<?php echo htmlspecialchars($batch['phone']); ?>" class="text-stone-200 font-semibold hover:underline break-all"><?php echo htmlspecialchars($batch['phone']); ?></a>
                </div>
                <div class="bg-stone-900/50 rounded-lg px-2 py-2 border border-stone-800/50">
                    <div class="text-stone-500 mb-0.5">📦 Type</div>
                    <div class="text-stone-200 font-semibold capitalize"><?php echo str_replace('-',' ',htmlspecialchars($batch['order_type'])); ?></div>
                </div>
                <div class="bg-stone-900/50 rounded-lg px-2 py-2 border border-stone-800/50">
                    <div class="text-stone-500 mb-0.5">💰 Total</div>
                    <div class="text-amber-400 font-bold">$<?php echo number_format($batch['batch_total'],2); ?></div>
                </div>
            </div>

            <div class="bg-stone-900/60 rounded-lg px-4 py-3 mb-4 border border-stone-800/50">
                <div class="text-xs text-stone-500 uppercase tracking-wider mb-2 font-bold">Items</div>
                <div class="space-y-1.5 text-sm">
                    <?php while ($item = $items->fetch_assoc()): ?>
                    <div class="flex justify-between text-stone-300">
                        <span><?php echo htmlspecialchars($item['item_name']); ?> <span class="text-stone-500">× <?php echo $item['quantity']; ?></span></span>
                        <span class="text-amber-400 font-mono">$<?php echo number_format($item['total_price']*$item['quantity'],2); ?></span>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>

            <?php if ($batch['address']): ?>
            <div class="text-xs text-stone-400 mb-4">
                📍 <strong><?php echo htmlspecialchars($batch['address']); ?></strong><?php echo $batch['city'] ? ', '.htmlspecialchars($batch['city']) : ''; ?>
            </div>
            <?php endif; ?>

            <?php if ($batch['notes']): ?>
            <div class="bg-amber-950/30 border border-amber-900/40 rounded-lg px-3 py-2 text-xs text-amber-200 mb-4">
                <strong>Note:</strong> <?php echo htmlspecialchars($batch['notes']); ?>
            </div>
            <?php endif; ?>

            <form method="POST" class="flex gap-2">
                <input type="hidden" name="order_id"    value="<?php echo $batch['id']; ?>">
                <input type="hidden" name="filter_name" value="<?php echo htmlspecialchars($filter_name); ?>">
                <input type="hidden" name="filter_date" value="<?php echo htmlspecialchars($filter_date); ?>">
                <select name="new_status" class="flex-1 text-xs px-3 py-2 rounded-lg">
                    <?php foreach (['pending','preparing','delivering','completed','cancelled'] as $s): ?>
                    <option value="<?php echo $s; ?>" <?php echo $batch['status']===$s?'selected':''; ?>><?php echo ucfirst($s); ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" name="update_order_status"
                    class="text-xs bg-amber-700 hover:bg-amber-600 px-4 py-2 rounded-lg transition font-semibold">Update</button>
            </form>
        </div>
        <?php endwhile; ?>
    </div>

    <!-- ══ STAFF ══════════════════════════════════════════════════ -->
    <?php elseif ($tab === 'staff'): ?>
    <div class="mb-8">
        <h1 class="serif text-3xl md:text-4xl text-stone-100">Staff & Delivery</h1>
        <p class="text-stone-500 mt-1">View and manage your team.</p>
    </div>

    <div class="grid gap-3">
        <?php while ($s = $staff_list->fetch_assoc()): ?>
        <div class="glass rounded-2xl px-5 py-4 flex items-center gap-4 flex-wrap sm:flex-nowrap">
            <div class="w-11 h-11 rounded-full bg-amber-900/30 flex items-center justify-center text-amber-400 font-bold text-lg shrink-0">
                <?php echo strtoupper(substr($s['first_name'],0,1)); ?>
            </div>
            <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2 flex-wrap">
                    <span class="font-semibold text-stone-200"><?php echo htmlspecialchars($s['first_name'].' '.$s['last_name']); ?></span>
                    <span class="text-[10px] uppercase tracking-widest px-2 py-0.5 rounded-full <?php echo $s['role']==='staff'?'bg-blue-900/30 text-blue-400':'bg-purple-900/30 text-purple-400'; ?>">
                        <?php echo $s['role']; ?>
                    </span>
                </div>
                <p class="text-stone-500 text-sm truncate"><?php echo htmlspecialchars($s['email']); ?></p>
            </div>
            <div class="flex items-center gap-3 shrink-0 ml-auto">
                <span class="text-xs <?php echo $s['is_active']?'text-emerald-400':'text-red-400'; ?>">
                    <?php echo $s['is_active']?'● Active':'○ Inactive'; ?>
                </span>
                <a href="?tab=staff&toggle_user=<?php echo $s['id']; ?>"
                    class="text-xs px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-400 transition">
                    <?php echo $s['is_active']?'Deactivate':'Activate'; ?>
                </a>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php endif; ?>

</main>

<!-- ═══════════════════════════════════════════════════
     SCRIPTS
═══════════════════════════════════════════════════ -->
<script>
// ── Sidebar open / close ──────────────────────────────────────────────────────
function openSidebar() {
    document.getElementById('sidebar').classList.remove('-translate-x-full');
    document.getElementById('sidebar-backdrop').classList.remove('hidden');
    document.getElementById('hamburger').classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeSidebar() {
    document.getElementById('sidebar').classList.add('-translate-x-full');
    document.getElementById('sidebar-backdrop').classList.add('hidden');
    document.getElementById('hamburger').classList.remove('open');
    document.body.style.overflow = '';
}

// Close on Escape
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeSidebar();
});

// ── Charts ────────────────────────────────────────────────────────────────────
var prodData     = <?php echo json_encode($top_products); ?>;
var staffData    = <?php echo json_encode($staff_sales); ?>;
var delData      = <?php echo json_encode($delivery_sales); ?>;

var chartDefaults = {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: {
        x: { ticks: { color: '#78716c', font: { size: 10 } }, grid: { color: 'rgba(255,255,255,0.04)' } },
        y: { beginAtZero: true, ticks: { precision: 0, color: '#78716c', font: { size: 10 } }, grid: { color: 'rgba(255,255,255,0.06)' } }
    }
};

function makeBarChart(id, labels, data, color) {
    var el = document.getElementById(id);
    if (!el || !labels.length) return;
    new Chart(el.getContext('2d'), {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{ data: data, backgroundColor: color, borderRadius: 6 }]
        },
        options: chartDefaults
    });
}

document.addEventListener('DOMContentLoaded', function() {
    makeBarChart('chart-products',
        prodData.map(function(o){ return o.item_name; }),
        prodData.map(function(o){ return o.qty; }),
        'rgba(251,191,36,0.75)');

    makeBarChart('chart-staff',
        staffData.map(function(o){ return o.first_name + ' ' + o.last_name; }),
        staffData.map(function(o){ return o.cnt; }),
        'rgba(99,179,237,0.75)');

    makeBarChart('chart-delivery',
        delData.map(function(o){ return o.first_name + ' ' + o.last_name; }),
        delData.map(function(o){ return o.cnt; }),
        'rgba(167,139,250,0.75)');
});
</script>

</body>
</html>