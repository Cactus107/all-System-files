<?php
session_start();

/**
 * Roast & Revel - Authentication
 * IMPROVEMENTS:
 * - Uses prepared statements (prevents SQL injection)
 * - CSRF token protection
 * - Rate limiting via session
 * - Delivery role support added
 * - Input sanitization
 */

require_once 'config/db.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    redirectByRole($_SESSION['role']);
}

$error_message   = "";
$success_message = "";

// --- CSRF Protection ---
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// --- Role Determination ---
function determineRole(string $email): string {
    $email = strtolower(trim($email));
    if ($email === 'admin@roast.ph') return 'admin';
    if (str_ends_with($email, '@coffee.ph')) return 'staff';
    if (str_ends_with($email, '@delivery.ph')) return 'delivery';
    return 'user';
}

function redirectByRole(string $role): void {
    $map = [
        'admin'    => 'admin/admin_dashboard.php',
        'staff'    => 'staff/staff_dashboard.php',
        'delivery' => 'delivery/delivery_dashboard.php',
        'user'     => 'user/user_dashboard.php',
    ];
    header("Location: " . ($map[$role] ?? 'user/user_dashboard.php'));
    exit();
}

// --- Registration Handler ---
if (isset($_POST['register'])) {
    // CSRF check
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $error_message = "Invalid request. Please try again.";
    } else {
        $first_name = trim($_POST['first_name']);
        $last_name  = trim($_POST['last_name']);
        $email      = strtolower(trim($_POST['email']));
        $password   = $_POST['password'];

        // Validation
        if (strlen($password) < 8) {
            $error_message = "Password must be at least 8 characters.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error_message = "Please enter a valid email address.";
        } else {
            // Check for existing email using prepared statement
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $error_message = "This email is already registered. Please sign in.";
            } else {
                $hashed = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
                $role   = determineRole($email);

                $ins = $conn->prepare("INSERT INTO users (first_name, last_name, email, password, role) VALUES (?, ?, ?, ?, ?)");
                $ins->bind_param("sssss", $first_name, $last_name, $email, $hashed, $role);

                if ($ins->execute()) {
                    $role_label      = ucfirst($role);
                    $success_message = "Account created as {$role_label}! You can now sign in.";
                } else {
                    $error_message = "Registration failed. Please try again.";
                }
            }
            $stmt->close();
        }
    }
}

// --- Login Handler ---
if (isset($_POST['login'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $error_message = "Invalid request. Please try again.";
    } else {
        $email    = strtolower(trim($_POST['email']));
        $password = $_POST['password'];

        $stmt = $conn->prepare("SELECT id, first_name, password, role, is_active FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if (!$user['is_active']) {
                $error_message = "This account has been deactivated. Please contact support.";
            } elseif (password_verify($password, $user['password'])) {
                // Regenerate session to prevent fixation
                session_regenerate_id(true);

                $_SESSION['user_id']   = $user['id'];
                $_SESSION['user_name'] = $user['first_name'];
                $_SESSION['role']      = $user['role'];

                redirectByRole($user['role']);
            } else {
                $error_message = "Incorrect password. Please try again.";
            }
        } else {
            // Constant-time response to prevent user enumeration
            password_verify('dummy', '$2y$12$dummyhashfortimingattack');
            $error_message = "No account found with that email address.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join the Club | Roast & Revel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,400&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'DM Sans', sans-serif; }
        .serif { font-family: 'Playfair Display', serif; }
        .bg-panel {
            background: linear-gradient(160deg, #1a0f0a 0%, #2c1810 50%, #1a0f0a 100%);
        }
        .glass {
            background: rgba(255,255,255,0.03);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255,255,255,0.08);
        }
        input:focus { outline: none; border-color: #b45309; box-shadow: 0 0 0 3px rgba(180,83,9,0.15); }
        .tab-active { color: #fbbf24; border-bottom: 2px solid #fbbf24; }
        .tab-inactive { color: #78716c; border-bottom: 2px solid transparent; }
        .btn-primary { background: linear-gradient(135deg, #92400e, #b45309); }
        .btn-primary:hover { background: linear-gradient(135deg, #b45309, #d97706); }
        .grain::after {
            content: '';
            position: fixed; inset: 0;
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.04'/%3E%3C/svg%3E");
            pointer-events: none; z-index: 0; opacity: 0.3;
        }
        @keyframes fadeUp { from { opacity:0; transform:translateY(16px); } to { opacity:1; transform:translateY(0); } }
        .fade-up { animation: fadeUp 0.5s ease forwards; }
    </style>
</head>
<body class="min-h-screen bg-panel grain flex flex-col">

    <nav class="px-8 py-6">
        <a href="index.php" class="text-xl font-bold tracking-widest text-stone-100 serif">
            ROAST<span class="text-amber-500">&</span>REVEL
        </a>
    </nav>

    <main class="flex-grow flex items-center justify-center px-6 pb-16">
        <div class="w-full max-w-md fade-up relative z-10">

            <!-- Alerts -->
            <?php if ($error_message): ?>
                <div class="mb-6 flex items-start gap-3 bg-red-950/60 border border-red-900/50 text-red-300 px-5 py-4 rounded-2xl text-sm">
                    <svg class="w-5 h-5 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                    <span><?php echo htmlspecialchars($error_message); ?></span>
                </div>
            <?php endif; ?>
            <?php if ($success_message): ?>
                <div class="mb-6 flex items-start gap-3 bg-emerald-950/60 border border-emerald-800/50 text-emerald-300 px-5 py-4 rounded-2xl text-sm">
                    <svg class="w-5 h-5 mt-0.5 shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                    <span><?php echo htmlspecialchars($success_message); ?></span>
                </div>
            <?php endif; ?>

            <div class="glass rounded-3xl p-8 md:p-10">

                <!-- Tabs -->
                <div class="flex gap-6 mb-8 border-b border-white/10">
                    <button id="tab-login" onclick="showTab('login')" class="pb-4 text-sm font-semibold uppercase tracking-widest transition tab-active">Sign In</button>
                    <button id="tab-register" onclick="showTab('register')" class="pb-4 text-sm font-semibold uppercase tracking-widest transition tab-inactive">Create Account</button>
                </div>

                <!-- Login Form -->
                <div id="form-login">
                    <h2 class="serif text-3xl text-stone-100 mb-1">Welcome back.</h2>
                    <p class="text-stone-500 text-sm mb-8">Sign in to manage your orders.</p>

                    <form action="auth.php" method="POST" class="space-y-5">
                        <input type="hidden" name="login" value="1">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                        <div>
                            <label class="block text-xs font-semibold uppercase tracking-widest text-stone-500 mb-2">Email Address</label>
                            <input type="email" name="email" required placeholder="you@example.com"
                                class="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-stone-100 placeholder-stone-600 transition">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold uppercase tracking-widest text-stone-500 mb-2">Password</label>
                            <div class="relative">
                                <input id="login-pw" type="password" name="password" required placeholder="••••••••"
                                    class="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-stone-100 placeholder-stone-600 transition pr-12">
                                <button type="button" onclick="togglePw('login-pw')" class="absolute right-4 top-1/2 -translate-y-1/2 text-stone-500 hover:text-stone-300">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                </button>
                            </div>
                        </div>
                        <button type="submit" class="w-full btn-primary text-white py-4 rounded-xl font-semibold transition shadow-lg shadow-amber-900/20 mt-2">
                            Sign In →
                        </button>
                    </form>
                </div>

                <!-- Register Form -->
                <div id="form-register" class="hidden">
                    <h2 class="serif text-3xl text-stone-100 mb-1">Join the club.</h2>
                    <p class="text-stone-500 text-sm mb-8">
                        Staff: use <span class="text-amber-500">@coffee.ph</span> &nbsp;|&nbsp; Delivery: <span class="text-amber-500">@delivery.ph</span>
                    </p>

                    <form action="auth.php" method="POST" class="space-y-4">
                        <input type="hidden" name="register" value="1">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <label class="block text-xs font-semibold uppercase tracking-widest text-stone-500 mb-2">First Name</label>
                                <input type="text" name="first_name" required class="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-stone-100 transition">
                            </div>
                            <div>
                                <label class="block text-xs font-semibold uppercase tracking-widest text-stone-500 mb-2">Last Name</label>
                                <input type="text" name="last_name" required class="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-stone-100 transition">
                            </div>
                        </div>
                        <div>
                            <label class="block text-xs font-semibold uppercase tracking-widest text-stone-500 mb-2">Email Address</label>
                            <input type="email" name="email" required placeholder="you@example.com"
                                class="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-stone-100 placeholder-stone-600 transition">
                        </div>
                        <div>
                            <label class="block text-xs font-semibold uppercase tracking-widest text-stone-500 mb-2">Password <span class="normal-case font-normal">(min. 8 chars)</span></label>
                            <div class="relative">
                                <input id="reg-pw" type="password" name="password" required minlength="8"
                                    class="w-full px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-stone-100 transition pr-12">
                                <button type="button" onclick="togglePw('reg-pw')" class="absolute right-4 top-1/2 -translate-y-1/2 text-stone-500 hover:text-stone-300">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.458 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                </button>
                            </div>
                        </div>
                        <button type="submit" class="w-full bg-amber-700 hover:bg-amber-600 text-white py-4 rounded-xl font-semibold transition shadow-lg shadow-amber-900/20 mt-2">
                            Create Account →
                        </button>
                    </form>
                </div>

            </div>
        </div>
    </main>

    <script>
        function showTab(tab) {
            const isLogin = tab === 'login';
            document.getElementById('form-login').classList.toggle('hidden', !isLogin);
            document.getElementById('form-register').classList.toggle('hidden', isLogin);
            document.getElementById('tab-login').className    = `pb-4 text-sm font-semibold uppercase tracking-widest transition ${isLogin ? 'tab-active' : 'tab-inactive'}`;
            document.getElementById('tab-register').className = `pb-4 text-sm font-semibold uppercase tracking-widest transition ${!isLogin ? 'tab-active' : 'tab-inactive'}`;
        }
        function togglePw(id) {
            const el = document.getElementById(id);
            el.type = el.type === 'password' ? 'text' : 'password';
        }
        <?php if (isset($_POST['register'])): ?>
            window.onload = () => showTab('register');
        <?php endif; ?>
    </script>
</body>
</html>