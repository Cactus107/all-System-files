<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roast & Revel | Artisanal Coffee House</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --coffee-dark: #2C1810;
            --coffee-medium: #6F4E37;
            --coffee-light: #C2B280;
            --cream: #F5F5DC;
        }
        body {
            font-family: 'Inter', sans-serif;
            background-color: #faf9f6;
            color: var(--coffee-dark);
            scroll-behavior: smooth;
        }
        h1, h2, h3 {
            font-family: 'Playfair Display', serif;
        }
        .hero-gradient {
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), 
                        url('https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80&w=2070');
            background-size: cover;
            background-position: center;
        }
        .nav-blur {
            backdrop-filter: blur(8px);
            background-color: rgba(250, 249, 246, 0.8);
        }
        .menu-card:hover {
            transform: translateY(-5px);
            transition: all 0.3s ease;
        }
    </style>
</head>
<body class="antialiased">

    <!-- Navigation -->
    <nav class="fixed w-full z-50 nav-blur border-b border-stone-200">
        <div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
            <a href="index.php" class="text-2xl font-bold tracking-tight text-stone-800">ROAST<span class="text-amber-700">&</span>REVEL</a>
            
            <div class="hidden md:flex space-x-8 text-sm font-medium uppercase tracking-widest">
                <a href="#about" class="hover:text-amber-700 transition">About</a>
                <a href="#menu" class="hover:text-amber-700 transition">Menu</a>
                <a href="#contact" class="hover:text-amber-700 transition">Contact</a>
            </div>

            <div class="flex items-center gap-4">
                <a href="auth.php" class="bg-amber-800 text-white px-6 py-2 rounded-full text-sm font-semibold hover:bg-amber-900 transition text-center">Sign In</a>
            </div>
        </div>
    </nav>a

    <main>
        <!-- Hero Section -->
        <header class="h-screen flex items-center justify-center hero-gradient text-white text-center px-6">
            <div class="max-w-3xl">
                <span class="uppercase tracking-widest text-sm mb-4 block text-amber-200">Established 2024</span>
                <h1 class="text-5xl md:text-7xl mb-6">Awaken Your Senses, One Sip at a Time</h1>
                <p class="text-lg md:text-xl mb-10 opacity-90 font-light">Small-batch roasts and artisanal pastries served in the heart of the city.</p>
                <div class="flex flex-col md:flex-row gap-4 justify-center">
                    <a href="#menu" class="bg-amber-700 hover:bg-amber-800 text-white px-10 py-4 rounded-sm transition text-lg">View Our Menu</a>
                    <a href="#about" class="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/30 px-10 py-4 rounded-sm transition text-lg">Our Story</a>
                </div>
            </div>
        </header>

        <!-- Features -->
        <section id="about" class="py-24 px-6 max-w-7xl mx-auto">
            <div class="grid md:grid-cols-2 gap-16 items-center">
                <div class="relative">
                    <img src="https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&q=80&w=2070" alt="Coffee Brewing" class="rounded-lg shadow-2xl">
                    <div class="absolute -bottom-8 -right-8 bg-amber-100 p-8 hidden lg:block rounded-lg border border-amber-200">
                        <p class="text-amber-900 font-bold text-4xl">100%</p>
                        <p class="text-stone-600 text-sm">Organic Beans</p>
                    </div>
                </div>
                <div>
                    <h2 class="text-4xl mb-6 leading-tight">Crafted with Passion,<br>Sourced with Integrity</h2>
                    <p class="text-stone-600 mb-6 leading-relaxed">
                        At Roast & Revel, we believe the perfect cup of coffee is an art form. We partner directly with sustainable farmers across the globe to bring you unique flavor profiles that reflect their origin.
                    </p>
                    <ul class="space-y-4 mb-8">
                        <li class="flex items-center gap-3">
                            <svg class="w-5 h-5 text-amber-700" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"/></svg>
                            <span>Ethically sourced micro-lots</span>
                        </li>
                        <li class="flex items-center gap-3">
                            <svg class="w-5 h-5 text-amber-700" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"/></svg>
                            <span>Daily in-house roasting</span>
                        </li>
                    </ul>
                </div>
            </div>
        </section>

        <!-- Menu Section -->
        <section id="menu" class="bg-stone-100 py-24 px-6">
            <div class="max-w-7xl mx-auto text-center mb-16">
                <h2 class="text-4xl mb-4">Our Signature Selection</h2>
                <div class="w-24 h-1 bg-amber-700 mx-auto"></div>
            </div>
            <div class="max-w-7xl mx-auto grid md:grid-cols-3 gap-8">
                <div class="bg-white p-8 rounded-lg shadow-sm menu-card border border-stone-200">
                    <div class="flex justify-between items-start mb-4">
                        <h3 class="text-xl">Midnight Velvet</h3>
                        <span class="text-amber-800 font-semibold">$5.50</span>
                    </div>
                    <p class="text-stone-500 text-sm">Our darkest roast with notes of smoked chocolate and black cherry.</p>
                </div>
                <div class="bg-white p-8 rounded-lg shadow-sm menu-card border border-stone-200">
                    <div class="flex justify-between items-start mb-4">
                        <h3 class="text-xl">Honey Lavender Latte</h3>
                        <span class="text-amber-800 font-semibold">$6.25</span>
                    </div>
                    <p class="text-stone-500 text-sm">Locally sourced wildflower honey infused with dried lavender.</p>
                </div>
                <div class="bg-white p-8 rounded-lg shadow-sm menu-card border border-stone-200">
                    <div class="flex justify-between items-start mb-4">
                        <h3 class="text-xl">Cold Brew Nitro</h3>
                        <span class="text-amber-800 font-semibold">$5.75</span>
                    </div>
                    <p class="text-stone-500 text-sm">Steeped for 18 hours and served on tap for a creamy finish.</p>
                </div>
            </div>
        </section>

        <!-- Contact Section -->
        <section id="contact" class="py-24 px-6 max-w-7xl mx-auto">
            <div class="grid md:grid-cols-2 gap-16">
                <div>
                    <h2 class="text-4xl mb-8">Visit the Roastery</h2>
                    <div class="space-y-6 text-stone-600">
                        <div>
                            <p class="font-bold text-stone-800 uppercase text-xs tracking-widest mb-1">Address</p>
                            <p>123 Artisan Alley, Coffee District<br>Portland, OR 97201</p>
                        </div>
                        <div>
                            <p class="font-bold text-stone-800 uppercase text-xs tracking-widest mb-1">Hours</p>
                            <p>Mon - Fri: 7:00 AM - 6:00 PM<br>Sat - Sun: 8:00 AM - 8:00 PM</p>
                        </div>
                    </div>
                </div>
                <div class="bg-stone-50 p-8 rounded-lg border border-stone-200">
                    <h3 class="text-2xl mb-6">Send us a message</h3>
                    <form class="space-y-4">
                        <input type="text" placeholder="Full Name" required class="w-full p-3 border border-stone-300 rounded-sm focus:outline-none focus:border-amber-700">
                        <input type="email" placeholder="Email Address" required class="w-full p-3 border border-stone-300 rounded-sm focus:outline-none focus:border-amber-700">
                        <textarea placeholder="How can we help?" rows="4" required class="w-full p-3 border border-stone-300 rounded-sm focus:outline-none focus:border-amber-700"></textarea>
                        <button type="submit" class="w-full bg-stone-800 text-white py-4 font-semibold hover:bg-stone-900 transition">Send Message</button>
                    </form>
                </div>
            </div>
        </section>
    </main>

    <footer class="bg-stone-900 text-stone-400 py-12 px-6">
        <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8 border-b border-stone-800 pb-8 mb-8">
            <div class="text-2xl font-bold tracking-tight text-white">ROAST<span class="text-amber-700">&</span>REVEL</div>
            <div class="flex space-x-6 text-sm uppercase tracking-widest">
                <a href="#" class="hover:text-white transition">Instagram</a>
                <a href="#" class="hover:text-white transition">Facebook</a>
            </div>
        </div>
        <div class="max-w-7xl mx-auto text-xs uppercase tracking-widest">
            &copy; 2024 Roast & Revel Coffee Co. All rights reserved.
        </div>
    </footer>

    <script>
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
    </script>
</body>
</html>